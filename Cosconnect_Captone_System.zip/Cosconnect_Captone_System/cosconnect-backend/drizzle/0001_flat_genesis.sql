CREATE TYPE "public"."rejection_reason" AS ENUM('unavailable', 'damaged', 'size_mismatch', 'date_conflict', 'payment_issue', 'renter_issue', 'other');--> statement-breakpoint
CREATE TABLE "rental_rejections" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"original_rental_id" uuid NOT NULL,
	"reference_code" varchar(50) NOT NULL,
	"costume_id" uuid NOT NULL,
	"renter_uid" uuid NOT NULL,
	"costume_snapshot" jsonb NOT NULL,
	"renter_snapshot" jsonb NOT NULL,
	"requested_start_date" timestamp NOT NULL,
	"requested_end_date" timestamp NOT NULL,
	"requested_rental_amount" varchar(32) NOT NULL,
	"requested_security_deposit" varchar(32) NOT NULL,
	"requested_total_amount" varchar(32) NOT NULL,
	"rejected_at" timestamp DEFAULT now() NOT NULL,
	"rejected_by" uuid NOT NULL,
	"rejection_reason" "rejection_reason" NOT NULL,
	"rejection_message" text,
	"original_pickup_location" text,
	"original_delivery_method" varchar(50),
	"original_special_instructions" text,
	"original_payment_gcash_number" varchar(20),
	"original_refund_gcash_number" varchar(20),
	"original_refund_account_name" varchar(100),
	"original_notes" text,
	"payment_amount" varchar(32),
	"payment_status" varchar(32),
	"payment_processed_at" timestamp,
	"original_created_at" timestamp NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "rentals" ADD COLUMN "accepted_at" timestamp;--> statement-breakpoint
ALTER TABLE "rentals" ADD COLUMN "accepted_by" uuid;--> statement-breakpoint
ALTER TABLE "rentals" ADD COLUMN "payment_gcash_number" varchar(20);--> statement-breakpoint
ALTER TABLE "rentals" ADD COLUMN "refund_gcash_number" varchar(20);--> statement-breakpoint
ALTER TABLE "rentals" ADD COLUMN "refund_account_name" varchar(100);--> statement-breakpoint
ALTER TABLE "rental_rejections" ADD CONSTRAINT "rental_rejections_costume_id_costumes_id_fk" FOREIGN KEY ("costume_id") REFERENCES "public"."costumes"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "rental_rejections_original_id_idx" ON "rental_rejections" USING btree ("original_rental_id");--> statement-breakpoint
CREATE INDEX "rental_rejections_reference_code_idx" ON "rental_rejections" USING btree ("reference_code");--> statement-breakpoint
CREATE INDEX "rental_rejections_costume_id_idx" ON "rental_rejections" USING btree ("costume_id");--> statement-breakpoint
CREATE INDEX "rental_rejections_renter_uid_idx" ON "rental_rejections" USING btree ("renter_uid");--> statement-breakpoint
CREATE INDEX "rental_rejections_rejected_by_idx" ON "rental_rejections" USING btree ("rejected_by");--> statement-breakpoint
CREATE INDEX "rental_rejections_rejected_at_idx" ON "rental_rejections" USING btree ("rejected_at");--> statement-breakpoint
CREATE INDEX "rental_rejections_reason_idx" ON "rental_rejections" USING btree ("rejection_reason");--> statement-breakpoint
CREATE INDEX "rental_rejections_orig_payment_gcash_idx" ON "rental_rejections" USING btree ("original_payment_gcash_number");--> statement-breakpoint
CREATE INDEX "rental_rejections_orig_refund_gcash_idx" ON "rental_rejections" USING btree ("original_refund_gcash_number");--> statement-breakpoint
CREATE INDEX "rentals_accepted_by_idx" ON "rentals" USING btree ("accepted_by");--> statement-breakpoint
CREATE INDEX "rentals_payment_gcash_number_idx" ON "rentals" USING btree ("payment_gcash_number");--> statement-breakpoint
CREATE INDEX "rentals_refund_gcash_number_idx" ON "rentals" USING btree ("refund_gcash_number");