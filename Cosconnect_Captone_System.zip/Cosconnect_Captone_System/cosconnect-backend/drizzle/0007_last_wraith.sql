ALTER TABLE "rentals" ADD COLUMN "completed_at" timestamp;--> statement-breakpoint
CREATE INDEX "rentals_completed_at_idx" ON "rentals" USING btree ("completed_at");