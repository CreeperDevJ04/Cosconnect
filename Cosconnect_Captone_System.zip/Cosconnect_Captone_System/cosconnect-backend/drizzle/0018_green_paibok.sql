ALTER TABLE "community_post_report_reviews" DISABLE ROW LEVEL SECURITY;--> statement-breakpoint
DROP TABLE "community_post_report_reviews" CASCADE;--> statement-breakpoint
ALTER TABLE "community_post_reports" ADD COLUMN "status" varchar(50) DEFAULT 'pending' NOT NULL;--> statement-breakpoint
ALTER TABLE "community_post_reports" ADD COLUMN "reviewed_by" uuid;--> statement-breakpoint
ALTER TABLE "community_post_reports" ADD COLUMN "reviewed_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "community_post_reports" ADD COLUMN "review_notes" text;--> statement-breakpoint
ALTER TABLE "community_post_reports" ADD COLUMN "updated_at" timestamp with time zone DEFAULT now() NOT NULL;--> statement-breakpoint
ALTER TABLE "community_posts" ADD COLUMN "report_count" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "community_posts" ADD COLUMN "is_reported" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "users" ADD COLUMN "birth_date" date;--> statement-breakpoint
ALTER TABLE "community_post_reports" ADD CONSTRAINT "community_post_reports_reviewed_by_users_uid_fk" FOREIGN KEY ("reviewed_by") REFERENCES "public"."users"("uid") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "community_post_reports_status_idx" ON "community_post_reports" USING btree ("status");--> statement-breakpoint
CREATE INDEX "community_post_reports_reviewed_by_idx" ON "community_post_reports" USING btree ("reviewed_by");--> statement-breakpoint
CREATE INDEX "community_posts_report_count_idx" ON "community_posts" USING btree ("report_count");--> statement-breakpoint
ALTER TABLE "community_post_reports" ADD CONSTRAINT "community_post_reports_unique_user_post" UNIQUE("post_id","reporter_id");