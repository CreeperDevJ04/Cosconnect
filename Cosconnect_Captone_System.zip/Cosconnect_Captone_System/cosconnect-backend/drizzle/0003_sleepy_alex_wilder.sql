ALTER TABLE "rentals" ALTER COLUMN "status" SET DATA TYPE text;--> statement-breakpoint
ALTER TABLE "rentals" ALTER COLUMN "status" SET DEFAULT 'pending'::text;--> statement-breakpoint
DROP TYPE "public"."rental_status";--> statement-breakpoint
CREATE TYPE "public"."rental_status" AS ENUM('pending', 'confirmed', 'accepted', 'delivered', 'returned', 'completed', 'cancelled', 'rejected', 'overdue');--> statement-breakpoint
ALTER TABLE "rentals" ALTER COLUMN "status" SET DEFAULT 'pending'::"public"."rental_status";--> statement-breakpoint
ALTER TABLE "rentals" ALTER COLUMN "status" SET DATA TYPE "public"."rental_status" USING "status"::"public"."rental_status";