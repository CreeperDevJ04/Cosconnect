ALTER TYPE "public"."payment_method" ADD VALUE 'paymaya';--> statement-breakpoint
ALTER TYPE "public"."payment_method" ADD VALUE 'card';