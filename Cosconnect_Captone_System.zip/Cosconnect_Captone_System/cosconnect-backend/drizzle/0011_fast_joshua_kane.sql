DROP INDEX "conversation_idx";--> statement-breakpoint
ALTER TABLE "conversations" DROP COLUMN "conversation_id";