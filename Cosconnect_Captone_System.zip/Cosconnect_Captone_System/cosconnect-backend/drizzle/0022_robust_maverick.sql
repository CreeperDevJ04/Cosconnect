ALTER TABLE "otp_codes" DROP CONSTRAINT "otp_codes_user_uid_users_uid_fk";
--> statement-breakpoint
ALTER TABLE "otp_codes" ALTER COLUMN "user_uid" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "otp_codes" ALTER COLUMN "otp_code" SET DATA TYPE varchar;--> statement-breakpoint
ALTER TABLE "otp_codes" ALTER COLUMN "otp_code" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "otp_codes" ALTER COLUMN "expires_at" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "otp_codes" ALTER COLUMN "is_used" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "otp_codes" ALTER COLUMN "created_at" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "otp_codes" ALTER COLUMN "updated_at" DROP NOT NULL;