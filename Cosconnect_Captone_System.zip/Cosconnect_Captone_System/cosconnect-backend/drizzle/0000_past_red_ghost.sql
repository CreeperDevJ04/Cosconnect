CREATE TYPE "public"."costume_status" AS ENUM('active', 'inactive', 'rented', 'maintenance');--> statement-breakpoint
CREATE TYPE "public"."gender" AS ENUM('male', 'female', 'unisex');--> statement-breakpoint
CREATE TYPE "public"."listing_type" AS ENUM('rent', 'sale', 'both');--> statement-breakpoint
CREATE TYPE "public"."payment_gateway_status" AS ENUM('awaiting_payment_method', 'awaiting_next_action', 'processing', 'succeeded', 'requires_payment_method', 'cancelled', 'pending');--> statement-breakpoint
CREATE TYPE "public"."payment_method" AS ENUM('gcash');--> statement-breakpoint
CREATE TYPE "public"."payment_status" AS ENUM('pending', 'processing', 'paid', 'failed', 'cancelled', 'refunded', 'partial_refund', 'expired');--> statement-breakpoint
CREATE TYPE "public"."payment_type" AS ENUM('rental_fee', 'security_deposit', 'extension_fee', 'damage_fee', 'refund');--> statement-breakpoint
CREATE TYPE "public"."rental_status" AS ENUM('pending', 'confirmed', 'active', 'completed', 'cancelled', 'overdue', 'returned');--> statement-breakpoint
CREATE TYPE "public"."business_type" AS ENUM('INDIVIDUAL', 'STORE');--> statement-breakpoint
CREATE TYPE "public"."document_type" AS ENUM('VALID_ID', 'SELFIE_WITH_ID', 'SECONDARY_ID_1', 'SECONDARY_ID_2', 'BUSINESS_PERMIT', 'DTI_CERTIFICATE', 'STOREFRONT_PHOTO');--> statement-breakpoint
CREATE TYPE "public"."id_type" AS ENUM('NATIONAL_ID', 'DRIVERS_LICENSE', 'PASSPORT', 'SSS_ID', 'PHILHEALTH_ID', 'VOTERS_ID', 'TIN_ID', 'POSTAL_ID', 'UMID', 'PRC_ID');--> statement-breakpoint
CREATE TYPE "public"."user_status" AS ENUM('active', 'inactive', 'suspended', 'pending_verification', 'verified', 'rejected');--> statement-breakpoint
CREATE TABLE "admin" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"email" text NOT NULL,
	"phone_number" text,
	"username" text NOT NULL,
	"profile_image" text,
	"full_name" text NOT NULL,
	"role" text DEFAULT 'admin' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now(),
	"updated_at" timestamp with time zone DEFAULT now(),
	CONSTRAINT "admin_email_unique" UNIQUE("email"),
	CONSTRAINT "admin_username_unique" UNIQUE("username")
);
--> statement-breakpoint
CREATE TABLE "costume_add_ons" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"costume_id" uuid NOT NULL,
	"name" varchar(100) NOT NULL,
	"description" text NOT NULL,
	"price" varchar(32) NOT NULL,
	"image_url" text,
	"category" varchar(50),
	"is_included" boolean DEFAULT false NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "costumes" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" varchar(255) NOT NULL,
	"brand" varchar(100) NOT NULL,
	"category" varchar(100) NOT NULL,
	"description" text NOT NULL,
	"gender" "gender" NOT NULL,
	"sizes" varchar(255) NOT NULL,
	"tags" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"listing_type" "listing_type" NOT NULL,
	"rental_price" varchar(32) DEFAULT '0' NOT NULL,
	"sale_price" varchar(32) DEFAULT '0' NOT NULL,
	"security_deposit" varchar(32) DEFAULT '0' NOT NULL,
	"discount_percentage" integer DEFAULT 0 NOT NULL,
	"extended_days_price" varchar(32) DEFAULT '0' NOT NULL,
	"main_images" jsonb NOT NULL,
	"additional_images" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"lender_uid" uuid NOT NULL,
	"status" "costume_status" DEFAULT 'active' NOT NULL,
	"is_available" boolean DEFAULT true NOT NULL,
	"view_count" integer DEFAULT 0 NOT NULL,
	"favorite_count" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "rental_payment_history" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"rental_id" uuid NOT NULL,
	"reference_code" varchar(50) NOT NULL,
	"paymongo_payment_intent_id" varchar(100),
	"paymongo_source_id" varchar(100),
	"session_id" varchar(100),
	"checkout_url" text,
	"gateway_status" "payment_gateway_status",
	"gateway_status_updated_at" timestamp,
	"payment_type" "payment_type" NOT NULL,
	"description" text,
	"payment_method" "payment_method" NOT NULL,
	"payment_reference" varchar(100),
	"amount" varchar(32) NOT NULL,
	"currency" varchar(3) DEFAULT 'PHP' NOT NULL,
	"status" "payment_status" DEFAULT 'pending' NOT NULL,
	"processed_at" timestamp,
	"processor_notes" text,
	"receipt_url" text,
	"receipt_number" varchar(100),
	"webhook_events" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"session_expires_at" timestamp,
	"metadata" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "rental_payment_history_reference_code_unique" UNIQUE("reference_code")
);
--> statement-breakpoint
CREATE TABLE "rentals" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"reference_code" varchar(50) NOT NULL,
	"costume_id" uuid NOT NULL,
	"renter_uid" uuid NOT NULL,
	"costume_snapshot" jsonb NOT NULL,
	"renter_snapshot" jsonb NOT NULL,
	"start_date" timestamp NOT NULL,
	"end_date" timestamp NOT NULL,
	"actual_return_date" timestamp,
	"rental_amount" varchar(32) NOT NULL,
	"security_deposit" varchar(32) NOT NULL,
	"total_amount" varchar(32) NOT NULL,
	"extended_days" integer DEFAULT 0 NOT NULL,
	"extension_fee" varchar(32) DEFAULT '0' NOT NULL,
	"status" "rental_status" DEFAULT 'pending' NOT NULL,
	"initial_condition_notes" text,
	"return_condition_notes" text,
	"damage_reported" boolean DEFAULT false NOT NULL,
	"damage_cost" varchar(32) DEFAULT '0' NOT NULL,
	"pickup_location" text,
	"delivery_method" varchar(50),
	"special_instructions" text,
	"notes" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "rentals_reference_code_unique" UNIQUE("reference_code")
);
--> statement-breakpoint
CREATE TABLE "business_addresses" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"business_info_id" uuid NOT NULL,
	"business_address" text,
	"street" varchar(255),
	"barangay" varchar(255),
	"zip_code" varchar(20),
	"province" varchar(100),
	"region" varchar(100),
	"country" varchar(100) DEFAULT 'Philippines',
	"city" jsonb,
	"is_primary" boolean DEFAULT true,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "user_addresses" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_uid" uuid NOT NULL,
	"address" text,
	"street" varchar(255),
	"barangay" varchar(255),
	"zip_code" varchar(20),
	"country" varchar(100) DEFAULT 'Philippines',
	"region" varchar(100),
	"province" varchar(100),
	"city" jsonb,
	"address_type" varchar(50) DEFAULT 'personal',
	"is_primary" boolean DEFAULT true,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "user_business_info" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_uid" uuid NOT NULL,
	"business_name" varchar(255),
	"business_description" text,
	"business_type" "business_type",
	"business_email" varchar(255),
	"business_phone_number" varchar(20),
	"business_telephone" varchar(20),
	"business_profile_image" text,
	"business_background_image" text,
	"upload_business_permit" text,
	"business_permit_file" text,
	"upload_dti_certificate" text,
	"upload_storefront_photo" text,
	"terms_and_conditions" text,
	"is_verified" boolean DEFAULT false,
	"verified_at" timestamp with time zone,
	"verified_by" uuid,
	"rejection_reason" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "user_business_info_user_uid_unique" UNIQUE("user_uid")
);
--> statement-breakpoint
CREATE TABLE "user_documents" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_uid" uuid NOT NULL,
	"document_type" "document_type" NOT NULL,
	"id_type" "id_type",
	"id_number" varchar(100),
	"file_url" text NOT NULL,
	"file_name" varchar(255),
	"has_valid_id" boolean DEFAULT false NOT NULL,
	"is_verified" boolean DEFAULT false,
	"verified_at" timestamp with time zone,
	"verified_by" uuid,
	"rejection_reason" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "users" (
	"uid" uuid PRIMARY KEY NOT NULL,
	"id" uuid DEFAULT gen_random_uuid() NOT NULL,
	"username" varchar(100) NOT NULL,
	"email" varchar(255) NOT NULL,
	"phone_number" varchar(20) NOT NULL,
	"full_name" varchar(255),
	"first_name" varchar(100),
	"middle_name" varchar(100),
	"last_name" varchar(100),
	"bio" text,
	"profile_image" text,
	"profile_background" text,
	"role" text[] DEFAULT '{"borrower"}' NOT NULL,
	"current_role" text DEFAULT 'borrower',
	"status" "user_status" DEFAULT 'active' NOT NULL,
	"is_online" boolean DEFAULT false,
	"rejected_message" text,
	"suspended_message" text,
	"email_verified" boolean DEFAULT false,
	"phone_verified" boolean DEFAULT false,
	"last_seen" timestamp with time zone,
	"last_account_status_email_sent" integer,
	"reset_token" varchar(255),
	"reset_token_expiry" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "users_id_unique" UNIQUE("id"),
	CONSTRAINT "users_username_unique" UNIQUE("username"),
	CONSTRAINT "users_email_unique" UNIQUE("email")
);
--> statement-breakpoint
ALTER TABLE "costume_add_ons" ADD CONSTRAINT "costume_add_ons_costume_id_costumes_id_fk" FOREIGN KEY ("costume_id") REFERENCES "public"."costumes"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "rental_payment_history" ADD CONSTRAINT "rental_payment_history_rental_id_rentals_id_fk" FOREIGN KEY ("rental_id") REFERENCES "public"."rentals"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "rentals" ADD CONSTRAINT "rentals_costume_id_costumes_id_fk" FOREIGN KEY ("costume_id") REFERENCES "public"."costumes"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "business_addresses" ADD CONSTRAINT "business_addresses_business_info_id_user_business_info_id_fk" FOREIGN KEY ("business_info_id") REFERENCES "public"."user_business_info"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "user_addresses" ADD CONSTRAINT "user_addresses_user_uid_users_uid_fk" FOREIGN KEY ("user_uid") REFERENCES "public"."users"("uid") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "user_business_info" ADD CONSTRAINT "user_business_info_user_uid_users_uid_fk" FOREIGN KEY ("user_uid") REFERENCES "public"."users"("uid") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "user_documents" ADD CONSTRAINT "user_documents_user_uid_users_uid_fk" FOREIGN KEY ("user_uid") REFERENCES "public"."users"("uid") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "costume_add_ons_costume_id_idx" ON "costume_add_ons" USING btree ("costume_id");--> statement-breakpoint
CREATE INDEX "costume_add_ons_name_idx" ON "costume_add_ons" USING btree ("name");--> statement-breakpoint
CREATE INDEX "costume_add_ons_category_idx" ON "costume_add_ons" USING btree ("category");--> statement-breakpoint
CREATE INDEX "costume_add_ons_active_idx" ON "costume_add_ons" USING btree ("is_active");--> statement-breakpoint
CREATE INDEX "costumes_name_idx" ON "costumes" USING btree ("name");--> statement-breakpoint
CREATE INDEX "costumes_category_idx" ON "costumes" USING btree ("category");--> statement-breakpoint
CREATE INDEX "costumes_brand_idx" ON "costumes" USING btree ("brand");--> statement-breakpoint
CREATE INDEX "costumes_gender_idx" ON "costumes" USING btree ("gender");--> statement-breakpoint
CREATE INDEX "costumes_lender_uid_idx" ON "costumes" USING btree ("lender_uid");--> statement-breakpoint
CREATE INDEX "costumes_status_idx" ON "costumes" USING btree ("status");--> statement-breakpoint
CREATE INDEX "costumes_availability_idx" ON "costumes" USING btree ("is_available");--> statement-breakpoint
CREATE INDEX "costumes_listing_type_idx" ON "costumes" USING btree ("listing_type");--> statement-breakpoint
CREATE INDEX "costumes_created_at_idx" ON "costumes" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "rental_payment_rental_id_idx" ON "rental_payment_history" USING btree ("rental_id");--> statement-breakpoint
CREATE INDEX "rental_payment_reference_code_idx" ON "rental_payment_history" USING btree ("reference_code");--> statement-breakpoint
CREATE INDEX "rental_payment_method_idx" ON "rental_payment_history" USING btree ("payment_method");--> statement-breakpoint
CREATE INDEX "rental_payment_status_idx" ON "rental_payment_history" USING btree ("status");--> statement-breakpoint
CREATE INDEX "rental_payment_type_idx" ON "rental_payment_history" USING btree ("payment_type");--> statement-breakpoint
CREATE INDEX "rental_payment_processed_at_idx" ON "rental_payment_history" USING btree ("processed_at");--> statement-breakpoint
CREATE INDEX "rental_payment_session_id_idx" ON "rental_payment_history" USING btree ("session_id");--> statement-breakpoint
CREATE INDEX "rental_payment_paymongo_intent_idx" ON "rental_payment_history" USING btree ("paymongo_payment_intent_id");--> statement-breakpoint
CREATE INDEX "rental_payment_paymongo_source_idx" ON "rental_payment_history" USING btree ("paymongo_source_id");--> statement-breakpoint
CREATE INDEX "rental_payment_gateway_status_idx" ON "rental_payment_history" USING btree ("gateway_status");--> statement-breakpoint
CREATE INDEX "rental_payment_session_expiry_idx" ON "rental_payment_history" USING btree ("session_expires_at");--> statement-breakpoint
CREATE INDEX "rentals_reference_code_idx" ON "rentals" USING btree ("reference_code");--> statement-breakpoint
CREATE INDEX "rentals_costume_id_idx" ON "rentals" USING btree ("costume_id");--> statement-breakpoint
CREATE INDEX "rentals_renter_uid_idx" ON "rentals" USING btree ("renter_uid");--> statement-breakpoint
CREATE INDEX "rentals_status_idx" ON "rentals" USING btree ("status");--> statement-breakpoint
CREATE INDEX "rentals_start_date_idx" ON "rentals" USING btree ("start_date");--> statement-breakpoint
CREATE INDEX "rentals_end_date_idx" ON "rentals" USING btree ("end_date");--> statement-breakpoint
CREATE INDEX "business_addresses_business_idx" ON "business_addresses" USING btree ("business_info_id");--> statement-breakpoint
CREATE INDEX "user_addresses_user_idx" ON "user_addresses" USING btree ("user_uid");--> statement-breakpoint
CREATE INDEX "user_addresses_type_idx" ON "user_addresses" USING btree ("address_type");--> statement-breakpoint
CREATE INDEX "user_addresses_primary_idx" ON "user_addresses" USING btree ("is_primary");--> statement-breakpoint
CREATE INDEX "user_business_info_user_idx" ON "user_business_info" USING btree ("user_uid");--> statement-breakpoint
CREATE INDEX "user_business_info_verified_idx" ON "user_business_info" USING btree ("is_verified");--> statement-breakpoint
CREATE INDEX "user_business_info_type_idx" ON "user_business_info" USING btree ("business_type");--> statement-breakpoint
CREATE INDEX "user_documents_user_idx" ON "user_documents" USING btree ("user_uid");--> statement-breakpoint
CREATE INDEX "user_documents_type_idx" ON "user_documents" USING btree ("document_type");--> statement-breakpoint
CREATE INDEX "user_documents_verified_idx" ON "user_documents" USING btree ("is_verified");--> statement-breakpoint
CREATE UNIQUE INDEX "user_documents_unique_type_idx" ON "user_documents" USING btree ("user_uid","document_type");--> statement-breakpoint
CREATE UNIQUE INDEX "users_email_idx" ON "users" USING btree ("email");--> statement-breakpoint
CREATE UNIQUE INDEX "users_username_idx" ON "users" USING btree ("username");--> statement-breakpoint
CREATE INDEX "users_status_idx" ON "users" USING btree ("status");--> statement-breakpoint
CREATE INDEX "users_role_idx" ON "users" USING btree ("role");--> statement-breakpoint
CREATE INDEX "users_reset_token_idx" ON "users" USING btree ("reset_token");