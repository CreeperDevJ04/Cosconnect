CREATE TABLE "user_roles" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" uuid NOT NULL,
	"role" "user_role" NOT NULL
);
--> statement-breakpoint
ALTER TABLE "user_connections" RENAME TO "messages";--> statement-breakpoint
ALTER TABLE "conversations" RENAME COLUMN "message" TO "user1_role";--> statement-breakpoint
ALTER TABLE "conversations" RENAME COLUMN "message_type" TO "user2_role";--> statement-breakpoint
ALTER TABLE "conversations" RENAME COLUMN "sender_id" TO "created_at";--> statement-breakpoint
ALTER TABLE "conversations" RENAME COLUMN "receiver_id" TO "updated_at";--> statement-breakpoint
ALTER TABLE "messages" RENAME COLUMN "user1_id" TO "conversation_id";--> statement-breakpoint
ALTER TABLE "messages" RENAME COLUMN "user2_id" TO "sender_id";--> statement-breakpoint
ALTER TABLE "messages" RENAME COLUMN "user1_role" TO "sender_role";--> statement-breakpoint
ALTER TABLE "messages" RENAME COLUMN "user2_role" TO "message_type";--> statement-breakpoint
ALTER TABLE "messages" RENAME COLUMN "connected_at" TO "content";--> statement-breakpoint
ALTER TABLE "messages" RENAME COLUMN "last_message_id" TO "image_url";--> statement-breakpoint
ALTER TABLE "messages" DROP CONSTRAINT "user_connections_last_message_id_conversations_id_fk";
--> statement-breakpoint
ALTER TABLE "messages" ALTER COLUMN "message_type" SET DATA TYPE text;--> statement-breakpoint
DROP TYPE "public"."message_type";--> statement-breakpoint
CREATE TYPE "public"."message_type" AS ENUM('text', 'image');--> statement-breakpoint
ALTER TABLE "messages" ALTER COLUMN "message_type" SET DATA TYPE "public"."message_type" USING "message_type"::"public"."message_type";--> statement-breakpoint
DROP INDEX "sender_idx";--> statement-breakpoint
DROP INDEX "receiver_idx";--> statement-breakpoint
DROP INDEX "sender_role_idx";--> statement-breakpoint
DROP INDEX "receiver_role_idx";--> statement-breakpoint
DROP INDEX "timestamp_idx";--> statement-breakpoint
DROP INDEX "user1_idx";--> statement-breakpoint
DROP INDEX "user2_idx";--> statement-breakpoint
DROP INDEX "read_status_idx";--> statement-breakpoint
DROP INDEX "user_pair_unique";--> statement-breakpoint
DROP INDEX "connection_user1_idx";--> statement-breakpoint
DROP INDEX "connection_user2_idx";--> statement-breakpoint
ALTER TABLE "conversations" ALTER COLUMN "user1_id" SET DATA TYPE uuid;--> statement-breakpoint
ALTER TABLE "conversations" ALTER COLUMN "user2_id" SET DATA TYPE uuid;--> statement-breakpoint
ALTER TABLE "messages" ADD COLUMN "is_read" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "messages" ADD COLUMN "is_seen" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "messages" ADD COLUMN "created_at" timestamp with time zone DEFAULT now() NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "unique_user_role" ON "user_roles" USING btree ("user_id","role");--> statement-breakpoint
ALTER TABLE "messages" ADD CONSTRAINT "messages_conversation_id_conversations_id_fk" FOREIGN KEY ("conversation_id") REFERENCES "public"."conversations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "unique_conversation_pair" ON "conversations" USING btree ("user1_id","user1_role","user2_id","user2_role");--> statement-breakpoint
CREATE INDEX "conversation_user1_idx" ON "conversations" USING btree ("user1_id","user1_role");--> statement-breakpoint
CREATE INDEX "conversation_user2_idx" ON "conversations" USING btree ("user2_id","user2_role");--> statement-breakpoint
CREATE INDEX "message_conversation_idx" ON "messages" USING btree ("conversation_id");--> statement-breakpoint
CREATE INDEX "message_sender_idx" ON "messages" USING btree ("sender_id","sender_role");--> statement-breakpoint
CREATE INDEX "message_read_idx" ON "messages" USING btree ("is_read","is_seen");--> statement-breakpoint
ALTER TABLE "conversations" DROP COLUMN "sender_username";--> statement-breakpoint
ALTER TABLE "conversations" DROP COLUMN "receiver_username";--> statement-breakpoint
ALTER TABLE "conversations" DROP COLUMN "sender_role";--> statement-breakpoint
ALTER TABLE "conversations" DROP COLUMN "receiver_role";--> statement-breakpoint
ALTER TABLE "conversations" DROP COLUMN "is_read";--> statement-breakpoint
ALTER TABLE "conversations" DROP COLUMN "is_seen";--> statement-breakpoint
ALTER TABLE "conversations" DROP COLUMN "timestamp";