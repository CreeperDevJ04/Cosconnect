CREATE TABLE "community_post_reports" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"post_id" uuid NOT NULL,
	"reporter_id" uuid NOT NULL,
	"reason" varchar(255) NOT NULL,
	"details" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "community_post_reports" ADD CONSTRAINT "community_post_reports_post_id_community_posts_id_fk" FOREIGN KEY ("post_id") REFERENCES "public"."community_posts"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "community_post_reports" ADD CONSTRAINT "community_post_reports_reporter_id_users_uid_fk" FOREIGN KEY ("reporter_id") REFERENCES "public"."users"("uid") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "community_post_reports_post_id_idx" ON "community_post_reports" USING btree ("post_id");--> statement-breakpoint
CREATE INDEX "community_post_reports_reporter_id_idx" ON "community_post_reports" USING btree ("reporter_id");--> statement-breakpoint
CREATE INDEX "community_post_reports_reason_idx" ON "community_post_reports" USING btree ("reason");