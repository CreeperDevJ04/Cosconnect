ALTER TABLE "conversations" ALTER COLUMN "message_type" SET DATA TYPE text;--> statement-breakpoint
DROP TYPE "public"."message_type";--> statement-breakpoint
CREATE TYPE "public"."message_type" AS ENUM('text', 'system');--> statement-breakpoint
ALTER TABLE "conversations" ALTER COLUMN "message_type" SET DATA TYPE "public"."message_type" USING "message_type"::"public"."message_type";