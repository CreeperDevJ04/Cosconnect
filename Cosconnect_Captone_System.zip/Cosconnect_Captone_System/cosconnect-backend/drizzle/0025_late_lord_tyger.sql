CREATE TABLE "community_post_reactions" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"post_id" uuid NOT NULL,
	"user_uid" uuid NOT NULL,
	"reaction_type" varchar(50) NOT NULL,
	"reacted_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "community_post_reactions_unique_user_post" UNIQUE("post_id","user_uid")
);
--> statement-breakpoint
ALTER TABLE "community_post_reactions" ADD CONSTRAINT "community_post_reactions_post_id_community_posts_id_fk" FOREIGN KEY ("post_id") REFERENCES "public"."community_posts"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "community_post_reactions" ADD CONSTRAINT "community_post_reactions_user_uid_users_uid_fk" FOREIGN KEY ("user_uid") REFERENCES "public"."users"("uid") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "community_post_reactions_post_id_idx" ON "community_post_reactions" USING btree ("post_id");--> statement-breakpoint
CREATE INDEX "community_post_reactions_user_uid_idx" ON "community_post_reactions" USING btree ("user_uid");