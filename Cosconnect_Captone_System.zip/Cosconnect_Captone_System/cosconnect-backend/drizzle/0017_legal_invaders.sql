CREATE TABLE "community_post_report_reviews" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"report_id" uuid NOT NULL,
	"admin_id" uuid NOT NULL,
	"status" varchar(50) DEFAULT 'pending' NOT NULL,
	"notes" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "community_post_report_reviews" ADD CONSTRAINT "community_post_report_reviews_report_id_community_post_reports_id_fk" FOREIGN KEY ("report_id") REFERENCES "public"."community_post_reports"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "community_post_report_reviews" ADD CONSTRAINT "community_post_report_reviews_admin_id_users_uid_fk" FOREIGN KEY ("admin_id") REFERENCES "public"."users"("uid") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "community_post_report_reviews_report_id_idx" ON "community_post_report_reviews" USING btree ("report_id");--> statement-breakpoint
CREATE INDEX "community_post_report_reviews_admin_id_idx" ON "community_post_report_reviews" USING btree ("admin_id");--> statement-breakpoint
CREATE INDEX "community_post_report_reviews_status_idx" ON "community_post_report_reviews" USING btree ("status");