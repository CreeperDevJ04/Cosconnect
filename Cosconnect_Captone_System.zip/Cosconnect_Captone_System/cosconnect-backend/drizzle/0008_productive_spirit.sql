ALTER TABLE "rentals" ADD COLUMN "payout_completed_at" timestamp;--> statement-breakpoint
ALTER TABLE "rentals" ADD COLUMN "refund_completed_at" timestamp;--> statement-breakpoint
CREATE INDEX "rentals_payout_completed_at_idx" ON "rentals" USING btree ("payout_completed_at");--> statement-breakpoint
CREATE INDEX "rentals_refund_completed_at_idx" ON "rentals" USING btree ("refund_completed_at");