ALTER TABLE "otp_codes" RENAME COLUMN "user_uid" TO "email";--> statement-breakpoint
DROP INDEX "otp_codes_user_idx";--> statement-breakpoint
DROP INDEX "otp_codes_code_idx";--> statement-breakpoint
ALTER TABLE "otp_codes" ALTER COLUMN "otp_code" SET DATA TYPE varchar(6);--> statement-breakpoint
ALTER TABLE "otp_codes" ALTER COLUMN "otp_code" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "otp_codes" ALTER COLUMN "expires_at" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "otp_codes" ALTER COLUMN "is_used" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "otp_codes" ALTER COLUMN "created_at" SET NOT NULL;--> statement-breakpoint
CREATE INDEX "otp_codes_email_unused_idx" ON "otp_codes" USING btree ("email","is_used","created_at");--> statement-breakpoint
CREATE INDEX "otp_codes_expires_idx" ON "otp_codes" USING btree ("expires_at");--> statement-breakpoint
ALTER TABLE "otp_codes" DROP COLUMN "updated_at";