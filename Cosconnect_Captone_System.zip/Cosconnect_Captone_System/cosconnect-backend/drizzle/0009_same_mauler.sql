CREATE TYPE "public"."message_type" AS ENUM('inquiry', 'text', 'system');--> statement-breakpoint
CREATE TABLE "conversations" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"conversation_id" varchar(255) NOT NULL,
	"message" text NOT NULL,
	"message_type" "message_type" NOT NULL,
	"sender_id" varchar(255) NOT NULL,
	"receiver_id" varchar(255) NOT NULL,
	"receiver_username" varchar(255) NOT NULL,
	"sender_username" varchar(255) NOT NULL,
	"user1_id" varchar(255) NOT NULL,
	"user2_id" varchar(255) NOT NULL,
	"is_read" boolean DEFAULT false NOT NULL,
	"is_seen" boolean DEFAULT false NOT NULL,
	"timestamp" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "conversation_idx" ON "conversations" USING btree ("conversation_id");--> statement-breakpoint
CREATE INDEX "sender_idx" ON "conversations" USING btree ("sender_id");--> statement-breakpoint
CREATE INDEX "receiver_idx" ON "conversations" USING btree ("receiver_id");--> statement-breakpoint
CREATE INDEX "timestamp_idx" ON "conversations" USING btree ("timestamp");--> statement-breakpoint
CREATE INDEX "user1_idx" ON "conversations" USING btree ("user1_id");--> statement-breakpoint
CREATE INDEX "user2_idx" ON "conversations" USING btree ("user2_id");--> statement-breakpoint
CREATE INDEX "read_status_idx" ON "conversations" USING btree ("is_read","is_seen");