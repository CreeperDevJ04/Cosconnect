ALTER TABLE "terms_and_conditions" DROP CONSTRAINT "terms_and_conditions_id_pk";--> statement-breakpoint
ALTER TABLE "terms_and_conditions" ADD PRIMARY KEY ("id");--> statement-breakpoint
ALTER TABLE "terms_and_conditions" ALTER COLUMN "last_updated" SET DATA TYPE varchar(10);