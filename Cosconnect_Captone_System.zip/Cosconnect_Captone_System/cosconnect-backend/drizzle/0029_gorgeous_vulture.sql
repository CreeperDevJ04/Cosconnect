ALTER TYPE "public"."payment_method" ADD VALUE 'paymaya';--> statement-breakpoint
ALTER TYPE "public"."payment_method" ADD VALUE 'bank';--> statement-breakpoint
ALTER TABLE "rental_payment_history" ALTER COLUMN "status" SET DATA TYPE text;--> statement-breakpoint
ALTER TABLE "rental_payment_history" ALTER COLUMN "status" SET DEFAULT 'pending'::text;--> statement-breakpoint
DROP TYPE "public"."payment_status";--> statement-breakpoint
CREATE TYPE "public"."payment_status" AS ENUM('pending', 'processing', 'paid', 'failed', 'cancelled', 'partial_refund', 'expired');--> statement-breakpoint
ALTER TABLE "rental_payment_history" ALTER COLUMN "status" SET DEFAULT 'pending'::"public"."payment_status";--> statement-breakpoint
ALTER TABLE "rental_payment_history" ALTER COLUMN "status" SET DATA TYPE "public"."payment_status" USING "status"::"public"."payment_status";--> statement-breakpoint
ALTER TABLE "rental_payment_history" ALTER COLUMN "payment_type" SET DATA TYPE text;--> statement-breakpoint
DROP TYPE "public"."payment_type";--> statement-breakpoint
CREATE TYPE "public"."payment_type" AS ENUM('rental_fee', 'security_deposit', 'extension_fee', 'damage_fee');--> statement-breakpoint
ALTER TABLE "rental_payment_history" ALTER COLUMN "payment_type" SET DATA TYPE "public"."payment_type" USING "payment_type"::"public"."payment_type";--> statement-breakpoint
ALTER TABLE "rental_payment_history" ADD COLUMN "account_name" varchar(150);--> statement-breakpoint
ALTER TABLE "rental_payment_history" ADD COLUMN "account_number" varchar(50);--> statement-breakpoint
ALTER TABLE "rental_payment_history" ADD COLUMN "bank_name" varchar(100);--> statement-breakpoint
ALTER TABLE "rental_payment_history" ADD COLUMN "payment_provider" varchar(100);