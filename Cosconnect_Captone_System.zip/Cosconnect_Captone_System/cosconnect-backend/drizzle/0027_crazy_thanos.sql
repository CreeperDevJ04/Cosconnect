ALTER TABLE "community_post_reactions" DROP CONSTRAINT "community_post_reactions_unique_user_post";--> statement-breakpoint
ALTER TABLE "community_comments" ADD COLUMN "reaction_count" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "community_post_reactions" ADD COLUMN "comment_id" uuid;--> statement-breakpoint
ALTER TABLE "community_post_reactions" ADD COLUMN "user_role" varchar(50) NOT NULL;--> statement-breakpoint
ALTER TABLE "community_post_reactions" ADD CONSTRAINT "community_post_reactions_comment_id_community_comments_id_fk" FOREIGN KEY ("comment_id") REFERENCES "public"."community_comments"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "community_post_reactions_comment_id_idx" ON "community_post_reactions" USING btree ("comment_id");--> statement-breakpoint
CREATE INDEX "community_post_reactions_user_role_idx" ON "community_post_reactions" USING btree ("user_role");--> statement-breakpoint
ALTER TABLE "community_post_reactions" ADD CONSTRAINT "community_post_reactions_unique_user_role_post" UNIQUE("post_id","comment_id","user_uid","user_role");