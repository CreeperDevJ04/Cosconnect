ALTER TABLE "rental_payment_history" ALTER COLUMN "payment_method" SET DATA TYPE text;--> statement-breakpoint
DROP TYPE "public"."payment_method";--> statement-breakpoint
CREATE TYPE "public"."payment_method" AS ENUM('gcash');--> statement-breakpoint
ALTER TABLE "rental_payment_history" ALTER COLUMN "payment_method" SET DATA TYPE "public"."payment_method" USING "payment_method"::"public"."payment_method";--> statement-breakpoint
DROP INDEX "rental_rejections_orig_payment_paymaya_idx";--> statement-breakpoint
DROP INDEX "rental_rejections_orig_refund_paymaya_idx";--> statement-breakpoint
DROP INDEX "rentals_payment_paymaya_number_idx";--> statement-breakpoint
DROP INDEX "rentals_refund_paymaya_number_idx";--> statement-breakpoint
ALTER TABLE "rental_rejections" DROP COLUMN "original_payment_paymaya_number";--> statement-breakpoint
ALTER TABLE "rental_rejections" DROP COLUMN "original_refund_paymaya_number";--> statement-breakpoint
ALTER TABLE "rentals" DROP COLUMN "payment_method";--> statement-breakpoint
ALTER TABLE "rentals" DROP COLUMN "payment_paymaya_number";--> statement-breakpoint
ALTER TABLE "rentals" DROP COLUMN "refund_paymaya_number";