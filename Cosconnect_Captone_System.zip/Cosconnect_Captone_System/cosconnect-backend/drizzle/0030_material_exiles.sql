ALTER TYPE "public"."payment_status" ADD VALUE 'refunded' BEFORE 'partial_refund';--> statement-breakpoint
ALTER TYPE "public"."payment_type" ADD VALUE 'refund';--> statement-breakpoint
ALTER TABLE "rental_payment_history" ALTER COLUMN "payment_method" SET DATA TYPE text;--> statement-breakpoint
ALTER TABLE "rentals" ALTER COLUMN "payment_method" SET DATA TYPE text;--> statement-breakpoint
ALTER TABLE "rentals" ALTER COLUMN "payment_method" SET DEFAULT 'gcash'::text;--> statement-breakpoint
DROP TYPE "public"."payment_method";--> statement-breakpoint
CREATE TYPE "public"."payment_method" AS ENUM('gcash', 'paymaya');--> statement-breakpoint
ALTER TABLE "rental_payment_history" ALTER COLUMN "payment_method" SET DATA TYPE "public"."payment_method" USING "payment_method"::"public"."payment_method";--> statement-breakpoint
ALTER TABLE "rentals" ALTER COLUMN "payment_method" SET DEFAULT 'gcash'::"public"."payment_method";--> statement-breakpoint
ALTER TABLE "rentals" ALTER COLUMN "payment_method" SET DATA TYPE "public"."payment_method" USING "payment_method"::"public"."payment_method";--> statement-breakpoint
ALTER TABLE "rental_rejections" ADD COLUMN "original_payment_paymaya_number" varchar(20);--> statement-breakpoint
ALTER TABLE "rental_rejections" ADD COLUMN "original_refund_paymaya_number" varchar(20);--> statement-breakpoint
ALTER TABLE "rentals" ADD COLUMN "payment_method" "payment_method" DEFAULT 'gcash' NOT NULL;--> statement-breakpoint
ALTER TABLE "rentals" ADD COLUMN "payment_paymaya_number" varchar(20);--> statement-breakpoint
ALTER TABLE "rentals" ADD COLUMN "refund_paymaya_number" varchar(20);--> statement-breakpoint
CREATE INDEX "rental_rejections_orig_payment_paymaya_idx" ON "rental_rejections" USING btree ("original_payment_paymaya_number");--> statement-breakpoint
CREATE INDEX "rental_rejections_orig_refund_paymaya_idx" ON "rental_rejections" USING btree ("original_refund_paymaya_number");--> statement-breakpoint
CREATE INDEX "rentals_payment_paymaya_number_idx" ON "rentals" USING btree ("payment_paymaya_number");--> statement-breakpoint
CREATE INDEX "rentals_refund_paymaya_number_idx" ON "rentals" USING btree ("refund_paymaya_number");--> statement-breakpoint
ALTER TABLE "rental_payment_history" DROP COLUMN "account_name";--> statement-breakpoint
ALTER TABLE "rental_payment_history" DROP COLUMN "account_number";--> statement-breakpoint
ALTER TABLE "rental_payment_history" DROP COLUMN "bank_name";--> statement-breakpoint
ALTER TABLE "rental_payment_history" DROP COLUMN "payment_provider";