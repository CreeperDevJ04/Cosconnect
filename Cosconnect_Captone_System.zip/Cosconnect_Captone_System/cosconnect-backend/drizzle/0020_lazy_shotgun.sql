CREATE TABLE "terms_and_conditions" (
	"id" uuid DEFAULT gen_random_uuid() NOT NULL,
	"user_id" uuid NOT NULL,
	"title" varchar(255) NOT NULL,
	"last_updated" varchar(20) NOT NULL,
	"sections" jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "terms_and_conditions_id_pk" PRIMARY KEY("id")
);
--> statement-breakpoint
CREATE INDEX "idx_terms_user_id" ON "terms_and_conditions" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "idx_terms_title" ON "terms_and_conditions" USING btree ("title");--> statement-breakpoint
CREATE INDEX "idx_terms_updated_at" ON "terms_and_conditions" USING btree ("updated_at");--> statement-breakpoint
ALTER TABLE "notifications" DROP COLUMN "sender";