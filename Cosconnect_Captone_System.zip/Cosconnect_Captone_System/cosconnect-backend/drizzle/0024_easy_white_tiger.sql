CREATE TYPE "public"."user_role" AS ENUM('admin', 'lender', 'borrower');--> statement-breakpoint
CREATE TABLE "user_connections" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user1_id" varchar(255) NOT NULL,
	"user2_id" varchar(255) NOT NULL,
	"user1_role" "user_role" NOT NULL,
	"user2_role" "user_role" NOT NULL,
	"connected_at" timestamp with time zone DEFAULT now() NOT NULL,
	"last_message_id" uuid
);
--> statement-breakpoint
ALTER TABLE "conversations" ADD COLUMN "sender_role" "user_role" NOT NULL;--> statement-breakpoint
ALTER TABLE "conversations" ADD COLUMN "receiver_role" "user_role" NOT NULL;--> statement-breakpoint
ALTER TABLE "user_connections" ADD CONSTRAINT "user_connections_last_message_id_conversations_id_fk" FOREIGN KEY ("last_message_id") REFERENCES "public"."conversations"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "user_pair_unique" ON "user_connections" USING btree ("user1_id","user2_id","user1_role","user2_role");--> statement-breakpoint
CREATE INDEX "connection_user1_idx" ON "user_connections" USING btree ("user1_id","user1_role");--> statement-breakpoint
CREATE INDEX "connection_user2_idx" ON "user_connections" USING btree ("user2_id","user2_role");--> statement-breakpoint
CREATE INDEX "sender_role_idx" ON "conversations" USING btree ("sender_role");--> statement-breakpoint
CREATE INDEX "receiver_role_idx" ON "conversations" USING btree ("receiver_role");