ALTER TABLE "community_comments" DROP CONSTRAINT "community_comments_post_id_community_posts_id_fk";
--> statement-breakpoint
ALTER TABLE "community_comments" DROP CONSTRAINT "community_comments_parent_comment_id_community_comments_id_fk";
--> statement-breakpoint
ALTER TABLE "community_comments" DROP CONSTRAINT "community_comments_author_id_users_uid_fk";
--> statement-breakpoint
ALTER TABLE "community_comments" ADD CONSTRAINT "community_comments_post_id_community_posts_id_fk" FOREIGN KEY ("post_id") REFERENCES "public"."community_posts"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "community_comments" ADD CONSTRAINT "community_comments_parent_comment_id_community_comments_id_fk" FOREIGN KEY ("parent_comment_id") REFERENCES "public"."community_comments"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "community_comments" ADD CONSTRAINT "community_comments_author_id_users_uid_fk" FOREIGN KEY ("author_id") REFERENCES "public"."users"("uid") ON DELETE no action ON UPDATE no action;