ALTER TABLE "rentals" ALTER COLUMN "status" SET DATA TYPE text;--> statement-breakpoint
ALTER TABLE "rentals" ALTER COLUMN "status" SET DEFAULT 'pending'::text;--> statement-breakpoint
DROP TYPE "public"."rental_status";--> statement-breakpoint
CREATE TYPE "public"."rental_status" AS ENUM('pending', 'confirmed', 'active', 'delivered', 'returned', 'completed', 'cancelled', 'overdue');--> statement-breakpoint
ALTER TABLE "rentals" ALTER COLUMN "status" SET DEFAULT 'pending'::"public"."rental_status";--> statement-breakpoint
ALTER TABLE "rentals" ALTER COLUMN "status" SET DATA TYPE "public"."rental_status" USING "status"::"public"."rental_status";--> statement-breakpoint
ALTER TABLE "rentals" ADD COLUMN "delivered_at" timestamp;--> statement-breakpoint
ALTER TABLE "rentals" ADD COLUMN "delivered_by" uuid;--> statement-breakpoint
ALTER TABLE "rentals" ADD COLUMN "returned_at" timestamp;--> statement-breakpoint
ALTER TABLE "rentals" ADD COLUMN "returned_by" uuid;--> statement-breakpoint
CREATE INDEX "rentals_delivered_by_idx" ON "rentals" USING btree ("delivered_by");--> statement-breakpoint
CREATE INDEX "rentals_returned_by_idx" ON "rentals" USING btree ("returned_by");