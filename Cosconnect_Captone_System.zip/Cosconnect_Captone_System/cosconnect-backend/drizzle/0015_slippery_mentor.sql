CREATE TYPE "public"."recipient_role" AS ENUM('borrower', 'lender', 'admin');--> statement-breakpoint
ALTER TYPE "public"."notification_type" ADD VALUE 'PAYMENT_REMINDER' BEFORE 'NEW_MESSAGE';--> statement-breakpoint
ALTER TYPE "public"."notification_type" ADD VALUE 'LENDER_VERIFICATION_PENDING';--> statement-breakpoint
ALTER TYPE "public"."notification_type" ADD VALUE 'LENDER_VERIFICATION_APPROVED';--> statement-breakpoint
ALTER TYPE "public"."notification_type" ADD VALUE 'LENDER_VERIFICATION_REJECTED';--> statement-breakpoint
ALTER TYPE "public"."notification_type" ADD VALUE 'ACCOUNT_SUSPENDED';--> statement-breakpoint
ALTER TYPE "public"."notification_type" ADD VALUE 'ACCOUNT_REACTIVATED';--> statement-breakpoint
ALTER TABLE "notifications" DROP CONSTRAINT "notifications_sender_id_users_uid_fk";
--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN "recipient_role" "recipient_role" DEFAULT 'borrower' NOT NULL;--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN "recipient_email" varchar(255) NOT NULL;--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN "sender_role" "recipient_role";--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN "sender_type" varchar(20);--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN "archived_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "notifications" ADD COLUMN "expires_at" timestamp with time zone;--> statement-breakpoint
CREATE INDEX "notifications_recipient_role_idx" ON "notifications" USING btree ("recipient_role");--> statement-breakpoint
CREATE INDEX "notifications_recipient_email_idx" ON "notifications" USING btree ("recipient_email");--> statement-breakpoint
CREATE INDEX "notifications_recipient_status_idx" ON "notifications" USING btree ("recipient_id","status");--> statement-breakpoint
CREATE INDEX "notifications_recipient_role_status_idx" ON "notifications" USING btree ("recipient_id","recipient_role","status");