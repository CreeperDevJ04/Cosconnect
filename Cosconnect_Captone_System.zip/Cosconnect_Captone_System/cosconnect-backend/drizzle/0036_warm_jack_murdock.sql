ALTER TYPE "public"."notification_type" ADD VALUE 'RENTAL_DELIVERED' BEFORE 'PAYMENT_REMINDER';--> statement-breakpoint
ALTER TYPE "public"."notification_type" ADD VALUE 'RENTAL_RETURNED' BEFORE 'PAYMENT_REMINDER';--> statement-breakpoint
ALTER TYPE "public"."payment_type" ADD VALUE 'payout';--> statement-breakpoint
CREATE TABLE "categories" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"category_name" varchar(100) NOT NULL,
	"slug" varchar(100) NOT NULL,
	"status" varchar(20) DEFAULT 'active' NOT NULL,
	"product_listing_count" integer DEFAULT 0 NOT NULL,
	"total_rental_count" integer DEFAULT 0 NOT NULL,
	"admin_id" varchar(100) NOT NULL,
	"admin_name" varchar(100) NOT NULL,
	"admin_email" varchar(255) NOT NULL,
	"admin_role" varchar(50) NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "categories_slug_unique" UNIQUE("slug")
);
--> statement-breakpoint
CREATE TABLE "tags" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"tag_name" varchar(100) NOT NULL,
	"slug" varchar(100) NOT NULL,
	"category" varchar(100) NOT NULL,
	"status" varchar(20) DEFAULT 'active' NOT NULL,
	"product_listing_count" integer DEFAULT 0 NOT NULL,
	"total_rental_count" integer DEFAULT 0 NOT NULL,
	"admin_id" varchar(100) NOT NULL,
	"admin_name" varchar(100) NOT NULL,
	"admin_email" varchar(255) NOT NULL,
	"admin_role" varchar(50) NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "tags_slug_unique" UNIQUE("slug")
);
--> statement-breakpoint
ALTER TABLE "rentals" ADD COLUMN "processing_fee" numeric(10, 2) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE "rentals" ADD COLUMN "commission_fee" numeric(10, 2) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE "rentals" ADD COLUMN "revenue_sum" numeric(10, 2) DEFAULT '0' NOT NULL;