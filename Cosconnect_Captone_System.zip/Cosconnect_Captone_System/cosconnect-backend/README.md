```
once in the directory inside the terminal run the following in the terminal to run the project:

npm install --force
npm run dev
```

```
open http://localhost:8000
```
