export interface LenderData {
    email: string;
    password: string;
    fullName: string;
    username: string;
    phoneNumber: string;
    businessName: string;
    businessAddress: string;
    businessType: string;
    businessPermitNumber: string;
    businessPermitFile: string;
    description: string;
    hasValidId: boolean;
    validIdType: string;
    validIdNumber: string;
    validIdFile: string;
}