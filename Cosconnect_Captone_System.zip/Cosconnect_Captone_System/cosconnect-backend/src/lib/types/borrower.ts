export interface BorrowerData {
    personalInfo: {
        email: string;
        password: string;
        fullName: string;
        username: string;
        phoneNumber: string;
        address: string;
        city: string;
        barangay: string;
        province: string;
        zipCode: string;
        region: string;
        street: string;
    };
    identification: {
        hasValidId: boolean;
        validIdType?: string;
        validIdNumber?: string;
        validIdFile?: string;
        secondaryIdType1?: string;
        secondaryIdFile1?: string;
        secondaryIdType2?: string;
        secondaryIdFile2?: string;
    };
    otpCode: string;
}