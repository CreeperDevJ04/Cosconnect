import { z } from 'zod';

// Document types for type safety
export const DocumentType = {
    VALID_ID: 'VALID_ID',
    SELFIE_WITH_ID: 'SELFIE_WITH_ID',
    BUSINESS_PERMIT: 'BUSINESS_PERMIT',
    DTI_CERTIFICATE: 'DTI_CERTIFICATE',
    STOREFRONT_PHOTO: 'STOREFRONT_PHOTO'
} as const;

export type DocumentType = typeof DocumentType[keyof typeof DocumentType];

// Valid ID types enum that matches your database enum
export const ValidIdTypeEnum = z.enum([
    'NATIONAL_ID',
    'DRIVERS_LICENSE',
    'PASSPORT',
    'SSS_ID',
    'PHILHEALTH_ID',
    'VOTERS_ID',
    'TIN_ID',
    'POSTAL_ID',
    'UMID',
    'PRC_ID'
]);

export type ValidIdType = z.infer<typeof ValidIdTypeEnum>;

// Business type enum that matches your database enum
export const BusinessTypeEnum = z.enum(['INDIVIDUAL', 'STORE']);
export type BusinessType = z.infer<typeof BusinessTypeEnum>;

// Base business info schema with common fields
const BaseBusinessInfoSchema = z.object({
    business_name: z.string().min(1, "Business name is required"),
    business_description: z.string().min(1, "Business description is required"),
    business_email: z.string().email("Valid business email is required"),
    business_phone_number: z.string().min(1, "Business phone number is required"),
    business_telephone: z.string().optional(),

    business_profile_image: z.string().optional(),
    business_background_image: z.string().optional(),
    business_permit_file: z.string().optional(),

    business_address: z.string().min(1, "Business address is required"),
    street: z.string().min(1, "Street is required"),
    barangay: z.string().min(1, "Barangay is required"),
    city: z.object({
        id: z.string().min(1, "City ID is required"),
        name: z.string().min(1, "City name is required"),
    }),
    province: z.string().min(1, "Province is required"),
    region: z.string().min(1, "Region is required"),
    zip_code: z.string().min(1, "Zip code is required"),
});

// Individual business info schema
export const IndividualBusinessInfoSchema = BaseBusinessInfoSchema.extend({
    business_type: z.literal('INDIVIDUAL'),
});

export type IndividualBusinessInfo = z.infer<typeof IndividualBusinessInfoSchema>;

// Store business info schema with additional required documents
export const StoreBusinessInfoSchema = BaseBusinessInfoSchema.extend({
    business_type: z.literal('STORE'),
    upload_dti_certificate: z.string().min(1, "DTI certificate is required for store business"),
    upload_business_permit: z.string().min(1, "Business permit is required for store business"),
    upload_storefront_photo: z.string().min(1, "Storefront photo is required for store business"),
});

export type StoreBusinessInfo = z.infer<typeof StoreBusinessInfoSchema>;

// Union type for business info
export const BusinessInfoSchema = z.discriminatedUnion('business_type', [
    IndividualBusinessInfoSchema,
    StoreBusinessInfoSchema,
]);

export type BusinessInfo = z.infer<typeof BusinessInfoSchema>;

// Main lender form data schema
export const LenderFormDataSchema = z.object({
    personal_info: z.object({
        first_name: z.string().min(1, "First name is required"),
        last_name: z.string().min(1, "Last name is required"),
        full_name: z.string().min(1, "Full name is required"),
        username: z.string().min(3, "Username must be at least 3 characters"),
        email: z.string().email("Valid email is required"),
        phone_number: z.string().optional(),
    }),

    identification: z.object({
        has_valid_id: z.boolean().refine(val => val === true, {
            message: "Valid ID is required for lender registration"
        }),
        valid_id_type: ValidIdTypeEnum,
        valid_id_number: z.string().min(1, "Valid ID number is required"),
        valid_id_file: z.string().url("Valid ID file URL is required"),
        selfie_with_id: z.string().url("Selfie with ID URL is required"),
    }),

    business_info: BusinessInfoSchema,

    terms_and_conditions: z.literal('Accepted', {
        errorMap: () => ({ message: "Terms and conditions must be accepted" })
    }),
});

export type LenderFormData = z.infer<typeof LenderFormDataSchema>;

// Document interface for database operations
export interface DocumentData {
    file_url: string;
    has_valid_id: boolean;
    id_type?: string;
    id_number?: string;
}