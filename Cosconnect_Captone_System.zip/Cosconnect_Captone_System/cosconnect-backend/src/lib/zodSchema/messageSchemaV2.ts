import { z } from 'zod';

export const InquiryMessageSchema = z.object({
    costumeName: z.string().min(1, 'Costume name is required'),
    lenderId: z.string().min(1, 'Lender ID is required').max(50).regex(/^[a-zA-Z0-9_-]+$/, 'Invalid lender ID'),
    lenderUsername: z.string().min(1, 'Lender username is required').max(50).regex(/^[\w.-]+$/, 'Invalid lender username'),
    borrowerId: z.string().min(1, 'Borrower ID is required').max(50).regex(/^[a-zA-Z0-9_-]+$/, 'Invalid borrower ID'),
    borrowerUsername: z.string().min(1, 'Borrower username is required').max(50).regex(/^[\w.-]+$/, 'Invalid borrower username'),
    costumeId: z.string().min(1, 'Costume ID is required').max(50).regex(/^[a-zA-Z0-9_-]+$/, 'Invalid costume ID'),
    conversationId: z.string().min(1, 'Conversation ID is required'),
    timestamp: z.string().datetime('Invalid timestamp format').optional(),
});

export const SendMessageSchema = z.object({
    conversation_id: z.string().min(1, "Conversation ID is required"),
    message: z.string().min(1, "Message content is required"),
    message_type: z.enum(['inquiry', 'text', 'system']),
    sender_id: z.string().min(1, "Sender ID is required"),
    receiver_id: z.string().min(1, "Receiver ID is required"),
    sender_username: z.string().min(1, "Sender username is required"),
    receiver_username: z.string().min(1, "Receiver username is required"),
    user1_id: z.string().uuid("User1 ID must be a valid UUID"),
    user2_id: z.string().uuid("User2 ID must be a valid UUID"),
    costume_id: z.string().optional(),
    costume_name: z.string().optional()
});

export type SendMessageSchemaType = z.infer<typeof SendMessageSchema>;

export type InquiryMessageSchemaType = z.infer<typeof InquiryMessageSchema>;