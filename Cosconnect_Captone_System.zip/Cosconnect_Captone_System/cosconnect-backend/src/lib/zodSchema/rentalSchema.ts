import { z } from "zod";

// Schema for rental request (snake_case)
export const RentalRequestSchema = z.object({

    costume_id: z.string().uuid("Costume ID must be a valid UUID"),

    payment_method: z.object({
        type: z.literal("gcash"), // only gcash supported
        gcash_number: z.string().min(1, "GCash number is required"),
        refund_account_name: z.string().min(1, "Refund account name is required"),
        refund_gcash_number: z.string().min(1, "Refund GCash number is required"),
    }),

    personal_details: z.object({
        user_id: z.string().uuid("User ID must be a valid UUID"),
        first_name: z.string().min(1, "First name is required"),
        last_name: z.string().min(1, "Last name is required"),
        email: z.string().email("Invalid email"),
        phone_number: z.string().min(3, "Phone number is required"),

    }),

    schedule: z.object({
        delivery_address: z.string().min(1, "Delivery address is required"),
        delivery_method: z.enum(["delivery", "pickup"]),
        start_date: z.string().datetime("Start date must be a valid ISO date"),
        end_date: z.string().datetime("End date must be a valid ISO date"),
        special_instructions: z.string().optional(),
    }),
});

export type RentalRequestSchemaType = z.infer<typeof RentalRequestSchema>;