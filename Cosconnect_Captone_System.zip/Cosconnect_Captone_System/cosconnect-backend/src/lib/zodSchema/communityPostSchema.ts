import { z } from "zod";

// Zod Schema for Heart Community Post
export const HeartCommunityPostSchema = z.object({
    action: z.enum(["liked", "unliked"]),
    borrower: z.object({
        uid: z.string().min(1, "User ID is required"),
        name: z.string().min(1, "Name is required"),
        email: z.string().email("Valid email is required"),
        avatarUrl: z.string().optional()
    }),
    postId: z.string().min(1, "Post ID is required"),
    postAuthor: z.string().min(1, "Post aut hor is required"),

});

// Type inference from Zod schema
export type HeartCommunityPostDataType = z.infer<typeof HeartCommunityPostSchema>;

export const createCommunityPostSchema = z.object({
    author: z.object({
        id: z.string().min(1, 'Author ID is required'),
        name: z.string().min(1, 'Author name is required'),
        role: z.string().min(1, 'Author role is required'),
        avatar: z.string().min(1, 'Author avatar is required'),
    }),
    content: z.string().min(1, 'Content is required'),
    images: z.array(z.string().url('Each image must be a valid URL')).optional().default([]),
    isForSale: z.boolean().default(false)
});

export const createCommentSchema = z.object({
    post_id: z.string().uuid({ message: 'Invalid post_id format' }),
    parent_comment_id: z.string().uuid({ message: 'Invalid parent_comment_id format' }).optional().nullable(),
    commenter: z.object({
        user_id: z.string().uuid({ message: 'Invalid user_id format' }),
        username: z.string().min(1, 'Username is required'),
        user_avatar_url: z.string().url('Avatar must be a valid URL'),
    }),
    comment: z.object({
        content: z.string().min(1, 'Content is required'),
        images: z.array(z.string().url('Each image must be a valid URL')).optional().default([]),
    }),
});

