// Email templates

import { User } from '@/schema/users';
import nodemailer from 'nodemailer'

// Configure nodemailer transporter
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER ,
        pass: process.env.EMAIL_PASSWORD || '' // Use environment variables for security
    }
});

const userEmailTemplate = (username: string) => `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">Lender Application Received</h2>
        <p>Dear ${username},</p>
        <p>Thank you for applying to become a lender on our platform. We have received your application and it is currently under review.</p>
        <p><strong>What happens next:</strong></p>
        <ul>
            <li>Our team will review your application within 3-5 business days</li>
            <li>We will verify your documents and business information</li>
            <li>You will receive an email notification once the review is complete</li>
        </ul>
        <p>If you have any questions, please don't hesitate to contact our support team.</p>
        <p>Best regards,<br>The Platform Team</p>
    </div>
`;

const adminEmailTemplate = (userData: any) => `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #dc2626;">New Lender Application</h2>
        <p>A new lender application has been submitted for review:</p>
        <table style="border-collapse: collapse; width: 100%;">
            <tr><td style="padding: 8px; border: 1px solid #ddd;"><strong>Username:</strong></td><td style="padding: 8px; border: 1px solid #ddd;">${userData.username}</td></tr>
            <tr><td style="padding: 8px; border: 1px solid #ddd;"><strong>Full Name:</strong></td><td style="padding: 8px; border: 1px solid #ddd;">${userData.full_name || 'N/A'}</td></tr>
            <tr><td style="padding: 8px; border: 1px solid #ddd;"><strong>Email:</strong></td><td style="padding: 8px; border: 1px solid #ddd;">${userData.email}</td></tr>
            <tr><td style="padding: 8px; border: 1px solid #ddd;"><strong>Business Name:</strong></td><td style="padding: 8px; border: 1px solid #ddd;">${userData.business_info?.business_name || 'N/A'}</td></tr>
            <tr><td style="padding: 8px; border: 1px solid #ddd;"><strong>Business Type:</strong></td><td style="padding: 8px; border: 1px solid #ddd;">${userData.business_info?.business_type || 'N/A'}</td></tr>
            <tr><td style="padding: 8px; border: 1px solid #ddd;"><strong>Applied On:</strong></td><td style="padding: 8px; border: 1px solid #ddd;">${new Date().toLocaleString()}</td></tr>
        </table>
        <p>Please log in to the admin panel to review this application.</p>
    </div>
`;

// Send emails function
export const sendEmails = async (user: User) => {
    try {
        // Send to user
        await transporter.sendMail({
            from: process.env.EMAIL_USER ,
            to: user.email,
            subject: 'Lender Application Received - Under Review',
            html: userEmailTemplate(user.username)
        });

        // Send to admin
        if (process.env.ADMIN_EMAIL) {
            await transporter.sendMail({
                from: process.env.EMAIL_USER ,
                to: process.env.ADMIN_EMAIL,
                subject: 'New Lender Application - Review Required',
                html: adminEmailTemplate(user)
            });
        }
    } catch (error) {
        console.error('Email send failed:', error);
    }
};