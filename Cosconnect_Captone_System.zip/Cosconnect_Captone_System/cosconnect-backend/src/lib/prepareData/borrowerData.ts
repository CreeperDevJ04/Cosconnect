export const prepareUserData = (data: any) => {
    return {
        email: data.email.trim(),
        username: data.username.toLowerCase().trim(),
        fullName: data.fullName.trim(),
        phoneNumber: data.phoneNumber,
        address: data.address.trim(),
        role: 'borrower',
        identification: {
            hasValidId: data.hasValidId,
            type: data.validIdType,
            number: data.validIdNumber,
            file: data.validIdFile
        },
        createdAt: new Date(),
        updatedAt: new Date()
    };
};
