

export const prepareUserLenderData = (data: any) => {
    return {
        email: data.email.trim(),
        username: data.username.toLowerCase().trim(),
        fullName: data.fullName.trim(),
        phoneNumber: data.phoneNumber,
        role: 'lender',
        businessDetails: {
            name: data.businessName.trim(),
            address: data.businessAddress.trim(),
            type: data.businessType,
            permitNumber: data.businessPermitNumber,
            permitFile: data.businessPermitFile,
            description: data.description.trim()
        },
        identification: {
            hasValidId: data.hasValidId,
            type: data.validIdType,
            number: data.validIdNumber,
            file: data.validIdFile
        },
        createdAt: new Date(),
        updatedAt: new Date()
    };
};