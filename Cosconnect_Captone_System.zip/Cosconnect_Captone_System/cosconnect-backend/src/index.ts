// src/server.ts or index.ts
import dotenv from 'dotenv';
dotenv.config();

import { Hono } from 'hono';
import { bodyLimit } from 'hono/body-limit';
import { cors } from 'hono/cors';
import { createServer } from 'http';

import adminRoutesV2 from './routes/adminRouteV2';
import lenderRoutes from './routes/lenderRoute';

import marketPlaceRoute from './routes/marketPlaceRoute';


import productRoutes from './routes/productRoute';
import rentalRoutes from './routes/rentalRoute';


import costumeRoute from './routes/costumeRoute';
import userRoutes from './routes/userRoute';
import communityRoutes from './routes/communityRoute';
import messageRoutes from './routes/messageRoute';

import accountingRoutes from './routes/accountingRoute';
import otpRoutes from './routes/otpRoute';
import notificationsRoutes from './routes/notificationsRoute';
import analyticsRoutes from './routes/analyticsRoute';
import subscriptionRoutes from './routes/subscriptionRoute';
import categoryRoutes from './routes/categoryRoute';
import tagsRoutes from './routes/tagsRoute';

import { testConnection } from './db/supabase/db_connect.js';
import { initializeSocketIO } from './socket/socketHandler';

const app = new Hono();

app.use(
  bodyLimit({
    maxSize: 4 * 1024 * 1024, // 4 MB limit
    onError: (c) => c.text('Payload too large', 413)
  })
);

// Update CORS to allow all origins
app.use('*', async (c, next) => {
  // Handle preflight requests
  if (c.req.method === 'OPTIONS') {
    return new Response(null, {
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, PATCH, OPTIONS',
        'Access-Control-Allow-Headers': '*',
        'Access-Control-Max-Age': '86400', // 24 hours
      }
    });
  }

  await next();

  // Add CORS headers to the response
  c.header('Access-Control-Allow-Origin', '*');
  c.header('Access-Control-Allow-Headers', '*');
  c.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
});

app.use(
  cors({
    origin: '*',
    allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
    allowHeaders: ['Content-Type', 'Authorization'],
    credentials: true,
  })
);

app.get('/', (c) => c.text('Hello Hono!'));

// Health check route
app.get('/', async (c) => {
  try {
    console.log("🔍 Health check: Testing database connection...");
    const connected = await testConnection();

    return c.json({
      status: connected ? 'Connected to DB!' : 'Failed to connect to DB',
      success: connected,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error("❌ Health check failed:", error);
    return c.json({
      status: 'Health check failed',
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    }, 500);
  }
});

app.route("/api/v1/community", communityRoutes);
app.route("/api/v1/messages", messageRoutes);
app.route("/api/v1/rental", rentalRoutes);
app.route("/api/v1/costume", costumeRoute);
app.route("/api/v1/admin", adminRoutesV2);
app.route("/api/v1/user", userRoutes);
app.route("/api/v1/lender", lenderRoutes);
app.route("/api/v1/marketplace", marketPlaceRoute);
app.route("/api/v1/products", productRoutes);
app.route("/api/v1/accounting", accountingRoutes);
app.route("/api/v1/otp", otpRoutes);
app.route("/api/v1/notifications", notificationsRoutes);
app.route("/api/v1/analytics", analyticsRoutes);
app.route("/api/v1/subscription", subscriptionRoutes);
app.route("/api/v1", categoryRoutes);
app.route("/api/v1", tagsRoutes);

const PORT = process.env.PORT || 8000;

// Create HTTP server with Hono app 
const server = createServer(async (req, res) => {
  try {
    // Handle the request with Hono
    const headers = new Headers();
    for (const [key, value] of Object.entries(req.headers)) {
      if (value) headers.set(key, Array.isArray(value) ? value.join(', ') : value);
    }

    let body: string | undefined;
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      const chunks: Buffer[] = [];
      for await (const chunk of req) {
        chunks.push(chunk);
      }
      body = Buffer.concat(chunks).toString();
    }

    const request = new Request(`http://${req.headers.host}${req.url}`, {
      method: req.method,
      headers,
      body
    });

    const response = await app.fetch(request);
    const responseHeaders: Record<string, string> = {};
    response.headers.forEach((value, key) => {
      responseHeaders[key] = value;
    });

    res.writeHead(response.status, responseHeaders);
    const responseBody = await response.text();
    res.end(responseBody);
  } catch (error) {
    console.error('❌ Error handling HTTP request:', error);
    res.writeHead(500);
    res.end('Internal Server Error');
  }
});

// Initialize Socket.IO
export const io = initializeSocketIO(server);

// Start the server
server.listen(PORT, async () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
  console.log('🔌 WebSocket server is ready');
  console.log('📡 Available transports: WebSocket, Polling');

  // Database connection already tested in health check

  // Test connection before starting server
  const isConnected = await testConnection();

  if (!isConnected) {
    console.error("❌ Failed to connect to database. Server will still start but database operations will fail.");
  }

  console.log('✅ Server initialization complete!');
  console.log('-----------------------------------');
});

// Handle server errors
server.on('error', (error) => {
  console.error('❌ Server error:', error);
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n🛑 Shutting down server...');
  server.close(() => {
    console.log('✅ Server closed');
    process.exit(0);
  });
});

process.on('SIGTERM', () => {
  console.log('\n🛑 Shutting down server...');
  server.close(() => {
    console.log('✅ Server closed');
    process.exit(0);
  });
});