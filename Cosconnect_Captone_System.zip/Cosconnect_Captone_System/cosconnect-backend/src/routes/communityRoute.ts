
import communityController from '@/controller/communityController';
import communityPost from '@/controller/communityPost';
import { Hono } from 'hono';

const router = new Hono();

router.post("/create-post", communityController.createPost)
router.get("/get-all-posts", communityController.getAllPosts)
router.post("/comment-on-post", communityController.commentOnPost)
router.get("/get-comments-on-post/:post_id", communityController.getCommentsOnThePost)
router.put("/like-post", communityController.reactOnPost)
router.delete("/delete-post/:post_id", communityController.deletePostById)
router.put("/update-my-post/:post_id", communityController.updateMyPost)
router.post("/report-post", communityController.reportPost)
router.get("/get-all-report-posts", communityController.getAllReportPosts)
router.put("/approve-report-post", communityController.approvedReportedPostRemovePost)
router.delete("/delete-my-comment/:comment_id", communityController.deleteMyComment)
// Cursor-paginated my posts endpoint
router.get("/my-posts", communityController.getMyPosts)
export default router