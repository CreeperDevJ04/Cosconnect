import { Hono } from 'hono';
import tagsController from '../controller/tagsController';

const router = new Hono();

// GET /api/v1/tags - Get all active tags
router.get('/tags', tagsController.getAllTags);

// GET /api/v1/tags/:category - Get tags by category
router.get('/tags/:category', tagsController.getTagsByCategory);

// GET /api/v1/tags/id/:id - Get tag by ID
router.get('/tags/id/:id', tagsController.getTagById);

// GET /api/v1/tags/slug/:slug - Get tag by slug
router.get('/tags/slug/:slug', tagsController.getTagBySlug);

export default router;