import costumeController from '@/controller/costumeController';
import { Hono } from 'hono';

const router = new Hono();

router.post("/create", costumeController.createCostume)
router.get("/marketplace", costumeController.getMarketplaceCostumes)
router.get("/my-costumes/:lenderId", costumeController.getMyCostumes)
router.put("/edit/:id", costumeController.editCostumeDataById)

export default router