import adminControllerV2 from '@/controller/adminControllerV2';
import { Hono } from 'hono';

const router = new Hono();

router.get("/:id", adminControllerV2.getAdminDataById)
router.get("/all/users", adminControllerV2.getAllUsersCreated)
router.patch("/user/:userId", adminControllerV2.updateUserStatus)
router.patch("/user/:userId/document/:documentType/verify", adminControllerV2.verifyUserDocument)
router.delete("/user/bulk-delete", adminControllerV2.deleteUsersByBulkIds)
router.delete("/user/delete/:userId", adminControllerV2.deleteUserById)
router.post("/user/warning-block", adminControllerV2.sendWarningBlockUserAccount)
router.patch("/user/:userId/warning", adminControllerV2.updateUserAccountStatus)
router.get("/analytics", adminControllerV2.getAnalyticsData)
router.put("/update-info", adminControllerV2.updateAdminInfo)
export default router;
