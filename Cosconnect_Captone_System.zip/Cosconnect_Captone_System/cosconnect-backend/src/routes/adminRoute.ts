import adminController from '@/controller/adminController';
import { Hono } from 'hono';

const router = new Hono();

router.post('/verify-otp', adminController.verifyAdminOTP);
router.post('/resend-otp', adminController.resendOTP);
router.post('/signin', adminController.initiateAdminSignIn);
router.post('/create', adminController.createAdmin);
router.get('/borrowers', adminController.getAllCreatedBorrowers);
router.get('/lenders', adminController.getAllCreatedLenders);

router.patch('/borrower-status', adminController.updateBorrowerStatus);
router.patch('/lender-status', adminController.updateLenderStatus);

router.delete('/borrower-account', adminController.deleteBorrowerAccount);
router.delete('/lender-account', adminController.deleteLenderAccount);

export default router;