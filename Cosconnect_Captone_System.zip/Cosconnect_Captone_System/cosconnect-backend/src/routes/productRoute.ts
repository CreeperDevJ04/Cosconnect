import productController from '@/controller/productController';
import { Hono } from 'hono';

const router = new Hono();

router.post("create-category", productController.createCategory)
router.get("get-all-categories", productController.getAllCategories)
router.patch("update-category/:categoryId", productController.updateCategoryById)

router.post("create-tag", productController.createTags)
router.get("get-all-tags", productController.getAllTags)
router.patch("update-tag/:tagId", productController.updateTagsById)

router.post("store-cosplay-tags-data", productController.storeCosplayTagsData)

// ✅ Product Route

router.get('/get-products/:lenderId', productController.getAllProducts);
router.get('/get-product/:productId', productController.getProductById);
router.get('/get-products-for-borrowers', productController.getAllProductsForBorrowers);

// delete
router.delete("/delete-product/:productId", productController.deleteProductById)

router.get("/get-my-products/:lenderId", productController.getMyProductsByLenderId)
export default router