import { Hono } from 'hono';
import categoryController from '../controller/categoryController';

const router = new Hono();

// GET /api/v1/categories - Get all active categories
router.get('/categories', categoryController.getAllCategories);

// GET /api/v1/categories/:id - Get category by ID
router.get('/categories/:id', categoryController.getCategoryById);

// GET /api/v1/categories/slug/:slug - Get category by slug
router.get('/categories/slug/:slug', categoryController.getCategoryBySlug);

export default router;