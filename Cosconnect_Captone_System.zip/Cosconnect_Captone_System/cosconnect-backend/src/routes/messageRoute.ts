
import messageController from '@/controller/messageController';
import { Hono } from 'hono';

const router = new Hono();



router.get("/contacts/:userId", messageController.getContacts);
router.get("/conversation/:userId/:partnerId", messageController.getConversation);
router.post("/send-message", messageController.sendMessage);
router.delete("/message/:messageId", messageController.deleteMessage);
export default router;  