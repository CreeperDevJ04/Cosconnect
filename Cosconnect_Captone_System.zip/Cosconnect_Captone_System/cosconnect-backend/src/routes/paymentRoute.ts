import { Hono } from 'hono';
import rentalScheduleCreatePaymentCheckout, {
    checkPaymentStatus,
    handlePaymentCancellation,
    handlePaymentWebhook
} from '../services/rentalScheduleCreatePaymentCheckout';

const router = new Hono();

// Logger function
const logger = {
    info: (message: string, data?: any) => {
        console.log(`[INFO] ${new Date().toISOString()} - ${message}`, data ? JSON.stringify(data, null, 2) : '');
    },
    error: (message: string, error: any) => {
        console.error(`[ERROR] ${new Date().toISOString()} - ${message}`, error);
        if (error.response) {
            console.error('Response data:', error.response.data);
            console.error('Response status:', error.response.status);
        }
    },
    debug: (message: string, data?: any) => {
        if (process.env.NODE_ENV === 'development') {
            console.debug(`[DEBUG] ${new Date().toISOString()} - ${message}`, data ? JSON.stringify(data, null, 2) : '');
        }
    }
};

// Create payment session for costume rental
router.post("/payment-costume", rentalScheduleCreatePaymentCheckout.proceedToPaymentForCostumeRent)

// Cancel payment
router.post("/payment-costume/cancel", async (c) => {
    try {
        logger.info('Received payment cancellation request');
        const response = await handlePaymentCancellation(c);
        logger.info('Payment cancellation processed successfully', response);
        return response;
    } catch (error) {
        logger.error('Payment cancellation failed', error);
        return c.json({
            success: false,
            error: 'Payment cancellation failed',
            message: error instanceof Error ? error.message : 'An unexpected error occurred'
        }, 500);
    }
});

// Check payment status
router.get("/payment-costume/status/:sessionId", async (c) => {
    try {
        const sessionId = c.req.param('sessionId');
        logger.info('Checking payment status', { sessionId });

        const status = await checkPaymentStatus(sessionId);
        logger.info('Payment status retrieved', { sessionId, status });

        return c.json({
            success: true,
            status
        });
    } catch (error) {
        logger.error('Payment status check failed', error);
        return c.json({
            success: false,
            error: 'Failed to check payment status',
            message: error instanceof Error ? error.message : 'An unexpected error occurred'
        }, 500);
    }
});

// Webhook endpoint for payment status updates
router.post("/payment-costume/webhook", async (c) => {
    try {
        logger.info('Received payment webhook');
        const webhookData = await c.req.json();
        logger.debug('Webhook data received', webhookData);

        const response = await handlePaymentWebhook(c);
        logger.info('Webhook processed successfully', response);
        return response;
    } catch (error) {
        logger.error('Webhook processing failed', error);
        return c.json({
            success: false,
            error: 'Webhook processing failed',
            message: error instanceof Error ? error.message : 'An unexpected error occurred'
        }, 500);
    }
});





export default router;