import accountingController from '@/controller/accountingController';
import { Hono } from 'hono';

const router = new Hono();

router.get('/all-rejections', accountingController.getRentalRejections);
router.get('/all-rentals', accountingController.getCompletedRentalsForAccounting);
router.post('/transfer-money-borrower', accountingController.sendRefundMoneyBorrower);
router.post('/transfer-money-lender', accountingController.sendPayoutMoneyLender);
export default router;
