import { Hono } from 'hono';
import analyticsController from '@/controller/analyticsController';

const router = new Hono();

router.get('/', analyticsController.getAnalytics);
export default router;
