import userController from '@/controller/userController';
import { Hono } from 'hono';

/**
 * User route
 */
const router = new Hono();

/**
 * Get user data
 */
router.get("/user", userController.getUserData);

/**
 * Update user info
 */
router.patch("/:id", userController.updatePersonalInfo);

/**
 * Get user roles
 */
router.get("/roles/:userId", userController.getUserRoles);

/**
 * Switch user role
 */
router.patch("/switch-role/:userId", userController.switchRole);

/**
 * Get user profile
 */
router.get("/profile", userController.getUserDataByIdWithRole);
router.get("/data/:user_id", userController.getUserDataById);

router.post("/send-otp", userController.sendOtpCode);
export default router;