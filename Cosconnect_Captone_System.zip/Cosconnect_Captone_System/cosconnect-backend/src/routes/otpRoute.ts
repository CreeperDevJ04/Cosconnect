
import otpController from '@/controller/otpController';
import { Hono } from 'hono';

const router = new Hono();

router.post('/verify-otp', otpController.verifyOtpCode);

router.post('/resend-otp', otpController.resendOtpCode);


export default router;
