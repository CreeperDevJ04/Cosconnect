import rentalsController from '@/controller/rentalsController';
import { Hono } from 'hono';

const router = new Hono();

router.post('/send-return-proof', rentalsController.sendReturnProof)

router.get("/transactions", rentalsController.getTransactionsRentals)

router.post("/request", rentalsController.createRentalRequest)
router.post("/confirm-payment/:reference_code", rentalsController.confirmPayment)
router.get("/my-rentals/:user_id", rentalsController.getMyRentals)
router.get("/lender-rentals/:user_id", rentalsController.getLenderRentals)
router.get("/rejections/:userId", rentalsController.getRentalRejections)
router.get("/all-rejections", rentalsController.getAllRentalRejections) // MOVED BEFORE /:rental_id


router.post("/payment-status/:sessionId", rentalsController.getPaymentSession)
router.put("/update-rental-status", rentalsController.updateRentalRequestStatus)
router.get("/costume-booked-dates/:costume_id", rentalsController.getBookedDateRanges)

router.get("/:rental_id", rentalsController.getRentalById) // MOVED AFTER specific routes

export default router;