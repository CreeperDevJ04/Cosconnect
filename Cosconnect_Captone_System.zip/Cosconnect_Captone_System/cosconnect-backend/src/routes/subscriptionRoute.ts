import { Hono } from 'hono';
import subscriptionController from '../controller/subscriptionController';
const router = new Hono();

// Create subscription payment checkout session
router.post('/pay', subscriptionController.paySubscription);

// Webhook endpoint for PayMongo subscription payment events
router.post('/webhook', subscriptionController.subscriptionPaymentWebhook);

// Confirm subscription payment
router.post('/confirm/:session_id', subscriptionController.confirmSubscriptionPayment);

export default router;
