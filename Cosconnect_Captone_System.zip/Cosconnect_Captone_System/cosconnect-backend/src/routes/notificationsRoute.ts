
import notificationController from '@/controller/notificationController';
import { Hono } from 'hono';

const router = new Hono();

router.get("/get-my-notifications", notificationController.getMyNotifications);
router.get("/unread-count", notificationController.getUnreadCount);
router.delete("/delete-notification/:id", notificationController.deleteNotification);
router.patch("/mark-as-read/:id", notificationController.markAsRead);
router.patch("/mark-all-as-read", notificationController.markAllAsRead);

export default router;
