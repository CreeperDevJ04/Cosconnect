
import marketPlaceController from '@/controller/marketPlaceController';
import { Hono } from 'hono';

const router = new Hono();


router.get('/costumes', marketPlaceController.getMarketplaceCostumes);
router.get('/costume/:id', marketPlaceController.getCostumeById);

export default router;  