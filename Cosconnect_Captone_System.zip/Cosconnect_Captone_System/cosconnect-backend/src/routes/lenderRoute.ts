import { Hono } from 'hono';
import lenderController from '@/controller/lenderController';

const router = new Hono();

router.post("/register/:userId", lenderController.registerLenderAccount)

router.post("/terms/create", lenderController.createLenderTermsCondition)

router.get("/terms/my/:lenderId", lenderController.getMyTermsConditionById)

router.put("/terms/update/:id", lenderController.updateTermsConditionById)

export default router;