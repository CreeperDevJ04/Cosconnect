import { Timestamp } from "firebase-admin/firestore";

// Response types
export type HeartPostResponse = {
    success: boolean;
    message: string;
    data?: {
        totalHearts: number;
        userHasLiked: boolean;
        heartId?: string;
    };
    error?: string;
};

// Heart data structure for Firestore
export type HeartData = {
    userId: string;
    userName: string;
    userEmail: string;
    userAvatarUrl?: string;
    postId: string;
    postAuthor: string;
    createdAt: Timestamp;
    updatedAt: Timestamp;
};
// Your existing types
export interface CommentFormData {
    content: string
    images: string[]
}

export interface Commenter {
    userId: string
    username: string
    userEmail: string
    userAvatarUrl?: string
}

export interface PostAuthor {
    id: string
    name: string
    avatar: string
    role: string
}

export interface CommentPayload {
    postId: string
    postAuthorId: PostAuthor
    comment: CommentFormData
    commenter: Commenter
}

// Comment document structure for Firestore
export interface CommentDocument {
    id: string
    postId: string
    postAuthorId: {
        id: string
        name: string
        avatar: string
        role: string
    }
    commenter: {
        userId: string
        username: string
        userEmail: string
        userAvatarUrl?: string
    }
    content: string
    images: string[]
    createdAt: Timestamp
    updatedAt: Timestamp
    isDeleted: boolean
    likesCount: number
    repliesCount: number
}
