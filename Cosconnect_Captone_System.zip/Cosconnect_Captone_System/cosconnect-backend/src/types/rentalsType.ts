export interface CostumeType {
    type: string;
    price: string;
    image?: string;
}

export interface MainOffer {
    type: string;
    price: string;
    image?: string;
}

export interface SelectedAddOn {
    id: string;
    name: string;
    image: string;
    price: string;
    description: string;
}

export interface SelectedItems {
    mainOffer: {
        selected: boolean;
        data: MainOffer | null;
    };
    selectedCostumeType: {
        selected: boolean;
        data: CostumeType | null;
    };
    selectedAddOns: SelectedAddOn[];
}

// Updated interface to match the actual frontend data structure
export interface ScheduleFormData {
    rental_id: string;
    costume_id: string;
    borrower_user_id: string;
    lender_user_id: string;
    rental: {
        startDate: string; // ISO date
        endDate: string;   // ISO date
        totalDays: number;
        selectedItems: SelectedItems;
        pricing: {
            dailyRate: number;
            totalCost: number;
            currency: string;
        };
    };
    metadata: {
        conversationId: string;
        createdAt: string; // ISO date
    };
}


// src/types/RentalTransaction.ts

export interface RentalTransaction {
    borrower: {
        uid: string;
        fullName: string;
        email: string;
        phoneNumber: string;
    };
    paymentDetails: {
        amount: number;
        currency: string;
        paymentMethod: string;
        termsAccepted: boolean;
        timestamp: string;
    };
    rental: {
        conversationId: string;
        dailyRate: number;
        startDate: string;
        endDate: string;
        lenderId: string;
        lenderUsername: string;
        productId: string;
        productName: string;
        selectedItems: {
            main_offer: Record<string, any>;
            costume_type: Record<string, any>;
            add_ons: Array<Record<string, any>>;
        };
        totalCost: number;
        totalDays: number;
    };
}

// New simplified payment request interface
export interface PaymentRequest {
    conversation_id: string;
    rental_id: string;
    payment_method: string;
    terms_accepted: boolean;
}

// Payment result interface
export interface PaymentResult {
    success: boolean;
    rental_id?: string;
    payment_intent_id?: string;
    status?: 'pending' | 'paid' | 'cancelled' | 'failed' | 'expired' | 'refunded';
    amount?: number;
    currency?: string;
    payment_method?: string;
    checkout_url?: string;
    error?: string;
}