import { BusinessInfo, Identification, PersonalInfo } from './lenderTypes';
import { Context } from 'hono';

declare module 'hono' {
  interface ContextVariableMap {
    user?: {
      uid: string;
      email: string | null;
      fullName?: string;
      username?: string;
      businessName?: string;
      role: 'lender' | 'borrower' | 'admin';
      businessInfo?: BusinessInfo;
      identification?: Identification;
      personalInfo?: Omit<PersonalInfo, 'password'>;
      phoneNumber?: string;
      address?: string;
    }
  }
}

export {};
