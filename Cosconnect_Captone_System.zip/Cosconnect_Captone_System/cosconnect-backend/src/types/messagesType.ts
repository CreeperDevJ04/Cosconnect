export interface User {
  id: string;
  name: string;
  avatar: string;
  isOnline: boolean;
}

export interface Message {
  id: string;
  content: string;
  senderId: string;
  timestamp: Date;
  isRead: boolean;
  type: 'text' | 'image' | 'file';
}

export interface Conversation {
  id: string;
  participants: User[];
  lastMessage: Message;
  unreadCount: number;
  updatedAt: Date;
  messages: Message[];
}

export interface MessageFormData {
  content: string;
}

export type ProductReservationPayload = {
  dailyRate: number;
  totalCost: number;
  totalDays: number;
  startDate: Date; // or string, depending on serialization
  endDate: Date;   // or string

  productDetails: {
    id: string;
    lenderId: string;
    lenderUsername: string;
    name: string;
  };

  selectedItems: {
    mainOffer: boolean;
    selectedAddOns: string[]; // assuming IDs or names
    selectedProductType: string | null;
  };
};


export interface BorrowerInquiry {
  borrowerId: string;
  borrowerInfo: {
    id: string;
    username: string;
    name?: string;
    email?: string;
    profileImage?: string;
    phoneNumber: string;
    region: string;
    city: {
      id: string;
      name: string;
    };
  };
  lastMessage: {
    content: string;
    timestamp: any;
    messageId: string;
    costumeDetails?: {
      id: string;
      name: string;
      category: string;
      images: string[];
      price: number | null;
      size: string | null;
    };
    messageType: string;
    isRead: boolean;
  };
  unreadCount: number;
  totalMessages: number;
  conversationId: string;
}

export interface ConversationMessage {
  id: string;
  content: string;
  senderId: string;
  receiverId: string;
  senderUsername: string;
  receiverUsername: string;
  timestamp: any;
  createdAt: string;
  isRead: boolean;
  messageType: string;
  conversationId: string;
  participants: string[];
  costumeDetails?: {
    id: string;
    name: string;
    category: string;
    images: string[];
    price: number | null;
    size: string | null;
  };
  costumeId?: string;
  costumeName?: string;
}


export type ConversationDataType = {
  id: string;
  conversationId: string;
  costumeId: string;
  costumeName: string;
  isRead: boolean;
  message: string;
  messageType: 'inquiry' | 'text' | string;
  receiverId: string;
  receiverUsername: string;
  senderId: string;
  senderUsername: string;
  timestamp: Date;
};
