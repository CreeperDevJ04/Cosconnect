export interface BorrowerPersonalInfoFormDataType {
    first_name: string;
    middle_name: string;
    last_name: string;
    username: string;
    email: string;
    phone_number: string;
    bio: string;
    birth_date: string;
    street: string;
    barangay: string;
    zip_code: string;
    country: string;
    region: string;
    province: string;
    city: {
        id: string;
        name: string;
    };
}



