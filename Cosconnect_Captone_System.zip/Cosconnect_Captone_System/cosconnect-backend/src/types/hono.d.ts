// src/types/hono.d.ts
import { Context } from 'hono';

export interface UserRequest {
    uid: string;
    email: string | null;
    fullName: string;
    username: string;
}

declare module 'hono' {
    interface ContextVariableMap {
        user: UserRequest;
    }

    interface Env {
        Variables: {
            user: UserRequest;
        };
    }

    interface HonoRequest {
        user?: UserRequest;
    }
}