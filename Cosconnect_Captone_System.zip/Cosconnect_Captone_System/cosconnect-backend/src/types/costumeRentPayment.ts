
export interface PaymentData {
    borrower: {
        uid: string;
        fullName: string;
        email: string;
        phoneNumber: string;
    };
    rental: {
        productId: string;
        productName: string;
        lenderId: string;
        lenderUsername: string;
        startDate: string;
        endDate: string;
        totalDays: number;
        dailyRate: number;
        totalCost: number;
        conversationId: string;
        selectedItems: {
            mainOffer: boolean;
            selectedProductType: string | null;
            selectedAddOns: string[];
        };
    };
    paymentDetails: {
        amount: number;
        currency: string;
        paymentMethod: string;
        termsAccepted: boolean;
        timestamp: string;
    };
}


export type CostumeRentSchedulePayload = {
    conversationId: string;
    dailyRate: number;
    totalCost: number;
    totalDays: number;
    lenderUid: string;
    borrowerUid: string;
    startDate: Date | string;
    endDate: Date | string;
    productDetails: {
        id: string;
        lenderId: string;
        lenderUsername: string;
        name: string;
    };
    selectedItems: {
        mainOffer: boolean;
        selectedAddOns: string[];
        selectedProductType: string | null;
    };
};
