// types/lender-form-data-type.ts

export interface PersonalInfo {
    first_name: string;
    last_name: string;
    full_name: string;
    username: string;
    email: string;
    phone_number: string;
}

export type ValidIdType =
    | 'NATIONAL_ID'
    | 'DRIVERS_LICENSE'
    | 'PASSPORT'
    | 'SSS_ID'
    | 'PHILHEALTH_ID'
    | 'VOTERS_ID'
    | 'TIN_ID'
    | 'POSTAL_ID'
    | 'UMID'
    | 'PRC_ID';

export interface Identification {
    has_valid_id: boolean;
    valid_id_type: ValidIdType;
    valid_id_number: string;
    valid_id_file: string;
    selfie_with_id: string;
}

export interface BaseBusinessInfo {
    business_name: string;
    business_email: string;
    business_description: string;
    business_phone_number: string;
    business_telephone?: string;
    business_address?: string;
    street: string;
    barangay: string;
    city: {
        id: string;
        name: string;
    };
    province: string;
    region: string;
    zip_code: string;
    terms_and_conditions: 'Accepted';
}

export interface IndividualBusinessInfo extends BaseBusinessInfo {
    business_type: 'INDIVIDUAL';
}

export interface RegisteredBusinessInfo extends BaseBusinessInfo {
    business_type: 'STORE';
    upload_dti_certificate: string;
    upload_business_permit: string;
    upload_storefront_photo: string;
}

export type BusinessInfo = IndividualBusinessInfo | RegisteredBusinessInfo;

export interface LenderFormDataType {
    personal_info: PersonalInfo;
    identification: Identification;
    business_info: BusinessInfo;

}
