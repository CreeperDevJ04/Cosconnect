export type PostDataType = {
    author: {
        id: string;
        name: string;
        role: string;
        avatar: string;
    };
    content: string;
    images: string[];
};


type GetCommunityPostData = {
    author: {
        id: string;
        name: string;
        role: string;
        avatar: string;
    };
    content: string;
    comments: number;
    createdAt: string; // or Date if you plan to convert timestamps
    updatedAt: string; // or Date
    heartCount: number;
    likes: number;
    isLiked: boolean;
    images: string[];
};

