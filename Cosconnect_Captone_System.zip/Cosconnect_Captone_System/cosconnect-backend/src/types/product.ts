export interface Product {
    id: string;
    name: string;
    brand: string;
    category: string;
    description: string;
    discount: number;
    gender: 'male' | 'female' | 'unisex';
    regularPrice: number;
    stock: number;
    weight: number;
    tags: string[];
    mainImages: {
        front: string;
        back: string;
    };
    additionalImages: {
        url: string;
        order: number;
    }[];
    lenderUser: {
        businessName: string;
        email: string;
        fullName: string;
        role: 'lender';
        uid: string;
        username: string;
    };

    deliveryOptions: ('pickup' | 'delivery')[];
    sizes: string[];
    colors: string[];
    addOns?: {
        id: string;
        name: string;
        description: string;
        price: string; // validated as non-negative string number
        image?: any | null;
    }[];
    createdAt: string;
    updatedAt: string;
    status: string;
}
