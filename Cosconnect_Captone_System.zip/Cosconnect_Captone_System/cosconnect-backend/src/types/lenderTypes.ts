export const primaryIdTypes = [
  "NATIONAL_ID",
  "PASSPORT",
  "DRIVERS_LICENSE",
  "UMID",
  "SSS_ID",
  "GSIS_ID",
  "PRC_ID",
  "POSTAL_ID",
  "PHILHEALTH_ID",
  "VOTERS_ID",
  "SENIOR_CITIZEN_ID",
  "PWD_ID",
  "INTEGRATED_BAR_ID",
  "OFW_ID",
] as const;

export const secondaryIdTypes = [
  "BARANGAY_ID",
  "POLICE_CLEARANCE",
  "NBI_CLEARANCE",
  "BIRTH_CERTIFICATE",
  "TIN_ID",
  "PAGIBIG_ID",
  "COMPANY_ID",
  "SCHOOL_ID",
  "POSTAL_ID",
  "BRGY_CLEARANCE",
  "CEDULA",
  "INSURANCE_ID",
  "BIR_ID",
  "OWWA_ID",
  "MARINA_ID",
] as const;

// ✅ Types from constants
export type PrimaryIdType = (typeof primaryIdTypes)[number];
export type SecondaryIdType = (typeof secondaryIdTypes)[number];

// ✅ Business Info Type
export type BusinessInfo = {
  businessName: string;
  businessAddress: string;
  businessPermitNumber?: string;
  businessPermitFile?: string;
  businessType: 'INDIVIDUAL' | 'CORPORATION' | string;
  businessDescription: string;
  businessPhoneNumber?: string;
  street: string;
  zipCode: string;
  province: string;
  city: string;
  region: string;
  country: string;
  selfieWithId?: string;
  barangay: string;
};

// ✅ Identification Type (handles both primary & secondary IDs)
export type Identification = {
  hasValidId: boolean;

  // If true
  validIdType?: PrimaryIdType;
  validIdNumber?: string;
  validIdFile?: string;

  // If false
  secondaryIdType1?: SecondaryIdType;
  secondaryIdType2?: SecondaryIdType;
  secondaryIdFile1?: string;
  secondaryIdFile2?: string;
};

// ✅ Personal Info Type
export type PersonalInfo = {
  fullName: string;
  username: string;
  email: string;
  password: string;

};

// ✅ Combined Form Type
export type UserFormData = {
  businessInfo: BusinessInfo;
  identification: Identification;
  personalInfo: PersonalInfo;
  otpCode: string;
};




export type ProductDataType = {
  name: string;
  brand: string;
  category: string;
  description: string;
  discount: number;
  gender: 'male' | 'female' | 'unisex';
  regularPrice: number;
  selectedColor: string;
  selectedSize: 'XS' | 'S' | 'M' | 'L' | 'XL';
  stock: number;
  weight: number;
  tags: string[];
  mainImages: {
    front: string;
    back: string;
  };
  additionalImages: Array<{
    url: string;
    order: number;
  }>;
};