// types/CreateCostumeFormDataType.ts

export type AddOnType = {
    id: string;
    name: string;
    description: string;
    price: string;
    image: string;
};

export type AdditionalImageType = {
    url: string;
    order: number;
};

export type CostumeTypeOption = {
    type: string; // e.g., 'full_set_costume_shoes'
    price: string;
};

export type MainImagesType = {
    front: string;
    back: string;
};

export type LenderUserType = {
    uid: string;
    username: string;
    email: string;
};

export type OfferType = {
    type: string;
    price: string;
};

export interface CreateCostumeFormDataType {
    name: string;
    description: string;
    category: string;
    brand: string;
    sizes: string;
    gender: 'male' | 'female' | 'unisex';
    tags: string[];
    extended_days: string;
    discount: string;
    security_deposit: string;
    sale_price: string;
    listingType: 'rent' | 'sell' | 'both';
    selectedCostumeType: string;
    mainImages: MainImagesType;
    additionalImages: AdditionalImageType[];
    costumeType: CostumeTypeOption[];
    mainOffer: OfferType;
    addOns: AddOnType[];
    lenderUser: LenderUserType;
}
