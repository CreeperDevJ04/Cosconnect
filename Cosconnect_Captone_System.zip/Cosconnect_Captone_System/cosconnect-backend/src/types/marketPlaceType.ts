export interface MarketPlacePostDataType {
    id: string;
    author: {
        id: string;
        name: string;
        avatar: string;
        role: "borrower" | "admin" | "lender" | string; // Adjust as needed
    };
    content: string;
    images: string[];
    likes: number;
    isLiked: boolean;
    comments: number;
    createdAt: any; // Depending on how you parse it
}


// Validation schema for request body
export interface CreatePostRequest {
    author: {
        id: string;
        name: string;
        avatar: string;
        role: "borrower" | "admin" | "lender" | string;
    };
    content: string;
    images?: string[];
}

// Response types
export interface CreatePostResponse {
    success: boolean;
    data?: MarketPlacePostDataType;
    error?: string;
}