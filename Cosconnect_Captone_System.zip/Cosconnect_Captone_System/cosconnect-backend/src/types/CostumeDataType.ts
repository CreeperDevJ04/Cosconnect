export interface AddOnV3 {
    id: string;
    name: string;
    description: string;
    image: string;
    price: string;
}

export interface AdditionalImageV3 {
    order: number;
    url: string;
}

export interface OfferV3 {
    type: string;
    price: string;
}

export interface LenderUserV3 {
    email: string;
    uid: string;
    username: string;
}

export interface MainImagesV3 {
    front: string;
    back: string;
}

export interface MainOfferV3 {
    type: string;
    price: string;
}

export interface CostumeDataV3 {
    addOns: AddOnV3[];
    additionalImages: AdditionalImageV3[];
    brand: string;
    category: string;
    colors: string;
    costumeOffers: OfferV3[];
    description: string;
    discount: string;
    gender: string;
    lenderUser: LenderUserV3;
    mainImages: MainImagesV3;
    mainOffer: MainOfferV3;
    name: string;
    sizes: string;
    tags: string[];
}