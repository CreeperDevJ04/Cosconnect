export interface InquiryMessageFormDataType {
    costumeName: string;
    lenderId: string;
    lenderUsername: string;
    borrowerId: string;
    borrowerUsername: string;
    costumeId: string;
    timestamp?: string;
    conversationId: string
}

// Constants
export const INQUIRY_MESSAGE_TEMPLATE = (costumeName: string): string => {
    return `Hi! I'm interested in renting your "${costumeName}" costume. Is it still available?`;
};

// Types for better type safety
export interface InquiryResponse {
    success: boolean;
    message: string;
    conversationId: string;
    isNewConversation: boolean;
    inquiryMessage?: string;
    error?: string;
}

export interface ValidationError {
    field: string;
    message: string;
}
