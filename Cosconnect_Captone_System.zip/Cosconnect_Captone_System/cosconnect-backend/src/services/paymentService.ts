// messageController.ts - FIXED VERSION
import axios from 'axios';
import { eq } from 'drizzle-orm';
import { db } from '../db/supabase/db_connect';
import { costumes } from '../schema/costumes';
import { users } from '../schema/users';
import { payment_history } from '../utils/payment_history';
import { rentals } from '../utils/rentals';
import { rental_requests } from '../utils/rentals_request';

// Payment configuration - ONLY DECLARE ONCE IN YOUR ENTIRE PROJECT
const PAYMONGO_API_URL = 'https://api.paymongo.com/v1';
const PAYMONGO_SECRET_KEY = process.env.PAYMONGO_SECRET_KEY || "";

// Environment variables
const FRONTEND_URL = process.env.FRONTEND_URL || 'http://localhost:3000';

// Types
export type PaymentStatus = 'pending' | 'paid' | 'cancelled' | 'failed' | 'expired' | 'refunded';




// Helper function to get authorization header - ONLY DECLARE ONCE
const getAuthHeader = (): string => {
    if (!PAYMONGO_SECRET_KEY) {
        throw new Error('PAYMONGO_SECRET_KEY is not configured');
    }
    return `Basic ${Buffer.from(PAYMONGO_SECRET_KEY + ':').toString('base64')}`;
};


// Helper function to normalize GCash number
const normalizeGCashNumber = (gcashNumber: string): string => {
    // Remove all non-digit characters
    const digitsOnly = gcashNumber.replace(/\D/g, '');

    // Handle different formats:
    // +639516073901 -> 09516073901
    // 639516073901 -> 09516073901  
    // 09516073901 -> 09516073901
    if (digitsOnly.length === 12 && digitsOnly.startsWith('63')) {
        // Format: 639516073901 -> 09516073901
        return '0' + digitsOnly.substring(2);
    } else if (digitsOnly.length === 11 && digitsOnly.startsWith('09')) {
        // Format: 09516073901 -> 09516073901 (already correct)
        return digitsOnly;
    } else if (digitsOnly.length === 10 && digitsOnly.startsWith('9')) {
        // Format: 9516073901 -> 09516073901
        return '0' + digitsOnly;
    }

    // Return as-is if none of the above patterns match
    return digitsOnly;
};

type TransferMoneyPayload = {
    accountName: string;
    amount: number;
    gcashNumber: string;
    borrowerId?: string;
    lenderId?: string;
    notes: string;
    rentalId: string;
    type: 'refund' | 'payout';
};

interface PayMongoWalletTransaction {
    data: {
        id: string;
        type: string;
        attributes: {
            amount: number;
            currency: string;
            description: string;
            status: string;
            livemode: boolean;
            created_at: number;
            updated_at: number;
            reference_number: string;
            source: {
                id: string;
                type: string;
            };
            balance_transaction_id: string;
            fee: number;
            remarks: string;
            statement_descriptor: string;
            network: 'pesonet' | 'instapay';
            recipient_name: string;
            recipient_account_number: string;
            recipient_bank_code: string;
        };
    };
}

export const paymongoService = {
    // Create wallet transaction for GCash transfers using PayMongo's send_money API
    createWalletTransaction: async (
        walletId: string,
        amount: number,
        recipientAccountNumber: string,
        recipientName: string,
        description: string,
        purpose: string = 'Invoice settlement'
    ) => {
        try {
            const amountInCentavos = Math.round(amount * 100);
            console.log(`[PayMongo] Creating wallet transaction: ${amount} PHP to ${recipientAccountNumber}`);

            // Using the correct PayMongo send_money API format
            const requestData = {
                data: {
                    attributes: {
                        amount: amountInCentavos,
                        provider: "gcash",
                        type: "send_money",
                        receiver: {
                            bank_account_name: recipientName,
                            bank_account_number: recipientAccountNumber,
                            bank_code: "GCASH"
                        },
                        callback_url: `${FRONTEND_URL}/api/paymongo/callback`,
                        description: description,
                        purpose: purpose
                    }
                }
            };

            console.log('[PayMongo] Request data:', JSON.stringify(requestData, null, 2));

            const response = await axios.post(
                `${PAYMONGO_API_URL}/wallets/${walletId}/transactions`,
                requestData,
                {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': getAuthHeader()
                    }
                }
            );

            console.log(`[PayMongo] Wallet transaction created successfully: ${response.data.data.id}`);
            return response.data as PayMongoWalletTransaction;
        } catch (error: any) {
            console.error('[PayMongo] Error creating wallet transaction:', {
                message: error.message,
                response: error.response?.data,
                status: error.response?.status
            });

            if (error.response?.data?.errors) {
                const paymongoError = error.response.data.errors[0];
                throw new Error(`PayMongo Error: ${paymongoError.detail || paymongoError.title}`);
            }
            throw new Error(`Failed to create wallet transaction: ${error.message}`);
        }
    },

    // Get available wallets
    getWallets: async () => {
        try {
            console.log('[PayMongo] Fetching available wallets');
            const response = await axios.get(
                `${PAYMONGO_API_URL}/wallets`,
                {
                    headers: {
                        'Authorization': getAuthHeader()
                    }
                }
            );
            console.log('[PayMongo] Wallets fetched successfully');
            return response.data;
        } catch (error: any) {
            console.error('[PayMongo] Error fetching wallets:', {
                message: error.message,
                response: error.response?.data,
                status: error.response?.status
            });
            throw new Error(`Failed to fetch wallets: ${error.message}`);
        }
    },

    // Create a new wallet if none exists
    createWallet: async (name: string = 'Primary Wallet') => {
        try {
            console.log('[PayMongo] Creating new wallet:', name);
            const requestData = {
                data: {
                    attributes: {
                        name: name,
                        description: 'Auto-created wallet for transactions'
                    }
                }
            };

            const response = await axios.post(
                `${PAYMONGO_API_URL}/wallets`,
                requestData,
                {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': getAuthHeader()
                    }
                }
            );

            console.log(`[PayMongo] Wallet created successfully: ${response.data.data.id}`);
            return response.data;
        } catch (error: any) {
            console.error('[PayMongo] Error creating wallet:', {
                message: error.message,
                response: error.response?.data,
                status: error.response?.status
            });

            if (error.response?.data?.errors) {
                const paymongoError = error.response.data.errors[0];
                throw new Error(`PayMongo Error: ${paymongoError.detail || paymongoError.title}`);
            }
            throw new Error(`Failed to create wallet: ${error.message}`);
        }
    }
};

// Main payment service function - UPDATED with proper wallet handling
export const walletSendMoney = async (payload: TransferMoneyPayload) => {
    try {
        console.log('[walletSendMoney] Processing request:', JSON.stringify(payload, null, 2));

        // Validate payload
        if (!payload.accountName || !payload.amount || !payload.gcashNumber || !payload.rentalId) {
            const error = 'Missing required fields: accountName, amount, gcashNumber, or rentalId';
            console.error('[walletSendMoney] Validation error:', error);
            return {
                success: false,
                error: error,
                details: {
                    missingFields: [
                        !payload.accountName ? 'accountName' : null,
                        !payload.amount ? 'amount' : null,
                        !payload.gcashNumber ? 'gcashNumber' : null,
                        !payload.rentalId ? 'rentalId' : null
                    ].filter(Boolean)
                }
            };
        }

        if (payload.amount <= 0) {
            const error = 'Amount must be greater than zero';
            console.error('[walletSendMoney] Validation error:', error);
            return {
                success: false,
                error: error
            };
        }

        // Normalize GCash number to handle +63 format
        const normalizedGCashNumber = normalizeGCashNumber(payload.gcashNumber);
        console.log(`[walletSendMoney] Original GCash number: ${payload.gcashNumber}, Normalized: ${normalizedGCashNumber}`);

        // Validate normalized GCash number format (Philippine standard: 11 digits starting with 09)
        if (!/^09\d{9}$/.test(normalizedGCashNumber)) {
            const error = `Invalid GCash number format. Expected format: 09XXXXXXXXX (11 digits). Received: ${normalizedGCashNumber}`;
            console.error('[walletSendMoney] GCash number validation error:', error);
            return {
                success: false,
                error: error
            };
        }

        // Check if rental exists
        console.log(`[walletSendMoney] Checking if rental exists: ${payload.rentalId}`);
        try {
            const [rentalResult] = await db
                .select({
                    id: rentals.id
                })
                .from(rentals)
                .where(eq(rentals.id, payload.rentalId))
                .execute();

            if (!rentalResult) {
                const error = `Rental not found with ID: ${payload.rentalId}`;
                console.error('[walletSendMoney] Rental validation error:', error);
                return {
                    success: false,
                    error: error
                };
            }

            console.log(`[walletSendMoney] Rental found: ${payload.rentalId}`);
        } catch (dbError: any) {
            console.error('[walletSendMoney] Database query error:', {
                message: dbError.message,
                stack: dbError.stack
            });
            return {
                success: false,
                error: 'Database connection error',
                details: {
                    message: dbError.message
                }
            };
        }

        // Skip wallet API and go directly to manual processing for now
        console.log('[walletSendMoney] Using manual processing (Wallet API temporarily disabled)');

        // Prepare payout data for manual processing
        const payoutData = {
            accountName: payload.accountName,
            amount: payload.amount,
            gcashNumber: normalizedGCashNumber,
            originalGCashNumber: payload.gcashNumber,
            notes: payload.notes,
            processedAt: new Date().toISOString(),
            status: 'pending_manual_processing',
            payoutMethod: 'gcash_manual',
            reason: 'Manual processing - Wallet API requires setup'
        };

        // Determine update fields based on payload type
        let updateFields = {};
        if (payload.type === 'refund' && payload.borrowerId) {
            updateFields = {
                security_deposit_refund_borrower: {
                    ...payoutData,
                    borrowerId: payload.borrowerId
                }
            };
        } else if (payload.type === 'payout' && payload.lenderId) {
            updateFields = {
                payout_cashout_lender: {
                    ...payoutData,
                    lenderId: payload.lenderId
                }
            };
        } else {
            const error = 'Invalid payload type or missing user ID';
            console.error('[walletSendMoney] Field validation error:', {
                type: payload.type,
                borrowerId: payload.borrowerId,
                lenderId: payload.lenderId
            });
            return {
                success: false,
                error: error
            };
        }

        // Update the rental record
        console.log(`[walletSendMoney] Updating rental record for manual processing: ${payload.rentalId}`);
        try {
            const updateResult = await db
                .update(rentals)
                .set({
                    ...updateFields,
                    updated_at: new Date()
                })
                .where(eq(rentals.id, payload.rentalId))
                .execute();

            // Check if the update was successful
            const [updatedRental] = await db
                .select({
                    id: rentals.id
                })
                .from(rentals)
                .where(eq(rentals.id, payload.rentalId))
                .execute();

            if (!updatedRental) {
                const error = 'Failed to update rental record';
                console.error('[walletSendMoney] Database update error:', error);
                return {
                    success: false,
                    error: error
                };
            }

            console.log(`[walletSendMoney] Manual processing recorded for rental ${payload.rentalId}`);

            // Return success response for manual processing
            return {
                success: true,
                message: 'GCash transfer recorded for manual processing. Please process this payment manually through your GCash account.',
                data: {
                    rentalId: payload.rentalId,
                    type: payload.type,
                    amount: payload.amount,
                    status: 'pending_manual_processing',
                    gcashNumber: normalizedGCashNumber,
                    originalGCashNumber: payload.gcashNumber,
                    accountName: payload.accountName,
                    notes: payload.notes,
                    processedAt: new Date().toISOString(),
                    instructions: `Please send ₱${payload.amount} to GCash number ${normalizedGCashNumber} (${payload.accountName}) for rental ${payload.rentalId}`
                }
            };

        } catch (dbError: any) {
            console.error('[walletSendMoney] Database update error:', {
                message: dbError.message,
                stack: dbError.stack
            });
            return {
                success: false,
                error: 'Failed to update rental record',
                details: {
                    message: dbError.message
                }
            };
        }

    } catch (error: any) {
        console.error('[walletSendMoney] Unexpected error:', {
            message: error.message,
            stack: error.stack,
            details: error.details || null
        });
        return {
            success: false,
            error: error.message || 'Failed to process money transfer',
            details: {
                message: error.message,
                stack: error.stack
            }
        };
    }
};

// Alternative function that tries to use wallet API with proper error handling
export const walletSendMoneyWithAPI = async (payload: TransferMoneyPayload) => {
    try {
        console.log('[walletSendMoneyWithAPI] Processing request:', JSON.stringify(payload, null, 2));

        // ... (same validation code as above) ...

        // Normalize GCash number to handle +63 format
        const normalizedGCashNumber = normalizeGCashNumber(payload.gcashNumber);
        console.log(`[walletSendMoneyWithAPI] Original GCash number: ${payload.gcashNumber}, Normalized: ${normalizedGCashNumber}`);

        // Validate normalized GCash number format
        if (!/^09\d{9}$/.test(normalizedGCashNumber)) {
            const error = `Invalid GCash number format. Expected format: 09XXXXXXXXX (11 digits). Received: ${normalizedGCashNumber}`;
            console.error('[walletSendMoneyWithAPI] GCash number validation error:', error);
            return {
                success: false,
                error: error
            };
        }

        // Attempt to use Wallet Transactions API
        console.log('[walletSendMoneyWithAPI] Attempting GCash ~transfer via Wallet Transactions API');

        try {
            // First, get available wallets
            const wallets = await paymongoService.getWallets();

            console.log('[walletSendMoneyWithAPI] Available wallets:', JSON.stringify(wallets, null, 2));

            let primaryWallet = null;

            // Check if we have any wallets
            if (!wallets.data || wallets.data.length === 0) {
                console.log('[walletSendMoneyWithAPI] No wallets found. This is expected for new PayMongo accounts.');

                // For now, throw an error with instructions
                throw new Error(
                    'No wallets found in your PayMongo account. ' +
                    'Please create a wallet in your PayMongo dashboard first. ' +
                    'Go to: https://dashboard.paymongo.com/wallets and create a new wallet.'
                );
            } else {
                // Find an active wallet
                primaryWallet = wallets.data.find((wallet: any) =>
                    wallet.attributes?.status === 'active' ||
                    wallet.attributes?.is_primary === true
                ) || wallets.data[0]; // Use first available wallet as fallback
            }

            if (!primaryWallet) {
                throw new Error('No active wallet found for transactions');
            }

            const walletId = primaryWallet.id;
            console.log(`[walletSendMoneyWithAPI] Using wallet: ${walletId}`);

            // Create wallet transaction for GCash transfer using normalized number
            const transaction = await paymongoService.createWalletTransaction(
                walletId,
                payload.amount,
                normalizedGCashNumber,
                payload.accountName,
                payload.notes || `GCash transfer for rental ${payload.rentalId}`,
                `${payload.type === 'refund' ? 'Security deposit refund' : 'Rental payout'} for rental ${payload.rentalId}`
            );

            const transactionId = transaction.data.id;
            const transactionStatus = transaction.data.attributes.status;
            const transactionReference = transaction.data.attributes.reference_number || transaction.data.id;

            console.log(`[walletSendMoneyWithAPI] Wallet transaction created: ID=${transactionId}, Status=${transactionStatus}, Reference=${transactionReference}`);

            // ... (rest of the success handling code) ...

            return {
                success: true,
                message: 'GCash transfer initiated successfully via Wallet Transactions API',
                data: {
                    rentalId: payload.rentalId,
                    type: payload.type,
                    amount: payload.amount,
                    status: transactionStatus,
                    transactionId: transactionId,
                    referenceNumber: transactionReference,
                    gcashNumber: normalizedGCashNumber,
                    originalGCashNumber: payload.gcashNumber,
                    processedAt: new Date().toISOString()
                }
            };

        } catch (apiError: any) {
            console.error('[walletSendMoneyWithAPI] Wallet API failed:', {
                message: apiError.message,
                stack: apiError.stack
            });

            // Fall back to manual processing
            return await walletSendMoney(payload);
        }

    } catch (error: any) {
        console.error('[walletSendMoneyWithAPI] Unexpected error:', {
            message: error.message,
            stack: error.stack
        });

        // Fall back to manual processing
        return await walletSendMoney(payload);
    }
};

// Validate required environment variables
const validateEnvironment = (): void => {
    if (!PAYMONGO_SECRET_KEY) {
        throw new Error('PAYMONGO_SECRET_KEY environment variable is required');
    }
    if (!FRONTEND_URL) {
        throw new Error('FRONTEND_URL environment variable is required');
    }
};

// Create redirect URLs for payment flow
const createRedirectUrls = (rentalRequestId: string) => {
    return {
        success_url: `${FRONTEND_URL}/payment/success?rental_request_id=${rentalRequestId}`,
        cancel_url: `${FRONTEND_URL}/payment/cancel?rental_request_id=${rentalRequestId}`,
    };
};

// Create PayMongo checkout session
export const createRentalCheckoutSession = async (
    rentalRequestId: string,
    amount: number,
    currency: string = 'PHP',
    productName: string
): Promise<any> => {
    try {
        validateEnvironment();

        const redirectUrls = createRedirectUrls(rentalRequestId);

        // Prepare PayMongo checkout session payload
        const payload = {
            data: {
                attributes: {
                    line_items: [
                        {
                            amount: Math.round(amount * 100), // PayMongo expects cents
                            currency: currency,
                            name: `Rental payment for ${productName}`,
                            quantity: 1,
                        }
                    ],
                    payment_method_types: ['gcash', 'card'],
                    success_url: redirectUrls.success_url,
                    cancel_url: redirectUrls.cancel_url,
                    description: `Rental payment for ${productName}`,
                    metadata: {
                        rentalRequestId: rentalRequestId,
                        productName: productName,
                    }
                }
            }
        };

        const response = await axios.post(
            `${PAYMONGO_API_URL}/checkout_sessions`,
            payload,
            {
                headers: {
                    'Authorization': getAuthHeader(),
                    'Content-Type': 'application/json'
                }
            }
        );

        return response.data;
    } catch (error: any) {
        if (axios.isAxiosError(error)) {
            const errorDetail = error.response?.data?.errors?.[0]?.detail || 'Unknown PayMongo error';
            throw new Error(`PayMongo API Error: ${errorDetail}`);
        }
        throw new Error(`Failed to create checkout session: ${error.message}`);
    }
};

// Process rental payment - main function
export const processRentalPayment = async (rentalRequestId: string): Promise<PaymentResult> => {
    try {
        // Validate input data
        if (!rentalRequestId || typeof rentalRequestId !== 'string') {
            throw new Error('Rental request ID is required');
        }

        // 1. Get rental request details from database
        const rentalRequestData = await db
            .select()
            .from(rental_requests)
            .where(eq(rental_requests.id, rentalRequestId))
            .limit(1);

        if (rentalRequestData.length === 0) {
            throw new Error('Rental request not found');
        }

        const rentalRequest = rentalRequestData[0];
        if (!rentalRequest) {
            throw new Error('Rental request not found');
        }

        // Check if rental request is approved
        if (rentalRequest.status !== 'approved') {
            throw new Error(`Rental request is not approved. Current status: ${rentalRequest.status}`);
        }

        // Check if payment already exists
        if (rentalRequest.payment_history_id) {
            throw new Error('Payment already exists for this rental request');
        }

        // 2. Get costume details for better product naming
        const costumeData = await db
            .select({
                name: costumes.name,
                brand: costumes.brand,
                category: costumes.category
            })
            .from(costumes)
            .where(eq(costumes.id, rentalRequest.costume_id))
            .limit(1);

        const costume = costumeData[0];
        const productName = costume ? `${costume.name}${costume.brand ? ` - ${costume.brand}` : ''}` : 'Costume Rental';

        // 3. Create checkout session with PayMongo
        const amount = rentalRequest.estimated_total_amount / 100; // Convert from cents
        const currency = rentalRequest.currency;

        const checkoutResponse = await createRentalCheckoutSession(
            rentalRequestId,
            amount,
            currency,
            productName
        );

        console.log('PayMongo Response:', JSON.stringify(checkoutResponse, null, 2));

        // Handle different response structures
        const checkoutSession = checkoutResponse.data?.data || checkoutResponse.data;
        if (!checkoutSession) {
            throw new Error('Invalid response from PayMongo - no session data');
        }

        const sessionId = checkoutSession.id;
        const checkoutUrl = checkoutSession.attributes?.checkout_url;
        const paymentIntentId = checkoutSession.attributes?.payment_intent?.id;

        console.log('Checkout Session Created:', sessionId);
        console.log('Payment Intent ID:', paymentIntentId);
        console.log('Checkout URL:', checkoutUrl);

        if (!sessionId) {
            throw new Error('No session ID received from PayMongo');
        }

        if (!checkoutUrl) {
            throw new Error('No checkout URL received from PayMongo');
        }

        const finalSessionId = paymentIntentId || sessionId;
        const status: PaymentStatus = 'pending'; // Checkout sessions start as pending

        // 3. Store payment record in database
        const paymentData = {
            session_id: sessionId,
            payment_intent_id: finalSessionId,
            rental_id: rentalRequestId, // Use rental request ID as rental_id
            borrower_user_id: rentalRequest.borrower_user_id,
            lender_user_id: rentalRequest.lender_user_id,
            product_id: rentalRequest.costume_id,
            product_name: productName,
            amount: rentalRequest.estimated_total_amount, // Already in cents
            currency: currency,
            status: status,
            payment_type: 'online' as const,
            payment_method: 'checkout_session' as any,
            selected_items: rentalRequest.selected_items,
            metadata: checkoutSession.attributes?.metadata || {},
            description: `Rental payment for ${productName}`,
            success_url: `${FRONTEND_URL}/payment/success?rental_request_id=${rentalRequestId}`,
            cancel_url: `${FRONTEND_URL}/payment/cancel?rental_request_id=${rentalRequestId}`,
            created_at: new Date(),
            updated_at: new Date(),
        };

        const [newPaymentRecord] = await db.insert(payment_history).values(paymentData).returning();

        if (!newPaymentRecord) {
            throw new Error('Failed to create payment record');
        }

        // 4. Update rental request with payment history ID
        await db
            .update(rental_requests)
            .set({
                payment_history_id: newPaymentRecord.id,
                updated_at: new Date()
            })
            .where(eq(rental_requests.id, rentalRequestId));

        // 5. Return success response
        return {
            success: true,
            rental_id: rentalRequestId,
            payment_intent_id: finalSessionId,
            status,
            amount: rentalRequest.estimated_total_amount,
            currency,
            payment_method: 'checkout_session',
            checkout_url: checkoutUrl,
        };
    } catch (error: any) {
        console.error('Payment processing error:', error);

        return {
            success: false,
            error: error.message || 'Failed to process rental payment',
        };
    }
};

// Get payment status by rental ID
export const getPaymentStatus = async (rentalId: string): Promise<PaymentResult> => {
    try {
        const paymentRecord = await db
            .select()
            .from(payment_history)
            .where(eq(payment_history.rental_id, rentalId))
            .limit(1);

        if (paymentRecord.length === 0) {
            return {
                success: false,
                error: 'Payment record not found',
            };
        }

        const record = paymentRecord[0];

        if (!record) {
            return {
                success: false,
                error: 'Payment record is undefined',
            };
        }

        return {
            success: true,
            rental_id: record.rental_id,
            payment_intent_id: record.payment_intent_id,
            status: record.status,
            amount: record.amount,
            currency: record.currency,
            payment_method: record.payment_method,
        };
    } catch (error: any) {
        return {
            success: false,
            error: error.message || 'Failed to get payment status',
        };
    }
};



// Get payment session details from database
export const getPaymentSessionFromDB = async (sessionId: string) => {
    try {
        console.log('Getting payment session from database for:', sessionId);

        const paymentRecord = await db
            .select()
            .from(payment_history)
            .where(eq(payment_history.session_id, sessionId))
            .limit(1);

        if (paymentRecord.length === 0) {
            // Try searching by payment_intent_id as fallback
            const paymentRecordByIntent = await db
                .select()
                .from(payment_history)
                .where(eq(payment_history.payment_intent_id, sessionId))
                .limit(1);

            if (paymentRecordByIntent.length === 0) {
                return {
                    success: false,
                    error: 'Payment session not found in database'
                };
            }

            return {
                success: true,
                data: paymentRecordByIntent[0]
            };
        }

        return {
            success: true,
            data: paymentRecord[0]
        };
    } catch (error: any) {
        console.error('Error getting payment session from database:', error);
        return {
            success: false,
            error: error.message || 'Failed to get payment session from database'
        };
    }
};

// Update payment status in database
export const updatePaymentStatus = async (sessionId: string, newStatus: PaymentStatus) => {
    try {
        console.log(`Updating payment status for session ${sessionId} to ${newStatus}`);

        const [updatedPayment] = await db
            .update(payment_history)
            .set({
                status: newStatus,
                updated_at: new Date()
            })
            .where(eq(payment_history.session_id, sessionId))
            .returning();

        if (!updatedPayment) {
            // Try updating by payment_intent_id as fallback
            const [updatedPaymentByIntent] = await db
                .update(payment_history)
                .set({
                    status: newStatus,
                    updated_at: new Date()
                })
                .where(eq(payment_history.payment_intent_id, sessionId))
                .returning();

            if (!updatedPaymentByIntent) {
                return {
                    success: false,
                    error: 'Payment record not found for status update'
                };
            }

            return {
                success: true,
                data: updatedPaymentByIntent
            };
        }

        return {
            success: true,
            data: updatedPayment
        };
    } catch (error: any) {
        console.error('Error updating payment status:', error);
        return {
            success: false,
            error: error.message || 'Failed to update payment status'
        };
    }
};

// Import types from the types file
import type { PaymentRequest, PaymentResult } from '../types/rentalsType';

// Process payment with simplified interface - can find by conversation_id or rental_id
export const processSimplifiedPayment = async (paymentRequest: PaymentRequest): Promise<PaymentResult> => {
    try {
        // Validate input data
        if (!paymentRequest.conversation_id && !paymentRequest.rental_id) {
            throw new Error('Either conversation_id or rental_id is required');
        }

        if (!paymentRequest.terms_accepted) {
            throw new Error('Terms must be accepted to proceed with payment');
        }

        if (!paymentRequest.payment_method) {
            throw new Error('Payment method is required');
        }

        // Validate payment method
        const validPaymentMethods = ['gcash', 'card', 'paymaya', 'bank_transfer'];
        if (!validPaymentMethods.includes(paymentRequest.payment_method)) {
            throw new Error(`Invalid payment method. Must be one of: ${validPaymentMethods.join(', ')}`);
        }

        // 1. Find rental request by conversation_id or rental_id
        let rentalRequestData;

        if (paymentRequest.conversation_id) {
            // Find by conversation_id
            rentalRequestData = await db
                .select()
                .from(rental_requests)
                .where(eq(rental_requests.conversation_id, paymentRequest.conversation_id))
                .limit(1);
        } else {
            // Find by rental_id (which is actually the rental request id)
            rentalRequestData = await db
                .select()
                .from(rental_requests)
                .where(eq(rental_requests.id, paymentRequest.rental_id))
                .limit(1);
        }

        if (rentalRequestData.length === 0) {
            throw new Error('Rental request not found');
        }

        const rentalRequest = rentalRequestData[0];
        if (!rentalRequest) {
            throw new Error('Rental request not found');
        }

        // Check if rental request is approved
        if (rentalRequest.status !== 'approved') {
            throw new Error(`Rental request is not approved. Current status: ${rentalRequest.status}`);
        }

        // Check if payment already exists
        if (rentalRequest.payment_history_id) {
            throw new Error('Payment already exists for this rental request');
        }

        // 2. Get costume details for better product naming
        const costumeData = await db
            .select({
                name: costumes.name,
                brand: costumes.brand,
                category: costumes.category
            })
            .from(costumes)
            .where(eq(costumes.id, rentalRequest.costume_id))
            .limit(1);

        const costume = costumeData[0];
        const productName = costume ? `${costume.name}${costume.brand ? ` - ${costume.brand}` : ''}` : 'Costume Rental';

        // 3. Create checkout session with PayMongo
        const amount = rentalRequest.estimated_total_amount / 100; // Convert from cents
        const currency = rentalRequest.currency;

        const checkoutResponse = await createRentalCheckoutSession(
            rentalRequest.id, // Use the actual rental request ID
            amount,
            currency,
            productName
        );

        console.log('PayMongo Response:', JSON.stringify(checkoutResponse, null, 2));

        // Handle different response structures
        const checkoutSession = checkoutResponse.data?.data || checkoutResponse.data;
        if (!checkoutSession) {
            throw new Error('Invalid response from PayMongo - no session data');
        }

        const sessionId = checkoutSession.id;
        const checkoutUrl = checkoutSession.attributes?.checkout_url;
        const paymentIntentId = checkoutSession.attributes?.payment_intent?.id;

        console.log('Checkout Session Created:', sessionId);
        console.log('Payment Intent ID:', paymentIntentId);
        console.log('Checkout URL:', checkoutUrl);

        if (!sessionId) {
            throw new Error('No session ID received from PayMongo');
        }

        if (!checkoutUrl) {
            throw new Error('No checkout URL received from PayMongo');
        }

        const finalSessionId = paymentIntentId || sessionId;
        const status: PaymentStatus = 'pending'; // Checkout sessions start as pending

        // 3. Store payment record in database
        const paymentData = {
            session_id: sessionId,
            payment_intent_id: finalSessionId,
            rental_id: rentalRequest.id, // Use rental request ID as rental_id
            borrower_user_id: rentalRequest.borrower_user_id,
            lender_user_id: rentalRequest.lender_user_id,
            product_id: rentalRequest.costume_id,
            product_name: productName,
            amount: rentalRequest.estimated_total_amount, // Already in cents
            currency: currency,
            status: status,
            payment_type: 'online' as const,
            payment_method: paymentRequest.payment_method as any, // Use the provided payment method
            selected_items: rentalRequest.selected_items,
            metadata: {
                ...checkoutSession.attributes?.metadata || {},
                conversation_id: rentalRequest.conversation_id,
                payment_method: paymentRequest.payment_method,
                terms_accepted: paymentRequest.terms_accepted
            },
            description: `Rental payment for ${productName}`,
            success_url: `${FRONTEND_URL}/payment/success?rental_request_id=${rentalRequest.id}`,
            cancel_url: `${FRONTEND_URL}/payment/cancel?rental_request_id=${rentalRequest.id}`,
            created_at: new Date(),
            updated_at: new Date(),
        };

        const [newPaymentRecord] = await db.insert(payment_history).values(paymentData).returning();

        if (!newPaymentRecord) {
            throw new Error('Failed to create payment record');
        }

        // 4. Create rental record and remove rental request (after payment is successful)
        // Note: This will be called when payment is confirmed, not here
        // For now, just update the rental request with payment history ID
        await db
            .update(rental_requests)
            .set({
                payment_history_id: newPaymentRecord.id,
                updated_at: new Date()
            })
            .where(eq(rental_requests.id, rentalRequest.id));

        // 5. Return success response
        return {
            success: true,
            rental_id: rentalRequest.id,
            payment_intent_id: finalSessionId,
            status,
            amount: rentalRequest.estimated_total_amount,
            currency,
            payment_method: paymentRequest.payment_method,
            checkout_url: checkoutUrl,
        };
    } catch (error: any) {
        console.error('Payment processing error:', error);

        return {
            success: false,
            error: error.message || 'Failed to process rental payment',
        };
    }
};

// Create rental record and remove rental request after successful payment
export const createRentalAndRemoveRequest = async (rentalRequestId: string, paymentRecordId: string): Promise<any> => {
    try {
        // 1. Get rental request details
        const rentalRequestData = await db
            .select()
            .from(rental_requests)
            .where(eq(rental_requests.id, rentalRequestId))
            .limit(1);

        if (rentalRequestData.length === 0) {
            throw new Error('Rental request not found');
        }

        const rentalRequest = rentalRequestData[0];
        if (!rentalRequest) {
            throw new Error('Rental request is undefined');
        }

        // 2. Get costume details
        const costumeData = await db
            .select()
            .from(costumes)
            .where(eq(costumes.id, rentalRequest.costume_id))
            .limit(1);

        if (costumeData.length === 0) {
            throw new Error('Costume not found');
        }

        const costume = costumeData[0];
        if (!costume) {
            throw new Error('Costume is undefined');
        }

        // 3. Get user details
        const [borrowerData, lenderData] = await Promise.all([
            db.select({
                username: users.username,
                email: users.email,
                profile_image: users.profile_image
            })
                .from(users)
                .where(eq(users.uid, rentalRequest.borrower_user_id))
                .limit(1),

            db.select({
                username: users.username
            })
                .from(users)
                .where(eq(users.uid, rentalRequest.lender_user_id))
                .limit(1)
        ]);

        if (borrowerData.length === 0 || lenderData.length === 0) {
            throw new Error('User details not found');
        }

        const borrower = borrowerData[0];
        const lender = lenderData[0];

        if (!borrower || !lender) {
            throw new Error('User details are undefined');
        }

        // 4. Extract costume image safely
        const costumeImage = costume.main_images?.front || costume.main_images?.back || '';

        // 5. Prepare rental data
        const rentalData = {
            costume_id: rentalRequest.costume_id,
            costume_name: costume.name,
            costume_image: costumeImage,

            // Lender details
            lender_user_id: rentalRequest.lender_user_id,
            lender_username: lender.username,

            // Borrower details
            borrower_user_id: rentalRequest.borrower_user_id,
            renter_username: borrower.username,
            renter_email: borrower.email,
            renter_profile_image: borrower.profile_image,

            // Rental details
            rental_start_date: rentalRequest.requested_start_date,
            rental_end_date: rentalRequest.requested_end_date,
            total_days: rentalRequest.total_days,

            // Pricing information
            daily_rate: rentalRequest.estimated_daily_rate,
            total_amount: rentalRequest.estimated_total_amount,
            currency: rentalRequest.currency,

            // Selected items
            main_offer_selected: rentalRequest.selected_items?.mainOffer?.selected ?? false,
            main_offer_data: rentalRequest.selected_items?.mainOffer?.data ?? null,
            costume_type_selected: rentalRequest.selected_items?.selectedCostumeType?.selected ?? false,
            costume_type_data: rentalRequest.selected_items?.selectedCostumeType?.data ?? null,
            selected_add_ons: rentalRequest.selected_items?.selectedAddOns ?? [],

            // Payment information
            payment_history_id: paymentRecordId,
            payment_status: 'paid' as const,
            payment_history_ids: [paymentRecordId],

            // Metadata
            conversation_id: rentalRequest.conversation_id,
            status: 'confirmed' as const,

            // Payment timestamps
            paid_at: new Date(),
            status_updated_at: new Date(),

            // Timestamps
            created_at: new Date(),
            updated_at: new Date(),

            // Additional fields
            is_active: true,
            notes: rentalRequest.notes
        };

        // 6. Insert rental record
        const [newRental] = await db
            .insert(rentals)
            .values(rentalData as any)
            .returning();

        if (!newRental) {
            throw new Error('Failed to create rental record');
        }

        // 7. Delete rental request
        await db
            .delete(rental_requests)
            .where(eq(rental_requests.id, rentalRequestId));

        return {
            success: true,
            rental: newRental,
            message: 'Rental created and rental request removed successfully'
        };

    } catch (error: any) {
        console.error('Error creating rental and removing request:', error);
        return {
            success: false,
            error: error.message || 'Failed to create rental and remove request'
        };
    }
};

// Handle PayMongo webhook for payment confirmation
export const handlePaymentWebhook = async (webhookData: any): Promise<any> => {
    try {
        console.log('Processing payment webhook:', JSON.stringify(webhookData, null, 2));

        // Extract payment details from webhook
        const eventType = webhookData.type;
        const paymentData = webhookData.data;

        if (eventType !== 'payment.succeeded') {
            return {
                success: false,
                message: `Ignoring webhook event: ${eventType}`
            };
        }

        const paymentIntentId = paymentData.attributes.payment_intent?.id || paymentData.id;
        const status = paymentData.attributes.status;

        if (status !== 'succeeded') {
            return {
                success: false,
                message: `Payment not succeeded. Status: ${status}`
            };
        }

        // Find payment record by payment intent ID
        const paymentRecord = await db
            .select()
            .from(payment_history)
            .where(eq(payment_history.payment_intent_id, paymentIntentId))
            .limit(1);

        if (paymentRecord.length === 0) {
            return {
                success: false,
                error: 'Payment record not found'
            };
        }

        const payment = paymentRecord[0];
        if (!payment) {
            return {
                success: false,
                error: 'Payment record is undefined'
            };
        }

        // Update payment status to paid
        await db
            .update(payment_history)
            .set({
                status: 'paid',
                paid_at: new Date(),
                updated_at: new Date()
            })
            .where(eq(payment_history.id, payment.id));

        // Create rental and remove rental request
        const rentalResult = await createRentalAndRemoveRequest(payment.rental_id, payment.id);

        if (!rentalResult.success) {
            return {
                success: false,
                error: rentalResult.error
            };
        }

        return {
            success: true,
            message: 'Payment processed successfully and rental created',
            rental_id: rentalResult.rental.id
        };

    } catch (error: any) {
        console.error('Error processing payment webhook:', error);
        return {
            success: false,
            error: error.message || 'Failed to process payment webhook'
        };
    }
};

// Create subscription payment checkout session
interface SubscriptionPaymentParams {
    email: string;
    fullName: string;
    phoneNumber: string;
    userId: string;
    subscriptionType?: 'monthly' | 'yearly';
    user?: any;
    businessInfo?: any;
}

export const createSubscriptionPayment = async (params: SubscriptionPaymentParams) => {
    try {
        const {
            email,
            fullName,
            phoneNumber,
            userId,
            subscriptionType = 'monthly',
            user,
            businessInfo
        } = params;

        console.log('[Subscription Payment] Creating checkout session for:', {
            email,
            fullName,
            userId,
            subscriptionType,
            hasUser: !!user,
            hasBusiness: !!businessInfo
        });

        // Define subscription amounts (in PHP)
        const subscriptionAmounts = {
            monthly: 999.00,  // ₱99/month
            yearly: 5999.00   // ₱999/year (2 months free)
        };

        const amount = subscriptionAmounts[subscriptionType];
        const amountInCentavos = Math.round(amount * 100);

        // Prepare billing information (use form data as primary, fallback to DB)
        const billingName = fullName || user?.full_name || user?.username || 'User';
        const billingEmail = email || user?.email || '';
        const billingPhone = phoneNumber || user?.phone_number || businessInfo?.business_phone_number || '';

        // Generate reference code
        const referenceCode = `SUB-${Date.now()}-${userId.substring(0, 8).toUpperCase()}`;

        const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:3000';

        console.log('[Subscription Payment] Amount conversion:', {
            amount_PHP: amount,
            amountInCentavos: amountInCentavos,
            calculation: `${amount} * 100 = ${amountInCentavos}`
        });

        // Create PayMongo checkout session (like rentals)
        const checkoutResponse = await axios.post(
            `${PAYMONGO_API_URL}/checkout_sessions`,
            {
                data: {
                    attributes: {
                        payment_method_types: ['gcash', 'paymaya', 'card', 'dob', 'dob_ubp'],
                        line_items: [{
                            name: `CosConnect ${subscriptionType === 'monthly' ? 'Monthly' : 'Yearly'} Subscription`,
                            amount: amountInCentavos,
                            currency: 'PHP',
                            quantity: 1,
                            description: `Premium subscription - ${subscriptionType}`
                        }],
                        payment_intent_data: {
                            capture_type: 'automatic',
                            description: `CosConnect ${subscriptionType} subscription for ${billingName}`,
                            metadata: {
                                user_id: userId,
                                subscription_type: subscriptionType,
                                payment_type: 'subscription',
                                reference_code: referenceCode,
                                user_role: user?.role?.join(',') || 'borrower',
                                business_name: businessInfo?.business_name || null,
                                amount: amount.toFixed(2)
                            }
                        },
                        customer_email: billingEmail,
                        success_url: `${frontendUrl}/subscription/success?reference=${referenceCode}`,
                        cancel_url: `${frontendUrl}/subscription/failed?reference=${referenceCode}`,
                        reference_number: referenceCode,
                        send_email_receipt: true,
                        description: `CosConnect ${subscriptionType} Premium Subscription`,
                        billing: {
                            name: billingName,
                            email: billingEmail,
                            phone: billingPhone || '09000000000'
                        }
                    }
                }
            },
            {
                headers: {
                    'Authorization': getAuthHeader(),
                    'Content-Type': 'application/json'
                },
                timeout: 30000
            }
        );

        const checkoutSession = checkoutResponse.data.data;
        const expiresAtString = checkoutSession.attributes.expires_at;
        const sessionExpiresAt = expiresAtString && !isNaN(new Date(expiresAtString).getTime())
            ? new Date(expiresAtString)
            : new Date(Date.now() + 24 * 60 * 60 * 1000);

        console.log('[Subscription Payment] Checkout session created:', {
            session_id: checkoutSession.id,
            payment_intent_id: checkoutSession.attributes.payment_intent?.id,
            checkout_url: checkoutSession.attributes.checkout_url,
            reference: referenceCode
        });

        return {
            success: true,
            session_id: checkoutSession.id,
            payment_intent_id: checkoutSession.attributes.payment_intent?.id || null,
            checkout_url: checkoutSession.attributes.checkout_url,
            reference_number: referenceCode,
            amount: amount,
            subscription_type: subscriptionType,
            expires_at: sessionExpiresAt,
            status: 'pending'
        };

    } catch (error: any) {
        console.error('[Subscription Payment] Error creating checkout session:', {
            message: error.message,
            response: error.response?.data,
            status: error.response?.status
        });

        if (error.response?.data?.errors) {
            const paymongoError = error.response.data.errors[0];
            return {
                success: false,
                error: paymongoError.detail || paymongoError.title || 'Failed to create checkout session'
            };
        }

        return {
            success: false,
            error: error.message || 'Failed to create subscription payment'
        };
    }
};

// Process subscription payment webhook (called after successful payment)
export const processSubscriptionPaymentWebhook = async (
    paymentIntentId: string,
    metadata: any
) => {
    try {
        console.log('[Subscription Webhook] Processing payment:', { paymentIntentId, metadata });

        const userId = metadata.user_id;
        const subscriptionType = metadata.subscription_type;

        if (!userId || !subscriptionType) {
            return {
                success: false,
                error: 'Missing user_id or subscription_type in metadata'
            };
        }

        // Calculate subscription end date
        const startDate = new Date();
        const endDate = new Date();

        if (subscriptionType === 'monthly') {
            endDate.setMonth(endDate.getMonth() + 1);
        } else if (subscriptionType === 'yearly') {
            endDate.setFullYear(endDate.getFullYear() + 1);
        }

        // Update user to premium
        const [updatedUser] = await db
            .update(users)
            .set({
                is_premium: true,
                subscription_type: subscriptionType,
                subscription_status: 'active',
                subscription_start_date: startDate,
                subscription_end_date: endDate,
                subscription_payment_id: paymentIntentId,
                subscription_reference: metadata.reference_code || null,
                updated_at: new Date()
            })
            .where(eq(users.uid, userId))
            .returning();

        if (!updatedUser) {
            return {
                success: false,
                error: 'Failed to update user subscription status'
            };
        }

        console.log('[Subscription Webhook] User upgraded to premium:', {
            userId,
            subscriptionType,
            startDate,
            endDate
        });

        return {
            success: true,
            message: 'User upgraded to premium successfully',
            user: updatedUser
        };

    } catch (error: any) {
        console.error('[Subscription Webhook] Error processing payment:', error);
        return {
            success: false,
            error: error.message || 'Failed to process subscription payment webhook'
        };
    }
};

