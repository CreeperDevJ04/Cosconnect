// messageController.ts
import axios from 'axios';
import type { Context } from 'hono';
import nodemailer from 'nodemailer';
import { db } from "../db/firebase/config";

// Payment Data Interface
export interface PaymentData {
    borrower: {
        uid: string;
        fullName: string;
        email: string;
        phoneNumber: string;
    };
    rental: {
        productId: string;
        productName: string;
        lenderId: string;
        lenderUsername: string;
        startDate: string;
        endDate: string;
        totalDays: number;
        dailyRate: number;
        totalCost: number;
        conversationId: string;
        selectedItems: {
            mainOffer: boolean;
            selectedProductType: string | null;
            selectedAddOns: string[];
        };
    };
    paymentDetails: {
        amount: number;
        currency: string;
        paymentMethod: PaymentMethod;
        termsAccepted: boolean;
        timestamp: string;
    };
}

// Payment Method Types
export type PaymentMethod =
    | 'gcash'
    | 'card'
    | 'paymaya'
    | 'bpi'
    | 'bdo'
    | 'unionbank'
    | 'metrobank'
    | 'rcbc'
    | 'chinabank'
    | 'landbank';

// Payment Status Types
export type PaymentStatus = 'pending' | 'paid' | 'cancelled' | 'failed';

// Payment Method Details
const PAYMENT_METHODS = {
    gcash: {
        name: 'GCash',
        type: 'gcash',
        description: 'Pay using GCash mobile wallet'
    },
    card: {
        name: 'Credit/Debit Card',
        type: 'card',
        description: 'Pay using credit or debit card'
    },
    paymaya: {
        name: 'PayMaya',
        type: 'paymaya',
        description: 'Pay using PayMaya wallet'
    },
    bpi: {
        name: 'BPI',
        type: 'bpi',
        description: 'Pay using BPI online banking'
    },
    bdo: {
        name: 'BDO',
        type: 'bdo',
        description: 'Pay using BDO online banking'
    },
    unionbank: {
        name: 'UnionBank',
        type: 'unionbank',
        description: 'Pay using UnionBank online banking'
    },
    metrobank: {
        name: 'Metrobank',
        type: 'metrobank',
        description: 'Pay using Metrobank online banking'
    },
    rcbc: {
        name: 'RCBC',
        type: 'rcbc',
        description: 'Pay using RCBC online banking'
    },
    chinabank: {
        name: 'China Bank',
        type: 'chinabank',
        description: 'Pay using China Bank online banking'
    },
    landbank: {
        name: 'Landbank',
        type: 'landbank',
        description: 'Pay using Landbank online banking'
    }
};

// Configure nodemailer transporter
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER ,
        pass: process.env.EMAIL_PASSWORD || ''
    }
});

const PAYMONGO_API_URL = 'https://api.paymongo.com/v1';
const PAYMONGO_SECRET_KEY = process.env.PAYMONGO_SECRET_KEY;

// Logger function
const logger = {
    info: (message: string, data?: any) => {
        console.log(`[INFO] ${new Date().toISOString()} - ${message}`, data ? JSON.stringify(data, null, 2) : '');
    },
    error: (message: string, error: any) => {
        console.error(`[ERROR] ${new Date().toISOString()} - ${message}`, error);
        if (error.response) {
            console.error('Response data:', error.response.data);
            console.error('Response status:', error.response.status);
        }
    },
    debug: (message: string, data?: any) => {
        if (process.env.NODE_ENV === 'development') {
            console.debug(`[DEBUG] ${new Date().toISOString()} - ${message}`, data ? JSON.stringify(data, null, 2) : '');
        }
    }
};

// Email template for payment confirmation
const createPaymentConfirmationEmail = (data: PaymentData) => {
    const paymentMethod = PAYMENT_METHODS[data.paymentDetails.paymentMethod];
    return `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #333;">Payment Confirmation for Costume Rental</h2>
            <p>Dear ${data.borrower.fullName},</p>
            <p>Thank you for your costume rental payment. Here are your payment details:</p>
            
            <div style="background-color: #f5f5f5; padding: 20px; border-radius: 5px; margin: 20px 0;">
                <h3 style="color: #444;">Payment Details</h3>
                <p><strong>Amount:</strong> ₱${data.paymentDetails.amount.toFixed(2)} ${data.paymentDetails.currency}</p>
                <p><strong>Payment Method:</strong> ${paymentMethod.name}</p>
                <p><strong>Transaction Date:</strong> ${new Date(data.paymentDetails.timestamp).toLocaleString()}</p>
            </div>

            <div style="background-color: #f5f5f5; padding: 20px; border-radius: 5px; margin: 20px 0;">
                <h3 style="color: #444;">Rental Details</h3>
                <p><strong>Product:</strong> ${data.rental.productName}</p>
                <p><strong>Lender:</strong> ${data.rental.lenderUsername}</p>
                <p><strong>Start Date:</strong> ${new Date(data.rental.startDate).toLocaleDateString()}</p>
                <p><strong>End Date:</strong> ${new Date(data.rental.endDate).toLocaleDateString()}</p>
                <p><strong>Total Days:</strong> ${data.rental.totalDays}</p>
                <p><strong>Daily Rate:</strong> ₱${data.rental.dailyRate.toFixed(2)} ${data.paymentDetails.currency}</p>
                <p><strong>Total Cost:</strong> ₱${data.rental.totalCost.toFixed(2)} ${data.paymentDetails.currency}</p>
            </div>

            <p>If you have any questions about your rental, please don't hesitate to contact us.</p>
            <p>Best regards,<br>CosConnect Team</p>
        </div>
    `;
};

// Email template for payment cancellation
const createPaymentCancellationEmail = (data: PaymentData) => {
    const paymentMethod = PAYMENT_METHODS[data.paymentDetails.paymentMethod];
    return `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #333;">Payment Cancelled - Costume Rental</h2>
            <p>Dear ${data.borrower.fullName},</p>
            <p>Your payment for the costume rental has been cancelled. Here are the details:</p>
            
            <div style="background-color: #f5f5f5; padding: 20px; border-radius: 5px; margin: 20px 0;">
                <h3 style="color: #444;">Rental Details</h3>
                <p><strong>Product:</strong> ${data.rental.productName}</p>
                <p><strong>Lender:</strong> ${data.rental.lenderUsername}</p>
                <p><strong>Start Date:</strong> ${new Date(data.rental.startDate).toLocaleDateString()}</p>
                <p><strong>End Date:</strong> ${new Date(data.rental.endDate).toLocaleDateString()}</p>
                <p><strong>Total Days:</strong> ${data.rental.totalDays}</p>
                <p><strong>Total Cost:</strong> ₱${data.rental.totalCost.toFixed(2)} ${data.paymentDetails.currency}</p>
                <p><strong>Payment Method:</strong> ${paymentMethod.name}</p>
            </div>

            <p>If you would like to try the payment again or have any questions, please don't hesitate to contact us.</p>
            <p>Best regards,<br>CosConnect Team</p>
        </div>
    `;
};

// Validate payment data
const validatePaymentData = (paymentData: PaymentData): string[] => {
    logger.debug('Validating payment data', paymentData);
    const errors: string[] = [];

    // Validate borrower data
    if (!paymentData.borrower.uid) errors.push('Borrower UID is required');
    if (!paymentData.borrower.email) errors.push('Borrower email is required');
    if (!paymentData.borrower.fullName) errors.push('Borrower full name is required');

    // Validate rental data
    if (!paymentData.rental.conversationId) errors.push('Conversation ID is required');
    if (!paymentData.rental.productId) errors.push('Product ID is required');
    if (paymentData.rental.totalDays <= 0) errors.push('Total days must be greater than 0');

    // Validate payment details
    if (paymentData.paymentDetails.amount <= 0) errors.push('Payment amount must be greater than 0');
    if (!paymentData.paymentDetails.currency) errors.push('Currency is required');
    if (!paymentData.paymentDetails.paymentMethod) errors.push('Payment method is required');
    if (!paymentData.paymentDetails.termsAccepted) errors.push('Terms must be accepted');

    // Validate payment method
    if (!PAYMENT_METHODS[paymentData.paymentDetails.paymentMethod]) {
        errors.push(`Invalid payment method: ${paymentData.paymentDetails.paymentMethod}`);
    }

    // Validate amount matches total cost
    if (Math.abs(paymentData.paymentDetails.amount - paymentData.rental.totalCost) > 0.01) {
        errors.push('Payment amount does not match rental total cost');
    }

    if (errors.length > 0) {
        logger.error('Payment validation failed', errors);
    }

    return errors;
};

// Create payment session for costume rental
export const createCostumeRentalPaymentSession = async (paymentData: PaymentData) => {
    try {
        console.log('=== Payment Session Creation Started ===');
        console.log('Payment Data:', JSON.stringify(paymentData, null, 2));

        // Ensure currency is in uppercase PHP
        const currency = 'PHP';
        console.log('Using Currency:', currency);

        // Get frontend URL from environment or use a default
        const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:3000';
        console.log('Using Frontend URL:', frontendUrl);

        logger.info('Creating payment session', {
            amount: paymentData.paymentDetails.amount,
            paymentMethod: paymentData.paymentDetails.paymentMethod,
            productName: paymentData.rental.productName,
            currency: currency,
            frontendUrl: frontendUrl
        });

        // Validate payment data
        const validationErrors = validatePaymentData(paymentData);
        if (validationErrors.length > 0) {
            console.error('Validation Errors:', validationErrors);
            throw new Error(`Validation failed: ${validationErrors.join(', ')}`);
        }

        const paymentMethod = PAYMENT_METHODS[paymentData.paymentDetails.paymentMethod];
        console.log('Selected Payment Method:', paymentMethod);

        // Create payment intent
        console.log('Creating Payment Intent...');
        const paymentIntentResponse = await axios.post(
            `${PAYMONGO_API_URL}/payment_intents`,
            {
                data: {
                    attributes: {
                        amount: Math.round(paymentData.paymentDetails.amount * 100),
                        payment_method_allowed: [paymentMethod.type],
                        currency: currency,
                        description: `Rental payment for ${paymentData.rental.productName}`,
                        metadata: {
                            borrowerId: paymentData.borrower.uid,
                            lenderId: paymentData.rental.lenderId,
                            productId: paymentData.rental.productId,
                            conversationId: paymentData.rental.conversationId,
                            startDate: paymentData.rental.startDate,
                            endDate: paymentData.rental.endDate,
                            totalDays: paymentData.rental.totalDays.toString(),
                            paymentMethod: paymentMethod.name
                        }
                    }
                }
            },
            {
                headers: {
                    'Authorization': `Basic ${Buffer.from(PAYMONGO_SECRET_KEY + ':').toString('base64')}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        console.log('Payment Intent Response:', JSON.stringify(paymentIntentResponse.data, null, 2));

        // Create payment source with proper redirect URLs
        console.log('Creating Payment Source...');
        const sourceResponse = await axios.post(
            `${PAYMONGO_API_URL}/sources`,
            {
                data: {
                    attributes: {
                        type: paymentMethod.type,
                        amount: Math.round(paymentData.paymentDetails.amount * 100),
                        currency: currency,
                        redirect: {
                            success: `${frontendUrl}/payment/success?session_id=${paymentIntentResponse.data.data.id}`,
                            failed: `${frontendUrl}/payment/failed?session_id=${paymentIntentResponse.data.data.id}`
                        }
                    }
                }
            },
            {
                headers: {
                    'Authorization': `Basic ${Buffer.from(PAYMONGO_SECRET_KEY + ':').toString('base64')}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        console.log('Payment Source Response:', JSON.stringify(sourceResponse.data, null, 2));

        // Get the checkout URL from the source response
        const checkoutUrl = sourceResponse.data.data.attributes.redirect.checkout_url;
        console.log('Checkout URL:', checkoutUrl);

        const result = {
            success: true,
            paymentIntent: paymentIntentResponse.data.data,
            source: sourceResponse.data.data,
            redirectUrl: checkoutUrl,
            sessionId: paymentIntentResponse.data.data.id
        };

        console.log('=== Payment Session Creation Completed ===');
        console.log('Final Result:', JSON.stringify(result, null, 2));

        return result;
    } catch (error: any) {
        console.error('=== Payment Session Creation Error ===');
        console.error('Error Details:', error);
        if (error.response) {
            console.error('Error Response Data:', error.response.data);
            console.error('Error Response Status:', error.response.status);
        }
        throw new Error(error.response?.data?.errors?.[0]?.detail || 'Failed to create payment session');
    }
};

// Check payment status
export const checkPaymentStatus = async (sessionId: string): Promise<PaymentStatus> => {
    try {
        logger.info('Checking payment status', { sessionId });

        const response = await axios.get(
            `${PAYMONGO_API_URL}/payment_intents/${sessionId}`,
            {
                headers: {
                    'Authorization': `Basic ${Buffer.from(PAYMONGO_SECRET_KEY + ':').toString('base64')}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        const status = response.data.data.attributes.status;
        logger.info('Payment status retrieved', { sessionId, status });
        return status as PaymentStatus;
    } catch (error) {
        logger.error('Payment Status Check Error', error);
        return 'failed';
    }
};

// Main payment processing function
export const proceedToPaymentForCostumeRent = async (c: Context) => {
    try {
        console.log('=== Payment Processing Started ===');

        // Parse request body
        const paymentData: PaymentData = await c.req.json();

        // Ensure currency is set to PHP
        paymentData.paymentDetails.currency = 'PHP';

        console.log('Received Payment Data:', JSON.stringify(paymentData, null, 2));

        // Validate required fields
        const validationErrors = validatePaymentData(paymentData);
        if (validationErrors.length > 0) {
            console.error('Validation Errors:', validationErrors);
            return c.json({
                success: false,
                error: 'Validation failed',
                details: validationErrors
            }, 400);
        }

        // Create payment session
        console.log('Creating Payment Session...');
        const paymentSession = await createCostumeRentalPaymentSession(paymentData);
        console.log('Payment Session Created:', JSON.stringify(paymentSession, null, 2));

        // Store payment intent in database
        console.log('Storing Payment Intent in Database...');
        const dbData = {
            ...paymentData,
            status: 'pending',
            createdAt: new Date().toISOString(),
            paymentIntentId: paymentSession.paymentIntent.id,
            sourceId: paymentSession.source.id
        };
        console.log('Database Data:', JSON.stringify(dbData, null, 2));
        await db.collection('payment-intents').doc(paymentSession.paymentIntent.id).set(dbData);

        // Send confirmation email
        try {
            console.log('Sending Confirmation Email...');
            const emailHtml = createPaymentConfirmationEmail(paymentData);
            await transporter.sendMail({
                from: process.env.EMAIL_USER ,
                to: paymentData.borrower.email,
                subject: 'Payment Initiated - Costume Rental',
                html: emailHtml
            });
            console.log('Confirmation Email Sent Successfully');
        } catch (emailError) {
            console.error('Email Sending Error:', emailError);
        }

        const response = {
            success: true,
            message: 'Payment session created successfully',
            data: {
                checkoutUrl: paymentSession.redirectUrl, // This is the URL you'll use in your frontend
                sessionId: paymentSession.sessionId,
                amount: paymentData.paymentDetails.amount,
                currency: 'PHP',
                paymentMethod: PAYMENT_METHODS[paymentData.paymentDetails.paymentMethod].name
            }
        };

        console.log('=== Payment Processing Completed ===');
        console.log('Final Response:', JSON.stringify(response, null, 2));

        return c.json(response, 200);

    } catch (error: any) {
        console.error('=== Payment Processing Error ===');
        console.error('Error Details:', error);
        if (error.response) {
            console.error('Error Response Data:', error.response.data);
            console.error('Error Response Status:', error.response.status);
        }
        return c.json({
            success: false,
            error: 'Payment processing failed',
            message: error.message || 'An unexpected error occurred'
        }, 500);
    }
};

// Handle payment cancellation
export const handlePaymentCancellation = async (c: Context) => {
    try {
        const { sessionId } = await c.req.json();
        logger.info('Handling payment cancellation', { sessionId });

        // Get payment intent from database
        const paymentDoc = await db.collection('payment-intents').doc(sessionId).get();
        if (!paymentDoc.exists) {
            logger.error('Payment session not found', { sessionId });
            return c.json({
                success: false,
                message: 'Payment session not found'
            }, 404);
        }

        const paymentData = paymentDoc.data() as PaymentData;

        // Update payment status
        await db.collection('payment-intents').doc(sessionId).update({
            status: 'cancelled',
            cancelledAt: new Date().toISOString()
        });

        logger.info('Payment status updated to cancelled', { sessionId });

        // Send cancellation email
        try {
            const emailHtml = createPaymentCancellationEmail(paymentData);
            await transporter.sendMail({
                from: process.env.EMAIL_USER ,
                to: paymentData.borrower.email,
                subject: 'Payment Cancelled - Costume Rental',
                html: emailHtml
            });
            logger.info('Cancellation email sent', { email: paymentData.borrower.email });
        } catch (emailError) {
            logger.error('Email sending failed', emailError);
        }

        return c.json({
            success: true,
            message: 'Payment cancelled successfully'
        });

    } catch (error: any) {
        logger.error('Payment Cancellation Error', error);
        return c.json({
            success: false,
            message: error.message || 'Failed to cancel payment'
        }, 500);
    }
};

// Webhook handler for payment status updates (recommended)
export const handlePaymentWebhook = async (c: Context) => {
    try {
        const webhookData = await c.req.json();
        const eventType = webhookData.data.attributes.type;

        if (eventType === 'payment.paid') {
            const paymentId = webhookData.data.id;
            const metadata = webhookData.data.attributes.metadata;

            // Update rental status to paid
            const rentalsRef = db.collection('rentals-costume');
            const q = rentalsRef.where('conversationId', '==', metadata.conversationId);
            const querySnapshot = await q.get();

            if (!querySnapshot.empty) {
                const rentalDoc = querySnapshot.docs[0];
                await rentalsRef.doc(rentalDoc?.id as string).update({
                    paymentStatus: 'paid',
                    paymentId: paymentId,
                    paidAt: new Date().toISOString()
                });

                // Log successful payment
                await db.collection('payment-logs').add({
                    conversationId: metadata.conversationId,
                    paymentId: paymentId,
                    status: 'completed',
                    timestamp: new Date().toISOString()
                });
            }
        }

        return c.json({ success: true }, 200);
    } catch (error) {
        console.error('Webhook processing error:', error);
        return c.json({ success: false }, 500);
    }
};

export default { proceedToPaymentForCostumeRent }