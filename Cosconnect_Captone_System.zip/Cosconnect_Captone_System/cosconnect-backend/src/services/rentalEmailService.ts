import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER ,
    pass: process.env.EMAIL_PASSWORD || '',
  },
});

interface PartyInfo {
  email: string;
  name: string;
}

export type RentalStatusEmailType = 'accepted' | 'rejected' | 'delivered' | 'returned';

interface RentalStatusEmailOrder {
  id: string;
  costumeName: string;
  borrower: PartyInfo;
  lender: PartyInfo;
}

interface RentalStatusEmailOptions {
  triggerRole?: 'lender' | 'borrower';
  rejectMessage?: string;
  returnNotes?: string | null;
  damageInfo?: { isDamaged: boolean; damageCost: string };
}

export async function sendRentalStatusEmails(
  order: RentalStatusEmailOrder,
  status: RentalStatusEmailType,
  options: RentalStatusEmailOptions = {}
): Promise<void> {
  const { borrower, lender, costumeName, id } = order;
  const { triggerRole = 'lender', rejectMessage, returnNotes, damageInfo } = options;

  const baseUrl = process.env.FRONTEND_URL || 'https://cosconnect.onnline';

  const subjectMap: Record<RentalStatusEmailType, string> = {
    accepted: `Rental Accepted: ${costumeName}`,
    rejected: `Rental Rejected: ${costumeName}`,
    delivered: `Costume Delivered: ${costumeName}`,
    returned: `Costume Returned: ${costumeName}`,
  };

  const borrowerBody = () => {
    switch (status) {
      case 'accepted':
        return `Hello ${borrower.name},\n\nGood news — your rental request for "${costumeName}" has been approved by ${lender.name}.\n\nYou can review the full rental details in your CosConnect account:\n${baseUrl}/my-rentals\n\nReference ID: ${id}\n\nBest regards,\nCosConnect Rentals Team`;
      case 'rejected':
        return `Hello ${borrower.name},\n\nWe’re sorry to let you know that your rental request for "${costumeName}" was not approved.${
          rejectMessage ? `\n\nReason provided: ${rejectMessage}` : ''
        }\n\nYou can view your rental activity here:\n${baseUrl}/my-rentals\n\nReference ID: ${id}\n\nBest regards,\nCosConnect Rentals Team`;
      case 'delivered':
        return `Hello ${borrower.name},\n\nYour rented costume "${costumeName}" has been marked as delivered by ${lender.name}.\n\nPlease log in to your CosConnect account to review the item and confirm its condition:\n${baseUrl}/my-rentals\n\nReference ID: ${id}\n\nBest regards,\nCosConnect Rentals Team`;
      case 'returned': {
        // Keep the message simple – just let the borrower know the costume was returned
        return `Hello ${borrower.name},\n\nThe costume "${costumeName}" has been marked as returned.\nNotes from the lender: ${returnNotes || 'N/A'}.\n\nYou can review this rental in your account:\n${baseUrl}/my-rentals\n\nReference ID: ${id}\n\nBest regards,\nCosConnect Rentals Team`;
      }
    }
  };

  const lenderBody = () => {
    switch (status) {
      case 'accepted':
        return `Hello ${lender.name},\n\nYou have successfully approved a rental request for "${costumeName}" from ${borrower.name}.\n\nYou can manage this rental from your CosConnect lender dashboard:\n${baseUrl}/lender/manage-rentals\n\nReference ID: ${id}\n\nBest regards,\nCosConnect Rentals Team`;
      case 'rejected':
        return `Hello ${lender.name},\n\nYou declined a rental request for "${costumeName}" from ${borrower.name}.${
          rejectMessage ? `\n\nReason noted: ${rejectMessage}` : ''
        }\n\nYou can review your recent rental activity here:\n${baseUrl}/lender/manage-rentals\n\nReference ID: ${id}\n\nBest regards,\nCosConnect Rentals Team`;
      case 'delivered':
        return `Hello ${lender.name},\n\nYou marked the costume "${costumeName}" as delivered to ${borrower.name}.\n\nIf needed, you can update this rental from your lender dashboard:\n${baseUrl}/lender/manage-rentals\n\nReference ID: ${id}\n\nBest regards,\nCosConnect Rentals Team`;
      case 'returned': {
        // Keep the message simple – just let the lender know the costume was returned
        return `Hello ${lender.name},\n\nThe costume "${costumeName}" has been marked as returned.\nNotes from the borrower: ${returnNotes || 'N/A'}.\n\nYou can review this rental in your lender dashboard:\n${baseUrl}/lender/manage-rentals\n\nReference ID: ${id}\n\nBest regards,\nCosConnect Rentals Team`;
      }
    }
  };

  try {
    // Only notify the opposite party based on who triggered the action
    const tasks: Promise<any>[] = [];

    // If lender triggered the change, notify borrower only
    if (triggerRole !== 'borrower') {
      tasks.push(
        transporter.sendMail({
          from: process.env.EMAIL_USER ,
          to: borrower.email,
          subject: subjectMap[status],
          text: borrowerBody(),
        })
      );
    }

    // If borrower triggered the change, notify lender only
    if (triggerRole !== 'lender') {
      tasks.push(
        transporter.sendMail({
          from: process.env.EMAIL_USER ,
          to: lender.email,
          subject: subjectMap[status],
          text: lenderBody(),
        })
      );
    }

    if (tasks.length > 0) {
      await Promise.all(tasks);
    }
  } catch (err) {
    console.error('Error sending rental status emails:', err);
  }
}

// Simple helper for return proof emails – notify a single party that proof was submitted
export async function sendReturnProofEmail(
  order: RentalStatusEmailOrder,
  target: 'borrower' | 'lender'
): Promise<void> {
  const { borrower, lender, costumeName, id } = order;
  const recipient = target === 'lender' ? lender : borrower;

  const subject = `Return proof submitted: ${costumeName}`;
  const body = `Hi ${recipient.name},\n\nReturn proof has been submitted for the costume "${costumeName}".\nYou can review the details in your rentals dashboard.\n\nReference ID: ${id}`;

  try {
    await transporter.sendMail({
      from: process.env.EMAIL_USER ,
      to: recipient.email,
      subject,
      text: body,
    });
  } catch (err) {
    console.error('Error sending return proof email:', err);
  }
}

interface LenderVerificationEmailParams {
  email: string;
  name: string;
  status: 'approved' | 'rejected';
  reason?: string;
}

export async function sendLenderVerificationEmail({
  email,
  name,
  status,
  reason,
}: LenderVerificationEmailParams): Promise<void> {
  const baseUrl = process.env.FRONTEND_URL || 'https://cosconnect.onnline';

  const subject =
    status === 'approved'
      ? 'Your CosConnect lender account has been approved'
      : 'Your CosConnect lender application was rejected';

  const bodyLines: string[] = [];
  bodyLines.push(`Hi ${name},`);
  bodyLines.push('');

  if (status === 'approved') {
    bodyLines.push('Great news! Your CosConnect lender account has been approved and verified.');
    bodyLines.push('You can now list costumes and manage your rentals from your lender dashboard.');
  } else {
    bodyLines.push('We\'re sorry to let you know that your CosConnect lender application was not approved.');
    if (reason) {
      bodyLines.push('');
      bodyLines.push(`Reason: ${reason}`);
    }
  }

  bodyLines.push('');
  bodyLines.push(`You can access your account here: ${baseUrl}/dashboard`);
  bodyLines.push('');
  bodyLines.push('Best regards,');
  bodyLines.push('CosConnect Team');

  const text = bodyLines.join('\n');

  try {
    await transporter.sendMail({
      from: process.env.EMAIL_USER ,
      to: email,
      subject,
      text,
    });
  } catch (err) {
    console.error('Error sending lender verification email:', err);
  }
}
