import nodemailer from 'nodemailer';

// Configure nodemailer transporter
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER ,
        pass: process.env.EMAIL_PASSWORD || ''
    }
});


// Add this interface near the top with other interfaces
interface WarningEmailParams {
    recipientEmail: string;
    recipientName: string;
    warningReason: string;
    adminNotes?: string;
    warningLevel: 'first' | 'final';
    blockDate?: string; // ISO date string
}

// Add this function to emailServices.ts
export const sendWarningEmail = async ({
    recipientEmail,
    recipientName,
    warningReason,
    adminNotes,
    warningLevel,
    blockDate
}: WarningEmailParams): Promise<boolean> => {
    try {
        const isFinalWarning = warningLevel === 'final';
        const warningTitle = isFinalWarning ? 'Final Warning: Account Suspension Imminent' : 'Warning: Content Violation';

        const emailContent = `
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>${warningTitle}</title>
            </head>
            <body style="margin: 0; padding: 0; background-color: #f5f5f5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
                <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5; padding: 20px 0;">
                    <tr>
                        <td align="center">
                            <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); overflow: hidden;">
                                <!-- Header -->
                                <tr>
                                    <td style="background: linear-gradient(135deg, #ffc107 0%, #ff9800 100%); padding: 40px 30px; text-align: center;">
                                        <div style="width: 60px; height: 60px; background-color: rgba(255,255,255,0.3); border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 15px;">
                                            <span style="font-size: 32px;">⚠️</span>
                                        </div>
                                        <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600;">
                                            ${warningTitle}
                                        </h1>
                                    </td>
                                </tr>

                                <!-- Body -->
                                <tr>
                                    <td style="padding: 40px 30px;">
                                        <p style="margin: 0 0 20px 0; color: #333333; font-size: 16px; line-height: 1.6;">
                                            Hello <strong>${recipientName}</strong>,
                                        </p>
                                        
                                        <p style="margin: 0 0 20px 0; color: #555555; font-size: 15px; line-height: 1.6;">
                                            ${isFinalWarning
                ? `This is a final warning regarding your recent activity on CosConnect. Your account is at risk of being suspended due to repeated violations of our community guidelines.`
                : `We're reaching out to inform you about a recent violation of our community guidelines.`}
                                        </p>

                                        <div style="background-color: #fff8e1; border-left: 4px solid #ffc107; padding: 15px; margin-bottom: 25px; border-radius: 0 8px 8px 0;">
                                            <p style="margin: 0 0 10px 0; color: #333; font-weight: 600;">Reason for Warning:</p>
                                            <p style="margin: 0; color: #555; font-size: 14px;">${warningReason}</p>
                                            ${adminNotes ? `
                                                <p style="margin: 10px 0 0 0; color: #333; font-weight: 600;">Admin Notes:</p>
                                                <p style="margin: 5px 0 0 0; color: #555; font-size: 14px;">${adminNotes}</p>
                                            ` : ''}
                                        </div>

                                        ${isFinalWarning && blockDate ? `
                                            <div style="background-color: #fff3e0; border: 1px solid #ffb74d; padding: 15px; margin-bottom: 25px; border-radius: 8px;">
                                                <p style="margin: 0 0 10px 0; color: #e65100; font-weight: 600; display: flex; align-items: center;">
                                                    <span style="margin-right: 8px;">⏰</span> Account Suspension Notice
                                                </p>
                                                <p style="margin: 0; color: #555; font-size: 14px;">
                                                    Your account will be suspended on <strong>${new Date(blockDate).toLocaleDateString()}</strong> if the issue is not resolved.
                                                </p>
                                            </div>
                                        ` : ''}

                                        <p style="margin: 0 0 15px 0; color: #555555; font-size: 15px; line-height: 1.6;">
                                            ${isFinalWarning
                ? 'To prevent your account from being suspended, please review our community guidelines and ensure your content complies with our policies.'
                : 'Please review our community guidelines to understand what content is allowed on our platform.'}
                                        </p>

                                        <div style="margin: 30px 0; text-align: center;">
                                            <a href="${process.env.FRONTEND_URL || 'https://yourwebsite.com'}/community-guidelines" 
                                               style="display: inline-block; background-color: #007bff; color: #ffffff; text-decoration: none; padding: 12px 25px; border-radius: 6px; font-weight: 500; font-size: 15px;">
                                                Review Community Guidelines
                                            </a>
                                        </div>

                                        <p style="margin: 0 0 5px 0; color: #555555; font-size: 14px; line-height: 1.6;">
                                            If you believe this warning was sent in error, please contact our support team.
                                        </p>
                                        
                                        <p style="margin: 20px 0 0 0; color: #777777; font-size: 14px; line-height: 1.6; border-top: 1px solid #eeeeee; padding-top: 20px;">
                                            This is an automated message. Please do not reply to this email.
                                        </p>
                                    </td>
                                </tr>

                                <!-- Footer -->
                                <tr>
                                    <td style="background-color: #f9f9f9; padding: 20px 30px; text-align: center; border-top: 1px solid #eeeeee;">
                                        <p style="margin: 0; color: #777777; font-size: 13px; line-height: 1.5;">
                                            &copy; ${new Date().getFullYear()} CosConnect. All rights reserved.<br>
                                            <a href="${process.env.FRONTEND_URL || 'https://yourwebsite.com'}/privacy" style="color: #007bff; text-decoration: none;">Privacy Policy</a> | 
                                            <a href="${process.env.FRONTEND_URL || 'https://yourwebsite.com'}/terms" style="color: #007bff; text-decoration: none; margin: 0 10px;">Terms of Service</a> | 
                                            <a href="${process.env.FRONTEND_URL || 'https://yourwebsite.com'}/contact" style="color: #007bff; text-decoration: none;">Contact Support</a>
                                        </p>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </body>
            </html>
        `;

        await transporter.sendMail({
            from: `"CosConnect Moderation" <${process.env.EMAIL_USER }>`,
            to: recipientEmail,
            subject: `${isFinalWarning ? '⚠️ FINAL WARNING: ' : '⚠️ Warning: '} Community Guidelines Violation - ${warningLevel === 'first' ? 'First Warning' : 'Final Warning'}`,
            html: emailContent,
        });

        return true;
    } catch (error) {
        console.error('Error sending warning email:', error);
        return false;
    }
};

interface PostRemovalEmailParams {
    recipientEmail: string;
    recipientName: string;
    postContent: string;
    reportReason: string;
    adminNotes?: string;
}

export const sendPostRemovalEmail = async ({
    recipientEmail,
    recipientName,
    postContent,
    reportReason,
    adminNotes
}: PostRemovalEmailParams): Promise<boolean> => {
    try {
        // Truncate content safely
        const truncatedContent = postContent.length > 200
            ? `${postContent.substring(0, 200)}...`
            : postContent;

        const emailContent = `
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Post Removal Notice</title>
            </head>
            <body style="margin: 0; padding: 0; background-color: #f5f5f5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
                <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5; padding: 20px 0;">
                    <tr>
                        <td align="center">
                            <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); overflow: hidden;">
                                <!-- Header -->
                                <tr>
                                    <td style="background: linear-gradient(135deg, #dc3545 0%, #c82333 100%); padding: 40px 30px; text-align: center;">
                                        <div style="width: 60px; height: 60px; background-color: rgba(255,255,255,0.2); border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 15px;">
                                            <span style="font-size: 32px;">🚫</span>
                                        </div>
                                        <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600;">
                                            Content Removed
                                        </h1>
                                        <p style="margin: 10px 0 0 0; color: rgba(255,255,255,0.9); font-size: 14px;">
                                            Community Guidelines Violation
                                        </p>
                                    </td>
                                </tr>

                                <!-- Body -->
                                <tr>
                                    <td style="padding: 40px 30px;">
                                        <p style="margin: 0 0 20px 0; color: #333333; font-size: 16px; line-height: 1.6;">
                                            Hello <strong>${recipientName}</strong>,
                                        </p>
                                        
                                        <p style="margin: 0 0 25px 0; color: #555555; font-size: 15px; line-height: 1.6;">
                                            We're writing to inform you that your post on <strong>CosConnect</strong> has been removed following a review by our moderation team. The content was found to violate our community guidelines.
                                        </p>

                                        <!-- Content Box -->
                                        <table width="100%" cellpadding="0" cellspacing="0" style="margin: 0 0 25px 0; border-left: 4px solid #dc3545; background-color: #fff5f5; border-radius: 8px; overflow: hidden;">
                                            <tr>
                                                <td style="padding: 20px;">
                                                    <p style="margin: 0 0 12px 0; color: #721c24; font-size: 13px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">
                                                        📄 Removed Content
                                                    </p>
                                                    <p style="margin: 0 0 15px 0; color: #333333; font-size: 14px; line-height: 1.5; font-style: italic; padding: 12px; background-color: #ffffff; border-radius: 6px; border: 1px solid #f5c6cb;">
                                                        "${truncatedContent}"
                                                    </p>
                                                    
                                                    <p style="margin: 0 0 8px 0; color: #721c24; font-size: 13px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">
                                                        ⚠️ Violation Reason
                                                    </p>
                                                    <p style="margin: 0 0 ${adminNotes ? '15px' : '0'} 0; color: #333333; font-size: 14px; line-height: 1.5;">
                                                        <strong>${reportReason}</strong>
                                                    </p>
                                                    
                                                    ${adminNotes ? `
                                                        <p style="margin: 0 0 8px 0; color: #721c24; font-size: 13px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">
                                                            📝 Additional Notes
                                                        </p>
                                                        <p style="margin: 0; color: #555555; font-size: 14px; line-height: 1.5;">
                                                            ${adminNotes}
                                                        </p>
                                                    ` : ''}
                                                </td>
                                            </tr>
                                        </table>

                                        <!-- Info Box -->
                                        <table width="100%" cellpadding="0" cellspacing="0" style="margin: 0 0 25px 0; background-color: #fff8e1; border-radius: 8px; overflow: hidden;">
                                            <tr>
                                                <td style="padding: 20px;">
                                                    <p style="margin: 0 0 10px 0; color: #f57c00; font-size: 14px; font-weight: 600;">
                                                        ℹ️ What This Means
                                                    </p>
                                                    <ul style="margin: 0; padding-left: 20px; color: #555555; font-size: 14px; line-height: 1.6;">
                                                        <li style="margin-bottom: 8px;">Your post has been permanently removed from CosConnect</li>
                                                        <li style="margin-bottom: 8px;">Please review our community guidelines before posting again</li>
                                                        <li style="margin-bottom: 0;">Repeated violations may result in account restrictions</li>
                                                    </ul>
                                                </td>
                                            </tr>
                                        </table>

                                        <p style="margin: 0 0 20px 0; color: #555555; font-size: 15px; line-height: 1.6;">
                                            We value every member of our community and encourage respectful, constructive interactions. If you believe this action was taken in error, please don't hesitate to reach out to our support team.
                                        </p>

                                        <!-- CTA Button -->
                                        <table cellpadding="0" cellspacing="0" style="margin: 0 0 25px 0;">
                                            <tr>
                                                <td align="center" style="border-radius: 6px; background-color: #007bff;">
                                                    <a href="mailto:support@cosconnect.com" style="display: inline-block; padding: 14px 30px; color: #ffffff; text-decoration: none; font-size: 15px; font-weight: 600; border-radius: 6px;">
                                                        Contact Support
                                                    </a>
                                                </td>
                                                <td style="padding-left: 15px;">
                                                    <a href="https://cosconnect.com/guidelines" style="display: inline-block; padding: 14px 30px; color: #007bff; text-decoration: none; font-size: 15px; font-weight: 600; border: 2px solid #007bff; border-radius: 6px; background-color: #ffffff;">
                                                        Review Guidelines
                                                    </a>
                                                </td>
                                            </tr>
                                        </table>

                                        <p style="margin: 0; color: #555555; font-size: 15px; line-height: 1.6;">
                                            Thank you for your understanding and cooperation.
                                        </p>
                                        
                                        <p style="margin: 20px 0 0 0; color: #333333; font-size: 15px; line-height: 1.6;">
                                            Best regards,<br>
                                            <strong>The CosConnect Moderation Team</strong>
                                        </p>
                                    </td>
                                </tr>

                                <!-- Footer -->
                                <tr>
                                    <td style="background-color: #f8f9fa; padding: 25px 30px; border-top: 1px solid #e9ecef;">
                                        <p style="margin: 0 0 10px 0; color: #6c757d; font-size: 12px; line-height: 1.5; text-align: center;">
                                            This is an automated notification from CosConnect. Please do not reply to this email.
                                        </p>
                                        <p style="margin: 0; color: #6c757d; font-size: 12px; line-height: 1.5; text-align: center;">
                                            © ${new Date().getFullYear()} CosConnect. All rights reserved.
                                        </p>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </body>
            </html>
        `;

        const mailOptions = {
            from: `"CosConnect Moderation Team" <${process.env.EMAIL_USER }>`,
            to: recipientEmail,
            subject: '🚫 Your Post Has Been Removed - CosConnect',
            html: emailContent
        };

        await transporter.sendMail(mailOptions);
        console.log(`Post removal email sent successfully to: ${recipientEmail}`);
        return true;

    } catch (error) {
        console.error('Error sending post removal email:', error);
        return false;
    }
};

interface OrderPartyInfo {
    email: string;
    name: string;
}

interface OrderStatusEmailOrder {
    id: string;
    type: string;
    status: string;
    item: {
        name: string;
    };
    borrower: OrderPartyInfo;
    lender: OrderPartyInfo;
}

type OrderStatusEmailType = 'accepted' | 'rejected' | 'delivered' | 'returned';

interface OrderStatusEmailOptions {
    triggerRole?: 'lender' | 'borrower';
    rejectMessage?: string;
}

export const notifyOrderStatusChange = async (
    order: OrderStatusEmailOrder,
    status: OrderStatusEmailType,
    options: OrderStatusEmailOptions = {}
): Promise<boolean> => {
    try {
        const { borrower, lender, item, id } = order;
        const { triggerRole = 'lender', rejectMessage } = options;

        // Decide who should receive the email based on who triggered the action
        // If lender triggered, notify borrower; if borrower triggered, notify lender
        const recipient: OrderPartyInfo = triggerRole === 'lender' ? borrower : lender;

        const baseUrl = process.env.FRONTEND_URL || 'http://localhost:3000';

        const subjectMap: Record<OrderStatusEmailType, string> = {
            accepted: `Rental Accepted: ${item.name}`,
            rejected: `Rental Request Rejected: ${item.name}`,
            delivered: `Costume Delivered: ${item.name}`,
            returned: `Costume Returned: ${item.name}`,
        };

        const plainBodyForStatus = () => {
            switch (status) {
                case 'accepted':
                    return `Hi ${recipient.name},\n\nYour rental request for "${item.name}" has been accepted.\nYou can view the rental details here: ${baseUrl}/my-rentals.\n\nReference ID: ${id}`;
                case 'rejected':
                    return `Hi ${recipient.name},\n\nUnfortunately, your rental request for "${item.name}" was rejected.${rejectMessage ? `\n\nReason: ${rejectMessage}` : ''
                        }\n\nReference ID: ${id}`;
                case 'delivered':
                    return `Hi ${recipient.name},\n\nThe costume "${item.name}" has been marked as delivered.\nPlease check the details in your account: ${baseUrl}/my-rentals.\n\nReference ID: ${id}`;
                case 'returned':
                    return `Hi ${recipient.name},\n\nThe costume "${item.name}" has been marked as returned.\nYou can review the rental in your account: ${baseUrl}/my-rentals.\n\nReference ID: ${id}`;
            }
        };

        const statusDescription = (() => {
            switch (status) {
                case 'accepted':
                    return 'Great news! Your rental request has been approved.';
                case 'rejected':
                    return 'We want to let you know that this rental request was not approved.';
                case 'delivered':
                    return 'The lender has marked this costume as delivered.';
                case 'returned':
                    return 'This rental has been marked as returned.';
            }
        })();

        const extraLine = status === 'rejected' && rejectMessage
            ? `<p style="margin: 0 0 15px 0; color: #b00020; font-size: 14px; line-height: 1.6;"><strong>Reason provided:</strong> ${rejectMessage}</p>`
            : '';

        const statusIcon = (() => {
            switch (status) {
                case 'accepted':
                    return '✅';
                case 'rejected':
                    return '❌';
                case 'delivered':
                    return '📦';
                case 'returned':
                    return '🎉';
            }
        })();

        const emailHtml = `
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8" />
                <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                <title>${subjectMap[status]}</title>
            </head>
            <body style="margin:0;padding:0;background-color:#f5f5f5;font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
                <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#f5f5f5;padding:24px 0;">
                    <tr>
                        <td align="center">
                            <table width="600" cellpadding="0" cellspacing="0" style="background-color:#ffffff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,0.06);overflow:hidden;">
                                <tr>
                                    <td style="background-color:#f43f5e;padding:28px 32px;color:#ffffff;text-align:left;">
                                        <h1 style="margin:0 0 4px 0;font-size:22px;font-weight:600;">${statusIcon ? `${statusIcon} ` : ''}${subjectMap[status]}</h1>
                                        <p style="margin:0;font-size:13px;opacity:0.9;">Rental update from CosConnect</p>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding:28px 32px 16px 32px;">
                                        <p style="margin:0 0 16px 0;color:#111827;font-size:15px;line-height:1.6;">Hi <strong>${recipient.name}</strong>,</p>
                                        <p style="margin:0 0 16px 0;color:#4b5563;font-size:14px;line-height:1.6;">${statusDescription || ''}</p>

                                        ${extraLine}

                                        <table width="100%" cellpadding="0" cellspacing="0" style="margin:16px 0 20px 0;border-collapse:collapse;border-radius:10px;overflow:hidden;border:1px solid #e5e7eb;">
                                            <tr style="background-color:#f9fafb;">
                                                <td colspan="2" style="padding:14px 16px;color:#111827;font-size:14px;font-weight:600;">Rental Summary</td>
                                            </tr>
                                            <tr>
                                                <td style="padding:10px 16px;border-top:1px solid #e5e7eb;color:#6b7280;font-size:13px;">Item</td>
                                                <td style="padding:10px 16px;border-top:1px solid #e5e7eb;color:#111827;font-size:13px;font-weight:500;">${item.name}</td>
                                            </tr>
                                            <tr>
                                                <td style="padding:10px 16px;border-top:1px solid #e5e7eb;color:#6b7280;font-size:13px;">Status</td>
                                                <td style="padding:10px 16px;border-top:1px solid #e5e7eb;color:#111827;font-size:13px;text-transform:capitalize;">${status}</td>
                                            </tr>
                                            <tr>
                                                <td style="padding:10px 16px;border-top:1px solid #e5e7eb;color:#6b7280;font-size:13px;">Reference ID</td>
                                                <td style="padding:10px 16px;border-top:1px solid #e5e7eb;color:#111827;font-size:13px;font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;">${id}</td>
                                            </tr>
                                        </table>

                                        <p style="margin:0 0 18px 0;color:#4b5563;font-size:14px;line-height:1.6;">You can review this rental any time from your CosConnect account.</p>

                                        <div style="margin:0 0 24px 0;text-align:left;">
                                            <a href="${baseUrl}/my-rentals" style="display:inline-block;padding:10px 20px;background-color:#ec4899;color:#ffffff;text-decoration:none;border-radius:9999px;font-size:14px;font-weight:500;">View my rentals</a>
                                        </div>

                                        <p style="margin:0;color:#9ca3af;font-size:12px;line-height:1.6;">If you did not expect this email, you can safely ignore it.</p>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding:16px 32px 20px 32px;background-color:#f9fafb;border-top:1px solid #e5e7eb;text-align:center;">
                                        <p style="margin:0 0 4px 0;color:#6b7280;font-size:11px;">CosConnect Rentals • Powered by the CosConnect platform</p>
                                        <p style="margin:0;color:#9ca3af;font-size:11px;">© ${new Date().getFullYear()} CosConnect. All rights reserved.</p>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </body>
            </html>
        `;

        await transporter.sendMail({
            from: process.env.EMAIL_USER ,
            to: recipient.email,
            subject: subjectMap[status],
            text: plainBodyForStatus(),
            html: emailHtml,
        });

        return true;
    } catch (error) {
        console.error('Error sending order status email:', error);
        return false;
    }
};

interface OrderUpdateEmailParams {
    recipientEmail: string;
    recipientName: string;
    orderId: string;
    itemName: string;
    updateType:
    | 'return_initiated'
    | 'return_approved'
    | 'return_rejected'
    | 'general_update';
    message: string;
    actionRequired?: boolean;
}

export const sendOrderUpdateEmail = async ({
    recipientEmail,
    recipientName,
    orderId,
    itemName,
    updateType,
    message,
    actionRequired = false,
}: OrderUpdateEmailParams): Promise<boolean> => {
    try {
        const baseUrl = process.env.FRONTEND_URL || 'http://localhost:3000';

        const subjectPrefixMap: Record<OrderUpdateEmailParams['updateType'], string> = {
            return_initiated: 'Return Proof Submitted',
            return_approved: 'Return Approved',
            return_rejected: 'Return Rejected',
            general_update: 'Rental Update',
        };

        const subject = `${subjectPrefixMap[updateType]} - ${itemName}`;

        const dashboardUrl = `${baseUrl}/lender/manage-rentals`;

        const actionLine = actionRequired
            ? `\n\nAction required: Please review this rental in your dashboard: ${dashboardUrl}.`
            : '';

        const emailText = `Hi ${recipientName},\n\n${message}${actionLine}\n\nRental Reference ID: ${orderId}`;

        const updateIcon = (() => {
            switch (updateType) {
                case 'return_initiated':
                    return '📸';
                case 'return_approved':
                    return '✅';
                case 'return_rejected':
                    return '❌';
                case 'general_update':
                    return 'ℹ️';
            }
        })();

        const emailHtml = `
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8" />
                <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                <title>${subject}</title>
            </head>
            <body style="margin:0;padding:0;background-color:#f5f5f5;font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
                <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#f5f5f5;padding:24px 0;">
                    <tr>
                        <td align="center">
                            <table width="600" cellpadding="0" cellspacing="0" style="background-color:#ffffff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,0.06);overflow:hidden;">
                                <tr>
                                    <td style="background-color:#f43f5e;padding:28px 32px;color:#ffffff;text-align:left;">
                                        <h1 style="margin:0 0 4px 0;font-size:22px;font-weight:600;">${updateIcon ? `${updateIcon} ` : ''}${subject}</h1>
                                        <p style="margin:0;font-size:13px;opacity:0.9;">Rental update from CosConnect</p>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding:28px 32px 16px 32px;">
                                        <p style="margin:0 0 16px 0;color:#111827;font-size:15px;line-height:1.6;">Hi <strong>${recipientName}</strong>,</p>
                                        <p style="margin:0 0 18px 0;color:#4b5563;font-size:14px;line-height:1.6;">${message}</p>

                                        <table width="100%" cellpadding="0" cellspacing="0" style="margin:16px 0 20px 0;border-collapse:collapse;border-radius:10px;overflow:hidden;border:1px solid #e5e7eb;">
                                            <tr style="background-color:#f9fafb;">
                                                <td colspan="2" style="padding:14px 16px;color:#111827;font-size:14px;font-weight:600;">Rental Details</td>
                                            </tr>
                                            <tr>
                                                <td style="padding:10px 16px;border-top:1px solid #e5e7eb;color:#6b7280;font-size:13px;">Item</td>
                                                <td style="padding:10px 16px;border-top:1px solid #e5e7eb;color:#111827;font-size:13px;font-weight:500;">${itemName}</td>
                                            </tr>
                                            <tr>
                                                <td style="padding:10px 16px;border-top:1px solid #e5e7eb;color:#6b7280;font-size:13px;">Reference ID</td>
                                                <td style="padding:10px 16px;border-top:1px solid #e5e7eb;color:#111827;font-size:13px;font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;">${orderId}</td>
                                            </tr>
                                        </table>

                                        ${actionRequired
                ? `<p style="margin:0 0 16px 0;color:#b45309;font-size:13px;line-height:1.6;"><strong>Action required:</strong> Please review this rental in your dashboard.</p>
                                               <div style="margin:0 0 24px 0;"><a href="${dashboardUrl}" style="display:inline-block;padding:10px 20px;background-color:#0ea5e9;color:#ffffff;text-decoration:none;border-radius:9999px;font-size:14px;font-weight:500;">Open lender dashboard</a></div>`
                : '<p style="margin:0 0 24px 0;color:#6b7280;font-size:13px;line-height:1.6;">No immediate action is required on your side.</p>'}

                                        <p style="margin:0;color:#9ca3af;font-size:12px;line-height:1.6;">If you did not expect this email, you can safely ignore it.</p>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding:16px 32px 20px 32px;background-color:#f9fafb;border-top:1px solid #e5e7eb;text-align:center;">
                                        <p style="margin:0 0 4px 0;color:#6b7280;font-size:11px;">CosConnect Rentals • Powered by the CosConnect platform</p>
                                        <p style="margin:0;color:#9ca3af;font-size:11px;">© ${new Date().getFullYear()} CosConnect. All rights reserved.</p>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </body>
            </html>
        `;

        await transporter.sendMail({
            from: process.env.EMAIL_USER ,
            to: recipientEmail,
            subject,
            text: emailText,
            html: emailHtml,
        });

        return true;
    } catch (error) {
        console.error('Error sending order update email:', error);
        return false;
    }
};
