import nodemailer from 'nodemailer';

// Lightweight dedicated mailer for return-proof notifications
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER ,
    pass: process.env.EMAIL_PASSWORD || '',
  },
});

export interface ReturnProofEmailParams {
  recipientEmail: string;
  recipientName: string;
  borrowerName: string;
  orderId: string;
  itemName: string;
}

export const sendReturnProofEmail = async ({
  recipientEmail,
  recipientName,
  borrowerName,
  orderId,
  itemName,
}: ReturnProofEmailParams): Promise<boolean> => {
  try {
    const html = `<!DOCTYPE html>
<html lang="en"><head><meta charset=\"UTF-8\" /><title>Return Proof Submitted</title></head>
<body style=\"margin:0;padding:0;background:#f5f5f5;font-family:Arial,Helvetica,sans-serif;\">
  <table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" style=\"padding:20px 0;background:#f5f5f5;\">
    <tr><td align=\"center\">
      <table width=\"600\" cellspacing=\"0\" cellpadding=\"0\" style=\"background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.05);\">
        <tr><td style=\"background:#6c63ff;color:#fff;text-align:center;padding:30px;\">
          <h1 style=\"margin:0;font-size:22px;\">Return Proof Submitted</h1>
        </td></tr>
        <tr><td style=\"padding:30px;font-size:15px;color:#333;\">
          <p>Hi <strong>${recipientName}</strong>,</p>
          <p><strong>${borrowerName}</strong> has uploaded photo/video proof for <strong>${itemName}</strong> (Order ID: <strong>${orderId}</strong>).</p>
          <p>Please review the proof and coordinate the physical return.</p>
          <p style=\"text-align:center;margin:25px 0;\">
            <a href=\"${process.env.FRONTEND_URL || 'https://cosconnectme.com'}/orders/${orderId}\" style=\"display:inline-block;background:#6c63ff;color:#fff;text-decoration:none;padding:12px 25px;border-radius:6px;font-weight:600;\">View Order</a>
          </p>
          <p style=\"font-size:12px;color:#666;\">This is an automated message from CosConnect.</p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;

    await transporter.sendMail({
      from: process.env.EMAIL_USER ,
      to: recipientEmail,
      subject: 'Return Proof Submitted – Action Required',
      html,
    });

    return true;
  } catch (error) {
    console.error('Error sending return-proof email:', error);
    return false;
  }
};
