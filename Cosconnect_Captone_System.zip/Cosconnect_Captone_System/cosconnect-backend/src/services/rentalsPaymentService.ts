// services/paymentService.ts
import { rentalPaymentHistory } from '@/db-schema';
import db from '@/db/supabase/db_connect';

import axios from 'axios';
import { randomUUID } from 'crypto';
import { eq } from 'drizzle-orm';
import { Context } from 'hono';

// PayMongo configuration
const PAYMONGO_API_URL = 'https://api.paymongo.com/v1';
const PAYMONGO_SECRET_KEY = process.env.PAYMONGO_SECRET_KEY;

if (!PAYMONGO_SECRET_KEY) {
    throw new Error('PAYMONGO_SECRET_KEY environment variable is required');
}

// Payment method configuration - focusing on GCash only
const PAYMENT_METHODS = {
    gcash: {
        type: 'gcash',
        name: 'GCash'
    }
} as any;


interface PaymentSessionResult {
    success: boolean;
    paymentIntent: any;
    source: any;
    redirectUrl: string;
    sessionId: string;
    expiresAt?: Date;
}

// Logger utility (replace with your actual logger)
const logger = {
    info: (message: string, data?: any) => console.log(`[INFO] ${message}`, data),
    error: (message: string, error?: any) => console.error(`[ERROR] ${message}`, error),
    warn: (message: string, data?: any) => console.warn(`[WARN] ${message}`, data)
};

// Validation function
const validatePaymentData = (paymentData: any): string[] => {
    const errors: string[] = [];

    // Validate borrower data
    if (!paymentData.borrower.uid) errors.push('Borrower UID is required');
    if (!paymentData.borrower.name) errors.push('Borrower name is required');
    if (!paymentData.borrower.email) errors.push('Borrower email is required');

    // Validate rental data
    if (!paymentData.rental.productId) errors.push('Product ID is required');
    if (!paymentData.rental.productName) errors.push('Product name is required');
    if (!paymentData.rental.lenderId) errors.push('Lender ID is required');

    // Validate payment details
    if (!paymentData.paymentDetails.amount || paymentData.paymentDetails.amount <= 0) {
        errors.push('Valid payment amount is required');
    }

    if (paymentData.paymentDetails.paymentMethod !== 'gcash') {
        errors.push('Only GCash payment method is supported');
    }

    return errors;
};


// Helper function to get authorization header
export const getAuthHeader = (): string => {
    if (!PAYMONGO_SECRET_KEY) {
        throw new Error('PAYMONGO_SECRET_KEY is not configured');
    }
    return `Basic ${Buffer.from(PAYMONGO_SECRET_KEY + ':').toString('base64')}`;
};




/**
 * Create payment session for costume rental using PayMongo
 * Focuses specifically on GCash integration using checkout sessions
 */
export const createCostumeRentalPaymentSession = async (paymentData: any): Promise<PaymentSessionResult> => {
    try {
        console.log('=== PayMongo Payment Session Creation Started ===');
        console.log('Payment Data:', JSON.stringify(paymentData, null, 2));

        // Validate payment data
        const validationErrors = validatePaymentData(paymentData);
        if (validationErrors.length > 0) {
            console.error('Validation Errors:', validationErrors);
            throw new Error(`Validation failed: ${validationErrors.join(', ')}`);
        }

        // Configuration
        const currency = 'PHP';
        const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:3000';

        // Generate reference number
        const referenceNumber = `RENT-${Date.now().toString().slice(-6)}-${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`;

        // Calculate amount in centavos
        const amountInCentavos = Math.round(paymentData.paymentDetails.amount * 100);

        console.log('Creating Checkout Session...');
        const checkoutSessionResponse = await axios.post(
            `${PAYMONGO_API_URL}/checkout_sessions`,
            {
                data: {
                    attributes: {
                        // Only using GCash
                        payment_method_types: ['gcash'],
                        line_items: [
                            {
                                name: `Rental: ${paymentData.rental.productName}`,
                                amount: amountInCentavos,
                                currency: currency,
                                quantity: 1,
                            }
                        ],
                        payment_intent_data: {
                            capture_type: 'automatic',
                            description: `Rental payment for ${paymentData.rental.productName}`,
                            metadata: {
                                rental_id: paymentData.rental.conversationId,
                                product_id: paymentData.rental.productId,
                                borrower_id: paymentData.borrower.uid,
                                lender_id: paymentData.rental.lenderId,
                                start_date: paymentData.rental.startDate,
                                end_date: paymentData.rental.endDate,
                                reference_number: referenceNumber,
                            }
                        },
                        customer_email: paymentData.borrower.email,
                        success_url: `${frontendUrl}/payment/success?reference=${referenceNumber}`,
                        cancel_url: `${frontendUrl}/payment/failed?reference=${referenceNumber}`,
                        reference_number: referenceNumber,
                        send_email_receipt: true,
                        description: `Rental payment for ${paymentData.rental.productName} (${paymentData.rental.startDate} to ${paymentData.rental.endDate})`,
                        billing: {
                            name: paymentData.borrower.name,
                            email: paymentData.borrower.email,
                            phone: paymentData.borrower.phone || '09000000000',
                        }
                    }
                }
            },
            {
                headers: {
                    'Authorization': getAuthHeader(),
                    'Content-Type': 'application/json'
                },
                timeout: 30000
            }
        );

        console.log('Checkout Session Created:', {
            id: checkoutSessionResponse.data.data.id,
            checkoutUrl: checkoutSessionResponse.data.data.attributes.checkout_url
        });

        const session = checkoutSessionResponse.data.data;
        const sessionAttributes = session.attributes;
        const paymentIntent = sessionAttributes.payment_intent;

        // Prepare the result
        const result: PaymentSessionResult = {
            success: true,
            paymentIntent: paymentIntent,
            source: null, // No source with checkout sessions
            redirectUrl: sessionAttributes.checkout_url,
            sessionId: session.id,
            expiresAt: new Date(sessionAttributes.expires_at)
        };

        logger.info('PayMongo payment session created successfully', {
            sessionId: session.id,
            referenceNumber: referenceNumber,
            paymentIntentId: paymentIntent?.id,
            checkoutUrl: sessionAttributes.checkout_url,
            expiresAt: sessionAttributes.expires_at
        });

        console.log('=== PayMongo Payment Session Creation Completed ===');
        return result;

    } catch (error: any) {
        console.error('=== PayMongo Payment Session Creation Error ===');
        console.error('Error Details:', error);

        if (error.response) {
            console.error('PayMongo API Error Response:', {
                status: error.response.status,
                statusText: error.response.statusText,
                data: error.response.data
            });
            logger.error('PayMongo API error', {
                status: error.response.status,
                error: error.response.data
            });
        }

        if (error.code === 'ECONNABORTED') {
            throw new Error('Payment service timeout. Please try again.');
        }

        // Extract meaningful error message from PayMongo response
        const errorMessage = error.response?.data?.errors?.[0]?.detail
            || error.response?.data?.message
            || error.message
            || 'Failed to create payment session';

        logger.error('Payment session creation failed', {
            error: errorMessage,
            originalError: error.message
        });

        throw new Error(errorMessage);
    }
};

/**
 * Get payment details after successful payment
 */
export const getCheckoutSessionStatus = async (sessionId: string) => {
    try {
        console.log('Getting checkout session status for:', sessionId);

        const checkoutSessionResponse = await axios.get(
            `${PAYMONGO_API_URL}/checkout_sessions/${sessionId}`,
            {
                headers: {
                    'Authorization': getAuthHeader(),
                    'Content-Type': 'application/json'
                }
            }
        );

        const session = checkoutSessionResponse.data.data;
        const paymentIntent = session.attributes.payment_intent;

        // If payment intent is available, get its status
        if (paymentIntent) {
            const paymentIntentResponse = await axios.get(
                `${PAYMONGO_API_URL}/payment_intents/${paymentIntent.id}`,
                {
                    headers: {
                        'Authorization': getAuthHeader(),
                        'Content-Type': 'application/json'
                    }
                }
            );

            const paymentIntentData = paymentIntentResponse.data.data;
            const paymongoStatus = paymentIntentData.attributes.status;
            const mappedStatus = mapPaymentStatus(paymongoStatus);

            return {
                success: true,
                sessionId,
                paymentIntentId: paymentIntent.id,
                paymongoStatus, // Original PayMongo status
                status: mappedStatus, // Mapped status for your database
                amount: paymentIntentData.attributes.amount / 100,
                currency: paymentIntentData.attributes.currency,
                metadata: paymentIntentData.attributes.metadata
            };
        }

        // If no payment intent yet
        return {
            success: true,
            sessionId,
            paymongoStatus: 'awaiting_payment_method',
            status: mapPaymentStatus('awaiting_payment_method'),
            message: 'Checkout session created but payment not yet initiated'
        };

    } catch (error: any) {
        console.error('Error getting checkout session status:', error);

        if (error.response?.status === 404) {
            return {
                success: false,
                paymongoStatus: 'not_found',
                status: 'unknown',
                message: 'Checkout session not found'
            };
        }

        return {
            success: false,
            paymongoStatus: 'error',
            status: 'unknown',
            message: error.message || 'Failed to get checkout session status'
        };
    }
};

/**
 * Endpoint handler for getting payment session status
 */
export const getPaymentSession = async (c: Context) => {
    const sessionId = c.req.param('sessionId');

    try {
        console.log('Getting payment session for:', sessionId);
        const paymentStatus = await getCheckoutSessionStatus(sessionId);

        return c.json({
            success: true,
            sessionId,
            status: paymentStatus.status,
            paymongoStatus: paymentStatus.paymongoStatus,
            paymentDetails: paymentStatus,
            message: `Payment status: ${paymentStatus.status}`
        }, 200);

    } catch (error: any) {
        console.error('Error fetching payment session:', error);

        return c.json({
            success: false,
            message: 'Failed to fetch payment session',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        }, 500);
    }
};


// Helper function to map PayMongo status to your database status
export const mapPaymentStatus = (paymongoStatus: string) => {
    switch (paymongoStatus) {
        case 'succeeded':
            return 'paid';
        case 'processing':
        case 'awaiting_next_action':
            return 'processing';
        case 'requires_payment_method':
        case 'awaiting_payment_method':
            return 'pending';
        case 'cancelled':
            return 'cancelled';
        case 'failed':
            return 'failed';
        case 'expired':
            return 'expired';
        default:
            return 'unknown';
    }
};





// Export types
export type { PaymentSessionResult };