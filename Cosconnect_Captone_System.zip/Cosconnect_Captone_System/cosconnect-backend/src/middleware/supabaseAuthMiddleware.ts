import type { Context, Next } from "hono";
import { supabase } from "../db/supabase/auth";

const JWT_SECRET = process.env.JWT_SECRET as string;

export const verifySupabaseToken = async (c: Context, next: Next) => {
    try {
        // Get token from Authorization header
        const authHeader = c.req.header('Authorization');

        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return c.json({
                success: false,
                message: 'Authorization header missing or malformed'
            }, 401);
        }

        const token = authHeader.replace('Bearer ', '');

        // For now, we'll use JWT verification (you can switch to Supabase JWT later)
        // When Supabase client is installed, you can use:
        // const { data: { user }, error } = await supabase.auth.getUser(token);

        if (!supabase) {
            return c.json({
                success: false,
                message: 'Supabase authentication not configured'
            }, 500);
        }

        // Verify the JWT token with Supabase
        const { data: { user }, error } = await supabase.auth.getUser(token);

        if (error || !user) {
            return c.json({
                success: false,
                message: 'Invalid or expired token'
            }, 401);
        }

        // Set user information in the context
        c.set('user', user);
        c.set('userId', user.id);

        // Continue to the next middleware or route handler
        await next();

    } catch (error: any) {
        console.error('Supabase Authentication Error:', error);
        return c.json({
            success: false,
            message: error.message || 'Invalid or expired token'
        }, 401);
    }
};