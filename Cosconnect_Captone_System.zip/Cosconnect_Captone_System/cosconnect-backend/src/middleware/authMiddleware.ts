import { Context, Next } from "hono";
import { verify } from "hono/jwt";
import { JWTPayload } from "hono/utils/jwt/types";

const JWT_SECRET = process.env.JWT_SECRET as string;

export const verifyToken = async (c: Context, next: Next) => {
    try {
        // Get token from Authorization header
        const authHeader = c.req.header('Authorization');

        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return c.json({
                success: false,
                message: 'Authorization header missing or malformed'
            }, 401);
        }

        const token = authHeader.replace('Bearer ', '');

        // Verify the token
        const decoded = await verify(token, JWT_SECRET);

        // Set user information in the context
        c.set('user', decoded as any);

        // Continue to the next middleware or route handler
        await next();

    } catch (error: any) {
        console.error('Authentication Error:', error);

        return c.json({
            success: false,
            message: error.message || 'Invalid or expired token'
        }, 401);
    }
};