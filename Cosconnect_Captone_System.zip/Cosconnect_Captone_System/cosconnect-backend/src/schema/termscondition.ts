// schema/termsAndConditions.ts
import { relations } from "drizzle-orm";
import type { InferInsertModel, InferSelectModel } from "drizzle-orm";
import {
    pgTable,
    uuid,
    text,
    jsonb,
    timestamp,
    varchar,
    index,
    primaryKey,
} from "drizzle-orm/pg-core";

// Define the section type to match your payload
export type Section = {
    id: string;
    heading: string;
    content: string;
    lastUpdated: string; // ISO date string
};

// Main Terms & Conditions Table
export const termsAndConditions = pgTable("terms_and_conditions",
    {
        // Auto-generated fields
        id: uuid("id").primaryKey().defaultRandom(),
        createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
        updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),

        // Required fields from payload
        userId: uuid("user_id").notNull(),
        title: varchar("title", { length: 255 }).notNull(),
        lastUpdated: varchar("last_updated", { length: 10 }).notNull(), // YYYY-MM-DD format

        // JSONB array of sections
        sections: jsonb("sections").$type<Section[]>().notNull(),
    },
    (table) => ({
        // Indexes
        userIdx: index("idx_terms_user_id").on(table.userId),
        titleIdx: index("idx_terms_title").on(table.title),
        updatedAtIdx: index("idx_terms_updated_at").on(table.updatedAt),
    })
);

// Type Definitions
export type TermsAndConditions = InferSelectModel<typeof termsAndConditions>;
export type NewTermsAndConditions = InferInsertModel<typeof termsAndConditions>;

// Payload type that matches your input
export type TermsAndConditionsPayload = {
    title: string;
    lastUpdated: string; // YYYY-MM-DD
    userId: string;
    sections: Section[];
};