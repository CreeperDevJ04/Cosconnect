// schema/rentalPayments.ts
import { relations } from 'drizzle-orm';
import type { InferInsertModel, InferSelectModel } from 'drizzle-orm';
import {
    pgTable,
    uuid,
    timestamp,
    varchar,
    jsonb,
    index,
    pgEnum,
    text
} from 'drizzle-orm/pg-core';
import { rentals } from './rentals';
import { costumes } from './costumes';

// ═══════════════════════════════════════════════════════════════
// 🎯 ENUMS
// ═══════════════════════════════════════════════════════════════
// ✅ UPDATED: Added 'paymaya' and 'card' payment methods
export const paymentMethodEnum = pgEnum('payment_method', [
    'gcash',
    'paymaya',
    'card'
]);

export const paymentStatusEnum = pgEnum('payment_status', [
    'pending',
    'processing',
    'paid',
    'failed',
    'cancelled',
    'refunded',
    'partial_refund',
    'expired'  // Added for session timeout
]);

export const paymentTypeEnum = pgEnum('payment_type', [
    'rental_fee',      // Main rental payment
    'security_deposit', // Security deposit
    'extension_fee',   // Late return fee
    'damage_fee',      // Damage compensation
    'refund',          // Refund transaction
    'payout',
]);

// PayMongo specific statuses
export const paymentGatewayStatusEnum = pgEnum('payment_gateway_status', [
    'awaiting_payment_method',
    'awaiting_next_action',
    'processing',
    'succeeded',
    'requires_payment_method',
    'cancelled',
    'pending'
]);

// ═══════════════════════════════════════════════════════════════
// 💳 RENTAL PAYMENT HISTORY TABLE
// ═══════════════════════════════════════════════════════════════
export const rentalPaymentHistory = pgTable('rental_payment_history', {
    id: uuid('id').primaryKey().defaultRandom(),

    // References
    rental_id: uuid('rental_id').notNull().references(() => rentals.id, { onDelete: 'cascade' }),

    // Human-friendly reference code for frontend
    reference_code: varchar('reference_code', { length: 50 }).unique().notNull(),
    // Example: RENTPAY-2025-00001

    // PayMongo Integration Fields
    paymongo_payment_intent_id: varchar('paymongo_payment_intent_id', { length: 100 }),
    paymongo_source_id: varchar('paymongo_source_id', { length: 100 }),
    session_id: varchar('session_id', { length: 100 }), // PayMongo session ID for tracking
    checkout_url: text('checkout_url'), // PayMongo checkout URL

    // Payment gateway status (from PayMongo)
    gateway_status: paymentGatewayStatusEnum('gateway_status'),
    gateway_status_updated_at: timestamp('gateway_status_updated_at'),

    // Payment classification
    payment_type: paymentTypeEnum('payment_type').notNull(),
    description: text('description'), // Human readable description

    // Payment details
    payment_method: paymentMethodEnum('payment_method').notNull(),
    payment_reference: varchar('payment_reference', { length: 100 }),
    // e.g. gcash reference number, paymaya number, card last 4 digits

    // Amount information
    amount: varchar('amount', { length: 32 }).notNull(),
    currency: varchar('currency', { length: 3 }).default('PHP').notNull(),

    // Status tracking
    status: paymentStatusEnum('status').default('pending').notNull(),

    // Processing information
    processed_at: timestamp('processed_at'), // When payment was confirmed
    processor_notes: text('processor_notes'), // Admin notes about processing

    // Receipt and proof
    receipt_url: text('receipt_url'), // Link to receipt/proof image
    receipt_number: varchar('receipt_number', { length: 100 }), // Official receipt number

    // PayMongo webhook tracking
    webhook_events: jsonb('webhook_events').$type<Array<{
        event_type: string;
        event_id: string;
        timestamp: string;
        data: any;
    }>>().default([]).notNull(),

    // Session expiry for PayMongo
    session_expires_at: timestamp('session_expires_at'), // When PayMongo session expires

    // Extra flexible data
    metadata: jsonb('metadata').$type<{
        gateway_response?: any;     // Payment gateway API response
        customer_info?: any;        // Additional customer details for this payment
        payment_method_info?: {     // ✅ NEW: Payment method specific info
            type: 'gcash' | 'paymaya' | 'card';
            payment_number?: string;  // GCash/PayMaya number
            refund_details?: {
                account_name: string;
                account_number: string;
                method: string;
            };
        };
        rental_details?: {          // ✅ NEW: Rental specific info
            start_date: string;
            end_date: string;
            total_days: number;
            delivery_method: string;
        };
        refund_reason?: string;     // If this is a refund, why?
        original_payment_id?: string; // If this is a refund, reference to original
        paymongo_metadata?: any;    // PayMongo specific metadata
        session_details?: {         // Session creation details
            created_via: string;
            frontend_url: string;
            redirect_success: string;
            redirect_failed: string;
            session_error?: string | null;
            expires_at_raw?: string;
        };
        [key: string]: any;         // Additional flexible data
    }>().default({}).notNull(),

    // Timestamps
    created_at: timestamp('created_at').defaultNow().notNull(),
    updated_at: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
    rentalIdIdx: index('rental_payment_rental_id_idx').on(table.rental_id),
    referenceIdx: index('rental_payment_reference_code_idx').on(table.reference_code),
    methodIdx: index('rental_payment_method_idx').on(table.payment_method),
    statusIdx: index('rental_payment_status_idx').on(table.status),
    typeIdx: index('rental_payment_type_idx').on(table.payment_type),
    processedAtIdx: index('rental_payment_processed_at_idx').on(table.processed_at),

    // PayMongo specific indexes
    sessionIdIdx: index('rental_payment_session_id_idx').on(table.session_id),
    paymongoIntentIdx: index('rental_payment_paymongo_intent_idx').on(table.paymongo_payment_intent_id),
    paymongoSourceIdx: index('rental_payment_paymongo_source_idx').on(table.paymongo_source_id),
    gatewayStatusIdx: index('rental_payment_gateway_status_idx').on(table.gateway_status),
    sessionExpiryIdx: index('rental_payment_session_expiry_idx').on(table.session_expires_at),
}));

// ═══════════════════════════════════════════════════════════════
// 🔗 RELATIONS
// ═══════════════════════════════════════════════════════════════
export const rentalPaymentHistoryRelations = relations(rentalPaymentHistory, ({ one }) => ({
    rental: one(rentals, {
        fields: [rentalPaymentHistory.rental_id],
        references: [rentals.id],
    }),
}));

// Also update the rentals relations to include payments
export const rentalsWithPaymentsRelations = relations(rentals, ({ one, many }) => ({
    costume: one(costumes, {
        fields: [rentals.costume_id],
        references: [costumes.id],
    }),
    payments: many(rentalPaymentHistory),
}));

// ═══════════════════════════════════════════════════════════════
// 📋 TYPE DEFINITIONS
// ═══════════════════════════════════════════════════════════════
// Main types
export type RentalPayment = InferSelectModel<typeof rentalPaymentHistory>;
export type NewRentalPayment = InferInsertModel<typeof rentalPaymentHistory>;

// Utility types for common queries
export type RentalPaymentWithRental = RentalPayment & {
    rental?: any; // Will be properly typed when rental relation is imported
};

// Payment summary type for business logic
export type PaymentSummary = {
    total_paid: string;
    pending_amount: string;
    refunded_amount: string;
    payment_count: number;
    last_payment_date?: Date;
    active_session_id?: string;
    session_expires_at?: Date;
};

// PayMongo session tracking type
export type PaymentSession = {
    session_id: string;
    payment_intent_id: string;
    source_id: string;
    checkout_url: string;
    status: string;
    expires_at: Date;
    metadata: any;
};

// ✅ NEW: Payment method types
export type PaymentMethodType = 'gcash' | 'paymaya' | 'card';

export type PaymentMethodInfo = {
    type: PaymentMethodType;
    payment_number?: string;
    refund_details?: {
        account_name: string;
        account_number: string;
        method: string;
    };
};