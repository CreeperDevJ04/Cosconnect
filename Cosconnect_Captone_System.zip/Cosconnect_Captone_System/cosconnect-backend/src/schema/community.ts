// src/schema/community.ts
import {
    pgTable,
    uuid,
    varchar,
    text,
    integer,
    boolean,
    jsonb,
    timestamp,
    index,
    foreignKey,
    unique,
} from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';
import type { InferSelectModel, InferInsertModel } from 'drizzle-orm';
import { users } from './users';

// COMMUNITY POSTS TABLE
export const community_posts = pgTable('community_posts', {
    id: uuid('id').primaryKey().defaultRandom(),

    author_id: uuid('author_id')
        .notNull()
        .references(() => users.uid, { onDelete: 'cascade' }),

    author_name: varchar('author_name', { length: 100 }).notNull(),
    author_role: varchar('author_role', { length: 50 }).notNull(),
    author_avatar: text('author_avatar').notNull(),

    content: text('content').notNull(),
    images: jsonb('images').$type<string[]>().default([]).notNull(),
    is_for_sale: boolean('is_for_sale').default(false).notNull(),

    heart_count: integer('heart_count').default(0).notNull(),
    likes: integer('likes').default(0).notNull(),

    // Report tracking
    report_count: integer('report_count').default(0).notNull(),
    is_reported: boolean('is_reported').default(false).notNull(),

    created_at: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
    updated_at: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
    authorIdx: index('community_posts_author_id_idx').on(table.author_id),
    createdAtIdx: index('community_posts_created_at_idx').on(table.created_at),
    heartCountIdx: index('community_posts_heart_count_idx').on(table.heart_count),
    reportCountIdx: index('community_posts_report_count_idx').on(table.report_count),
}));

// COMMUNITY COMMENTS TABLE
export const community_comments = pgTable('community_comments', {
    id: uuid('id').primaryKey().defaultRandom(),
    post_id: uuid('post_id').notNull(),
    parent_comment_id: uuid('parent_comment_id'),
    author_id: uuid('author_id').notNull(),

    author_name: varchar('author_name', { length: 100 }).notNull(),
    author_role: varchar('author_role', { length: 50 }).notNull(),
    author_avatar: text('author_avatar').notNull(),

    content: text('content').notNull(),
    images: jsonb('images').$type<string[]>().default([]).notNull(),

    // Reaction tracking for comments
    reaction_count: integer('reaction_count').default(0).notNull(),

    created_at: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
    updated_at: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
    postFk: foreignKey({
        columns: [table.post_id],
        foreignColumns: [community_posts.id],
    }),
    parentFk: foreignKey({
        columns: [table.parent_comment_id],
        foreignColumns: [table.id],
    }),
    authorFk: foreignKey({
        columns: [table.author_id],
        foreignColumns: [users.uid],
    }),
    postIdx: index('community_comments_post_id_idx').on(table.post_id),
    parentIdx: index('community_comments_parent_comment_id_idx').on(table.parent_comment_id),
    authorIdx: index('community_comments_author_id_idx').on(table.author_id),
    createdAtIdx: index('community_comments_created_at_idx').on(table.created_at),
}));

// COMMUNITY POST REPORTS TABLE
export const community_post_reports = pgTable('community_post_reports', {
    id: uuid('id').primaryKey().defaultRandom(),

    post_id: uuid('post_id')
        .notNull()
        .references(() => community_posts.id, { onDelete: 'cascade' }),

    reporter_id: uuid('reporter_id')
        .notNull()
        .references(() => users.uid, { onDelete: 'cascade' }),

    reason: varchar('reason', { length: 255 }).notNull(),
    details: text('details'),

    status: varchar('status', { length: 50 }).default('pending').notNull(),
    reviewed_by: uuid('reviewed_by').references(() => users.uid, { onDelete: 'set null' }),
    reviewed_at: timestamp('reviewed_at', { withTimezone: true }),
    review_notes: text('review_notes'),

    created_at: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
    updated_at: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
    postIdx: index('community_post_reports_post_id_idx').on(table.post_id),
    reporterIdx: index('community_post_reports_reporter_id_idx').on(table.reporter_id),
    reasonIdx: index('community_post_reports_reason_idx').on(table.reason),
    statusIdx: index('community_post_reports_status_idx').on(table.status),
    reviewedByIdx: index('community_post_reports_reviewed_by_idx').on(table.reviewed_by),
    uniqueUserPost: unique('community_post_reports_unique_user_post').on(table.post_id, table.reporter_id),
}));

// UNIFIED REACTIONS TABLE (for both posts and comments)
// UNIFIED REACTIONS TABLE (for both posts and comments, with role tracking)
export const community_post_reactions = pgTable('community_post_reactions', {
    id: uuid('id').primaryKey().defaultRandom(),

    // Target can be either a post or comment
    post_id: uuid('post_id')
        .notNull()
        .references(() => community_posts.id, { onDelete: 'cascade' }),

    // Optional: If this is a reaction to a comment, store the comment_id
    comment_id: uuid('comment_id')
        .references(() => community_comments.id, { onDelete: 'cascade' }),

    // User who reacted
    user_uid: uuid('user_uid')
        .notNull()
        .references(() => users.uid, { onDelete: 'cascade' }),

    // Role of the user when reacting (e.g. "borrower" or "lender")
    user_role: varchar('user_role', { length: 50 }).notNull(),

    // Reaction type (e.g. "heart", "like", "smile")
    reaction_type: varchar('reaction_type', { length: 50 }).notNull(),

    reacted_at: timestamp('reacted_at', { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
    postIdx: index('community_post_reactions_post_id_idx').on(table.post_id),
    commentIdx: index('community_post_reactions_comment_id_idx').on(table.comment_id),
    userIdx: index('community_post_reactions_user_uid_idx').on(table.user_uid),
    userRoleIdx: index('community_post_reactions_user_role_idx').on(table.user_role),

    // Unique: one reaction per user per role per post/comment
    uniqueUserRolePostReaction: unique(
        'community_post_reactions_unique_user_role_post'
    ).on(table.post_id, table.comment_id, table.user_uid, table.user_role),
}));

// RELATIONS
export const communityPostsRelations = relations(community_posts, ({ one, many }) => ({
    author: one(users, {
        fields: [community_posts.author_id],
        references: [users.uid],
    }),
    comments: many(community_comments),
    reports: many(community_post_reports),
    reactions: many(community_post_reactions),
}));

export const communityCommentsRelations = relations(community_comments, ({ one, many }) => ({
    post: one(community_posts, {
        fields: [community_comments.post_id],
        references: [community_posts.id],
    }),
    author: one(users, {
        fields: [community_comments.author_id],
        references: [users.uid],
    }),
    parent: one(community_comments, {
        fields: [community_comments.parent_comment_id],
        references: [community_comments.id],
        relationName: 'replies',
    }),
    replies: many(community_comments, { relationName: 'replies' }),
    reactions: many(community_post_reactions),
}));

export const communityPostReportsRelations = relations(community_post_reports, ({ one }) => ({
    post: one(community_posts, {
        fields: [community_post_reports.post_id],
        references: [community_posts.id],
    }),
    reporter: one(users, {
        fields: [community_post_reports.reporter_id],
        references: [users.uid],
    }),
    reviewer: one(users, {
        fields: [community_post_reports.reviewed_by],
        references: [users.uid],
    }),
}));

export const communityPostReactionsRelations = relations(community_post_reactions, ({ one }) => ({
    post: one(community_posts, {
        fields: [community_post_reactions.post_id],
        references: [community_posts.id],
    }),
    comment: one(community_comments, {
        fields: [community_post_reactions.comment_id],
        references: [community_comments.id],
    }),
    user: one(users, {
        fields: [community_post_reactions.user_uid],
        references: [users.uid],
    }),
}));

// TYPES
export type CommunityPost = InferSelectModel<typeof community_posts> & {
    author?: InferSelectModel<typeof users>;
    comments?: CommunityComment[];
    reports?: CommunityPostReport[];
    reactions?: CommunityPostReaction[];
};
export type NewCommunityPost = InferInsertModel<typeof community_posts>;

export type CommunityComment = InferSelectModel<typeof community_comments> & {
    author?: InferSelectModel<typeof users>;
    post?: CommunityPost;
    parent?: CommunityComment | null;
    replies?: CommunityComment[];
    reactions?: CommunityPostReaction[];
};
export type NewCommunityComment = InferInsertModel<typeof community_comments>;

export type CommunityPostReport = InferSelectModel<typeof community_post_reports> & {
    reporter?: InferSelectModel<typeof users>;
    post?: CommunityPost;
    reviewer?: InferSelectModel<typeof users>;
};
export type NewCommunityPostReport = InferInsertModel<typeof community_post_reports>;

export type CommunityPostReaction = InferSelectModel<typeof community_post_reactions> & {
    user?: InferSelectModel<typeof users>;
    post?: CommunityPost;
    comment?: CommunityComment;
};
export type NewCommunityPostReaction = InferInsertModel<typeof community_post_reactions>;