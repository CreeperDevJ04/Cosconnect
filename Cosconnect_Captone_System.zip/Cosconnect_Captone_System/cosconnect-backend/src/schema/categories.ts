import { pgTable, uuid, varchar, integer, timestamp, text } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

export const categories = pgTable('categories', {
    id: uuid('id').primaryKey().defaultRandom(),
    categoryName: varchar('category_name', { length: 100 }).notNull(),
    slug: varchar('slug', { length: 100 }).notNull().unique(),
    status: varchar('status', { length: 20 }).notNull().default('active'),
    productListingCount: integer('product_listing_count').notNull().default(0),
    totalRentalCount: integer('total_rental_count').notNull().default(0),
    adminId: varchar('admin_id', { length: 100 }).notNull(),
    adminName: varchar('admin_name', { length: 100 }).notNull(),
    adminEmail: varchar('admin_email', { length: 255 }).notNull(),
    adminRole: varchar('admin_role', { length: 50 }).notNull(),
    createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
});

export const categoriesRelations = relations(categories, ({ many }) => ({
    tags: many(tags),
}));

export type Category = typeof categories.$inferSelect;
export type NewCategory = typeof categories.$inferInsert;
