import {
    pgTable,
    uuid,
    text,
    boolean,
    timestamp,
    index,
    uniqueIndex,
    pgEnum,

} from 'drizzle-orm/pg-core';
import { InferInsertModel, InferSelectModel, sql } from 'drizzle-orm';

// === ENUMS ===
export const user_role_enum = pgEnum('user_role', ['admin', 'lender', 'borrower']);
export const message_type_enum = pgEnum('message_type', ['text', 'image']);

// === USER ROLES ===
export const user_roles = pgTable('user_roles', {
    id: uuid('id').primaryKey().defaultRandom(),
    user_id: uuid('user_id').notNull(),
    role: user_role_enum('role').notNull(),
}, (table) => ({
    uniqueUserRole: uniqueIndex('unique_user_role').on(table.user_id, table.role),
}));

// === CONVERSATIONS ===
// FIXED: Enforces user1 < user2 ordering to prevent duplicates
export const conversations = pgTable('conversations', {
    id: uuid('id').primaryKey().defaultRandom(),

    user1_id: uuid('user1_id').notNull(),
    user1_role: user_role_enum('user1_role').notNull(),

    user2_id: uuid('user2_id').notNull(),
    user2_role: user_role_enum('user2_role').notNull(),

    created_at: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
    updated_at: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
    // Ensures only one conversation between two users
    uniquePair: uniqueIndex('unique_conversation_pair').on(
        table.user1_id,
        table.user1_role,
        table.user2_id,
        table.user2_role
    ),
    // CRITICAL: Enforce ordering - user1 must always be "less than" user2
    // This prevents (A,B) and (B,A) from both existing
    orderingCheck: sql`CHECK ((user1_id || user1_role) < (user2_id || user2_role))`,
    user1Idx: index('conversation_user1_idx').on(table.user1_id, table.user1_role),
    user2Idx: index('conversation_user2_idx').on(table.user2_id, table.user2_role),
}));

// === MESSAGES ===
export const messages = pgTable('messages', {
    id: uuid('id').primaryKey().defaultRandom(),

    conversation_id: uuid('conversation_id')
        .notNull()
        .references(() => conversations.id, { onDelete: 'cascade' }),

    sender_id: uuid('sender_id').notNull(),
    sender_role: user_role_enum('sender_role').notNull(),

    message_type: message_type_enum('message_type').notNull(),
    content: text('content'),
    image_url: text('image_url'),

    is_read: boolean('is_read').notNull().default(false),
    is_seen: boolean('is_seen').notNull().default(false),

    created_at: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
    conversationIdx: index('message_conversation_idx').on(table.conversation_id),
    senderIdx: index('message_sender_idx').on(table.sender_id, table.sender_role),
    readIdx: index('message_read_idx').on(table.is_read, table.is_seen),
}));

// === TYPES ===
export type SelectConversation = InferSelectModel<typeof conversations>;
export type InsertConversation = InferInsertModel<typeof conversations>;

export type SelectMessage = InferSelectModel<typeof messages>;
export type InsertMessage = InferInsertModel<typeof messages>;

export type SelectUserRole = InferSelectModel<typeof user_roles>;
export type InsertUserRole = InferInsertModel<typeof user_roles>;