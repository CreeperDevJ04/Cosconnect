// schema/costumes.ts
import { relations, sql } from 'drizzle-orm';
import type { InferInsertModel, InferSelectModel, InferModel } from 'drizzle-orm';
import type { PgTableWithColumns } from 'drizzle-orm/pg-core';
import {
    boolean,
    index,
    integer,
    jsonb,
    pgEnum,
    pgTable,
    text,
    timestamp,
    uuid,
    varchar,
    primaryKey,
} from 'drizzle-orm/pg-core';

// Import types only to avoid circular dependencies
type UserTable = PgTableWithColumns<any>;

// ═══════════════════════════════════════════════════════════════
// 🎯 ENUMS
// ═══════════════════════════════════════════════════════════════
export const genderEnum = pgEnum('gender', ['male', 'female', 'unisex']);
export const costumeStatusEnum = pgEnum('costume_status', [
    'active',
    'inactive',
    'rented',
    'maintenance'
]);
export const listingTypeEnum = pgEnum('listing_type', [
    'rent',
    'sale',
    'both'
]);

// Note: Using users table from users.ts schema - no separate lender_info table needed

// ═══════════════════════════════════════════════════════════════
// 🎭 COSTUMES TABLE
// ═══════════════════════════════════════════════════════════════
export const costumes = pgTable('costumes', {
    id: uuid('id').primaryKey().defaultRandom(),

    // Basic Information
    name: varchar('name', { length: 255 }).notNull(),
    brand: varchar('brand', { length: 100 }).notNull(),
    category: varchar('category', { length: 100 }).notNull(),
    description: text('description').notNull(),
    gender: genderEnum('gender').notNull(),
    sizes: varchar('sizes', { length: 255 }).notNull(),
    tags: jsonb('tags').$type<string[]>().default([]).notNull(),

    // Pricing & Terms
    listing_type: listingTypeEnum('listing_type').notNull(),
    rental_price: varchar('rental_price', { length: 32 }).default('0').notNull(),
    sale_price: varchar('sale_price', { length: 32 }).default('0').notNull(),
    security_deposit: varchar('security_deposit', { length: 32 }).default('0').notNull(),
    discount_percentage: integer('discount_percentage').default(0).notNull(),
    extended_days_price: varchar('extended_days_price', { length: 32 }).default('0').notNull(),

    // Images
    main_images: jsonb('main_images').$type<{
        front: string;
        back: string;
    }>().notNull(),
    additional_images: jsonb('additional_images').$type<Array<{
        url: string;
        alt_text?: string;
        order: number;
    }>>().default([]).notNull(),

    // Lender Reference (references users table directly)
    lender_uid: uuid('lender_uid').notNull(), // References users.uid from users schema

    // Status & Availability
    status: costumeStatusEnum('status').default('active').notNull(),
    is_available: boolean('is_available').default(true).notNull(),

    // Metadata
    view_count: integer('view_count').default(0).notNull(),
    favorite_count: integer('favorite_count').default(0).notNull(),

    // Timestamps
    created_at: timestamp('created_at').defaultNow().notNull(),
    updated_at: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
    nameIdx: index('costumes_name_idx').on(table.name),
    categoryIdx: index('costumes_category_idx').on(table.category),
    brandIdx: index('costumes_brand_idx').on(table.brand),
    genderIdx: index('costumes_gender_idx').on(table.gender),
    lenderUidIdx: index('costumes_lender_uid_idx').on(table.lender_uid),
    statusIdx: index('costumes_status_idx').on(table.status),
    availabilityIdx: index('costumes_availability_idx').on(table.is_available),
    listingTypeIdx: index('costumes_listing_type_idx').on(table.listing_type),
    createdAtIdx: index('costumes_created_at_idx').on(table.created_at),
}));

// ═══════════════════════════════════════════════════════════════
// 🔗 COSTUME ADD-ONS TABLE (stores add-on data directly)
// ═══════════════════════════════════════════════════════════════
export const costumeAddOns = pgTable('costume_add_ons', {
    id: uuid('id').primaryKey().defaultRandom(),
    costume_id: uuid('costume_id').notNull().references(() => costumes.id, {
        onDelete: 'cascade'
    }),

    // Add-on details stored directly
    name: varchar('name', { length: 100 }).notNull(),
    description: text('description').notNull(),
    price: varchar('price', { length: 32 }).notNull(),
    image_url: text('image_url'),
    category: varchar('category', { length: 50 }), // e.g., 'accessory', 'makeup', 'prop'
    is_included: boolean('is_included').default(false).notNull(), // Free vs paid add-on
    is_active: boolean('is_active').default(true).notNull(),

    created_at: timestamp('created_at').defaultNow().notNull(),
    updated_at: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
    costumeIdIdx: index('costume_add_ons_costume_id_idx').on(table.costume_id),
    nameIdx: index('costume_add_ons_name_idx').on(table.name),
    categoryIdx: index('costume_add_ons_category_idx').on(table.category),
    activeIdx: index('costume_add_ons_active_idx').on(table.is_active),
}));

// ═══════════════════════════════════════════════════════════════
// 🔄 RELATIONS
// ═══════════════════════════════════════════════════════════════
// Note: User relations would be defined in users.ts schema

// Export a function that will be used to create relations after all tables are defined
export function createCostumeRelations(usersTable: UserTable) {
    return relations(costumes, ({ one, many }) => ({
        addOns: many(costumeAddOns),
        lender: one(usersTable, {
            fields: [costumes.lender_uid],
            references: [usersTable.uid],
            relationName: 'costumes',
        }),
    }));
}

// Export a function to create add-on relations
export function createCostumeAddOnsRelations() {
    return relations(costumeAddOns, ({ one }) => ({
        costume: one(costumes, {
            fields: [costumeAddOns.costume_id],
            references: [costumes.id],
        }),
    }));
}

// ═══════════════════════════════════════════════════════════════
// 📋 TYPE DEFINITIONS
// ═══════════════════════════════════════════════════════════════

// Lender Types - These will be populated when initializing the database
export type LenderInfo = any; // Will be replaced with actual user type
export type NewLenderInfo = any; // Will be replaced with actual user type

// Costume Types
export type Costume = InferSelectModel<typeof costumes>;
export type NewCostume = InferInsertModel<typeof costumes>;

// Costume Add-on Types
export type CostumeAddOn = InferSelectModel<typeof costumeAddOns>;
export type NewCostumeAddOn = InferInsertModel<typeof costumeAddOns>;

// ═══════════════════════════════════════════════════════════════
// 🎯 UTILITY TYPES FOR QUERIES
// ═══════════════════════════════════════════════════════════════

// Costume with lender and add-ons
export type CostumeWithDetails = Costume & {
    lender?: LenderInfo;
    addOns?: CostumeAddOn[];
};

// Lender with costume count
export type LenderInfoWithStats = LenderInfo & {
    costumes?: Costume[];
    _count?: {
        costumes: number;
    };
};