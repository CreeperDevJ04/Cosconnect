import {
    pgTable,
    text,
    uuid,
    timestamp,
} from 'drizzle-orm/pg-core'
import { InferInsertModel, InferSelectModel } from 'drizzle-orm'

// Define the `admin` table schema (snake_case)
export const admin = pgTable('admin', {
    id: uuid('id')
        .defaultRandom()
        .primaryKey(),

    email: text('email')
        .notNull()
        .unique(),

    phone_number: text('phone_number'),

    username: text('username')
        .notNull()
        .unique(),

    profile_image: text('profile_image'),

    full_name: text('full_name')
        .notNull(),

    role: text('role')
        .notNull()
        .default('admin'),

    created_at: timestamp('created_at', { withTimezone: true })
        .defaultNow(),

    updated_at: timestamp('updated_at', { withTimezone: true })
        .defaultNow(),
})

// Types
export type Admin = InferSelectModel<typeof admin>
export type NewAdmin = InferInsertModel<typeof admin>
