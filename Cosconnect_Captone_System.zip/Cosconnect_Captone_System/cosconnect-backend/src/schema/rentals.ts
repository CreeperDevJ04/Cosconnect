// schema/rentals.ts
import { relations } from 'drizzle-orm';
import type { InferInsertModel, InferSelectModel } from 'drizzle-orm';
import {
    pgTable,
    uuid,
    timestamp,
    jsonb,
    text,
    varchar,
    index,
    pgEnum,
    integer,
    boolean,
    decimal
} from 'drizzle-orm/pg-core';
import { costumes } from './costumes';

// ═══════════════════════════════════════════════════════════════
// 🎯 ENUMS
// ═══════════════════════════════════════════════════════════════
export const rentalStatusEnum = pgEnum('rental_status', [
    'pending',
    'confirmed',
    'accepted',
    'delivered',
    'returned',
    'completed',
    'cancelled',
    'rejected',
    'overdue'
]);

export const rejectionReasonEnum = pgEnum('rejection_reason', [
    'unavailable',
    'damaged',
    'size_mismatch',
    'date_conflict',
    'payment_issue',
    'renter_issue',
    'other'
]);

// ═══════════════════════════════════════════════════════════════
// 🏠 RENTALS TABLE (Active/Accepted requests only)
// ═══════════════════════════════════════════════════════════════
export const rentals = pgTable('rentals', {
    id: uuid('id').primaryKey().defaultRandom(),
    // Human-friendly reference code for frontend
    reference_code: varchar('reference_code', { length: 50 }).unique().notNull(),
    // Example: RENT-2025-00001

    // References
    costume_id: uuid('costume_id').notNull().references(() => costumes.id, { onDelete: 'cascade' }),
    renter_uid: uuid('renter_uid').notNull(), // references users.uid (from users schema)

    // Snapshots (immutable at rental time)
    costume_snapshot: jsonb('costume_snapshot').$type<{
        id: string;
        name: string;
        brand: string;
        category: string;
        sizes: string;
        rental_price: string;
        security_deposit: string;
        main_images: {
            front: string;
            back: string;
        };
        lender_info: {
            uid: string;
            name: string;
            phone?: string;
            email?: string;
        };
    }>().notNull(),

    renter_snapshot: jsonb('renter_snapshot').$type<{
        uid: string;
        name: string;
        email: string;
        phone?: string;
        address?: string;
    }>().notNull(),

    // Schedule
    start_date: timestamp('start_date').notNull(),
    end_date: timestamp('end_date').notNull(),
    actual_return_date: timestamp('actual_return_date'), // When actually returned

    // Pricing breakdown (captured at time of rental)
    rental_amount: varchar('rental_amount', { length: 32 }).notNull(),
    security_deposit: varchar('security_deposit', { length: 32 }).notNull(),
    total_amount: varchar('total_amount', { length: 32 }).notNull(),

    // Extended rental tracking
    extended_days: integer('extended_days').default(0).notNull(),
    extension_fee: varchar('extension_fee', { length: 32 }).default('0').notNull(),

    // Rental status (updated to include delivered and returned)
    status: rentalStatusEnum('status').default('pending').notNull(),

    // Status tracking timestamps
    accepted_at: timestamp('accepted_at'), // When lender accepted
    accepted_by: uuid('accepted_by'), // Lender who accepted
    delivered_at: timestamp('delivered_at'), // When marked as delivered
    delivered_by: uuid('delivered_by'), // Who marked as delivered
    returned_at: timestamp('returned_at'), // When marked as returned
    returned_by: uuid('returned_by'), // Who marked as returned
    completed_at: timestamp('completed_at'), // When rental was marked as completed

    // ✅ NEW FIELDS - Individual completion timestamps
    payout_completed_at: timestamp('payout_completed_at'), // When payout was completed
    refund_completed_at: timestamp('refund_completed_at'), // When refund was completed

    // Damage/condition tracking
    initial_condition_notes: text('initial_condition_notes'),
    return_condition_notes: text('return_condition_notes'),
    damage_reported: boolean('damage_reported').default(false).notNull(),
    damage_cost: varchar('damage_cost', { length: 32 }).default('0').notNull(),

    // Platform fees
    processing_fee: decimal('processing_fee', { precision: 10, scale: 2 }).default('0').notNull(),
    commission_fee: decimal('commission_fee', { precision: 10, scale: 2 }).default('0').notNull(),
    revenue_sum: decimal('revenue_sum', { precision: 10, scale: 2 }).default('0').notNull(),

    // Borrower’s return proof (images, video, message)
    return_proof: jsonb('return_proof')
        .$type<{
            message: string;
            image_urls: string[];
            video_url?: string | null;
            submitted_at?: string;
            submitted_by?: string;
        } | null>()
        .default(null),


    // Communication
    pickup_location: text('pickup_location'),
    delivery_method: varchar('delivery_method', { length: 50 }), // pickup, delivery, etc.
    special_instructions: text('special_instructions'),

    // GCash Payment Details
    payment_gcash_number: varchar('payment_gcash_number', { length: 20 }),  // GCash number used for payment
    refund_gcash_number: varchar('refund_gcash_number', { length: 20 }),    // GCash number for refunds
    refund_account_name: varchar('refund_account_name', { length: 100 }),   // Full name for refund account

    // ✅ UPDATED FIELDS FOR PAYOUT AND REFUND - Enhanced to store more transaction details
    security_deposit_refund_borrower: jsonb('security_deposit_refund_borrower').$type<{
        accountName: string;
        amount: number;
        gcashNumber: string;
        borrowerId: string;
        notes: string;
        processedAt?: string;
        status?: 'pending' | 'processing' | 'completed' | 'failed';
        transactionType: 'refund';
    } | null>().default(null),

    payout_cashout_lender: jsonb('payout_cashout_lender').$type<{
        accountName: string;
        amount: number;
        gcashNumber: string;
        lenderId: string;
        notes: string;
        processedAt?: string;
        status?: 'pending' | 'processing' | 'completed' | 'failed';
        transactionType: 'payout';
    } | null>().default(null),

    // Metadata
    notes: text('notes'),
    created_at: timestamp('created_at').defaultNow().notNull(),
    updated_at: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
    referenceIdx: index('rentals_reference_code_idx').on(table.reference_code),
    costumeIdx: index('rentals_costume_id_idx').on(table.costume_id),
    renterIdx: index('rentals_renter_uid_idx').on(table.renter_uid),
    statusIdx: index('rentals_status_idx').on(table.status),
    startDateIdx: index('rentals_start_date_idx').on(table.start_date),
    endDateIdx: index('rentals_end_date_idx').on(table.end_date),
    acceptedByIdx: index('rentals_accepted_by_idx').on(table.accepted_by),
    deliveredByIdx: index('rentals_delivered_by_idx').on(table.delivered_by),
    returnedByIdx: index('rentals_returned_by_idx').on(table.returned_by),
    completedAtIdx: index('rentals_completed_at_idx').on(table.completed_at),

    // ✅ NEW INDEXES for completion timestamps
    payoutCompletedAtIdx: index('rentals_payout_completed_at_idx').on(table.payout_completed_at),
    refundCompletedAtIdx: index('rentals_refund_completed_at_idx').on(table.refund_completed_at),

    // GCash payment field indexes
    paymentGcashNumberIdx: index('rentals_payment_gcash_number_idx').on(table.payment_gcash_number),
    refundGcashNumberIdx: index('rentals_refund_gcash_number_idx').on(table.refund_gcash_number),
}));

// ═══════════════════════════════════════════════════════════════
// 🚫 RENTAL REJECTIONS TABLE (Rejected requests only)
// ═══════════════════════════════════════════════════════════════
export const rentalRejections = pgTable('rental_rejections', {
    id: uuid('id').primaryKey().defaultRandom(),
    // Original rental data (snapshot at time of rejection)
    original_rental_id: uuid('original_rental_id').notNull(), // Original ID from rentals table
    reference_code: varchar('reference_code', { length: 50 }).notNull(),

    // References
    costume_id: uuid('costume_id').notNull().references(() => costumes.id, { onDelete: 'cascade' }),
    renter_uid: uuid('renter_uid').notNull(),

    // Snapshots (preserved from original rental)
    costume_snapshot: jsonb('costume_snapshot').$type<{
        id: string;
        name: string;
        brand: string;
        category: string;
        sizes: string;
        rental_price: string;
        security_deposit: string;
        main_images: {
            front: string;
            back: string;
        };
        lender_info: {
            uid: string;
            name: string;
            phone?: string;
            email?: string;
        };
    }>().notNull(),

    renter_snapshot: jsonb('renter_snapshot').$type<{
        uid: string;
        name: string;
        email: string;
        phone?: string;
        address?: string;
    }>().notNull(),

    // Original schedule
    requested_start_date: timestamp('requested_start_date').notNull(),
    requested_end_date: timestamp('requested_end_date').notNull(),

    // Original pricing
    requested_rental_amount: varchar('requested_rental_amount', { length: 32 }).notNull(),
    requested_security_deposit: varchar('requested_security_deposit', { length: 32 }).notNull(),
    requested_total_amount: varchar('requested_total_amount', { length: 32 }).notNull(),

    // Rejection details
    rejected_at: timestamp('rejected_at').defaultNow().notNull(),
    rejected_by: uuid('rejected_by').notNull(), // Lender who rejected
    rejection_reason: rejectionReasonEnum('rejection_reason').notNull(),
    rejection_message: text('rejection_message'), // Custom message from lender

    // Original request metadata
    original_pickup_location: text('original_pickup_location'),
    original_delivery_method: varchar('original_delivery_method', { length: 50 }),
    original_special_instructions: text('original_special_instructions'),

    // Original GCash Payment Details
    original_payment_gcash_number: varchar('original_payment_gcash_number', { length: 20 }),
    original_refund_gcash_number: varchar('original_refund_gcash_number', { length: 20 }),
    original_refund_account_name: varchar('original_refund_account_name', { length: 100 }),
    original_notes: text('original_notes'),

    // Payment info at time of rejection
    payment_amount: varchar('payment_amount', { length: 32 }),
    payment_status: varchar('payment_status', { length: 32 }),
    payment_processed_at: timestamp('payment_processed_at'),

    // Timestamps
    original_created_at: timestamp('original_created_at').notNull(), // When original request was made
    created_at: timestamp('created_at').defaultNow().notNull(), // When rejection record was created
}, (table) => ({
    originalIdIdx: index('rental_rejections_original_id_idx').on(table.original_rental_id),
    referenceIdx: index('rental_rejections_reference_code_idx').on(table.reference_code),
    costumeIdx: index('rental_rejections_costume_id_idx').on(table.costume_id),
    renterIdx: index('rental_rejections_renter_uid_idx').on(table.renter_uid),
    rejectedByIdx: index('rental_rejections_rejected_by_idx').on(table.rejected_by),
    rejectedAtIdx: index('rental_rejections_rejected_at_idx').on(table.rejected_at),
    reasonIdx: index('rental_rejections_reason_idx').on(table.rejection_reason),

    // GCash payment field indexes
    originalPaymentGcashNumberIdx: index('rental_rejections_orig_payment_gcash_idx').on(table.original_payment_gcash_number),
    originalRefundGcashNumberIdx: index('rental_rejections_orig_refund_gcash_idx').on(table.original_refund_gcash_number),
}));

// ═══════════════════════════════════════════════════════════════
// 🔗 RELATIONS
// ═══════════════════════════════════════════════════════════════
export const rentalsRelations = relations(rentals, ({ one, many }) => ({
    costume: one(costumes, {
        fields: [rentals.costume_id],
        references: [costumes.id],
    }),
    // paymentHistory will be added when payment schema is imported
}));

export const rentalRejectionsRelations = relations(rentalRejections, ({ one }) => ({
    costume: one(costumes, {
        fields: [rentalRejections.costume_id],
        references: [costumes.id],
    }),
}));

// ═══════════════════════════════════════════════════════════════
// 📋 TYPE DEFINITIONS
// ═══════════════════════════════════════════════════════════════
export type Rental = InferSelectModel<typeof rentals>;
export type NewRental = InferInsertModel<typeof rentals>;
export type RentalRejection = InferSelectModel<typeof rentalRejections>;
export type NewRentalRejection = InferInsertModel<typeof rentalRejections>;

// Utility type for rental with related data
export type RentalWithDetails = Rental & {
    costume?: any; // Will be properly typed when costume relation is set up
    payments?: any[]; // Will be properly typed when payment relation is set up
};

export type RentalRejectionWithDetails = RentalRejection & {
    costume?: any;
};

// GCash payment details type
export type GCashPaymentDetails = {
    payment_gcash_number: string;
    refund_gcash_number: string;
    refund_account_name: string;
};

// ✅ NEW TYPES for payout and refund data
export type PayoutData = {
    accountName: string;
    amount: number;
    gcashNumber: string;
    lenderId: string;
    notes: string;
    processedAt?: string;
    status?: 'pending' | 'processing' | 'completed' | 'failed';
    transactionType: 'payout';
};

export type RefundData = {
    accountName: string;
    amount: number;
    gcashNumber: string;
    borrowerId: string;
    notes: string;
    processedAt?: string;
    status?: 'pending' | 'processing' | 'completed' | 'failed';
    transactionType: 'refund';
};