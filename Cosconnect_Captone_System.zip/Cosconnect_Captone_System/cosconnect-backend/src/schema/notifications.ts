// src/schema/notifications.ts
import {
    pgTable,
    uuid,
    varchar,
    text,
    timestamp,
    boolean,
    index,
    jsonb,
    pgEnum,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import type { InferSelectModel, InferInsertModel } from "drizzle-orm";
import { users } from "./users";
import { admin } from "./admin";
import { community_posts } from "./community";
import { costumes } from "./costumes";
import { rentals } from "./rentals";
import { rentalPaymentHistory } from "./rentals_payment_history";

// ═══════════════════════════════════════════════════════════════
// 🎯 ENUMS
// ═══════════════════════════════════════════════════════════════
export const notificationTypeEnum = pgEnum("notification_type", [
    "NEW_COSTUME",
    "COMMUNITY_POST",
    "USER_SIGN_IN",
    "RENTAL_REQUEST",
    "RENTAL_APPROVED",
    "RENTAL_REJECTED",
    "RENTAL_UPDATED",
    "PAYMENT_SUCCESS",
    "PAYMENT_FAILED",
    "RENTAL_DELIVERED",
    "RENTAL_RETURNED",
    "PAYMENT_REMINDER",
    "NEW_MESSAGE",
    "SYSTEM_ALERT",
    "LENDER_VERIFICATION_PENDING",
    "LENDER_VERIFICATION_APPROVED",
    "LENDER_VERIFICATION_REJECTED",
    "ACCOUNT_SUSPENDED",
    "ACCOUNT_REACTIVATED",
]);

export const notificationStatusEnum = pgEnum("notification_status", [
    "UNREAD",
    "READ",
    "ARCHIVED",
]);

export const recipientRoleEnum = pgEnum("recipient_role", [
    "borrower",
    "lender",
    "admin",
]);

// ═══════════════════════════════════════════════════════════════
// 📦 METADATA TYPE
// ═══════════════════════════════════════════════════════════════
export type NotificationMetadata = {
    // Action URLs
    actionUrl?: string;
    actionLabel?: string;

    // Additional context
    costumeTitle?: string;
    rentalDates?: { start: string; end: string };
    paymentAmount?: number;
    reason?: string;

    // Generic metadata
    [key: string]: unknown;
};

// ═══════════════════════════════════════════════════════════════
// 🔔 NOTIFICATIONS TABLE
// ═══════════════════════════════════════════════════════════════
export const notifications = pgTable(
    "notifications",
    {
        id: uuid("id").primaryKey().defaultRandom(),

        // Recipient information
        recipient_id: uuid("recipient_id")
            .notNull()
            .references(() => users.uid, { onDelete: "cascade" }),
        recipient_role: recipientRoleEnum("recipient_role")
            .notNull()
            .default("borrower"),
        recipient_email: varchar("recipient_email", { length: 255 }).notNull(),

        // Sender information (can be user or admin)
        sender_id: uuid("sender_id"), // Can reference users.uid or admin.id
        sender_role: recipientRoleEnum("sender_role"),
        sender_type: varchar("sender_type", { length: 20 }), // 'user' or 'admin' or 'system'

        // Notification details
        type: notificationTypeEnum("type").notNull(),
        status: notificationStatusEnum("status").default("UNREAD").notNull(),
        title: varchar("title", { length: 255 }).notNull(),
        message: text("message").notNull(),

        // Related entities (nullable FKs)
        costume_id: uuid("costume_id").references(() => costumes.id, {
            onDelete: "set null",
        }),
        post_id: uuid("post_id").references(() => community_posts.id, {
            onDelete: "set null",
        }),
        rental_id: uuid("rental_id").references(() => rentals.id, {
            onDelete: "set null",
        }),
        payment_id: uuid("payment_id").references(() => rentalPaymentHistory.id, {
            onDelete: "set null",
        }),
        message_id: uuid("message_id"),

        // Flexible metadata for additional context
        metadata: jsonb("metadata")
            .$type<NotificationMetadata>()
            .notNull()
            .default({}),

        // Timestamps
        created_at: timestamp("created_at", { withTimezone: true })
            .defaultNow()
            .notNull(),
        read_at: timestamp("read_at", { withTimezone: true }),
        archived_at: timestamp("archived_at", { withTimezone: true }),
        expires_at: timestamp("expires_at", { withTimezone: true }),
        updated_at: timestamp("updated_at", { withTimezone: true })
            .defaultNow()
            .$onUpdate(() => new Date())
            .notNull(),

        // Soft delete
        is_deleted: boolean("is_deleted").default(false).notNull(),
    },
    (table) => ({
        // Primary indexes for querying
        recipientIdx: index("notifications_recipient_id_idx").on(
            table.recipient_id,
        ),
        recipientRoleIdx: index("notifications_recipient_role_idx").on(
            table.recipient_role,
        ),
        recipientEmailIdx: index("notifications_recipient_email_idx").on(
            table.recipient_email,
        ),
        senderIdx: index("notifications_sender_id_idx").on(table.sender_id),
        typeIdx: index("notifications_type_idx").on(table.type),
        statusIdx: index("notifications_status_idx").on(table.status),
        createdAtIdx: index("notifications_created_at_idx").on(
            table.created_at,
        ),

        // Composite indexes for common queries
        recipientStatusIdx: index("notifications_recipient_status_idx").on(
            table.recipient_id,
            table.status,
        ),
        recipientRoleStatusIdx: index("notifications_recipient_role_status_idx").on(
            table.recipient_id,
            table.recipient_role,
            table.status,
        ),

        // Entity-specific indexes
        costumeIdx: index("notifications_costume_id_idx").on(table.costume_id),
        postIdx: index("notifications_post_id_idx").on(table.post_id),
        rentalIdx: index("notifications_rental_id_idx").on(table.rental_id),
        paymentIdx: index("notifications_payment_id_idx").on(table.payment_id),
    }),
);

// ═══════════════════════════════════════════════════════════════
// 🔗 RELATIONS
// ═══════════════════════════════════════════════════════════════
export const notificationsRelations = relations(notifications, ({ one }) => ({
    recipient: one(users, {
        fields: [notifications.recipient_id],
        references: [users.uid],
        relationName: "recipient",
    }),
    sender: one(users, {
        fields: [notifications.sender_id],
        references: [users.uid],
        relationName: "sender",
    }),
    costume: one(costumes, {
        fields: [notifications.costume_id],
        references: [costumes.id],
    }),
    post: one(community_posts, {
        fields: [notifications.post_id],
        references: [community_posts.id],
    }),
    rental: one(rentals, {
        fields: [notifications.rental_id],
        references: [rentals.id],
    }),
    payment: one(rentalPaymentHistory, {
        fields: [notifications.payment_id],
        references: [rentalPaymentHistory.id],
    }),
}));

// ═══════════════════════════════════════════════════════════════
// 📋 TYPES
// ═══════════════════════════════════════════════════════════════
export type Notification = InferSelectModel<typeof notifications> & {
    recipient?: InferSelectModel<typeof users>;
    sender?: InferSelectModel<typeof users>;
    costume?: InferSelectModel<typeof costumes> | null;
    post?: InferSelectModel<typeof community_posts> | null;
    rental?: InferSelectModel<typeof rentals> | null;
    payment?: InferSelectModel<typeof rentalPaymentHistory> | null;
};

export type NewNotification = InferInsertModel<typeof notifications>;
export type NotificationType = typeof notificationTypeEnum.enumValues[number];
export type NotificationStatus = typeof notificationStatusEnum.enumValues[number];
export type RecipientRole = typeof recipientRoleEnum.enumValues[number];