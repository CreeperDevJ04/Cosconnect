// =============================================================================
// OPTIMIZED OTP SCHEMA (EMAIL-BASED) - schema/otp-code.ts
// =============================================================================
import {
    pgTable,
    uuid,
    varchar,
    timestamp,
    boolean,
    index,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import type { InferSelectModel, InferInsertModel } from "drizzle-orm";

export const otp_codes = pgTable("otp_codes", {
    id: uuid("id").default(sql`gen_random_uuid()`).primaryKey(),

    // ✅ Email replaces user_uid
    email: varchar("email", { length: 255 }).notNull(),

    otp_code: varchar("otp_code", { length: 6 }).notNull(),
    expires_at: timestamp("expires_at", { withTimezone: true }).notNull(),
    is_used: boolean("is_used").default(false).notNull(),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => [
    // ✅ Optimized index for lookup by email + unused codes
    index("otp_codes_email_unused_idx").on(table.email, table.is_used, table.created_at),
    index("otp_codes_expires_idx").on(table.expires_at),
]);

export type UserOtp = InferSelectModel<typeof otp_codes>;
export type NewUserOtp = InferInsertModel<typeof otp_codes>;
