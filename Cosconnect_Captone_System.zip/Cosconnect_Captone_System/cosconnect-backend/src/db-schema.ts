import { costumes, createCostumeAddOnsRelations, createCostumeRelations } from './schema/costumes';
import {

    rentals,
    rentalsRelations,

} from './schema/rentals';
import {


    rentalPaymentHistory,

} from './schema/rentals_payment_history';
import { createUserRelations, users } from './schema/users';

// Create relations
const userRelations = createUserRelations(costumes);
const costumeRelations = createCostumeRelations(users);
const costumeAddOnsRelations = createCostumeAddOnsRelations();

export {
    costumeAddOnsRelations, costumeRelations, costumes,
    // Types
    rentalPaymentHistory, rentals, rentalsRelations,
    // Relations
    userRelations,
    // Tables
    users
};

export * from './schema/costumes';
export * from './schema/rentals';
export * from './schema/rentals_payment_history';
export * from './schema/users';
export { user_documents } from './schema/users';

