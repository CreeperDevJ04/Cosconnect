import { signInWithEmailAndPassword } from "@firebase/auth";
import type { Context } from 'hono';
import { auth, clientAuth, db } from "../db/firebase/config";
import nodemailer from 'nodemailer';


// Configure nodemailer transporter
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER ,
        pass: process.env.EMAIL_PASSWORD || '' // Use environment variables for security
    }
});


// OTP utility functions
const generateOTP = (): string => {
    return Math.floor(100000 + Math.random() * 900000).toString();
};

const storeOTP = async (email: string, otp: string): Promise<void> => {
    const expiresAt = new Date();
    expiresAt.setMinutes(expiresAt.getMinutes() + 10); // OTP valid for 10 minutes

    // Store OTP in Firestore with expiration time
    await db.collection("otpCodes").doc(email).set({
        otp,
        expiresAt: expiresAt.toISOString(),
        createdAt: new Date().toISOString(),
        attempts: 0
    });
};

const verifyOTP = async (email: string, userOtp: string): Promise<boolean> => {
    const otpDoc = await db.collection("otpCodes").doc(email).get();

    if (!otpDoc.exists) {
        return false;
    }

    const otpData = otpDoc.data();
    const expiresAt = new Date(otpData?.expiresAt || '');

    // Check if OTP is expired
    if (expiresAt < new Date()) {
        return false;
    }

    // Update attempts
    await db.collection("otpCodes").doc(email).update({
        attempts: otpData?.attempts || 0 + 1
    });

    // Max attempts check (optional)
    if ((otpData?.attempts || 0) >= 5) {
        return false;
    }

    return otpData?.otp === userOtp;
};

const sendOTPEmail = async (userData: { email: string, fullName: string }, otp: string): Promise<void> => {
    const mailOptions = {
        from: process.env.EMAIL_USER ,
        to: userData.email,
        subject: 'CosConnect Email Verification Code',
        html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <h2>Verify Your Email Address</h2>
            <p>Hello ${userData.fullName},</p>
            <p>Thank you for registering with CosConnect. To complete your registration, please use the following verification code:</p>
            <div style="background-color: #f4f4f4; padding: 15px; text-align: center; font-size: 24px; font-weight: bold; letter-spacing: 5px; margin: 20px 0;">
                ${otp}
            </div>
            <p>This code will expire in 10 minutes.</p>
            <p>If you didn't request this code, please ignore this email.</p>
            <p>Best regards,<br>The CosConnect Team</p>
        </div>
    `
    };

    await transporter.sendMail(mailOptions);
};

// Request OTP for email verification
const requestOTP = async (c: Context) => {
    try {
        const body: { email: string, fullName: string } = await c.req.json();
        const { email, fullName } = body;

        if (!email) {
            return c.json({
                success: false,
                message: 'Email is required'
            }, 400);
        }

        // Check if email already exists
        try {
            const userByEmail = await auth.getUserByEmail(email);
            if (userByEmail) {
                return c.json({
                    success: false,
                    message: 'Email already in use. Please use a different email address.'
                }, 400);
            }
        } catch (error: any) {
            // Error means user doesn't exist, which is what we want
            if (error.code !== 'auth/user-not-found') {
                throw error;
            }
        }

        // Generate and store OTP
        const otp = generateOTP();
        await storeOTP(email, otp);

        // Send OTP email
        await sendOTPEmail({ email, fullName }, otp);

        return c.json({
            success: true,
            message: 'Verification code sent to your email'
        });
    } catch (error: any) {
        console.error('OTP Request Error:', error);
        return c.json({
            success: false,
            message: error.message || 'Failed to send verification code'
        }, 500);
    }
};



// Resend OTP
const resendOTP = async (c: Context) => {
    try {
        const body: { email: string, fullName: string } = await c.req.json();
        const { email, fullName } = body;

        if (!email) {
            return c.json({
                success: false,
                message: 'Email is required'
            }, 400);
        }

        // Check for rate limiting
        const otpDoc = await db.collection("otpCodes").doc(email).get();
        if (otpDoc.exists) {
            const otpData = otpDoc.data();
            const lastSent = new Date(otpData?.createdAt || '');
            const now = new Date();
            const diffInSeconds = (now.getTime() - lastSent.getTime()) / 1000;

            // Rate limit: allow resend only after 60 seconds
            if (diffInSeconds < 60) {
                return c.json({
                    success: false,
                    message: `Please wait ${Math.ceil(60 - diffInSeconds)} seconds before requesting a new code`
                }, 429);
            }
        }

        // Generate and store new OTP
        const otp = generateOTP();
        await storeOTP(email, otp);

        // Send OTP email
        await sendOTPEmail({ email, fullName }, otp);

        return c.json({
            success: true,
            message: 'New verification code sent to your email'
        });
    } catch (error: any) {
        console.error('Resend OTP Error:', error);
        return c.json({
            success: false,
            message: error.message || 'Failed to resend verification code'
        }, 500);
    }
};

// Function to send registration confirmation email
const sendRegistrationEmail = async (userData: { email: string, fullName: string }) => {
    try {
        // Email content
        const mailOptions = {
            from: '"CosConnect" <cosconnectme@gmail.com>',
            to: userData.email,
            subject: 'CosConnect Lender Registration Confirmation - Verification in Progress',
            html: `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
    
    <img src="[Your Logo URL]" alt="CosConnect Logo" style="max-width: 200px; margin: 20px 0;">
    
    <h2 style="color: #2E5A88; border-bottom: 1px solid #eeeeee; padding-bottom: 10px;">Thank You for Registering with CosConnect!</h2>
    
    <p>Dear ${userData.fullName},</p>
    
    <p>We're delighted to confirm that your lender registration with CosConnect has been successfully received. Thank you for choosing our platform to expand your lending opportunities.</p>
    
    <div style="background-color: #f9f9f9; border-left: 4px solid #2E5A88; padding: 15px; margin: 20px 0;">
        <h3 style="color: #2E5A88; margin-top: 0;">Verification Status: PENDING</h3>
        <p>Your application is currently under review by our verification team. We are carefully examining the business details and identification documents you've provided to ensure compliance with our platform standards.</p>
    </div>
    
    <h3 style="color: #2E5A88;">What Happens Next?</h3>
    
    <ol style="padding-left: 20px;">
        <li><strong>Review Process (Up to 3 Business Days)</strong><br>Our team will thoroughly review your application and documentation.</li>
        <li><strong>Verification Outcome</strong><br>You will receive an email notification with one of the following outcomes:
        <ul>
            <li><strong>Approved:</strong> Your account will be activated, allowing you to access the lender dashboard.</li>
            <li><strong>Additional Information Required:</strong> We may request specific additional documentation.</li>
            <li><strong>Not Approved:</strong> We'll provide detailed feedback explaining the decision and how you might address any issues.</li>
        </ul>
        </li>
    </ol>
    
    <h3 style="color: #2E5A88;">Important Information</h3>
    
    <ul style="padding-left: 20px;">
        <li>Please check your email regularly, including spam/junk folders.</li>
        <li>Do not create multiple accounts while your application is under review.</li>
        <li>The email with your verification results will be sent from <strong>cosconnectme@gmail.com</strong>.</li>
    </ul>
    
    <div style="background-color: #f0f7ff; border: 1px solid #d0e3ff; border-radius: 5px; padding: 15px; margin: 20px 0;">
        <h3 style="color: #2E5A88; margin-top: 0;">Need Assistance?</h3>
        <p>Our support team is ready to help with any questions about your application:</p>
        <p>📱 <strong>Phone:</strong> 09215186108<br>
        📧 <strong>Email:</strong> <a href="mailto:cosconnectme@gmail.com" style="color: #2E5A88;">cosconnectme@gmail.com</a></p>
    </div>
    
    <p>We appreciate your patience during the verification process and look forward to potentially welcoming you as a verified lender on the CosConnect platform.</p>
    
    <p>Warm regards,</p>
    
    <p><strong>The CosConnect Team</strong></p>
    
    <div style="border-top: 1px solid #eeeeee; padding-top: 15px; margin-top: 20px; font-size: 12px; color: #888888;">
        <p>This is an automated message. Please do not reply directly to this email.</p>
        <p>© 2025 CosConnect. All rights reserved.</p>
    </div>
    
    </div>
    `
        };

        // Send the email
        const info = await transporter.sendMail(mailOptions);
        console.log('Registration confirmation email sent:', info.messageId);
        return true;
    } catch (error) {
        console.error('Error sending registration confirmation email:', error);
        return false;
    }
};


const userLenderSignUp = async (c: Context) => {
    try {
        const body: any = await c.req.json();
        const { personalInfo, businessInfo, identification, otpCode } = body;

        // Validate OTP first before proceeding
        if (!otpCode) {
            return c.json({
                success: false,
                message: 'Email verification code is required'
            }, 400);
        }

        // Verify OTP
        const isOtpValid = await verifyOTP(personalInfo.email, otpCode);
        if (!isOtpValid) {
            return c.json({
                success: false,
                message: 'Invalid or expired verification code'
            }, 400);
        }

        // Validate Personal Info
        const requiredPersonalFields: (keyof any)[] = [
            'email', 'password', 'fullName', 'username',
        ];
        const missingPersonalFields = requiredPersonalFields.filter(field => !personalInfo[field]);

        // Validate Business BusinessInfo
        const requiredBusinessFields: (keyof any)[] = [
            'businessName', 'businessAddress', 'businessType',
            'businessDescription', 'businessPhoneNumber'
        ];
        const missingBusinessFields = requiredBusinessFields.filter(field => !businessInfo[field]);

        // Validate Identification
        if (identification.hasValidId) {
            if (!identification.validIdType || !identification.validIdNumber || !identification.validIdFile) {
                return c.json({
                    success: false,
                    message: 'Valid ID information is incomplete'
                }, 400);
            }
        } else {
            if (!identification.secondaryIdType1 || !identification.secondaryIdType2 ||
                !identification.secondaryIdFile1 || !identification.secondaryIdFile2) {
                return c.json({
                    success: false,
                    message: 'Secondary ID information is incomplete'
                }, 400);
            }
        }

        // Check for missing fields
        if (missingPersonalFields.length > 0 || missingBusinessFields.length > 0) {
            return c.json({
                success: false,
                message: `Missing required fields: ${[...missingPersonalFields, ...missingBusinessFields].join(', ')}`
            }, 400);
        }

        // Validate password length
        if (personalInfo.password.length < 6) {
            return c.json({
                success: false,
                message: 'Password must be at least 6 characters'
            }, 400);
        }

        // Create Firebase Auth user with additional claims
        const userRecord = await auth.createUser({
            email: personalInfo.email,
            password: personalInfo.password,
            displayName: personalInfo.username.toLowerCase(),
            emailVerified: true, // Set as verified since we've confirmed via OTP
        });

        // Set custom claims for the user
        await auth.setCustomUserClaims(userRecord.uid, {
            role: 'lender'
        });

        // Destructure needed fields
        const {
            fullName,
            email,
            username,
        } = personalInfo;

        const {
            businessName,
            businessAddress,
            businessType,
            businessDescription,
            businessPhoneNumber,
            selfieWithId,
            street,
            zipCode,
            province,
            city,
            barangay,
            region,
        } = businessInfo;

        const {
            hasValidId,
            validIdType,
            validIdNumber,
            validIdFile,
            secondaryIdType1,
            secondaryIdFile1,
            secondaryIdType2,
            secondaryIdFile2,
        } = identification;

        // Prepare and store user details in Firestore (excluding sensitive data)
        const userDataWithoutSensitive = {
            email,
            fullName,
            username: username.toLowerCase(),
            businessInfo: {
                businessName,
                businessAddress,
                businessType,
                businessDescription,
                businessPhoneNumber,
                street,
                zipCode,
                province,
                city,
                barangay,
                region,
                country: "Philippines",

                ...(businessType === "INDIVIDUAL" && {
                    selfieWithId: selfieWithId || null,
                }),
            },
            identification: {
                hasValidId,
                selfieWithId,
                ...(hasValidId
                    ? {
                        validIdType,
                        validIdNumber,
                        validIdFile,
                    }
                    : {
                        secondaryIdType1,
                        secondaryIdFile1,
                        secondaryIdType2,
                        secondaryIdFile2,
                    }),
            },
            uid: userRecord.uid,
            role: 'lender',
            status: 'pending',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            isVerified: false,
        };

        // Store non-sensitive data in Firestore
        await db.collection("users").doc(userRecord.uid).set(userDataWithoutSensitive);

        // Send welcome email
        await sendRegistrationEmail({
            email: personalInfo.email,
            fullName: personalInfo.fullName
        });

        // Clean up OTP record
        await db.collection("otpCodes").doc(personalInfo.email).delete();

        return c.json({
            success: true,
            message: 'Lender account created successfully',
            uid: userRecord.uid
        });
    } catch (error: any) {
        console.error('Lender Signup Error:', error);
        return c.json({
            success: false,
            message: error.message || 'Lender signup failed'
        }, 400);
    }
};



const userLenderSignIn = async (c: Context) => {
    try {
        const { email, password } = await c.req.json();

        if (!email || !password) {
            return c.json({
                success: false,
                message: 'Email and password are required'
            }, 400);
        }

        try {
            // First verify credentials using Firebase client auth
            const userCredential = await signInWithEmailAndPassword(clientAuth, email, password);
            const firebaseUser = userCredential.user;

            if (!firebaseUser) {
                return c.json({
                    success: false,
                    message: 'Authentication failed'
                }, 401);
            }

            // Get user from admin SDK to verify role and get additional data
            const userRecord = await auth.getUser(firebaseUser.uid);

            // Get Firestore data
            const userData = await db.collection("users").doc(firebaseUser.uid).get();

            if (!userData.exists) {
                return c.json({
                    success: false,
                    message: 'User data not found'
                }, 404);
            }

            const userDataObj = userData.data();

            // Check if account status is pending
            if (userDataObj?.status === "pending") {
                return c.json({
                    success: false,
                    message: 'Your account is currently under review. Our team will email you once your application has been approved or rejected. Please check your inbox including spam folders.',
                    status: 'under-review',
                    reviewData: { fullName: userDataObj?.fullName, email: userDataObj?.email }
                }, 403);
            }

            // Verify user is a lender
            const customClaims = userRecord.customClaims || {};
            if (customClaims.role !== 'lender') {
                return c.json({
                    success: false,
                    message: 'Access denied. This account is not registered as a lender.'
                }, 403);
            }

            // Create custom token with role claim
            const customToken = await auth.createCustomToken(firebaseUser.uid, {
                role: 'lender'
            });

            // Set user in context
            const user = {
                uid: firebaseUser.uid,
                email: userRecord.email || null,
                fullName: userDataObj?.fullName,
                username: userDataObj?.username,
                businessName: userDataObj?.businessName,
                role: 'lender' as const,
                businessInfo: userDataObj?.businessInfo as any | undefined,
                identification: userDataObj?.identification as any | undefined
            };
            c.set('user', user);

            return c.json({
                success: true,
                message: 'Lender signed in successfully',
                idToken: await firebaseUser.getIdToken(),
                customToken,
                user
            });

        } catch (authError: any) {
            console.error('Authentication Error:', authError);
            return c.json({
                success: false,
                message: 'Invalid email or password',
                status: "invalid-credentials"
            }, 401);
        }
    } catch (error: any) {
        console.error('Lender Sign In Error:', error);
        return c.json({
            success: false,
            message: error.message || 'An unexpected error occurred during sign in',
            status: "unexpected-error"
        }, 500);
    }
};


const updateLenderProfileDetails = async (c: Context) => {
    try {
        const lenderId = c.req.param('lenderId');
        if (!lenderId) {
            return c.json({ success: false, message: 'Lender ID is required' }, 400);
        }

        const body = await c.req.json();

        const {
            fullName,
            firstName,
            middleName,
            lastName,
            username,
            businessName,
            businessAddress,
            businessType,
            businessPermitNumber,
            description,
            email,
            phoneNumber,
            businessPhoneNumber,
            termsAndConditions,
        } = body;

        console.log("termsAndConditions", termsAndConditions);

        const userData = await db.collection('users').doc(lenderId).get();
        if (!userData.exists) {
            return c.json({ success: false, message: 'Lender not found' }, 404);
        }

        const existingData = userData.data();

        const updateData = {
            ...(fullName && { fullName }),
            ...(username && { username }),

            ...(email && { email }),


            firstName: firstName || existingData?.firstName || "",
            middleName: middleName !== undefined ? middleName : existingData?.middleName || "",
            lastName: lastName || existingData?.lastName || "",
            businessInfo: {
                name: businessName || existingData?.businessInfo?.name || "",
                address: businessAddress || existingData?.businessInfo?.address || "",
                type: businessType || existingData?.businessInfo?.type || "",
                permitNumber: businessPermitNumber || phoneNumber || existingData?.businessInfo?.permitNumber || "",
                termsAndConditions: termsAndConditions || existingData?.businessInfo?.termsAndConditions || "",
                businessPhoneNumber: businessPhoneNumber || existingData?.businessInfo?.phoneNumber || "",
                ...(termsAndConditions !== undefined && { termsAndConditions }),
                businessDescription: description || existingData?.businnesInfo.businessDescription || ""
            },

            updatedAt: new Date().toISOString()
        };

        console.log("updated", updateData)

        await userData.ref.update(updateData);

        return c.json({
            success: true,
            message: 'Lender profile updated successfully',
            data: {
                lenderId,
                ...updateData
            }
        });
    } catch (error) {
        console.error('Update Lender Profile Error:', error);
        return c.json({
            success: false,
            message: error instanceof Error ? error.message : 'An unexpected error occurred'
        }, 500);
    }
};


const getLenderDataByUsername = async (c: Context) => {
    try {
        // Get username from query parameters and convert to lowercase for case-insensitive comparison
        const username = c.req.param("username")?.toLowerCase();

        // Validate username parameter
        if (!username) {
            return c.json({
                success: false,
                message: 'Username is required',
                status: 'missing-parameter'
            }, 400);
        }

        // Query Firestore for the lender with the specified username
        const usersSnapshot = await db.collection('users')
            .where('username', '==', username)
            .where('role', '==', 'lender')
            .limit(1)
            .get();

        // Check if lender exists
        if (usersSnapshot.empty) {
            return c.json({
                success: false,
                message: 'Lender not found',
                status: 'not-found'
            }, 404);
        }

        // Get the first (and should be only) document
        const userDoc = usersSnapshot.docs[0];
        const userData = userDoc?.data();

        // Additional null check for userData
        if (!userData) {
            return c.json({
                success: false,
                message: 'Lender data is corrupted or incomplete',
                status: 'data-error'
            }, 500);
        }

        const lenderData = {
            uid: userDoc?.id ?? "",
            username: userData?.username ?? "",
            fullName: userData?.fullName ?? "",
            email: userData?.email ?? "",
            role: userData?.role ?? "lender",
            status: userData?.status ?? "unknown",
            isVerified: userData?.isVerified ?? false,
            createdAt: userData?.createdAt ?? new Date().toISOString(),
            updatedAt: userData?.updatedAt ?? new Date().toISOString(),
            selfieWithId: userData?.selfieWithId ?? "",

            businessInfo: {
                businessName: userData?.businessInfo?.businessName ?? "",
                businessAddress: userData?.businessInfo?.businessAddress ?? "",
                businessDescription: userData?.businessInfo?.businessDescription ?? "",
                businessType: userData?.businessInfo?.businessType ?? "",
                businessPhoneNumber: userData?.businessInfo?.businessPhoneNumber ?? "",
                businessPermitNumber: userData?.businessInfo?.businessPermitNumber ?? "",
                businessPermitFile: userData?.businessInfo?.businessPermitFile ?? "",
                termsAndConditions: userData?.businessInfo?.termsAndConditions ?? "",
                street: userData?.businessInfo?.street ?? "",
                zipCode: userData?.businessInfo?.zipCode ?? "",
                barangay: userData?.businessInfo?.barangay ?? "",
                province: userData?.businessInfo?.province ?? "",
                region: userData?.businessInfo?.region ?? "",
                country: userData?.businessInfo?.country ?? "Philippines",
                city: {
                    id: userData?.businessInfo?.city?.id ?? "",
                    name:
                        userData?.businessInfo?.city?.name ??
                        (typeof userData?.businessInfo?.city === "string"
                            ? userData.businessInfo.city
                            : ""),
                    country: userData?.businessInfo?.city?.country ?? "",
                    province: userData?.businessInfo?.city?.province ?? "",
                    region: userData?.businessInfo?.city?.region ?? "",
                },
            },

            identification: {
                hasValidId: userData?.identification?.hasValidId ?? false,
                validIdType: userData?.identification?.validIdType ?? "",
                validIdNumber: userData?.identification?.validIdNumber ?? "",
                validIdFile: userData?.identification?.validIdFile ?? "",
            },
        };

        // Return success response with formatted lender data
        return c.json({
            success: true,
            message: 'Lender data retrieved successfully',
            data: lenderData,
            status: 'success'
        });

    } catch (error: any) {
        console.error('Error getting lender data by username:', error);

        // Handle specific Firebase errors
        if (error.code === 'permission-denied') {
            return c.json({
                success: false,
                message: 'You do not have permission to access this resource',
                status: 'permission-denied'
            }, 403);
        }

        // Generic error response
        return c.json({
            success: false,
            message: 'An error occurred while fetching lender data',
            status: 'server-error',
            error: error.message
        }, 500);
    }
};


export default { userLenderSignUp, userLenderSignIn, updateLenderProfileDetails, requestOTP, resendOTP, getLenderDataByUsername };