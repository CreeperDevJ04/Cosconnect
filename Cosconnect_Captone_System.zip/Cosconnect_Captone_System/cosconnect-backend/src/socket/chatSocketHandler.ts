import { Server, Socket } from "socket.io";
import db from "../db/supabase/db_connect";
import { conversations, messages } from "@/schema/conversation";
import { eq, and, or } from "drizzle-orm";

// ============================================================================
// TYPES
// ============================================================================

interface SendMessageData {
    message: string;
    sender_id: string;
    sender_username: string;
    sender_role: "admin" | "lender" | "borrower";
    receiver_id: string;
    receiver_username: string;
    receiver_role: "admin" | "lender" | "borrower";
    message_type?: "text" | "image";
}

interface TypingData {
    userId: string;
    username: string;
    partnerId: string;
    isTyping: boolean;
}

interface MessageSeenData {
    partnerId: string;
    messageIds: string[];
    userId: string;
}

// ============================================================================
// USER SOCKET MAP
// ============================================================================

export const userSocketMap: { [userId: string]: Set<string> } = {};

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

const emitToUser = (io: Server, userId: string, event: string, data: any): boolean => {
    const socketIds = userSocketMap[userId];
    if (!socketIds || socketIds.size === 0) return false;

    socketIds.forEach(socketId => {
        io.to(socketId).emit(event, data);
    });
    return true;
};

const getOnlineUsers = (): string[] => Object.keys(userSocketMap);

const broadcastOnlineUsers = (io: Server) => {
    const users = getOnlineUsers();
    io.emit("onlineUsers", { users, count: users.length });
};

// ============================================================================
// MAIN SOCKET HANDLER
// ============================================================================

export const handleChatSocketEvents = (io: Server, socket: Socket) => {
    const userId = socket.handshake.query.userId as string;
    const username = socket.handshake.query.username as string;

    if (!userId) {
        console.error("❌ Socket connection rejected: No userId provided");
        socket.disconnect();
        return;
    }

    // ============================================================
    // CONNECTION
    // ============================================================
    if (!userSocketMap[userId]) userSocketMap[userId] = new Set<string>();
    userSocketMap[userId].add(socket.id);

    console.log(`🟢 User connected: ${userId} (${username})`);
    broadcastOnlineUsers(io);

    socket.broadcast.emit("userOnline", { userId, isOnline: true });

    socket.emit("welcome", {
        message: "Connected to chat server",
        socketId: socket.id,
        userId,
        timestamp: new Date().toISOString(),
    });

    // ============================================================
    // PING/PONG (HEALTH CHECK)
    // ============================================================
    socket.on("ping", data => {
        socket.emit("pong", {
            message: "pong",
            timestamp: new Date().toISOString(),
            ...data,
        });
    });

    // ============================================================
    // SEND MESSAGE
    // ============================================================
    socket.on("sendMessage", async (data: SendMessageData) => {
        console.log("📨 sendMessage:", data.sender_id, "→", data.receiver_id);

        const {
            message,
            sender_id,
            sender_username,
            sender_role,
            receiver_id,
            receiver_username,
            receiver_role,
            message_type = "text",
        } = data;

        if (!sender_id || !receiver_id || !message) {
            socket.emit("messageError", {
                error: "Missing required fields",
                timestamp: new Date().toISOString(),
            });
            return;
        }

        try {
            // ========================================================
            // 1️⃣ Find or create conversation between these two users
            // ========================================================
            const [existingConversation] = await db
                .select()
                .from(conversations)
                .where(
                    or(
                        and(
                            eq(conversations.user1_id, sender_id),
                            eq(conversations.user2_id, receiver_id)
                        ),
                        and(
                            eq(conversations.user1_id, receiver_id),
                            eq(conversations.user2_id, sender_id)
                        )
                    )
                );

            let conversationId = existingConversation?.id;
            if (!conversationId) {
                const [newConversation] = await db
                    .insert(conversations)
                    .values({
                        user1_id: sender_id,
                        user1_role: sender_role,
                        user2_id: receiver_id,
                        user2_role: receiver_role,
                    })
                    .returning({ id: conversations.id });
                conversationId = newConversation?.id;
                console.log("💬 Created new conversation:", conversationId);
            }

            // ========================================================
            // 2️⃣ Save message in messages table
            // ========================================================
            const [newMessage] = await db
                .insert(messages)
                .values({
                    conversation_id: conversationId || '',
                    sender_id,
                    sender_role,
                    message_type,
                    content: message,
                    is_read: false,
                    is_seen: false,
                })
                .returning();

            const messageData = {
                id: newMessage?.id,
                conversation_id: conversationId,
                sender_id,
                sender_username,
                sender_role,
                receiver_id,
                receiver_username,
                receiver_role,
                message_type,
                content: message,
                is_read: false,
                is_seen: false,
                created_at: newMessage?.created_at,
            };

            // ========================================================
            // 3️⃣ Emit new message to receiver and sender
            // ========================================================
            const delivered = emitToUser(io, receiver_id, "newMessage", messageData);

            emitToUser(io, sender_id, "messageDelivered", {
                ...messageData,
                delivered,
                deliveredAt: delivered ? new Date().toISOString() : null,
            });


        } catch (error) {
            console.error("❌ sendMessage error:", error);
            socket.emit("messageError", {
                error: "Failed to send message",
                timestamp: new Date().toISOString(),
            });
        }
    });

    // ============================================================
    // USER TYPING
    // ============================================================
    socket.on("userTyping", (data: TypingData) => {
        const { userId: typingUserId, username: typingUsername, partnerId, isTyping } = data;
        if (!typingUserId || !partnerId || typeof isTyping !== "boolean") return;

        emitToUser(io, partnerId, "userTyping", {
            userId: typingUserId,
            username: typingUsername,
            partnerId,
            isTyping,
        });
    });

    // ============================================================
    // MESSAGE SEEN
    // ============================================================
    socket.on("messageSeen", async (data: MessageSeenData) => {
        const { partnerId, messageIds, userId: viewerId } = data;
        if (!partnerId || !messageIds || messageIds.length === 0) return;

        console.log("👁️ messageSeen:", viewerId, "→", partnerId, `(${messageIds.length} msgs)`);

        try {
            await db
                .update(messages)
                .set({ is_read: true, is_seen: true })
                .where(and(eq(messages.sender_id, partnerId)));

            emitToUser(io, partnerId, "messageSeen", {
                partnerId: viewerId,
                messageIds,
            });

            console.log("✅ Messages marked as seen");
        } catch (error) {
            console.error("❌ messageSeen error:", error);
        }
    });

    // ============================================================
    // DISCONNECT
    // ============================================================
    socket.on("disconnect", reason => {
        console.log("🔴 Disconnect:", userId, "|", reason);

        if (userSocketMap[userId]) {
            userSocketMap[userId].delete(socket.id);

            if (userSocketMap[userId].size === 0) {
                delete userSocketMap[userId];
                socket.broadcast.emit("userOnline", { userId, isOnline: false });
                broadcastOnlineUsers(io);
                console.log("👤 User fully disconnected:", userId);
            }
        }
    });

    // ============================================================
    // ERROR
    // ============================================================
    socket.on("error", error => {
        console.error("🔥 Socket error:", error);
    });
};
