import { Server, Socket } from 'socket.io';
import { Server as HttpServer } from 'http';
import { handleRentalSocketEvents } from './rentalSocketHandler';
import { handleChatSocketEvents } from './chatSocketHandler';

// Initialize Socket.IO
export const initializeSocketIO = (server: HttpServer) => {
    const io = new Server(server, {
        cors: {
            origin: '*',
            methods: ['GET', 'POST'],
            credentials: true
        },
        transports: ['websocket', 'polling'],
        pingTimeout: 60000,
        pingInterval: 25000
    });

    // Socket.IO connection handling
    io.on('connection', (socket: Socket) => {
        console.log('🟢 New client connected:', socket.id);
        console.log(`👥 Total connected clients: ${io.engine.clientsCount}`);

        // ===== CHAT FUNCTIONALITY =====
        // Add chat handlers
        handleChatSocketEvents(io, socket);

        // ===== RENTAL FUNCTIONALITY =====
        // Add rental handlers
        handleRentalSocketEvents(io, socket);
    });

    return io;
}; 