// src/rentalSocket.ts
import { Server, Socket } from "socket.io";
import { v4 as uuidv4 } from "uuid";
import type { ScheduleFormData } from "../types/rentalsType";
import { db } from "../db/supabase/db_connect";
import { costumes } from "../schema/costumes";
import { users } from "../schema/users";
import { rental_requests } from "../utils/rentals_request";
import { eq, and } from "drizzle-orm";

export interface RentalRequestBackend {
    id: string;
    costume_id: string;
    rental_id: string;
    costume_name: string;
    costume_image: string;
    renter_id: string;
    renter_username: string;
    renter_email: string;
    renter_profile_image?: string;
    lender_id: string;
    lender_username: string;
    rental_start_date: string;
    rental_end_date: string;
    total_days: number;
    daily_rate: number;
    total_amount: number;
    currency: string;
    selectedItems: {
        mainOffer: {
            selected: boolean;
            data: {
                type: string;
                price: string;
                image?: string;
            } | null;
        };
        selectedCostumeType: {
            selected: boolean;
            data: {
                type: string;
                price: string;
                image?: string;
            } | null;
        };
        selectedAddOns: Array<{
            id: string;
            name: string;
            image: string;
            price: string;
            description: string;
        }>;
    };
    conversation_id: string;
    status: "pending" | "accepted" | "rejected" | "paid" | "confirmed" | "completed" | "cancelled";
    created_at: string;
    updated_at: string;
    // Add optional payment_details for status updates (e.g., payment info)
    payment_details?: any;
}

export const rentalRequests: Record<string, RentalRequestBackend> = {};
export const rentalUserSocketMap: Record<string, Set<string>> = {};

const getUserRentalRequests = (userId: string, type: "pending" | "sent") => {
    const requests = Object.values(rentalRequests);
    if (type === "pending") {
        return requests.filter(r => r.lender_id === userId && r.status === "pending");
    } else {
        return requests.filter(r => r.renter_id === userId);
    }
};

export const handleRentalSocketEvents = (io: Server, socket: Socket) => {
    const userId = socket.handshake.query.userId as string;

    console.log("🏠 Rental socket connected for user:", userId);

    // record their socket id
    if (!rentalUserSocketMap[userId]) rentalUserSocketMap[userId] = new Set();
    rentalUserSocketMap[userId]?.add(socket.id);

    // cleanup
    socket.on("disconnect", () => {
        rentalUserSocketMap[userId]?.delete(socket.id);
        if (rentalUserSocketMap[userId]?.size === 0) delete rentalUserSocketMap[userId];
    });

    // initial data
    socket.on("requestInitialRentalData", ({ userId }) => {
        const pendingRequests = getUserRentalRequests(userId, "pending");
        const myRequests = getUserRentalRequests(userId, "sent");
        socket.emit("initialRentalData", {
            pendingRequests,
            myRequests,
            notifications: [],
            unreadCount: 0
        });
        console.log(`✅ Initial rental data sent to user ${userId}`);
    });

    // handle rental request
    socket.on("sendRentalRequest", async (data: ScheduleFormData) => {
        console.log("🏠 Received rental request:", data);

        try {
            // Validate required fields using the actual ScheduleFormData structure
            if (!data.costume_id ||
                !data.borrower_user_id ||
                !data.lender_user_id ||
                !data.rental?.startDate ||
                !data.rental?.endDate ||
                !data.rental?.pricing?.dailyRate ||
                !data.rental?.pricing?.totalCost ||
                !data.metadata?.conversationId) {
                socket.emit("rentalRequestError", {
                    error: "Missing required fields",
                    message: "Please fill in all required data"
                });
                return;
            }

            // Fetch costume and user details from database
            const [costumeData, borrowerData, lenderData] = await Promise.all([
                db.select({


                    name: costumes.name,
                    main_images: costumes.main_images
                })
                    .from(costumes)
                    .where(eq(costumes.id, data.costume_id))
                    .limit(1),

                db.select({
                    username: users.username,
                    email: users.email,
                    profile_image: users.profile_image
                })
                    .from(users)
                    .where(eq(users.uid, data.borrower_user_id))
                    .limit(1),

                db.select({
                    username: users.username
                })
                    .from(users)
                    .where(eq(users.uid, data.lender_user_id))
                    .limit(1)
            ]);

            if (costumeData.length === 0) {
                socket.emit("rentalRequestError", {
                    error: "Costume not found",
                    message: "The specified costume does not exist"
                });
                return;
            }

            if (borrowerData.length === 0) {
                socket.emit("rentalRequestError", {
                    error: "Borrower not found",
                    message: "The specified borrower does not exist"
                });
                return;
            }

            if (lenderData.length === 0) {
                socket.emit("rentalRequestError", {
                    error: "Lender not found",
                    message: "The specified lender does not exist"
                });
                return;
            }

            const costume = costumeData[0];
            const borrower = borrowerData[0];
            const lender = lenderData[0];

            if (!costume || !borrower || !lender) {
                socket.emit("rentalRequestError", {
                    error: "Data not found",
                    message: "Could not fetch required data from database"
                });
                return;
            }

            const rentalRequest: RentalRequestBackend = {
                id: uuidv4(),
                rental_id: data.rental_id,
                costume_id: data.costume_id,
                costume_name: costume.name,
                costume_image: costume.main_images?.front || '',
                renter_id: data.borrower_user_id,
                renter_username: borrower.username,
                renter_email: borrower.email,
                renter_profile_image: borrower.profile_image || '',
                lender_id: data.lender_user_id,
                lender_username: lender.username,
                rental_start_date: data.rental.startDate,
                rental_end_date: data.rental.endDate,
                total_days: data.rental.totalDays,
                daily_rate: data.rental.pricing.dailyRate,
                total_amount: data.rental.pricing.totalCost,
                currency: data.rental.pricing.currency,
                selectedItems: data.rental.selectedItems,
                conversation_id: data.metadata.conversationId,
                status: "pending",
                created_at: data.metadata.createdAt,
                updated_at: new Date().toISOString()
            };


            // Store rentalRequest using rental_id as the key
            rentalRequests[rentalRequest.rental_id] = rentalRequest;

            // notify lender
            const lenderSockets = rentalUserSocketMap[data.lender_user_id];
            if (lenderSockets) {
                io.to([...lenderSockets]).emit("newRentalRequest", rentalRequest);
            }

            socket.emit("rentalRequestSent", {
                success: true,
                rental_id: rentalRequest.rental_id,
                message: "Rental request successfully created"
            });

            console.log(`✅ Rental request ${rentalRequest.id} processed`);
        } catch (error) {
            console.error("❌ Error processing rental request:", error);
            socket.emit("rentalRequestError", {
                error: "Server error",
                message: "Could not process rental request, try again"
            });
        }
    });

    // handle response
    socket.on("respondToRentalRequest", async (data) => {
        console.log("📋 Rental response received:", data);

        try {
            // If status is 'accepted', change to 'approved'
            const newStatus = data.status === 'accepted' ? 'approved' : data.status;

            // Query the database for the rental request
            const rentalData = await db
                .select()
                .from(rental_requests)
                .where(eq(rental_requests.rental_id, data.rental_id))
                .limit(1);

            if (rentalData.length === 0) {
                socket.emit("rentalResponseError", {
                    error: "Rental request not found"
                });
                return;
            }

            const rental = rentalData[0];
            console.log("rental", rental);

            // Only allow the lender to respond to the rental request
            if (!rental || userId !== rental.lender_user_id) {
                socket.emit("rentalResponseError", {
                    error: "Only the lender can respond to this rental request."
                });
                return;
            }

            // Update the rental request in the database
            const [updatedRental] = await db
                .update(rental_requests)
                .set({
                    status: newStatus,
                    lender_response: data.message,
                    responded_at: new Date(),
                    updated_at: new Date()
                })
                .where(eq(rental_requests.rental_id, data.rental_id))
                .returning();

            if (!updatedRental) {
                socket.emit("rentalResponseError", {
                    error: "Failed to update rental request"
                });
                return;
            }

            // Update in-memory cache for socket events (optional, for performance)
            if (rentalRequests[data.rental_id]) {
                rentalRequests[data.rental_id] = {
                    ...rentalRequests[data.rental_id]!,
                    status: newStatus,
                    updated_at: new Date().toISOString()
                } as RentalRequestBackend;
            }

            // notify renter
            const renterSockets = rentalUserSocketMap[rental?.borrower_user_id || ''];
            if (renterSockets) {
                io.to([...renterSockets]).emit("rentalStatusUpdate", {
                    rental_id: rental?.rental_id || data.rental_id,
                    status: newStatus,
                    message: data.message,
                    updated_by: data.lender_id,
                    updated_by_username: data.lender_username,
                    timestamp: updatedRental.updated_at.toISOString()
                });
            }

            socket.emit("rentalResponseSent", {
                success: true,
                rental_id: data.rental_id,
                status: newStatus
            });

            console.log(`✅ Rental ${data.rental_id} response processed`);
        } catch (error) {
            console.error("❌ Error processing rental response:", error);
            socket.emit("rentalResponseError", {
                error: "Failed to process response"
            });
        }
    });



    console.log("✅ Rental handlers registered for user:", userId);
};
