/**
 * Utility function to convert camelCase object keys to snake_case
 * @param obj - The object to convert
 * @returns The object with snake_case keys
 */
export const toSnakeCase = (obj: any): any => {
    if (obj === null || obj === undefined) {
        return obj;
    }

    if (Array.isArray(obj)) {
        return obj.map(item => toSnakeCase(item));
    }

    if (typeof obj === 'object') {
        const snakeCaseObj: any = {};
        for (const [key, value] of Object.entries(obj)) {
            const snakeKey = key.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);
            snakeCaseObj[snakeKey] = toSnakeCase(value);
        }
        return snakeCaseObj;
    }

    return obj;
};

/**
 * Utility function to convert snake_case object keys to camelCase
 * @param obj - The object to convert
 * @returns The object with camelCase keys
 */
export const toCamelCase = (obj: any): any => {
    if (obj === null || obj === undefined) {
        return obj;
    }

    if (Array.isArray(obj)) {
        return obj.map(item => toCamelCase(item));
    }

    if (typeof obj === 'object') {
        const camelCaseObj: any = {};
        for (const [key, value] of Object.entries(obj)) {
            const camelKey = key.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
            camelCaseObj[camelKey] = toCamelCase(value);
        }
        return camelCaseObj;
    }

    return obj;
}; 