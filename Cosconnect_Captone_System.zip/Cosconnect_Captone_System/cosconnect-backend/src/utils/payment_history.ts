import {
    integer,
    pgTable,
    text,
    timestamp,
    uuid,
    varchar,
    jsonb,
    index,
    pgEnum
} from 'drizzle-orm/pg-core';

// Payment status enum for better type safety
export const paymentStatusEnum = pgEnum('payment_status', [
    'pending',
    'paid',
    'cancelled',
    'failed',
    'expired',
    'refunded'
]);

// Payment method enum
export const paymentMethodEnum = pgEnum('payment_method', [
    'gcash',
    'card',
    'paymaya',
    'bank_transfer'
]);

// Payment type enum
export const paymentTypeEnum = pgEnum('payment_type', [
    'online',
    'offline',
    'wallet'
]);

export const payment_history = pgTable('payment_history', {
    id: uuid('id').primaryKey().notNull().defaultRandom(),

    // PayMongo specific fields
    session_id: varchar('session_id', { length: 255 }).notNull().unique(), // PayMongo payment intent/session
    payment_intent_id: varchar('payment_intent_id', { length: 255 }).notNull(), // PayMongo intent
    payment_source_id: varchar('payment_source_id', { length: 255 }), // PayMongo source (optional)

    // Business logic fields
    rental_id: uuid('rental_id').notNull(), // FK to rentals table
    borrower_user_id: varchar('borrower_user_id', { length: 150 }).notNull(),
    lender_user_id: varchar('lender_user_id', { length: 150 }).notNull(),
    product_id: varchar('product_id', { length: 255 }).notNull(),
    product_name: varchar('product_name', { length: 255 }).notNull(),

    // Payment details
    amount: integer('amount').notNull(), // in cents (PayMongo standard)
    currency: varchar('currency', { length: 3 }).notNull().default('PHP'),
    status: paymentStatusEnum('status').notNull().default('pending'),
    payment_type: paymentTypeEnum('payment_type').notNull().default('online'),
    payment_method: paymentMethodEnum('payment_method').notNull(),

    // Additional data
    selected_items: jsonb('selected_items').notNull().default('{}'), // JSON object for selected items
    metadata: jsonb('metadata').notNull().default('{}'), // JSON object for additional metadata
    description: text('description'),

    // Redirect URLs for payment flow
    success_url: varchar('success_url', { length: 500 }),
    cancel_url: varchar('cancel_url', { length: 500 }),

    // Timestamps
    paid_at: timestamp('paid_at'),
    cancelled_at: timestamp('cancelled_at'),
    expired_at: timestamp('expired_at'),
    refunded_at: timestamp('refunded_at'),
    created_at: timestamp('created_at').defaultNow().notNull(),
    updated_at: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
    // Indexes for better query performance
    sessionIdx: index('payment_history_session_id_idx').on(table.session_id),
    rentalIdx: index('payment_history_rental_id_idx').on(table.rental_id),
    borrowerIdx: index('payment_history_borrower_id_idx').on(table.borrower_user_id),
    lenderIdx: index('payment_history_lender_id_idx').on(table.lender_user_id),
    paymentIntentIdx: index('payment_history_payment_intent_id_idx').on(table.payment_intent_id),
    statusIdx: index('payment_history_status_idx').on(table.status),
    createdAtIdx: index('payment_history_created_at_idx').on(table.created_at),
}));

export type PaymentHistory = typeof payment_history.$inferSelect;
export type NewPaymentHistory = typeof payment_history.$inferInsert;