// File: schema/messages.ts

import { InferInsertModel, InferSelectModel } from 'drizzle-orm';
import {
    boolean,
    index,
    pgEnum,
    pgTable,
    text,
    timestamp,
    uuid,
    varchar
} from 'drizzle-orm/pg-core';

// Enum definition
export const message_type_enum = pgEnum('message_type', ['inquiry', 'text', 'system']);

export const messages = pgTable('messages', {
    id: uuid('id').primaryKey().defaultRandom(),

    // Conversation reference
    conversation_id: varchar('conversation_id', { length: 255 }).notNull(),

    // Costume reference
    costume_id: varchar('costume_id', { length: 255 }),
    costume_name: text('costume_name'),

    // Message content
    message: text('message').notNull(),
    message_type: message_type_enum('message_type').notNull(),

    // User references - using varchar for flexibility with different ID formats
    sender_id: varchar('sender_id', { length: 255 }).notNull(),
    receiver_id: varchar('receiver_id', { length: 255 }).notNull(),
    receiver_username: varchar('receiver_username', { length: 255 }).notNull(),
    sender_username: varchar('sender_username', { length: 255 }).notNull(),

    // Participants (for conversation tracking) - using varchar for consistency
    user1_id: varchar('user1_id', { length: 255 }).notNull(),
    user2_id: varchar('user2_id', { length: 255 }).notNull(),

    // Message Status Fields
    // is_read: true when receiver has opened the conversation and seen the message
    // is_seen: true when receiver has actually viewed/read the message content
    is_read: boolean('is_read').notNull().default(false),
    is_seen: boolean('is_seen').notNull().default(false),

    // Timestamp
    timestamp: timestamp('timestamp', { withTimezone: true }).notNull().defaultNow(),
}, (table) => ({
    conversationIdx: index('conversation_idx').on(table.conversation_id),
    senderIdx: index('sender_idx').on(table.sender_id),
    receiverIdx: index('receiver_idx').on(table.receiver_id),
    timestampIdx: index('timestamp_idx').on(table.timestamp),
    user1Idx: index('user1_idx').on(table.user1_id),
    user2Idx: index('user2_idx').on(table.user2_id),
    // Add index for read/seen status for better query performance
    readStatusIdx: index('read_status_idx').on(table.is_read, table.is_seen),
}));

// Types for selects/inserts
export type SelectMessage = InferSelectModel<typeof messages>;
export type InsertMessage = InferInsertModel<typeof messages>;

// Additional helper types
export type MessageStatus = 'unread' | 'read' | 'seen';
export type MessageType = 'inquiry' | 'text' | 'system';

// Helper type for message status
export interface MessageStatusInfo {
    is_read: boolean;
    is_seen: boolean;
    status: MessageStatus;
}

// Helper function to get message status
export const getMessageStatus = (is_read: boolean, is_seen: boolean): MessageStatus => {
    if (is_seen) return 'seen';
    if (is_read) return 'read';
    return 'unread';
};