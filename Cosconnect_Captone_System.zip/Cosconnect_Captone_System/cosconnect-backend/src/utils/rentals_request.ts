import type { InferInsertModel, InferSelectModel } from 'drizzle-orm';
import {
    boolean,
    index,
    integer,
    jsonb,
    pgEnum,
    pgTable,
    text,
    timestamp,
    uuid,
    varchar
} from 'drizzle-orm/pg-core';
import { costumes } from '../schema/costumes';
import { payment_history } from './payment_history';
import { users } from '../schema/users';

// =============================================================================
// ENUMS
// =============================================================================

export const rentalRequestStatusEnum = pgEnum('rental_request_status', [
    'pending_deposit',
    'pending_approval',
    'approved',
    'rejected',
    'expired',
    'cancelled'
]);

// =============================================================================
// RENTAL REQUESTS TABLE (Updated to match existing structure)
// =============================================================================

export const rental_requests = pgTable('rental_requests', {
    id: uuid('id').primaryKey().defaultRandom(),

    // Core identifiers
    conversation_id: varchar('conversation_id', { length: 255 }).notNull(),
    costume_id: uuid('costume_id').notNull().references(() => costumes.id),
    borrower_user_id: uuid('borrower_user_id').notNull().references(() => users.uid),
    lender_user_id: uuid('lender_user_id').notNull().references(() => users.uid),

    // Request details
    requested_start_date: timestamp('requested_start_date').notNull(),
    requested_end_date: timestamp('requested_end_date').notNull(),
    total_days: integer('total_days').notNull(),

    // Selected items (JSON object from frontend) - matches existing structure
    selected_items: jsonb('selected_items').notNull().$type<{
        mainOffer: {
            selected: boolean;
            data: {
                type: string;
                price: string;
                image?: string;
            } | null;
        };
        selectedCostumeType: {
            selected: boolean;
            data: {
                type: string;
                price: string;
                image?: string;
            } | null;
        };
        selectedAddOns: Array<{
            id: string;
            name: string;
            image: string;
            price: string;
            description: string;
        }>;
    }>(),

    // Pricing information (estimated)
    estimated_daily_rate: integer('estimated_daily_rate').notNull(), // in cents
    estimated_total_amount: integer('estimated_total_amount').notNull(), // in cents
    security_deposit_amount: integer('security_deposit_amount').notNull(), // in cents
    deposit_paid: boolean('deposit_paid').notNull().default(false),
    deposit_payment_intent_id: varchar('deposit_payment_intent_id', { length: 255 }), // Payment intent for deposit
    currency: varchar('currency', { length: 3 }).notNull().default('PHP'),

    // Request status and response
    status: rentalRequestStatusEnum('status').notNull().default('pending_deposit'),
    lender_response: text('lender_response'), // optional approval/rejection message
    rejection_reason: text('rejection_reason'), // if status is 'rejected'

    // Timestamps for deposit and approval
    deposit_paid_at: timestamp('deposit_paid_at'),
    approved_at: timestamp('approved_at'),

    // Timestamps
    requested_at: timestamp('requested_at').notNull().defaultNow(),
    responded_at: timestamp('responded_at'), // when lender approved/rejected
    expires_at: timestamp('expires_at').notNull(), // request expiry (e.g., 24 hours)
    created_at: timestamp('created_at').notNull().defaultNow(),
    updated_at: timestamp('updated_at').notNull().defaultNow(),

    // Additional fields
    is_active: boolean('is_active').notNull().default(true),
    notes: text('notes'), // additional notes

    // Links to actual rental (after approval and payment)
    rental_id: uuid('rental_id'), // rental_id as uuid string, can be set after approval
    payment_history_id: uuid('payment_history_id').references(() => payment_history.id), // FK to payment_history table

}, (table) => ({
    // Indexes for better query performance
    conversationIdx: index('rental_requests_conversation_id_idx').on(table.conversation_id),
    costumeIdx: index('rental_requests_costume_id_idx').on(table.costume_id),
    borrowerIdx: index('rental_requests_borrower_id_idx').on(table.borrower_user_id),
    lenderIdx: index('rental_requests_lender_id_idx').on(table.lender_user_id),
    statusIdx: index('rental_requests_status_idx').on(table.status),
    requestedAtIdx: index('rental_requests_requested_at_idx').on(table.requested_at),
    expiresAtIdx: index('rental_requests_expires_at_idx').on(table.expires_at),
    rentalIdIdx: index('rental_requests_rental_id_idx').on(table.rental_id),
    paymentHistoryIdx: index('rental_requests_payment_history_id_idx').on(table.payment_history_id),
}));

// =============================================================================
// TYPE EXPORTS
// =============================================================================

export type RentalRequest = InferSelectModel<typeof rental_requests>;
export type NewRentalRequest = InferInsertModel<typeof rental_requests>;