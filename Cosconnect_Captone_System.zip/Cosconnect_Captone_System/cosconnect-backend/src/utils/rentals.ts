import type { InferInsertModel, InferSelectModel } from 'drizzle-orm';
import {
    boolean,
    index,
    integer,
    jsonb,
    pgEnum,
    pgTable,
    text,
    timestamp,
    uuid,
    varchar
} from 'drizzle-orm/pg-core';
import { costumes } from '../schema/costumes';
import { payment_history } from './payment_history';
import { users } from '../schema/users';

// =============================================================================
// ENUMS
// =============================================================================

export const rentalStatusEnum = pgEnum('rental_status', [
    'pending_deposit',  // Waiting for security deposit payment
    'pending_approval', // Deposit paid, waiting for lender approval
    'confirmed',        // Lender approved, rental confirmed
    'active',           // Rental period has started
    'completed',        // Rental returned and completed successfully
    'cancelled',        // Rental cancelled (with potential refund)
    'disputed',         // Issues requiring resolution
    'deposit_refunded', // Security deposit refunded
    'overdue'           // Rental not returned on time
]);

export const deliveryMethodEnum = pgEnum('delivery_method', [
    'pickup',       // Borrower picks up from lender
    'delivery',     // Lender delivers to borrower
    'meetup',       // Meet at agreed location
    'shipping'      // Shipped via courier
]);

// =============================================================================
// RENTALS TABLE
// =============================================================================
// Purpose: Permanent records for confirmed rentals with complete historical data
// Lifecycle: Created from approved request → Confirmed → Active → Completed/Cancelled
// Note: Records are never deleted - they serve as permanent business records

export const rentals = pgTable('rentals', {
    id: uuid('id').primaryKey().defaultRandom(),

    // Reference to original request (for audit trail)
    original_request_id: uuid('original_request_id'), // Reference to deleted rental_request
    conversation_id: varchar('conversation_id', { length: 255 }).notNull(),

    // Core relationships
    costume_id: uuid('costume_id').notNull().references(() => costumes.id), // Original costume reference
    borrower_user_id: uuid('borrower_user_id').notNull().references(() => users.uid),
    lender_user_id: uuid('lender_user_id').notNull().references(() => users.uid),

    // Rental period
    start_date: timestamp('start_date').notNull(),
    end_date: timestamp('end_date').notNull(),
    total_days: integer('total_days').notNull(),

    // === IMMUTABLE SNAPSHOTS ===
    // These preserve the exact state at time of rental confirmation
    // and protect against data changes in referenced tables

    // Complete costume snapshot at time of rental
    costume_snapshot: jsonb('costume_snapshot').notNull().$type<{
        name: string;
        description: string;
        images: string[];
        daily_rate: number; // in cents
        category: string;
        size: string;
        condition: string;
        location: string;
        tags?: string[];
        availability?: any;
        lender_info: {
            user_id: string;
            username: string;
            full_name?: string;
            profile_image?: string;
            business_name?: string;
            contact_info?: string;
            business_address?: string;
        };
    }>(),

    // Complete borrower snapshot at time of rental
    borrower_snapshot: jsonb('borrower_snapshot').notNull().$type<{
        user_id: string;
        username: string;
        full_name?: string;
        email: string;
        phone_number: string;
        profile_image?: string;
        address?: {
            full_address: string;
            street?: string;
            barangay?: string;
            city: string;
            province: string;
            zip_code?: string;
        };
        verified_documents?: boolean;
    }>(),

    // Selected items snapshot (exactly what was agreed upon)
    selected_items: jsonb('selected_items').notNull().$type<{
        main_offer?: {
            type: string;
            price: number; // in cents
            image?: string;
            description?: string;
        };
        costume_type?: {
            type: string;
            price: number; // in cents
            image?: string;
            description?: string;
        };
        add_ons: Array<{
            id: string;
            name: string;
            image: string;
            price: number; // in cents
            description: string;
        }>;
    }>(),

    // === IMMUTABLE PRICING ===
    // Financial data that must never change once confirmed
    daily_rate: integer('daily_rate').notNull(), // in cents
    add_ons_total: integer('add_ons_total').notNull().default(0), // in cents
    subtotal: integer('subtotal').notNull(), // daily_rate * total_days + add_ons_total
    service_fee: integer('service_fee').notNull().default(0), // platform fee
    tax_amount: integer('tax_amount').notNull().default(0), // tax if applicable
    total_amount: integer('total_amount').notNull(), // final rental amount in cents

    // Security deposit (set by lender)
    security_deposit_amount: integer('security_deposit_amount').notNull(), // in cents
    security_deposit_paid: boolean('security_deposit_paid').notNull().default(false),
    security_deposit_refunded: boolean('security_deposit_refunded').notNull().default(false),
    security_deposit_refund_amount: integer('security_deposit_refund_amount'), // in case of partial refund

    currency: varchar('currency', { length: 3 }).notNull().default('PHP'),

    // === PAYMENT INFORMATION ===
    payment_history_id: uuid('payment_history_id').references(() => payment_history.id),
    payment_intent_id: varchar('payment_intent_id', { length: 255 }), // PayMongo/Stripe reference
    payment_method: varchar('payment_method', { length: 100 }), // e.g., 'card', 'gcash', 'maya'

    // === RENTAL STATUS & LIFECYCLE ===
    status: rentalStatusEnum('status').notNull().default('confirmed'),

    // === DELIVERY & LOGISTICS ===
    delivery_method: deliveryMethodEnum('delivery_method'),
    delivery_address: text('delivery_address'),
    pickup_location: text('pickup_location'),
    delivery_instructions: text('delivery_instructions'),
    pickup_instructions: text('pickup_instructions'),
    return_instructions: text('return_instructions'),

    // Tracking information
    delivery_tracking_number: varchar('delivery_tracking_number', { length: 100 }),
    return_tracking_number: varchar('return_tracking_number', { length: 100 }),

    // === COMMUNICATION & NOTES ===
    borrower_notes: text('borrower_notes'), // Original notes from request
    lender_response: text('lender_response'), // Lender's approval message
    special_instructions: text('special_instructions'), // Lender's special instructions
    internal_notes: text('internal_notes'), // Admin/system notes

    // === LIFECYCLE TIMESTAMPS ===
    deposit_paid_at: timestamp('deposit_paid_at'), // When security deposit was paid
    deposit_refunded_at: timestamp('deposit_refunded_at'), // When security deposit was refunded
    approved_at: timestamp('approved_at'), // When lender approved the rental
    confirmed_at: timestamp('confirmed_at'), // When payment confirmed
    started_at: timestamp('started_at'), // When rental period began
    delivered_at: timestamp('delivered_at'), // When item was delivered
    returned_at: timestamp('returned_at'), // When item was returned
    completed_at: timestamp('completed_at'), // When rental was marked complete
    cancelled_at: timestamp('cancelled_at'), // If cancelled

    // === CANCELLATION & DISPUTE HANDLING ===
    cancellation_reason: text('cancellation_reason'),
    cancelled_by: uuid('cancelled_by').references(() => users.uid), // Who initiated cancellation
    refund_amount: integer('refund_amount'), // Refund amount in cents
    refund_processed_at: timestamp('refund_processed_at'),

    dispute_reason: text('dispute_reason'),
    dispute_filed_by: uuid('dispute_filed_by').references(() => users.uid),
    dispute_filed_at: timestamp('dispute_filed_at'),
    dispute_resolution: text('dispute_resolution'),
    dispute_resolved_at: timestamp('dispute_resolved_at'),
    dispute_resolved_by: uuid('dispute_resolved_by').references(() => users.uid), // Admin who resolved

    // === QUALITY & FEEDBACK ===
    condition_on_delivery: text('condition_on_delivery'), // Condition when delivered
    condition_on_return: text('condition_on_return'), // Condition when returned
    damage_reported: boolean('damage_reported').notNull().default(false),
    damage_description: text('damage_description'),
    damage_photos: jsonb('damage_photos').$type<string[]>().default([]),

    // Ratings (populated after completion)
    borrower_rating: integer('borrower_rating'), // 1-5 rating of borrower
    lender_rating: integer('lender_rating'), // 1-5 rating of lender
    borrower_review: text('borrower_review'),
    lender_review: text('lender_review'),

    // === METADATA ===
    created_at: timestamp('created_at').notNull().defaultNow(),
    updated_at: timestamp('updated_at').notNull().defaultNow(),

    // System flags
    is_flagged: boolean('is_flagged').notNull().default(false),
    flag_reason: text('flag_reason'),

}, (table) => ({
    // === PERFORMANCE INDEXES ===

    // Primary lookup indexes
    conversationIdx: index('rentals_conversation_idx').on(table.conversation_id),
    costumeIdx: index('rentals_costume_idx').on(table.costume_id),
    borrowerIdx: index('rentals_borrower_idx').on(table.borrower_user_id),
    lenderIdx: index('rentals_lender_idx').on(table.lender_user_id),
    originalRequestIdx: index('rentals_original_request_idx').on(table.original_request_id),

    // Status and lifecycle indexes
    statusIdx: index('rentals_status_idx').on(table.status),
    dateRangeIdx: index('rentals_date_range_idx').on(table.start_date, table.end_date),
    createdAtIdx: index('rentals_created_at_idx').on(table.created_at),

    // Payment indexes
    paymentIdx: index('rentals_payment_history_idx').on(table.payment_history_id),
    paymentIntentIdx: index('rentals_payment_intent_idx').on(table.payment_intent_id),

    // Composite indexes for common queries
    borrowerStatusIdx: index('rentals_borrower_status_idx').on(table.borrower_user_id, table.status),
    lenderStatusIdx: index('rentals_lender_status_idx').on(table.lender_user_id, table.status),
    statusDateIdx: index('rentals_status_date_idx').on(table.status, table.start_date),

    // Business intelligence indexes
    completedDateIdx: index('rentals_completed_date_idx').on(table.completed_at),
    cancelledDateIdx: index('rentals_cancelled_date_idx').on(table.cancelled_at),
    disputeIdx: index('rentals_dispute_idx').on(table.dispute_filed_at),
    flaggedIdx: index('rentals_flagged_idx').on(table.is_flagged),
}));

// =============================================================================
// TYPE EXPORTS
// =============================================================================

export type Rental = InferSelectModel<typeof rentals>;
export type NewRental = InferInsertModel<typeof rentals>;
export type RentalStatus = typeof rentalStatusEnum.enumValues[number];
export type DeliveryMethod = typeof deliveryMethodEnum.enumValues[number];

// =============================================================================
// HELPER TYPES
// =============================================================================

export interface RentalWithDetails extends Rental {
    costume?: {
        id: string;
        name: string;
        images: string[];
        is_available: boolean;
    };
    borrower?: {
        uid: string;
        username: string;
        profile_image?: string;
    };
    lender?: {
        uid: string;
        username: string;
        profile_image?: string;
    };
    payment?: {
        id: string;
        status: string;
        amount: number;
    };
}

export interface CreateRentalInput {
    original_request_id?: string;
    conversation_id: string;
    costume_id: string;
    borrower_user_id: string;
    lender_user_id: string;
    start_date: Date;
    end_date: Date;
    total_days: number;
    costume_snapshot: Rental['costume_snapshot'];
    borrower_snapshot: Rental['borrower_snapshot'];
    selected_items: Rental['selected_items'];
    daily_rate: number;
    add_ons_total: number;
    subtotal: number;
    service_fee: number;
    total_amount: number;
    payment_history_id: string;
    payment_intent_id: string;
    payment_method?: string;
    delivery_method?: DeliveryMethod;
    delivery_address?: string;
    borrower_notes?: string;
    lender_response?: string;
    special_instructions?: string;
}

export interface RentalStatusUpdate {
    status: RentalStatus;
    notes?: string;
    timestamp?: Date;
}

// =============================================================================
// BUSINESS LOGIC HELPERS
// =============================================================================

// Define valid transitions for each status
type StatusTransitions = {
    [K in RentalStatus]: readonly RentalStatus[];
};

export const RENTAL_STATUS_FLOW: StatusTransitions = {
    pending_deposit: ['pending_approval', 'cancelled'] as const, // After deposit paid, waiting for approval
    pending_approval: ['confirmed', 'cancelled'] as const, // After approval, becomes confirmed
    confirmed: ['active', 'cancelled'] as const, // When rental period starts
    active: ['completed', 'overdue'] as const, // During rental period
    completed: ['deposit_refunded'] as const, // After return and inspection
    deposit_refunded: [], // Terminal state
    cancelled: [], // Terminal state
    disputed: ['completed', 'cancelled'] as const, // If issues arise
    overdue: ['completed', 'disputed', 'cancelled'] as const // If not returned on time
} as const;

export const isValidStatusTransition = (
    currentStatus: RentalStatus,
    newStatus: RentalStatus
): boolean => {
    const validTransitions = RENTAL_STATUS_FLOW[currentStatus];
    return validTransitions.includes(newStatus as RentalStatus);
};