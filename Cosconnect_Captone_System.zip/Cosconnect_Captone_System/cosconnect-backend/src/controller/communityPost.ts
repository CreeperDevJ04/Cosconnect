import { HeartCommunityPostSchema } from "@/lib/zodSchema/communityPostSchema";
import { CommentDocument, CommentPayload, HeartData, HeartPostResponse } from "@/types/communityPostType";
import { FieldValue, Timestamp } from 'firebase-admin/firestore';
import type { Context } from 'hono';
import { z } from "zod";
import { db } from "../db/firebase/firebaseAdmin";



const heartCommunityPost = async (c: Context): Promise<Response> => {
    try {
        // Parse and validate request body
        const body = await c.req.json();
        const validatedData = HeartCommunityPostSchema.parse(body);

        const { action, borrower, postId, postAuthor } = validatedData;
        const { uid: userId, name: userName, email: userEmail, avatarUrl } = borrower;

        // Start a Firestore transaction for data consistency
        const result = await db.runTransaction(async (transaction) => {
            // 1. Check if the post exists
            const postRef = db.collection('marketPlacePost').doc(postId);
            const postDoc = await transaction.get(postRef);

            if (!postDoc.exists) {
                throw new Error('Post not found');
            }

            // 2. Check if user has already hearted this post
            const heartRef = db.collection('postHearts').doc(`${postId}_${userId}`);
            const existingHeart = await transaction.get(heartRef);

            if (action === "liked") {
                if (existingHeart.exists) {
                    return {
                        success: false,
                        message: "You have already liked this post",
                        alreadyLiked: true
                    };
                }

                // Create new heart record
                const heartData: HeartData = {
                    userId,
                    userName,
                    userEmail,
                    userAvatarUrl: avatarUrl,
                    postId,
                    postAuthor,
                    createdAt: Timestamp.now(),
                    updatedAt: Timestamp.now()
                };

                // Add heart to postHearts collection
                transaction.set(heartRef, heartData);

                // Increment heart count in the post
                transaction.update(postRef, {
                    heartCount: FieldValue.increment(1),
                    updatedAt: Timestamp.now()
                });

                return {
                    success: true,
                    message: "Post liked successfully",
                    heartId: heartRef.id,
                    action: "added"
                };

            } else if (action === "unliked") {
                if (!existingHeart.exists) {
                    return {
                        success: false,
                        message: "You haven't liked this post yet",
                        notLiked: true
                    };
                }

                // Remove heart record
                transaction.delete(heartRef);

                // Decrement heart count in the post (ensure it doesn't go below 0)
                const currentPost = postDoc.data();
                const currentHeartCount = currentPost?.heartCount || 0;

                transaction.update(postRef, {
                    heartCount: Math.max(0, currentHeartCount - 1),
                    updatedAt: Timestamp.now()
                });

                return {
                    success: true,
                    message: "Post unliked successfully",
                    action: "removed"
                };
            }

            throw new Error("Invalid action");
        });

        // Handle transaction results
        if (!result.success) {
            return c.json({
                success: false,
                message: result.message
            }, result.alreadyLiked || result.notLiked ? 400 : 500);
        }

        // Get updated heart count and user status
        const updatedPostDoc = await db.collection('marketPlacePost').doc(postId).get();
        const updatedPost = updatedPostDoc.data();
        const totalHearts = updatedPost?.heartCount || 0;

        // Check if current user has liked the post
        const userHeartDoc = await db.collection('postHearts').doc(`${postId}_${userId}`).get();
        const userHasLiked = userHeartDoc.exists;

        const response: HeartPostResponse = {
            success: true,
            message: result.message,
            data: {
                totalHearts,
                userHasLiked,
                heartId: result.heartId
            }
        };

        return c.json(response, 200);

    } catch (error) {
        console.error('Error in heartCommunityPost:', error);

        // Handle Zod validation errors
        if (error instanceof z.ZodError) {
            return c.json({
                success: false,
                message: "Validation failed",
                error: error.errors.map(e => `${e.path.join('.')}: ${e.message}`).join(', ')
            }, 400);
        }

        // Handle custom errors
        if (error instanceof Error) {
            return c.json({
                success: false,
                message: error.message
            }, 400);
        }

        // Handle unexpected errors
        return c.json({
            success: false,
            message: "Internal server error",
            error: "An unexpected error occurred"
        }, 500);
    }
};



const commentOnCommunityPost = async (c: Context): Promise<Response> => {
    try {
        const body = await c.req.json() as CommentPayload;
        console.log("body", body);

        // Validate required fields
        if (!body.postId || !body.comment?.content || !body.commenter?.userId) {
            return c.json({
                success: false,
                error: "Missing required fields: postId, comment content, or commenter userId"
            }, 400);
        }

        // Verify the post exists
        const postRef = db.collection('marketPlacePost').doc(body.postId);
        const postDoc = await postRef.get();

        if (!postDoc.exists) {
            return c.json({
                success: false,
                error: "Post not found"
            }, 404);
        }

        // Create comment document
        const commentRef = db.collection('comments').doc();
        const now = Timestamp.now();

        const commentData: CommentDocument = {
            id: commentRef.id,
            postId: body.postId,
            postAuthorId: body.postAuthorId,
            commenter: body.commenter,
            content: body.comment.content,
            images: body.comment.images || [],
            createdAt: now,
            updatedAt: now,
            isDeleted: false,
            likesCount: 0,
            repliesCount: 0
        };

        // Add the comment
        await commentRef.set(commentData);

        return c.json({
            success: true,
            data: {
                commentId: commentRef.id,
                message: "Comment added successfully",
                comment: commentData
            }
        }, 201);

    } catch (error) {
        console.error('Error adding comment:', error);

        return c.json({
            success: false,
            error: "Internal server error while adding comment"
        }, 500);
    }
};

const getAllCommentOnTheCommunityPost = async (c: Context): Promise<Response> => {
    try {
        const postId = c.req.query('postId');
        console.log("first,", postId)
        if (!postId) {
            return c.json({
                success: false,
                message: "Post ID is required"
            }, 400);
        }

        // Get all comments for the post
        const commentsSnapshot = await db.collection('comments')
            .where('postId', '==', postId)
            .where('isDeleted', '==', false)
            .orderBy('createdAt', 'desc')
            .get();

        // Transform comments data
        const comments = commentsSnapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));

        return c.json({
            success: true,
            data: {
                comments,
                totalComments: comments.length
            }
        }, 200);

    } catch (error) {
        console.error('Error fetching comments:', error);

        if (error instanceof Error) {
            return c.json({
                success: false,
                message: error.message
            }, 500);
        }

        return c.json({
            success: false,
            message: "Internal server error while fetching comments"
        }, 500);
    }
};

interface User {
    id: string
    name: string
    avatar: string
    role: 'lender' | 'borrower' | string
}


const getCommunityPostDataById = async (c: Context): Promise<Response> => {
    try {
        const postId = c.req.param('postId');
        const userId = c.req.query('userId');

        if (!postId) {
            return c.json({
                success: false,
                message: "Post ID is required"
            }, 400);
        }

        if (!userId) {
            return c.json({
                success: false,
                message: "User ID is required"
            }, 400);
        }

        // Get post data
        const postRef = db.collection('marketPlacePost').doc(postId);
        const postDoc = await postRef.get();

        if (!postDoc.exists) {
            return c.json({
                success: false,
                message: "Post not found"
            }, 404);
        }

        const postData = postDoc.data();

        // Check if the current user has liked the post
        const heartRef = db.collection('postHearts').doc(`${postId}_${userId}`);
        const heartDoc = await heartRef.get();
        const isLiked = heartDoc.exists;

        // Transform the data to match the CommunityPost interface
        const formattedPost: any = {
            id: postDoc.id,
            author: postData?.author,
            content: postData?.content || '',
            images: postData?.images || [],
            comments: postData?.commentsCount || 0,
            heartCount: postData?.heartCount || 0,
            isLiked,
            createdAt: postData?.createdAt?.toDate().toISOString() || new Date().toISOString(),
            updatedAt: postData?.updatedAt?.toDate().toISOString() || new Date().toISOString()
        };

        console.log("fpss", formattedPost)

        return c.json({
            success: true,
            data: formattedPost
        }, 200);

    } catch (error) {
        console.error('Error fetching post:', error);

        if (error instanceof Error) {
            return c.json({
                success: false,
                message: error.message
            }, 500);
        }

        return c.json({
            success: false,
            message: "Internal server error while fetching post"
        }, 500);
    }
};

// Updated API function
const checkUserLikedPost = async (c: Context): Promise<Response> => {
    try {
        const { postIds, userId } = await c.req.json();


        if (!postIds || !userId || !Array.isArray(postIds) || postIds.length === 0) {
            return c.json({
                success: false,
                message: "postIds array and userId are required"
            }, 400);
        }

        // Check if posts exist (batch check)
        const postRefs = postIds.map(postId => db.collection('marketPlacePost').doc(postId));
        const postDocs = await db.getAll(...postRefs);

        // Filter out non-existent posts
        const existingPostIds = postDocs
            .filter(doc => doc.exists)
            .map(doc => doc.id);

        if (existingPostIds.length === 0) {
            return c.json({
                success: false,
                message: "No valid posts found"
            }, 404);
        }

        // Check heart status for all existing posts (batch check)
        const heartRefs = existingPostIds.map(postId =>
            db.collection('postHearts').doc(`${postId}_${userId}`)
        );
        const heartDocs = await db.getAll(...heartRefs);

        // Map results
        const results = existingPostIds.map((postId, index) => ({
            postId,
            isLiked: heartDocs[index]?.exists,
            userId
        }));

        return c.json({
            success: true,
            data: results,
            totalChecked: existingPostIds.length,
            totalRequested: postIds.length
        }, 200);

    } catch (error) {
        console.error('Error checking post like status:', error);

        if (error instanceof Error) {
            return c.json({
                success: false,
                message: error.message
            }, 500);
        }

        return c.json({
            success: false,
            message: "Internal server error while checking like status"
        }, 500);
    }
};

export default {
    heartCommunityPost,
    commentOnCommunityPost,
    getAllCommentOnTheCommunityPost,
    getCommunityPostDataById,
    checkUserLikedPost
}