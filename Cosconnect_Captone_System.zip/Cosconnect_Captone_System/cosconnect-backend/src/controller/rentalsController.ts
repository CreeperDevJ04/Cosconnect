// rentalsController.ts
import { randomUUID } from 'crypto';
import { and, asc, count, desc, eq, gte, ilike, inArray, lte, ne, or, sql } from 'drizzle-orm';
import type { Context } from 'hono';

import { costumes } from '@/schema/costumes';
import { rentalRejections, rentals, rentalStatusEnum } from '@/schema/rentals';
import { rentalPaymentHistory } from '@/schema/rentals_payment_history';
import { user_business_info, users } from '@/schema/users';
import db from '../db/supabase/db_connect';

import axios from 'axios';
import { notifyOrderStatusChange, sendOrderUpdateEmail } from '../services/emailServices';
import { notificationService, notificationTemplates } from './notificationController';

const sendReturnProof = async (c: Context): Promise<Response> => {
    try {
        const { rental_id, message, image_urls, video_url } = await c.req.json();
        console.log("sssssw2")

        // Validate required fields
        if (!rental_id || !message || !Array.isArray(image_urls)) {
            return c.json({ error: "Missing required fields" }, 400);
        }

        // 1. Find rental by rental_id
        const rental = await db
            .select()
            .from(rentals)
            .where(eq(rentals.id, rental_id))
            .limit(1);

        if (rental.length === 0) {
            return c.json({ error: "Rental not found" }, 404);
        }

        // 2. Build return_proof object (NO submitted_by)
        const returnProof = {
            message,
            image_urls,
            video_url: video_url || null,
            submitted_at: new Date().toISOString(),
        };

        // 3. Update rental with return_proof
        await db
            .update(rentals)
            .set({ return_proof: returnProof })
            .where(eq(rentals.id, rental_id));

        // Send email notification to lender that borrower has submitted return proof
        try {
            // Fetch related data
            const [costumeData] = await db.select().from(costumes).where(eq(costumes.id, rental[0]!.costume_id)).limit(1);
            if (costumeData) {
                const [renterUser] = await db.select().from(users).where(eq(users.uid, rental[0]!.renter_uid)).limit(1);
                const [lenderUser] = await db.select().from(users).where(eq(users.uid, costumeData.lender_uid)).limit(1);

                if (renterUser && lenderUser) {
                    const orderData = {
                        id: rental_id,
                        type: 'rent',
                        status: 'returned',
                        item: { name: costumeData.name },
                        borrower: {
                            email: renterUser.email,
                            name: renterUser.full_name || renterUser.username
                        },
                        lender: {
                            email: lenderUser.email,
                            name: lenderUser.full_name || lenderUser.username
                        }
                    };

                    await sendOrderUpdateEmail({
                        recipientEmail: lenderUser.email,
                        recipientName: lenderUser.full_name || lenderUser.username,
                        orderId: rental_id,
                        itemName: costumeData.name,
                        updateType: 'return_initiated',
                        message: `${(renterUser.full_name || renterUser.username)} has submitted return proof for costume ${costumeData.name}. Please review the photos/videos and coordinate the physical return.`,
                        actionRequired: true,
                    });
                    console.log('Email notification sent to lender for return proof submission:', rental_id);

                    // Create in-app notification for lender
                    await notificationService.create({
                        recipientId: costumeData.lender_uid,
                        recipientRole: 'lender',
                        senderId: renterUser.uid,
                        senderRole: 'borrower',
                        senderType: 'user',
                        type: 'RENTAL_UPDATED',
                        title: 'Return Proof Submitted',
                        message: `${renterUser.full_name || renterUser.username} submitted return proof for ${costumeData.name}.`,
                        rentalId: rental_id,
                        costumeId: costumeData.id,
                    });
                }
            }
        } catch (emailError) {
            console.error('Error sending return proof email notification:', emailError);
        }

        return c.json({
            success: true,
            message: "Return proof stored successfully",
            return_proof: returnProof
        });

    } catch (error) {
        console.error("Error submitting return proof:", error);
        return c.json({ error: "Internal server error" }, 500);
    }
};


/**
 * Get all payment transactions with rental details
 * 
 * Route: GET /api/rentals/transactions
 * 
 * Query parameters (all optional):
 * - page: number (default: 1)
 * - limit: number (default: 20, max: 100)
 * - status: filter by payment status (paid, pending, etc.)
 * - paymentType: filter by payment type (rental_fee, security_deposit, etc.)
 * - paymentMethod: filter by payment method (gcash, paymaya, card)
 * - search: search by reference code or payment reference
 * - dateFrom: filter from date (ISO string)
 * - dateTo: filter to date (ISO string)
 * - sortOrder: 'asc' | 'desc' (default: 'desc')
 * 
 * If NO filters are provided, it returns ALL transactions
 */
const getTransactionsRentals = async (c: Context) => {
    try {
        // Parse query parameters
        const page = Math.max(1, parseInt(c.req.query('page') || '1'));
        const limit = Math.min(100, Math.max(1, parseInt(c.req.query('limit') || '20')));
        const status = c.req.query('status');
        const paymentType = c.req.query('paymentType');
        const paymentMethod = c.req.query('paymentMethod');
        const search = c.req.query('search');
        const dateFrom = c.req.query('dateFrom');
        const dateTo = c.req.query('dateTo');
        const sortOrder = c.req.query('sortOrder') === 'asc' ? 'asc' : 'desc';

        const offset = (page - 1) * limit;

        console.log('🔍 Query params:', {
            page, limit, status, paymentType, paymentMethod, search, dateFrom, dateTo, sortOrder
        });

        // Build where conditions (only add if filter is provided)
        const conditions = [];

        if (status) {
            conditions.push(eq(rentalPaymentHistory.status, status as any));
        }

        if (paymentType) {
            conditions.push(eq(rentalPaymentHistory.payment_type, paymentType as any));
        }

        if (paymentMethod) {
            conditions.push(eq(rentalPaymentHistory.payment_method, paymentMethod as any));
        }

        if (search) {
            conditions.push(
                or(
                    ilike(rentalPaymentHistory.reference_code, `%${search}%`),
                    ilike(rentalPaymentHistory.payment_reference, `%${search}%`)
                )
            );
        }

        if (dateFrom) {
            conditions.push(gte(rentalPaymentHistory.created_at, new Date(dateFrom)));
        }

        if (dateTo) {
            conditions.push(lte(rentalPaymentHistory.created_at, new Date(dateTo)));
        }

        // Only apply where clause if there are conditions
        const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

        console.log('📋 Applied filters:', conditions.length, 'conditions');

        // Get total count for pagination
        const [totalResult] = await db
            .select({ count: count() })
            .from(rentalPaymentHistory)
            .where(whereClause);

        const totalTransactions = totalResult?.count || 0;

        console.log('📊 Total transactions found:', totalTransactions);

        // If no transactions found, return early with helpful message
        if (totalTransactions === 0) {
            return c.json({
                success: true,
                data: {
                    transactions: [],
                    pagination: {
                        page,
                        limit,
                        total: 0,
                        totalPages: 0,
                        hasNext: false,
                        hasPrev: false,
                    },
                    filters: {
                        status: status || null,
                        paymentType: paymentType || null,
                        paymentMethod: paymentMethod || null,
                        search: search || null,
                        dateFrom: dateFrom || null,
                        dateTo: dateTo || null,
                        sortOrder,
                    },
                    message: conditions.length > 0
                        ? 'No transactions found matching the filters. Try removing some filters.'
                        : 'No payment transactions in the database yet.'
                },
                timestamp: new Date().toISOString(),
            });
        }

        // Fetch payment history with rental details
        const paymentsData = await db
            .select()
            .from(rentalPaymentHistory)
            .leftJoin(rentals, eq(rentalPaymentHistory.rental_id, rentals.id))
            .where(whereClause)
            .orderBy(
                sortOrder === 'asc'
                    ? asc(rentalPaymentHistory.created_at)
                    : desc(rentalPaymentHistory.created_at)
            )
            .limit(limit)
            .offset(offset);

        console.log('✅ Fetched payments:', paymentsData.length);

        // Transform to clean structure for frontend table
        const transactions = paymentsData.map((row) => {
            const payment = row.rental_payment_history;
            const rental = row.rentals;

            return {
                // Payment Core Info
                id: payment.id,
                referenceCode: payment.reference_code,
                rentalId: payment.rental_id,

                // Payment Details
                paymentType: payment.payment_type,
                paymentMethod: payment.payment_method,
                paymentReference: payment.payment_reference,
                description: payment.description,

                // Amount & Currency
                amount: payment.amount,
                currency: payment.currency,

                // Status (THIS IS WHAT YOU NEED!)
                status: payment.status, // pending, paid, processing, failed, etc.
                gatewayStatus: payment.gateway_status,
                gatewayStatusUpdatedAt: payment.gateway_status_updated_at,

                // Processing Info
                processedAt: payment.processed_at,
                processorNotes: payment.processor_notes,

                // Receipt
                receiptUrl: payment.receipt_url,
                receiptNumber: payment.receipt_number,

                // PayMongo Integration
                paymongo: {
                    paymentIntentId: payment.paymongo_payment_intent_id,
                    sourceId: payment.paymongo_source_id,
                    sessionId: payment.session_id,
                    checkoutUrl: payment.checkout_url,
                    sessionExpiresAt: payment.session_expires_at,
                },

                // Metadata
                metadata: payment.metadata || {},

                // Timestamps
                createdAt: payment.created_at,
                updatedAt: payment.updated_at,

                // Rental Info (nested)
                rental: rental ? {
                    id: rental.id,
                    referenceCode: rental.reference_code,
                    status: rental.status,

                    // Dates
                    startDate: rental.start_date,
                    endDate: rental.end_date,
                    actualReturnDate: rental.actual_return_date,

                    // Amounts
                    rentalAmount: rental.rental_amount,
                    securityDeposit: rental.security_deposit,
                    totalAmount: rental.total_amount,
                    extensionFee: rental.extension_fee,
                    damageCost: rental.damage_cost,

                    // Costume Info from snapshot
                    costumeName: rental.costume_snapshot ? (rental.costume_snapshot as any).name : null,
                    costumeBrand: rental.costume_snapshot ? (rental.costume_snapshot as any).brand : null,
                    costumeCategory: rental.costume_snapshot ? (rental.costume_snapshot as any).category : null,

                    // Renter Info from snapshot
                    renterName: rental.renter_snapshot ? (rental.renter_snapshot as any).name : null,
                    renterEmail: rental.renter_snapshot ? (rental.renter_snapshot as any).email : null,
                    renterPhone: rental.renter_snapshot ? (rental.renter_snapshot as any).phone : null,

                    // Lender Info from costume snapshot
                    lenderName: rental.costume_snapshot
                        ? (rental.costume_snapshot as any).lender_info?.name
                        : null,
                    lenderPhone: rental.costume_snapshot
                        ? (rental.costume_snapshot as any).lender_info?.phone
                        : null,
                } : null,
            };
        });

        return c.json({
            success: true,
            data: {
                transactions,
                pagination: {
                    page,
                    limit,
                    total: totalTransactions,
                    totalPages: Math.ceil(totalTransactions / limit),
                    hasNext: offset + limit < totalTransactions,
                    hasPrev: page > 1,
                },
                filters: {
                    status: status || null,
                    paymentType: paymentType || null,
                    paymentMethod: paymentMethod || null,
                    search: search || null,
                    dateFrom: dateFrom || null,
                    dateTo: dateTo || null,
                    sortOrder,
                },
            },
            timestamp: new Date().toISOString(),
        });

    } catch (error) {
        console.error('❌ Error fetching transactions:', error);
        return c.json({
            success: false,
            error: 'Failed to fetch payment transactions',
            message: error instanceof Error ? error.message : 'Unknown error',
            details: process.env.NODE_ENV === 'development' ? error : undefined,
        }, 500);
    }
};


/**
 * Get all booked date ranges for a specific costume
 * @param c Context object containing the request
 * @returns Array of date ranges when the costume is already booked
 */
const getBookedDateRanges = async (c: Context): Promise<any> => {
    try {
        const { costume_id } = c.req.param();

        if (!costume_id) {
            return c.json({
                success: false,
                message: 'Costume ID is required',
                data: null,
            }, 400);
        }

        // Get all active bookings for this costume (only confirmed, accepted, and delivered rentals)
        const bookedRentals = await db
            .select({
                start_date: rentals.start_date,
                end_date: rentals.end_date,
                status: rentals.status,
                reference_code: rentals.reference_code
            })
            .from(rentals)
            .where(
                and(
                    eq(rentals.costume_id, costume_id),
                    or(
                        eq(rentals.status, 'confirmed'),
                        eq(rentals.status, 'accepted'),
                        eq(rentals.status, 'delivered')
                    )
                )
            )
            .orderBy(asc(rentals.start_date));

        // Format the date ranges for calendar display
        const bookedDateRanges = bookedRentals.map(rental => ({
            start_date: rental.start_date.toISOString().split('T')[0], // Format as YYYY-MM-DD
            end_date: rental.end_date.toISOString().split('T')[0],     // Format as YYYY-MM-DD
            status: rental.status,
            reference_code: rental.reference_code
        }));

        return c.json({
            success: true,
            message: 'Booked date ranges retrieved successfully',
            data: {
                costume_id,
                booked_date_ranges: bookedDateRanges,
                total_bookings: bookedDateRanges.length
            }
        }, 200);

    } catch (error: any) {
        console.error('Error fetching booked date ranges:', error);
        return c.json({
            success: false,
            message: 'Failed to fetch booked date ranges',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined,
            data: null
        }, 500);
    }
};


// PayMongo configuration
const PAYMONGO_API_URL = 'https://api.paymongo.com/v1';
const PAYMONGO_SECRET_KEY = process.env.PAYMONGO_SECRET_KEY;

if (!PAYMONGO_SECRET_KEY) {
    throw new Error('PAYMONGO_SECRET_KEY environment variable is required');
}

// Helper function to get authorization header
const getAuthHeader = (): string => {
    return `Basic ${Buffer.from(PAYMONGO_SECRET_KEY + ':').toString('base64')}`;
};

// emailTemplates.ts
export const rentalRequestEmailTemplates = {
    // Email template for LENDER
    lender: (data: {
        lenderName: string;
        renterName: string;
        costumeName: string;
        costumeBrand: string;
        startDate: string;
        endDate: string;
        totalDays: number;
        rentalAmount: string;
        securityDeposit: string;
        totalAmount: string;
        deliveryMethod: string;
        deliveryAddress: string;
        renterEmail: string;
        renterPhone: string;
        referenceCode: string;
    }) => ({
        subject: `New Rental Request - ${data.costumeName}`,
        html: `
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
        .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
        .info-box { background: white; padding: 20px; margin: 15px 0; border-radius: 8px; border-left: 4px solid #667eea; }
        .info-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #eee; }
        .info-label { font-weight: bold; color: #667eea; }
        .button { background: #667eea; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 20px 0; }
        .footer { text-align: center; color: #666; margin-top: 20px; font-size: 12px; }
        .highlight { background: #fff3cd; padding: 15px; border-radius: 5px; margin: 15px 0; border-left: 4px solid #ffc107; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎭 New Rental Request</h1>
            <p>You have received a new rental request!</p>
        </div>
        <div class="content">
            <p>Hello ${data.lenderName},</p>
            <p>Great news! <strong>${data.renterName}</strong> has requested to rent your costume.</p>
            
            <div class="info-box">
                <h3>📦 Costume Details</h3>
                <div class="info-row">
                    <span class="info-label">Costume:</span>
                    <span>${data.costumeName}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Brand:</span>
                    <span>${data.costumeBrand}</span>
                </div>
            </div>

            <div class="info-box">
                <h3>📅 Rental Period</h3>
                <div class="info-row">
                    <span class="info-label">Start Date:</span>
                    <span>${data.startDate}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">End Date:</span>
                    <span>${data.endDate}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Total Days:</span>
                    <span>${data.totalDays} days</span>
                </div>
            </div>

            <div class="info-box">
                <h3>💰 Payment Details</h3>
                <div class="info-row">
                    <span class="info-label">Rental Amount:</span>
                    <span>PHP ${data.rentalAmount}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Security Deposit:</span>
                    <span>PHP ${data.securityDeposit}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Processing Fee (3%):</span>
                    <span>PHP ${(Number(data.totalAmount) - Number(data.securityDeposit) - Number(data.rentalAmount)).toFixed(2)}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Total Amount:</span>
                    <span><strong>PHP ${data.totalAmount}</strong></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Reference Code:</span>
                    <span><strong>${data.referenceCode}</strong></span>
                </div>
            </div>

            <div class="info-box">
                <h3>🚚 Delivery Information</h3>
                <div class="info-row">
                    <span class="info-label">Method:</span>
                    <span>${data.deliveryMethod === 'delivery' ? '📦 Delivery' : '🏪 Pickup'}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Address:</span>
                    <span>${data.deliveryAddress}</span>
                </div>
            </div>

            <div class="info-box">
                <h3>👤 Renter Information</h3>
                <div class="info-row">
                    <span class="info-label">Name:</span>
                    <span>${data.renterName}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Email:</span>
                    <span>${data.renterEmail}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Phone:</span>
                    <span>${data.renterPhone}</span>
                </div>
            </div>

            <div class="highlight">
                <strong>⚠️ Action Required:</strong> Please review this rental request and respond within 24 hours. The customer has initiated payment and is waiting for your confirmation.
            </div>

            <center>
                <a href="https://cosconnect.online/my-rentals" class="button">
                    Review Rental Request
                </a>
            </center>
        </div>
        <div class="footer">
            <p>This is an automated email from CosConnect. Please do not reply directly to this email.</p>
            <p>&copy; 2025 CosConnect. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
        `,
        text: `New Rental Request - ${data.costumeName}

Hello ${data.lenderName},

You have received a new rental request from ${data.renterName}.

Costume: ${data.costumeName} (${data.costumeBrand})
Rental Period: ${data.startDate} to ${data.endDate} (${data.totalDays} days)
Total Amount: PHP ${data.totalAmount}
Reference Code: ${data.referenceCode}

Delivery Method: ${data.deliveryMethod}
Address: ${data.deliveryAddress}

Renter Contact:
- Email: ${data.renterEmail}
- Phone: ${data.renterPhone}

Please review and respond to this request within 24 hours.

Visit: http://localhost:3000rentals`
    }),

    // Email template for BORROWER/RENTER
    borrower: (data: {
        renterName: string;
        lenderName: string;
        costumeName: string;
        costumeBrand: string;
        startDate: string;
        endDate: string;
        totalDays: number;
        rentalAmount: string;
        securityDeposit: string;
        totalAmount: string;
        deliveryMethod: string;
        deliveryAddress: string;
        checkoutUrl: string;
        referenceCode: string;
        expiresAt: string;
    }) => ({
        subject: `Rental Request Confirmed - ${data.costumeName}`,
        html: `
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
        .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
        .info-box { background: white; padding: 20px; margin: 15px 0; border-radius: 8px; border-left: 4px solid #667eea; }
        .info-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #eee; }
        .info-label { font-weight: bold; color: #667eea; }
        .button { background: #28a745; color: white; padding: 15px 40px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 20px 0; font-size: 16px; font-weight: bold; }
        .footer { text-align: center; color: #666; margin-top: 20px; font-size: 12px; }
        .success-box { background: #d4edda; padding: 20px; border-radius: 5px; margin: 15px 0; border-left: 4px solid #28a745; }
        .warning-box { background: #fff3cd; padding: 15px; border-radius: 5px; margin: 15px 0; border-left: 4px solid #ffc107; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>✅ Rental Request Submitted!</h1>
            <p>Your rental request has been created successfully</p>
        </div>
        <div class="content">
            <p>Hello ${data.renterName},</p>
            
            <div class="success-box">
                <strong>🎉 Great News!</strong> Your rental request for <strong>${data.costumeName}</strong> has been submitted successfully.
            </div>

            <div class="info-box">
                <h3>📦 Costume Details</h3>
                <div class="info-row">
                    <span class="info-label">Costume:</span>
                    <span>${data.costumeName}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Brand:</span>
                    <span>${data.costumeBrand}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Owner:</span>
                    <span>${data.lenderName}</span>
                </div>
            </div>

            <div class="info-box">
                <h3>📅 Rental Period</h3>
                <div class="info-row">
                    <span class="info-label">Start Date:</span>
                    <span>${data.startDate}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">End Date:</span>
                    <span>${data.endDate}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Total Days:</span>
                    <span>${data.totalDays} days</span>
                </div>
            </div>

            <div class="info-box">
                <h3>💰 Payment Summary</h3>
                <div class="info-row">
                    <span class="info-label">Rental Amount (${data.totalDays} day${data.totalDays !== 1 ? 's' : ''}):</span>
                    <span>PHP ${data.rentalAmount}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Security Deposit:</span>
                    <span>PHP ${data.securityDeposit}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Processing Fee (3%):</span>
                    <span>PHP ${(Number(data.totalAmount) - Number(data.securityDeposit) - Number(data.rentalAmount)).toFixed(2)}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Total Amount:</span>
                    <span><strong>PHP ${data.totalAmount}</strong></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Reference Code:</span>
                    <span><strong>${data.referenceCode}</strong></span>
                </div>
            </div>

            <div class="info-box">
                <h3>🚚 Delivery Information</h3>
                <div class="info-row">
                    <span class="info-label">Method:</span>
                    <span>${data.deliveryMethod === 'delivery' ? '📦 Delivery' : '🏪 Pickup'}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Address:</span>
                    <span>${data.deliveryAddress}</span>
                </div>
            </div>

            <div class="warning-box">
                <strong>⏰ Complete Payment Before:</strong> ${data.expiresAt}<br>
                Your payment session will expire after this time. Please complete the payment as soon as possible.
            </div>

            <div class="info-box">
                <h3>📋 Next Steps</h3>
                <ol>
                    <li>Click the button above to complete your payment via GCash</li>
                    <li>Wait for the costume owner to confirm your rental request</li>
                    <li>You'll receive a confirmation email once approved</li>
                    <li>Prepare for costume pickup or delivery on the scheduled date</li>
                </ol>
            </div>
        </div>
        <div class="footer">
            <p>Need help? Contact us at cosconnectme@gmail.com</p>
            <p>&copy; 2025 CosConnect. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
        `,
        text: `Rental Request Confirmed - ${data.costumeName}

Hello ${data.renterName},

Your rental request has been submitted successfully!

Costume: ${data.costumeName} (${data.costumeBrand})
Owner: ${data.lenderName}
Rental Period: ${data.startDate} to ${data.endDate} (${data.totalDays} days)

Payment Summary:
- Rental Amount (${data.totalDays} day${data.totalDays !== 1 ? 's' : ''}): PHP ${data.rentalAmount}
- Security Deposit: PHP ${data.securityDeposit}
- Processing Fee (3%): PHP ${(Number(data.totalAmount) - Number(data.securityDeposit) - Number(data.rentalAmount)).toFixed(2)}
- Total Amount: PHP ${data.totalAmount}

Reference Code: ${data.referenceCode}

Delivery: ${data.deliveryMethod} - ${data.deliveryAddress}

Thank you for using CosConnect!`
    })
};

// emailService.ts
import { notifications } from '@/schema/notifications';
import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER ,
        pass: process.env.EMAIL_PASSWORD || ''
    }
});

/**
 * Send rental request notification emails to both lender and renter
 */
export const sendRentalRequestEmails = async (
    lenderEmail: string,
    renterEmail: string,
    lenderData: any,
    renterData: any
) => {
    try {
        const lenderTemplate = rentalRequestEmailTemplates.lender(lenderData);
        const renterTemplate = rentalRequestEmailTemplates.borrower(renterData);

        // Send email to lender
        await transporter.sendMail({
            from: '"CosConnect" <cosconnectme@gmail.com>',
            to: lenderEmail,
            subject: lenderTemplate.subject,
            html: lenderTemplate.html,
            text: lenderTemplate.text
        });

        // Send email to renter
        await transporter.sendMail({
            from: '"CosConnect" <cosconnectme@gmail.com>',
            to: renterEmail,
            subject: renterTemplate.subject,
            html: renterTemplate.html,
            text: renterTemplate.text
        });

        console.log('✅ Emails sent successfully to lender and renter');
        return { success: true };
    } catch (error) {
        console.error('❌ Error sending emails:', error);
        return { success: false, error };
    }
};


/**
 * Create a new rental request with PayMongo checkout session
 * This function handles the initial rental request submission from customers
 */
const createRentalRequest = async (c: Context) => {
    try {
        console.log('=== Creating Rental Request ===');

        // Parse and validate request body
        let requestData: any;

        try {
            requestData = await c.req.json<any>();
            console.log('Request Data:', requestData);
        } catch (error) {
            return c.json({
                success: false,
                error: 'Invalid JSON in request body'
            }, 400);
        }

        const {
            costume_id,
            personal_details,
            schedule,
            payment_method,
            pricing_breakdown
        } = requestData;

        // Get authenticated user ID
        const renter_uid = personal_details.user_id;
        if (!renter_uid) {
            return c.json({
                success: false,
                error: 'Authentication required'
            }, 401);
        }

        // ====================================================================
        // 💰 VALIDATE AND PROCESS PRICING BREAKDOWN
        // ====================================================================
        if (!pricing_breakdown ||
            typeof pricing_breakdown.days !== 'number' ||
            typeof pricing_breakdown.subtotal !== 'number' ||
            typeof pricing_breakdown.securityDeposit !== 'number') {
            return c.json({
                success: false,
                error: 'Invalid pricing breakdown provided. Required: days, subtotal, securityDeposit'
            }, 400);
        }

        // Extract pricing values
        const totalDays = pricing_breakdown.days;
        const rentalAmount = pricing_breakdown.subtotal;
        const securityDeposit = pricing_breakdown.securityDeposit;

        // Calculate processing fee (3% of subtotal) automatically on backend
        const processingFee = rentalAmount * 0.03;

        // Calculate total (subtotal + security deposit + processing fee)
        const totalAmount = rentalAmount + securityDeposit + processingFee;

        // Validate positive values
        if (totalDays <= 0 || rentalAmount <= 0 || securityDeposit < 0) {
            return c.json({
                success: false,
                error: 'Invalid pricing values. Days and amounts must be positive'
            }, 400);
        }

        console.log('Pricing Breakdown:', {
            days: totalDays,
            rental_amount: rentalAmount,
            security_deposit: securityDeposit,
            processing_fee: processingFee,
            total_amount: totalAmount
        });

        // ====================================================================
        // 💳 EXTRACT PAYMENT METHOD DETAILS
        // ====================================================================
        const paymentType = payment_method.type;
        let paymentNumber: string | null = null;
        let refundNumber: string | null = null;
        let refundAccountName: string | null = null;

        if (paymentType === 'gcash') {
            paymentNumber = payment_method.gcash_number || null;
            refundNumber = payment_method.refund_gcash_number || null;
            refundAccountName = payment_method.refund_account_name || null;
        } else if (paymentType === 'paymaya') {
            paymentNumber = payment_method.paymaya_number || null;
            refundNumber = payment_method.refund_paymaya_number || null;
            refundAccountName = payment_method.refund_account_name || null;
        } else if (paymentType === 'card') {
            paymentNumber = null;
            refundNumber = payment_method.refund_gcash_number || payment_method.refund_paymaya_number || null;
            refundAccountName = payment_method.refund_account_name || null;
        }

        console.log('Payment Details:', {
            paymentType,
            paymentNumber,
            refundNumber,
            refundAccountName
        });

        if (!refundNumber || !refundAccountName) {
            return c.json({
                success: false,
                error: 'Refund account details are required'
            }, 400);
        }

        // ====================================================================
        // 📅 VALIDATE DATE RANGE
        // ====================================================================
        const startDate = new Date(schedule.start_date);
        const endDate = new Date(schedule.end_date);
        const now = new Date();

        if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
            return c.json({
                success: false,
                error: 'Invalid date format provided'
            }, 400);
        }

        if (startDate <= now) {
            return c.json({
                success: false,
                error: 'Start date must be in the future'
            }, 400);
        }

        if (endDate <= startDate) {
            return c.json({
                success: false,
                error: 'End date must be after start date'
            }, 400);
        }

        // ====================================================================
        // 🎭 VALIDATE COSTUME AVAILABILITY
        // ====================================================================
        const [costume] = await db
            .select({
                id: costumes.id,
                name: costumes.name,
                brand: costumes.brand,
                category: costumes.category,
                sizes: costumes.sizes,
                main_images: costumes.main_images,
                lender_uid: costumes.lender_uid,
                status: costumes.status,
                is_available: costumes.is_available,
                listing_type: costumes.listing_type
            })
            .from(costumes)
            .where(eq(costumes.id, costume_id))
            .limit(1);

        if (!costume) {
            return c.json({
                success: false,
                error: 'Costume not found'
            }, 404);
        }

        if (!costume.is_available || costume.status !== 'active') {
            return c.json({
                success: false,
                error: 'Costume is not available for rent'
            }, 400);
        }

        if (costume.listing_type !== 'rent' && costume.listing_type !== 'both') {
            return c.json({
                success: false,
                error: 'This costume is not available for rental'
            }, 400);
        }

        if (costume.lender_uid === renter_uid) {
            return c.json({
                success: false,
                error: 'You cannot rent your own costume'
            }, 400);
        }

        // ====================================================================
        // 👤 FETCH LENDER INFORMATION
        // ====================================================================
        const [lender] = await db
            .select({
                uid: users.uid,
                username: users.username,
                email: users.email,
                phone_number: users.phone_number,
                full_name: users.full_name,
                profile_image: users.profile_image,
                business_name: user_business_info.business_name,
                business_phone: user_business_info.business_phone_number,
                business_email: user_business_info.business_email
            })
            .from(users)
            .leftJoin(user_business_info, eq(users.uid, user_business_info.user_uid))
            .where(eq(users.uid, costume.lender_uid))
            .limit(1);

        if (!lender) {
            return c.json({
                success: false,
                error: 'Costume owner not found'
            }, 404);
        }

        // ====================================================================
        // 🔍 CHECK FOR CONFLICTING RENTALS
        // ====================================================================
        const [conflictingRental] = await db
            .select({ id: rentals.id })
            .from(rentals)
            .where(
                and(
                    eq(rentals.costume_id, costume_id),
                    eq(rentals.status, 'confirmed'),
                    and(
                        lte(rentals.start_date, endDate),
                        gte(rentals.end_date, startDate)
                    )
                )
            )
            .limit(1);

        if (conflictingRental) {
            return c.json({
                success: false,
                error: 'Costume is already booked for the selected dates'
            }, 409);
        }

        // ====================================================================
        // 💾 CREATE RENTAL RECORD
        // ====================================================================
        const paymentReferenceCode = `RENTPAY-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`;
        const dailyRate = rentalAmount / totalDays;

        const rentalInsertData = {
            id: randomUUID(),
            reference_code: paymentReferenceCode,
            costume_id: costume_id,
            renter_uid: renter_uid,
            costume_snapshot: {
                id: costume.id,
                name: costume.name,
                brand: costume.brand,
                category: costume.category,
                sizes: costume.sizes,
                rental_price: dailyRate.toFixed(2),
                security_deposit: securityDeposit.toFixed(2),
                main_images: costume.main_images,
                lender_info: {
                    uid: lender.uid,
                    name: lender.business_name || lender.username,
                    phone: lender.business_phone || lender.phone_number,
                    email: lender.business_email || lender.email,
                    is_business: !!lender.business_name
                }
            },
            renter_snapshot: {
                uid: renter_uid,
                name: `${personal_details.first_name} ${personal_details.last_name}`,
                email: personal_details.email,
                phone: personal_details.phone_number,
                address: schedule.delivery_address
            },
            start_date: startDate,
            end_date: endDate,
            rental_amount: rentalAmount.toFixed(2),
            security_deposit: securityDeposit.toFixed(2),
            total_amount: totalAmount.toFixed(2),
            pickup_location: schedule.delivery_method === 'pickup' ? 'To be determined' : schedule.delivery_address,
            delivery_method: schedule.delivery_method,
            special_instructions: schedule.special_instructions,
            status: 'pending' as const,
            payment_gcash_number: paymentNumber,
            refund_gcash_number: refundNumber,
            refund_account_name: refundAccountName,
            notes: `Payment method: ${paymentType}${paymentNumber ? ` (${paymentNumber})` : ''}. Refund account: ${refundAccountName} (${refundNumber})`
        };

        const [newRental] = await db
            .insert(rentals)
            .values(rentalInsertData)
            .returning();

        if (!newRental) {
            return c.json({
                success: false,
                error: 'Failed to create rental request'
            }, 500);
        }

        console.log('✅ Rental created:', newRental.id);

        // ====================================================================
        // CREATE PAYMONGO CHECKOUT SESSION
        //      Lock checkout to the selected payment method (gcash/paymaya)
        // ====================================================================

        let checkoutSession = null;
        let sessionError = null;
        let sessionExpiresAt: Date;

        try {
            const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:3000';

            // Convert PHP amount to centavos (multiply by 100)
            // Example: 1700 PHP = 170000 centavos
            const amountInCentavos = Math.round(totalAmount * 100);

            console.log('PayMongo Amount Conversion:', {
                totalAmount_PHP: totalAmount,
                amountInCentavos: amountInCentavos,
                calculation: `${totalAmount} * 100 = ${amountInCentavos}`
            });

            // Determine allowed payment method types based on selected paymentType
            const paymentMethodTypes =
                paymentType === 'gcash'
                    ? ['gcash']
                    : paymentType === 'paymaya'
                        ? ['paymaya']
                        : ['gcash', 'paymaya', 'card'];

            const checkoutResponse = await axios.post(
                `${PAYMONGO_API_URL}/checkout_sessions`,
                {
                    data: {
                        attributes: {
                            payment_method_types: paymentMethodTypes,

                            line_items: [{
                                name: `Rental: ${costume.name}`,
                                amount: amountInCentavos,
                                currency: 'PHP',
                                quantity: 1,
                            }],
                            payment_intent_data: {
                                capture_type: 'automatic',
                                description: `Rental payment for ${costume.name}`,
                                metadata: {
                                    rental_id: newRental.id,
                                    costume_id: costume.id,
                                    renter_uid: renter_uid,
                                    lender_uid: costume.lender_uid,
                                    start_date: startDate.toISOString(),
                                    end_date: endDate.toISOString(),
                                    reference_code: paymentReferenceCode,
                                    payment_type: paymentType,
                                    total_days: totalDays.toString(),
                                    rental_amount: rentalAmount.toFixed(2),
                                    security_deposit: securityDeposit.toFixed(2),
                                    total_amount: totalAmount.toFixed(2)
                                }
                            },
                            customer_email: personal_details.email,
                            success_url: `${frontendUrl}/payment/success?reference=${paymentReferenceCode}`,
                            cancel_url: `${frontendUrl}/payment/failed?reference=${paymentReferenceCode}`,
                            reference_number: paymentReferenceCode,
                            send_email_receipt: true,
                            description: `Rental payment for ${costume.name} (${startDate.toDateString()} to ${endDate.toDateString()})`,
                            billing: {
                                name: `${personal_details.first_name} ${personal_details.last_name}`,
                                email: personal_details.email,
                                phone: personal_details.phone_number || '09000000000',
                            }
                        }
                    }
                },
                {
                    headers: {
                        'Authorization': getAuthHeader(),
                        'Content-Type': 'application/json'
                    },
                    timeout: 30000
                }
            );

            checkoutSession = checkoutResponse.data.data;
            const expiresAtString = checkoutSession.attributes.expires_at;
            sessionExpiresAt = expiresAtString && !isNaN(new Date(expiresAtString).getTime())
                ? new Date(expiresAtString)
                : new Date(Date.now() + 24 * 60 * 60 * 1000);

            console.log('✅ PayMongo checkout session created:', checkoutSession.id);
        } catch (error: any) {
            console.error('❌ PayMongo checkout failed:', error.response?.data || error.message);
            sessionError = error.response?.data?.errors?.[0]?.detail || error.message || 'Failed to create payment session';
            sessionExpiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);
        }

        // ====================================================================
        // 💾 CREATE PAYMENT RECORD
        // ====================================================================
        const paymentInsertData = {
            id: randomUUID(),
            rental_id: newRental.id,
            reference_code: paymentReferenceCode,
            payment_type: 'rental_fee' as const,
            description: `Rental payment for ${costume.name}`,
            payment_method: paymentType as 'gcash' | 'paymaya' | 'card',
            payment_reference: paymentNumber || null,
            amount: totalAmount.toFixed(2),
            currency: 'PHP',
            status: 'pending' as const,
            paymongo_payment_intent_id: checkoutSession?.attributes?.payment_intent?.id || null,
            paymongo_source_id: null,
            session_id: checkoutSession?.id || null,
            checkout_url: checkoutSession?.attributes?.checkout_url || null,
            gateway_status: checkoutSession ? 'awaiting_payment_method' : 'pending',
            session_expires_at: sessionExpiresAt,
            metadata: {
                customer_info: {
                    name: `${personal_details.first_name} ${personal_details.last_name}`,
                    email: personal_details.email,
                    phone: personal_details.phone_number
                },
                payment_method_info: {
                    type: paymentType,
                    payment_number: paymentNumber,
                    refund_details: {
                        account_name: refundAccountName,
                        account_number: refundNumber,
                        method: paymentType
                    }
                },
                rental_details: {
                    start_date: startDate.toISOString(),
                    end_date: endDate.toISOString(),
                    total_days: totalDays,
                    delivery_method: schedule.delivery_method
                },
                pricing_breakdown: {
                    days: totalDays,
                    daily_rate: dailyRate.toFixed(2),
                    rental_amount: rentalAmount.toFixed(2),
                    security_deposit: securityDeposit.toFixed(2),
                    total_amount: totalAmount.toFixed(2)
                },
                session_details: checkoutSession ? {
                    created_via: 'rental_request',
                    frontend_url: process.env.FRONTEND_URL || 'http://localhost:3000',
                    redirect_success: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/payment/success`,
                    redirect_failed: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/payment/failed`,
                    session_error: null,
                    expires_at_raw: checkoutSession.attributes.expires_at
                } : {
                    created_via: 'rental_request',
                    session_error: sessionError
                }
            }
        };

        try {
            const [newPayment] = await db
                .insert(rentalPaymentHistory)
                .values(paymentInsertData as any)
                .returning();

            if (!newPayment) {
                console.error('❌ Failed to create payment record');
                return c.json({
                    success: false,
                    error: 'Failed to create payment record'
                }, 500);
            }

            console.log('✅ Payment record created:', newPayment.id);
        } catch (dbError) {
            console.error('❌ Database error:', dbError);
            return c.json({
                success: false,
                error: 'Rental created but payment setup failed',
                details: dbError instanceof Error ? dbError.message : 'Database error',
                rental_info: {
                    rental_id: newRental.id,
                    reference_code: newRental.reference_code,
                    status: 'pending'
                }
            }, 500);
        }

        // ====================================================================
        // 📧 SEND NOTIFICATION EMAILS
        // ====================================================================
        console.log('Sending notification emails...');

        const lenderName = lender.business_name || lender.full_name || lender.username;
        const renterName = `${personal_details.first_name} ${personal_details.last_name}`;
        const lenderEmail = lender.business_email || lender.email;
        const renterEmail = personal_details.email;

        const formatDate = (date: Date) => {
            return date.toLocaleDateString('en-US', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
        };

        const emailLenderData = {
            lenderName,
            renterName,
            costumeName: costume.name,
            costumeBrand: costume.brand || 'N/A',
            startDate: formatDate(startDate),
            endDate: formatDate(endDate),
            totalDays,
            dailyRate: dailyRate.toFixed(2),
            rentalAmount: rentalAmount.toFixed(2),
            securityDeposit: securityDeposit.toFixed(2),
            totalAmount: totalAmount.toFixed(2),
            deliveryMethod: schedule.delivery_method,
            deliveryAddress: schedule.delivery_address || 'N/A',
            renterEmail: personal_details.email,
            renterPhone: personal_details.phone_number || 'N/A',
            referenceCode: paymentReferenceCode,
            specialInstructions: schedule.special_instructions || 'None'
        };

        const emailRenterData = {
            renterName,
            lenderName,
            costumeName: costume.name,
            costumeBrand: costume.brand || 'N/A',
            startDate: formatDate(startDate),
            endDate: formatDate(endDate),
            totalDays,
            dailyRate: dailyRate.toFixed(2),
            rentalAmount: rentalAmount.toFixed(2),
            securityDeposit: securityDeposit.toFixed(2),
            totalAmount: totalAmount.toFixed(2),
            deliveryMethod: schedule.delivery_method,
            deliveryAddress: schedule.delivery_address || 'N/A',
            checkoutUrl: checkoutSession?.attributes?.checkout_url || '#',
            referenceCode: paymentReferenceCode,
            expiresAt: formatDate(sessionExpiresAt),
            paymentMethod: paymentType.toUpperCase(),
            lenderEmail: lenderEmail,
            lenderPhone: lender.business_phone || lender.phone_number || 'N/A'
        };

        // Create in-app notification for lender about the new rental request
        try {
            const template = notificationTemplates.rentalRequest(renterName, costume.name);

            await notificationService.create({
                recipientId: lender.uid,
                recipientRole: 'lender',
                senderId: renter_uid,
                senderRole: 'borrower',
                senderType: 'user',
                type: 'RENTAL_REQUEST',
                title: template.title,
                message: template.message,
                costumeId: costume.id,
                rentalId: newRental.id,
                metadata: {
                    actionUrl: `/lender/rental/list?rentalId=${newRental.id}`,
                    costumeTitle: costume.name,
                    rentalDates: {
                        start: startDate.toISOString(),
                        end: endDate.toISOString()
                    }
                }
            });
        } catch (notificationError) {
            console.error('Error creating rental request notification:', notificationError);
        }

        sendRentalRequestEmails(lenderEmail, renterEmail, emailLenderData, emailRenterData)
            .then(result => {
                if (result.success) {
                    console.log('✅ Notification emails sent');
                } else {
                    console.error('⚠️ Email send failed:', result.error);
                }
            })
            .catch(error => {
                console.error('⚠️ Email error:', error);
            });

        // ====================================================================
        // 📤 RETURN RESPONSE
        // ====================================================================
        const responseData = {
            rental_id: newRental.id,
            reference_code: newRental.reference_code,
            payment_reference: paymentReferenceCode,
            status: newRental.status,
            costume: {
                id: costume.id,
                name: costume.name,
                brand: costume.brand
            },
            schedule: {
                start_date: startDate.toISOString(),
                end_date: endDate.toISOString(),
                total_days: totalDays,
                delivery_method: schedule.delivery_method
            },
            pricing: {
                daily_rate: dailyRate.toFixed(2),
                rental_amount: rentalAmount,
                security_deposit: securityDeposit,
                total_amount: totalAmount,
                currency: 'PHP'
            },
            payment_info: {
                method: paymentType,
                payment_number: paymentNumber,
                refund_account: {
                    name: refundAccountName,
                    number: refundNumber,
                    method: paymentType
                }
            },
            payment: checkoutSession ? {
                session_id: checkoutSession.id,
                checkout_url: checkoutSession.attributes.checkout_url,
                payment_intent_id: checkoutSession.attributes.payment_intent?.id,
                expires_at: sessionExpiresAt.toISOString(),
                instructions: `Complete payment via ${paymentType.toUpperCase()}`
            } : {
                message: 'Payment session could not be created',
                error: sessionError,
                fallback_instructions: 'Contact support for payment instructions'
            },
            next_steps: checkoutSession ? {
                message: 'Rental request created successfully',
                action_required: 'Complete payment using the checkout URL',
                payment_deadline: sessionExpiresAt.toISOString(),
                note: `Refunds will be processed to your ${paymentType.toUpperCase()} account`
            } : {
                message: 'Rental request submitted',
                action_required: 'Contact support for payment instructions',
                estimated_response_time: '24 hours'
            }
        };

        console.log('=== Rental Request Completed ===');

        return c.json({
            success: true,
            message: 'Rental request created successfully',
            data: responseData
        }, 201);

    } catch (error) {
        console.error('❌ Error in createRentalRequest:', error);

        return c.json({
            success: false,
            error: 'Failed to create rental request',
            details: error instanceof Error ? error.message : 'Unknown error'
        }, 500);
    }
};

// ====================================================================
// 📚 GET ALL RENTAL REJECTIONS
// ====================================================================
const getAllRentalRejections = async (c: Context): Promise<Response> => {
    try {
        // Get query parameters
        const page = parseInt(c.req.query('page') || '1');
        const limit = Math.min(parseInt(c.req.query('limit') || '10'), 50); // Max 50 per page
        const status = c.req.query('status'); // Optional status filter
        const offset = (page - 1) * limit;

        // Validate pagination parameters
        if (page < 1) {
            return c.json({
                success: false,
                message: "Page must be greater than 0"
            }, 400);
        }

        if (limit < 1) {
            return c.json({
                success: false,
                message: "Limit must be greater than 0"
            }, 400);
        }

        // Build where conditions for rental_rejections table
        let whereConditions = [];

        // Add status filter if provided (filter by rejection_reason)
        if (status) {
            const validReasons = ['unavailable', 'damaged', 'size_mismatch', 'date_conflict', 'payment_issue', 'renter_issue', 'other'];
            if (validReasons.includes(status)) {
                whereConditions.push(eq(rentalRejections.rejection_reason, status as any));
            }
        }

        const whereClause = whereConditions.length > 0 ? and(...whereConditions) : undefined;

        // Get total count for pagination - EXPLICITLY from rental_rejections table
        const [countResult] = await db
            .select({
                totalCount: count()
            })
            .from(rentalRejections) // FORCE rental_rejections table
            .where(whereClause);

        const totalCount = countResult?.totalCount ?? 0;

        // Get ALL data from rental_rejections table - NO JOINS, NO OTHER TABLES
        const rejectionsRawData = await db
            .select({
                // Explicitly select all fields from rental_rejections table
                id: rentalRejections.id,
                original_rental_id: rentalRejections.original_rental_id,
                reference_code: rentalRejections.reference_code,
                costume_id: rentalRejections.costume_id,
                renter_uid: rentalRejections.renter_uid,
                costume_snapshot: rentalRejections.costume_snapshot,
                renter_snapshot: rentalRejections.renter_snapshot,
                requested_start_date: rentalRejections.requested_start_date,
                requested_end_date: rentalRejections.requested_end_date,
                requested_rental_amount: rentalRejections.requested_rental_amount,
                requested_security_deposit: rentalRejections.requested_security_deposit,
                requested_total_amount: rentalRejections.requested_total_amount,
                rejected_at: rentalRejections.rejected_at,
                rejected_by: rentalRejections.rejected_by,
                rejection_reason: rentalRejections.rejection_reason,
                rejection_message: rentalRejections.rejection_message,
                original_pickup_location: rentalRejections.original_pickup_location,
                original_delivery_method: rentalRejections.original_delivery_method,
                original_special_instructions: rentalRejections.original_special_instructions,
                original_payment_gcash_number: rentalRejections.original_payment_gcash_number,
                original_refund_gcash_number: rentalRejections.original_refund_gcash_number,
                original_refund_account_name: rentalRejections.original_refund_account_name,
                original_notes: rentalRejections.original_notes,
                payment_amount: rentalRejections.payment_amount,
                payment_status: rentalRejections.payment_status,
                payment_processed_at: rentalRejections.payment_processed_at,
                original_created_at: rentalRejections.original_created_at,
                created_at: rentalRejections.created_at
            })
            .from(rentalRejections) // EXPLICITLY from rental_rejections table ONLY
            .where(whereClause)
            .orderBy(desc(rentalRejections.rejected_at))
            .limit(limit)
            .offset(offset);

        // Transform data - return ALL fields from rental_rejections table exactly as stored
        const rejections = rejectionsRawData.map((rejection) => ({
            // Primary fields
            id: rejection.id,
            original_rental_id: rejection.original_rental_id,
            reference_code: rejection.reference_code,
            costume_id: rejection.costume_id,
            renter_uid: rejection.renter_uid,

            // Snapshot data (JSONB fields)
            costume_snapshot: rejection.costume_snapshot,
            renter_snapshot: rejection.renter_snapshot,

            // Request details
            requested_start_date: rejection.requested_start_date.toISOString(),
            requested_end_date: rejection.requested_end_date.toISOString(),
            requested_rental_amount: rejection.requested_rental_amount,
            requested_security_deposit: rejection.requested_security_deposit,
            requested_total_amount: rejection.requested_total_amount,

            // Rejection details
            rejected_at: rejection.rejected_at.toISOString(),
            rejected_by: rejection.rejected_by,
            rejection_reason: rejection.rejection_reason,
            rejection_message: rejection.rejection_message,

            // Original request metadata
            original_pickup_location: rejection.original_pickup_location,
            original_delivery_method: rejection.original_delivery_method,
            original_special_instructions: rejection.original_special_instructions,

            // GCash payment details
            original_payment_gcash_number: rejection.original_payment_gcash_number,
            original_refund_gcash_number: rejection.original_refund_gcash_number,
            original_refund_account_name: rejection.original_refund_account_name,

            // Notes
            original_notes: rejection.original_notes,

            // Payment info at time of rejection
            payment_amount: rejection.payment_amount,
            payment_status: rejection.payment_status,
            payment_processed_at: rejection.payment_processed_at?.toISOString() || null,

            // Timestamps
            original_created_at: rejection.original_created_at.toISOString(),
            created_at: rejection.created_at.toISOString()
        }));

        // Calculate pagination info
        const totalPages = Math.ceil(totalCount / limit);
        const hasNextPage = page < totalPages;
        const hasPrevPage = page > 1;

        const pagination = {
            current_page: page,
            total_pages: totalPages,
            total_count: totalCount,
            per_page: limit,
            has_next_page: hasNextPage,
            has_prev_page: hasPrevPage,
            next_page: hasNextPage ? page + 1 : null,
            prev_page: hasPrevPage ? page - 1 : null
        };

        const response = {
            success: true,
            message: `Retrieved ${rejections.length} rental rejections from rental_rejections table`,
            data: {
                rejections,
                pagination,
                filters: {
                    status: status || null,
                    page,
                    limit
                },
                table_accessed: "rental_rejections" // Confirm which table was accessed
            }
        };

        return c.json(response, 200);

    } catch (error) {
        console.error('Error fetching all rental rejections:', error);
        return c.json({
            success: false,
            message: error instanceof Error ? error.message : 'Failed to fetch rental rejections',
            data: null,
            error: {
                type: error?.constructor?.name || 'Unknown Error',
                details: error instanceof Error ? error.message : 'Unknown error occurred'
            }
        }, 500);
    }
}

const getRentalRejections = async (c: Context): Promise<Response> => {
    try {
        const { userId } = c.req.param();
        // Get query parameters for pagination
        const page = parseInt(c.req.query('page') || '1');
        const limit = Math.min(parseInt(c.req.query('limit') || '10'), 50); // Max 50 per page
        const offset = (page - 1) * limit;
        // Validate user ID
        if (!userId) {
            return c.json({
                success: false,
                message: "User ID is required"
            }, 400);
        }
        // Get total count for pagination
        const [result] = await db
            .select({
                totalCount: count()
            })
            .from(rentalRejections)
            .innerJoin(costumes, eq(rentalRejections.costume_id, costumes.id))
            .where(eq(costumes.lender_uid, userId));

        const totalCount = result?.totalCount ?? 0;

        // Get paginated rejection data with costume details
        const rejectionsData = await db
            .select({
                rejection: rentalRejections,
                costume: costumes
            })
            .from(rentalRejections)
            .innerJoin(costumes, eq(rentalRejections.costume_id, costumes.id))
            .where(eq(costumes.lender_uid, userId))
            .orderBy(desc(rentalRejections.rejected_at))
            .limit(limit)
            .offset(offset);

        // Transform data to match the expected response format
        const rejections: any[] = rejectionsData.map(({ rejection, costume }) => ({
            id: rejection.id,
            original_rental_id: rejection.original_rental_id,
            reference_code: rejection.reference_code,
            costume: {
                id: costume.id,
                name: costume.name,
                brand: costume.brand,
                category: costume.category,
                sizes: costume.sizes,
                rental_price: costume.rental_price,
                security_deposit: costume.security_deposit,
                main_images: costume.main_images
            },
            renter: {
                uid: rejection.renter_snapshot.uid,
                name: rejection.renter_snapshot.name,
                email: rejection.renter_snapshot.email,
                phone: rejection.renter_snapshot.phone || ''
            },
            request: {
                start_date: rejection.requested_start_date.toISOString(),
                end_date: rejection.requested_end_date.toISOString(),
                rental_amount: rejection.requested_rental_amount,
                security_deposit: rejection.requested_security_deposit,
                total_amount: rejection.requested_total_amount,
                pickup_location: rejection.original_pickup_location || '',
                delivery_method: rejection.original_delivery_method || '',
                special_instructions: rejection.original_special_instructions,
                created_at: rejection.original_created_at.toISOString()
            },
            rejection: {
                reason: rejection.rejection_reason,
                message: rejection.rejection_message || '',
                rejected_at: rejection.rejected_at.toISOString(),
                rejected_by: rejection.rejected_by
            },
            payment: {
                amount: rejection.payment_amount || '0',
                status: rejection.payment_status || 'unknown',
                processed_at: rejection.payment_processed_at?.toISOString() || ''
            },
            created_at: rejection.created_at.toISOString()
        }));

        // Calculate pagination info
        const totalPages = Math.ceil(totalCount / limit);
        const hasNextPage = page < totalPages;
        const hasPrevPage = page > 1;

        const pagination: any = {
            current_page: page,
            total_pages: totalPages,
            total_count: totalCount,
            per_page: limit,
            has_next_page: hasNextPage,
            has_prev_page: hasPrevPage,
            next_page: hasNextPage ? page + 1 : null,
            prev_page: hasPrevPage ? page - 1 : null
        };

        const response: any = {
            success: true,
            message: `Retrieved ${rejections.length} rental rejections`,
            data: {
                rejections,
                pagination,
                filters: {
                    lender_id: userId,
                    page,
                    limit
                }
            }
        };

        return c.json(response, 200);
    } catch (error) {
        console.error('Error fetching rental rejections:', error);
        return c.json({
            success: false,
            message: error instanceof Error ? error.message : 'Failed to fetch rental rejections'
        }, 500);
    }
};


interface UpdateRentalStatusRequest {
    rental_id: string;
    user_id?: string; // Optional because lender_id might be used instead
    lender_id?: string; // Alternative to user_id for backward compatibility
    status: 'accept' | 'reject' | 'delivered' | 'returned';
    reject_message?: string;
    return_notes?: string;
}

const updateRentalRequestStatus = async (c: Context) => {
    try {
        const body = await c.req.json() as UpdateRentalStatusRequest;
        const { rental_id, status, reject_message, return_notes } = body;
        // Handle backward compatibility - use lender_id if user_id is not provided
        const user_id = body.user_id || body.lender_id;

        // Input validation
        if (!rental_id || !user_id || !status) {
            return c.json({
                success: false,
                error: "Missing required fields: rental_id, user_id/lender_id, and status are required"
            }, 400);
        }

        if (!["accept", "reject", "delivered", "returned"].includes(status)) {
            return c.json({
                success: false,
                error: "Status must be one of: 'accept', 'reject', 'delivered', 'returned'"
            }, 400);
        }

        if (status === "reject" && (!reject_message || !reject_message.trim())) {
            return c.json({
                success: false,
                error: "Rejection message is required when rejecting a rental"
            }, 400);
        }

        // Query rental with related data
        const rentalQueryResult = await db
            .select({
                rental: rentals,
                costume: costumes,
                payment: rentalPaymentHistory
            })
            .from(rentals)
            .innerJoin(costumes, eq(rentals.costume_id, costumes.id))
            .leftJoin(rentalPaymentHistory, eq(rentalPaymentHistory.rental_id, rentals.id))
            .where(eq(rentals.id, rental_id))
            .orderBy(desc(rentalPaymentHistory.created_at))
            .limit(1);

        if (!rentalQueryResult.length) {
            return c.json({
                success: false,
                error: "Rental request not found"
            }, 404);
        }

        const rentalData = rentalQueryResult[0] as any;
        const { rental, costume, payment } = rentalData;

        // Helper function to extract damage cost from return notes
        const extractDamageInfo = (notes: string) => {
            const isDamaged = notes.toUpperCase().includes('DAMAGED');
            let damageCost = '0';

            if (isDamaged) {
                // Look for cost patterns: ₱1000, PHP 1000, 1000, etc.
                const costMatch = notes.match(/₱\s*(\d+(?:,\d{3})*(?:\.\d{2})?)|PHP\s*(\d+(?:,\d{3})*(?:\.\d{2})?)|(\d+(?:,\d{3})*(?:\.\d{2})?)\s*(?:pesos?|php)?/i);
                if (costMatch) {
                    // Get the first non-undefined capture group
                    damageCost = (costMatch[1] || costMatch[2] || costMatch[3] || '0').replace(/,/g, '');
                }
            }

            return { isDamaged, damageCost };
        };

        // Status-specific business logic validation and processing
        switch (status) {
            case 'accept': {
                // Only lenders can accept, and rental must be confirmed with payment
                if (rental.status !== 'confirmed') {
                    return c.json({
                        success: false,
                        error: "Rental must be in 'confirmed' status to be accepted"
                    }, 400);
                }

                if (!payment || payment.status !== 'paid') {
                    return c.json({
                        success: false,
                        error: "Payment must be completed before accepting rental request"
                    }, 400);
                }

                if (costume.lender_uid !== user_id) {
                    return c.json({
                        success: false,
                        error: "Only the costume owner can accept rental requests"
                    }, 403);
                }

                const result = await db
                    .update(rentals)
                    .set({
                        status: 'accepted',
                        accepted_at: new Date(),
                        accepted_by: user_id,
                        updated_at: new Date()
                    })
                    .where(eq(rentals.id, rental_id))
                    .returning();

                // Send email notifications to both borrower and lender
                try {
                    // Get user details for email
                    const [renterDetails, lenderDetails] = await Promise.all([
                        db.select().from(users).where(eq(users.uid, rental.renter_uid)).limit(1),
                        db.select().from(users).where(eq(users.uid, costume.lender_uid)).limit(1)
                    ]);

                    const renter = renterDetails[0];
                    const lender = lenderDetails[0];

                    if (renter && lender) {
                        const orderData = {
                            id: rental_id,
                            type: 'rent',
                            status: 'accepted',
                            item: { name: costume.name },
                            borrower: {
                                email: renter.email,
                                name: renter.full_name || renter.username
                            },
                            lender: {
                                email: lender.email,
                                name: lender.full_name || lender.username
                            }
                        };

                        await notifyOrderStatusChange(orderData, 'accepted', { triggerRole: 'lender' });
                        console.log('Email notification sent to borrower for rental acceptance:', rental_id);

                        // Create in-app notifications for both borrower and lender
                        try {
                            // Notification for borrower (renter)
                            const borrowerNotification = notificationTemplates.rentalApproved(
                                lender.full_name || lender.username,
                                costume.name
                            );

                            await notificationService.create({
                                recipientId: rental.renter_uid,
                                recipientRole: "borrower",
                                type: "RENTAL_APPROVED",
                                title: borrowerNotification.title,
                                message: borrowerNotification.message,
                                costumeId: costume.id,
                                rentalId: rental_id,
                                senderId: costume.lender_uid,
                                senderRole: "lender",
                                senderType: "user",
                                metadata: {
                                    actionUrl: `/my-rentals?rentalId=${rental_id}`,
                                },
                            });

                            if (costume.lender_uid !== user_id) {
                                // Notification for lender
                                const lenderNotification = notificationTemplates.rentalApproved(
                                    lender.full_name || lender.username,
                                    costume.name
                                );

                                await notificationService.create({
                                    recipientId: costume.lender_uid,
                                    recipientRole: "lender",
                                    type: "RENTAL_APPROVED",
                                    title: lenderNotification.title,
                                    message: lenderNotification.message,
                                    costumeId: costume.id,
                                    rentalId: rental_id,
                                    senderId: rental.renter_uid,
                                    senderRole: "borrower",
                                    senderType: "user"
                                });
                            }

                            console.log('In-app notifications sent for rental acceptance:', rental_id);
                        } catch (notificationError) {
                            console.error('Failed to create in-app notifications for rental acceptance:', notificationError);
                            // Continue with response even if notification fails
                        }
                    }
                } catch (emailError) {
                    console.error('Failed to send email notifications for rental acceptance:', emailError);
                    // Continue with response even if email fails
                }

                return c.json({
                    success: true,
                    message: 'Rental request accepted successfully',
                    data: {
                        rental_id,
                        status: 'accepted',
                        accepted_at: new Date().toISOString(),
                        updated_at: new Date().toISOString()
                    }
                }, 200);
            }

            case 'reject': {
                // Only lenders can reject, and rental must be confirmed
                if (rental.status !== 'confirmed') {
                    return c.json({
                        success: false,
                        error: "Rental must be in 'confirmed' status to be rejected"
                    }, 400);
                }

                if (costume.lender_uid !== user_id) {
                    return c.json({
                        success: false,
                        error: "Only the costume owner can reject rental requests"
                    }, 403);
                }

                // Handle rejection with transaction
                const rejectionResult = await db.transaction(async (tx) => {
                    // Update rental status to rejected
                    const [updatedRental] = await tx
                        .update(rentals)
                        .set({
                            status: 'rejected',
                            updated_at: new Date()
                        })
                        .where(eq(rentals.id, rental_id))
                        .returning();

                    // Create rejection record
                    const [rejectionRecord] = await tx
                        .insert(rentalRejections)
                        .values({
                            id: randomUUID(),
                            original_rental_id: rental.id,
                            reference_code: rental.reference_code,
                            costume_id: rental.costume_id,
                            renter_uid: rental.renter_uid,
                            costume_snapshot: rental.costume_snapshot,
                            renter_snapshot: rental.renter_snapshot,
                            requested_start_date: rental.start_date,
                            requested_end_date: rental.end_date,
                            requested_rental_amount: rental.rental_amount,
                            requested_security_deposit: rental.security_deposit,
                            requested_total_amount: rental.total_amount,
                            rejected_at: new Date(),
                            rejected_by: user_id,
                            rejection_reason: 'other',
                            rejection_message: reject_message!.trim(),
                            original_pickup_location: rental.pickup_location,
                            original_delivery_method: rental.delivery_method,
                            original_special_instructions: rental.special_instructions,
                            original_payment_gcash_number: rental.payment_gcash_number,
                            original_refund_gcash_number: rental.refund_gcash_number,
                            original_refund_account_name: rental.refund_account_name,
                            original_created_at: rental.created_at,
                            payment_amount: payment?.payment_amount,
                            payment_status: payment?.payment_status,
                            payment_processed_at: payment?.created_at,
                        })
                        .returning();

                    return { updatedRental, rejectionRecord };
                });

                // Send email notifications to both borrower and lender
                try {
                    // Get user details for email
                    const [renterDetails, lenderDetails] = await Promise.all([
                        db.select().from(users).where(eq(users.uid, rental.renter_uid)).limit(1),
                        db.select().from(users).where(eq(users.uid, costume.lender_uid)).limit(1)
                    ]);

                    const renter = renterDetails[0];
                    const lender = lenderDetails[0];

                    if (renter && lender) {
                        const orderData = {
                            id: rental_id,
                            type: 'rent',
                            status: 'rejected',
                            item: { name: costume.name },
                            borrower: {
                                email: renter.email,
                                name: renter.full_name || renter.username
                            },
                            lender: {
                                email: lender.email,
                                name: lender.full_name || lender.username
                            }
                        };

                        await notifyOrderStatusChange(orderData, 'rejected', {
                            rejectMessage: reject_message,
                            triggerRole: 'lender'
                        });
                        console.log('Email notification sent to borrower for rental rejection:', rental_id);
                    }
                } catch (emailError) {
                    console.error('Failed to send email notifications for rental rejection:', emailError);
                    // Continue with response even if email fails
                }

                return c.json({
                    success: true,
                    message: 'Rental request rejected successfully',
                    data: {
                        rental_id,
                        status: 'rejected',
                        rejection_id: rejectionResult.rejectionRecord?.id,
                        updated_at: new Date().toISOString()
                    }
                }, 200);
            }

            case 'delivered': {
                // Only lenders can mark as delivered, and rental must be accepted
                if (rental.status !== 'accepted') {
                    return c.json({
                        success: false,
                        error: "Rental must be in 'accepted' status to be marked as delivered"
                    }, 400);
                }

                if (costume.lender_uid !== user_id) {
                    return c.json({
                        success: false,
                        error: "Only the costume owner can mark rentals as delivered"
                    }, 403);
                }

                const result = await db
                    .update(rentals)
                    .set({
                        status: 'delivered',
                        delivered_at: new Date(),
                        delivered_by: user_id,
                        updated_at: new Date()
                    })
                    .where(eq(rentals.id, rental_id))
                    .returning();

                // Send email notifications to both borrower and lender
                try {
                    // Get user details for email
                    const [renterDetails, lenderDetails] = await Promise.all([
                        db.select().from(users).where(eq(users.uid, rental.renter_uid)).limit(1),
                        db.select().from(users).where(eq(users.uid, costume.lender_uid)).limit(1)
                    ]);

                    const renter = renterDetails[0];
                    const lender = lenderDetails[0];

                    if (renter && lender) {
                        const orderData = {
                            id: rental_id,
                            type: 'rent',
                            status: 'delivered',
                            item: { name: costume.name },
                            borrower: {
                                email: renter.email,
                                name: renter.full_name || renter.username
                            },
                            lender: {
                                email: lender.email,
                                name: lender.full_name || lender.username
                            }
                        };

                        await notifyOrderStatusChange(orderData, 'delivered', { triggerRole: 'lender' });
                        console.log('Email notification sent to borrower for rental delivery:', rental_id);

                        // Create in-app notifications for both borrower and lender
                        try {
                            // Notification for borrower (renter)
                            const borrowerNotification = notificationTemplates.rentalDelivered(
                                costume.name,
                                lender.full_name || lender.username
                            );

                            await notificationService.create({
                                recipientId: rental.renter_uid,
                                recipientRole: "borrower",
                                type: "RENTAL_DELIVERED",
                                title: borrowerNotification.title,
                                message: borrowerNotification.message,
                                costumeId: costume.id,
                                rentalId: rental_id,
                                senderId: costume.lender_uid,
                                senderRole: "lender",
                                senderType: "user",
                                metadata: {
                                    actionUrl: `/my-rentals?rentalId=${rental_id}`,
                                },
                            });

                            if (costume.lender_uid !== user_id) {
                                // Notification for lender
                                const lenderNotification = notificationTemplates.rentalDelivered(
                                    costume.name,
                                    lender.full_name || lender.username
                                );

                                await notificationService.create({
                                    recipientId: costume.lender_uid,
                                    recipientRole: "lender",
                                    type: "RENTAL_DELIVERED",
                                    title: lenderNotification.title,
                                    message: lenderNotification.message,
                                    costumeId: costume.id,
                                    rentalId: rental_id,
                                    senderId: rental.renter_uid,
                                    senderRole: "borrower",
                                    senderType: "user"
                                });
                            }

                            console.log('In-app notifications sent for rental delivery:', rental_id);
                        } catch (notificationError) {
                            console.error('Failed to create in-app notifications for rental delivery:', notificationError);
                            // Continue with response even if notification fails
                        }
                    }
                } catch (emailError) {
                    console.error('Failed to send email notifications for rental delivery:', emailError);
                    // Continue with response even if email fails
                }

                return c.json({
                    success: true,
                    message: 'Rental marked as delivered successfully',
                    data: {
                        rental_id,
                        status: 'delivered',
                        delivered_at: new Date().toISOString(),
                        updated_at: new Date().toISOString()
                    }
                }, 200);
            }

            case 'returned': {
                // Both lenders and renters can mark as returned, rental must be delivered
                if (rental.status !== 'delivered') {
                    return c.json({
                        success: false,
                        error: "Rental must be in 'delivered' status to be marked as returned"
                    }, 400);
                }

                // Validate that user is either the lender or the renter
                const isLender = costume.lender_uid === user_id;
                const isRenter = rental.renter_uid === user_id;

                if (!isLender && !isRenter) {
                    return c.json({
                        success: false,
                        error: "Only the costume owner or renter can mark rentals as returned"
                    }, 403);
                }

                // Extract damage information from return notes if provided
                let damageInfo = { isDamaged: false, damageCost: '0' };
                if (return_notes) {
                    damageInfo = extractDamageInfo(return_notes);
                }

                const updateData: any = {
                    status: 'returned',
                    returned_at: new Date(),
                    returned_by: user_id,
                    actual_return_date: new Date(),
                    return_condition_notes: return_notes || null,
                    updated_at: new Date()
                };

                // Add damage-related fields if damage is reported
                if (damageInfo.isDamaged) {
                    updateData.damage_reported = true;
                    updateData.damage_cost = damageInfo.damageCost;
                }

                const result = await db
                    .update(rentals)
                    .set(updateData)
                    .where(eq(rentals.id, rental_id))
                    .returning();

                // Send email notifications to both borrower and lender
                try {
                    // Get user details for email
                    const [renterDetails, lenderDetails] = await Promise.all([
                        db.select().from(users).where(eq(users.uid, rental.renter_uid)).limit(1),
                        db.select().from(users).where(eq(users.uid, costume.lender_uid)).limit(1)
                    ]);

                    const renter = renterDetails[0];
                    const lender = lenderDetails[0];

                    if (renter && lender) {
                        const orderData = {
                            id: rental_id,
                            type: 'rent',
                            status: 'returned',
                            item: { name: costume.name },
                            borrower: {
                                email: renter.email,
                                name: renter.full_name || renter.username
                            },
                            lender: {
                                email: lender.email,
                                name: lender.full_name || lender.username
                            }
                        };

                        await notifyOrderStatusChange(orderData, 'returned', { triggerRole: isLender ? 'lender' : 'borrower' });
                        console.log(`Email notification sent to ${isLender ? 'borrower' : 'lender'} for rental return:`, rental_id);

                        // Create in-app notifications for both borrower and lender
                        try {
                            // Notification for borrower (renter)
                            const borrowerNotification = notificationTemplates.rentalReturned(
                                costume.name,
                                isLender ? (lender.full_name || lender.username) : (renter.full_name || renter.username)
                            );

                            await notificationService.create({
                                recipientId: rental.renter_uid,
                                recipientRole: "borrower",
                                type: "RENTAL_RETURNED",
                                title: borrowerNotification.title,
                                message: borrowerNotification.message,
                                costumeId: costume.id,
                                rentalId: rental_id,
                                senderId: isLender ? costume.lender_uid : rental.renter_uid,
                                senderRole: isLender ? "lender" : "borrower",
                                senderType: "user"
                            });

                            if (costume.lender_uid !== user_id) {
                                // Notification for lender
                                const lenderNotification = notificationTemplates.rentalReturned(
                                    costume.name,
                                    isLender ? (lender.full_name || lender.username) : (renter.full_name || renter.username)
                                );

                                await notificationService.create({
                                    recipientId: costume.lender_uid,
                                    recipientRole: "lender",
                                    type: "RENTAL_RETURNED",
                                    title: lenderNotification.title,
                                    message: lenderNotification.message,
                                    costumeId: costume.id,
                                    rentalId: rental_id,
                                    senderId: isLender ? costume.lender_uid : rental.renter_uid,
                                    senderRole: isLender ? "lender" : "borrower",
                                    senderType: "user"
                                });
                            }

                            console.log('In-app notifications sent for rental return:', rental_id);
                        } catch (notificationError) {
                            console.error('Failed to create in-app notifications for rental return:', notificationError);
                            // Continue with response even if notification fails
                        }
                    }
                } catch (emailError) {
                    console.error('Failed to send email notifications for rental return:', emailError);
                    // Continue with response even if email fails
                }

                const responseData: any = {
                    rental_id,
                    status: 'returned',
                    returned_at: new Date().toISOString(),
                    actual_return_date: new Date().toISOString(),
                    returned_by_role: isLender ? 'lender' : 'renter',
                    updated_at: new Date().toISOString()
                };

                // Include damage information in response if applicable
                if (damageInfo.isDamaged) {
                    responseData.damage_reported = true;
                    responseData.damage_cost = damageInfo.damageCost;
                    responseData.damage_notes = return_notes;
                }

                return c.json({
                    success: true,
                    message: damageInfo.isDamaged ?
                        'Rental marked as returned with damage reported' :
                        'Rental marked as returned successfully',
                    data: responseData
                }, 200);
            }

            default:
                return c.json({
                    success: false,
                    error: "Invalid status provided"
                }, 400);
        }
    } catch (error) {
        console.error('Error updating rental status:', error);
        return c.json({
            success: false,
            error: error instanceof Error ? error.message : 'Internal server error'
        }, 500);
    }
};


/**
 * Get all rentals for a specific user with pagination and filtering options
 * EXCLUDES rentals with 'pending' status
 * @param c Hono Context containing request data
 * @returns JSON response with rental data and pagination info
 */
const getMyRentals = async (c: Context): Promise<any> => {
    try {
        // Extract user ID from route parameters
        const userId = c.req.param('user_id');

        // Validate userId parameter
        if (!userId) {
            return c.json({
                success: false,
                data: {
                    rentals: [],
                    pagination: {
                        total: 0,
                        totalPages: 0,
                        currentPage: 1,
                        limit: 10
                    }
                },
                message: "User ID parameter is required"
            }, 400);
        }

        // Extract pagination and filter params from query with defaults
        const page = Math.max(1, parseInt(c.req.query('page') || '1', 10));
        const limit = Math.min(50, Math.max(1, parseInt(c.req.query('limit') || '10', 10))); // Max 50 items per page
        const statusFilter = c.req.query('status');

        // Calculate pagination offset
        const offset = (page - 1) * limit;

        // Build query conditions - EXCLUDE pending status
        let whereConditions = and(
            eq(rentals.renter_uid, userId),
            ne(rentals.status, 'pending') // Exclude pending rentals
        );

        // Add status filter if provided and valid (but still exclude pending)
        if (statusFilter && rentalStatusEnum.enumValues.includes(statusFilter as any)) {
            if (statusFilter !== 'pending') {
                whereConditions = and(
                    whereConditions,
                    eq(rentals.status, statusFilter as any)
                ) as any;
            }
        }

        // Execute count query for pagination
        const [countResult] = await db
            .select({ value: count() })
            .from(rentals)
            .where(whereConditions)
            .execute();

        const totalCount = Number(countResult?.value || 0);
        const totalPages = Math.ceil(totalCount / limit);

        // Main query to get rentals with costume data
        const rentalResults = await db
            .select({
                // Rental fields
                id: rentals.id,
                reference_code: rentals.reference_code,
                status: rentals.status,
                total_amount: rentals.total_amount,
                rental_amount: rentals.rental_amount,
                security_deposit: rentals.security_deposit,
                start_date: rentals.start_date,
                end_date: rentals.end_date,
                actual_return_date: rentals.actual_return_date,
                extended_days: rentals.extended_days,
                extension_fee: rentals.extension_fee,
                accepted_at: rentals.accepted_at,
                damage_reported: rentals.damage_reported,
                damage_cost: rentals.damage_cost,
                pickup_location: rentals.pickup_location,
                delivery_method: rentals.delivery_method,
                special_instructions: rentals.special_instructions,
                initial_condition_notes: rentals.initial_condition_notes,
                return_condition_notes: rentals.return_condition_notes,
                notes: rentals.notes,
                created_at: rentals.created_at,
                updated_at: rentals.updated_at,

                // Costume data
                costume: {
                    id: costumes.id,
                    name: costumes.name,
                    brand: costumes.brand,
                    category: costumes.category,
                    sizes: costumes.sizes,
                    rental_price: costumes.rental_price,
                    security_deposit: costumes.security_deposit,
                    main_images: costumes.main_images,
                    description: costumes.description,

                },

                // Snapshot data for historical reference
                costume_snapshot: rentals.costume_snapshot,
                renter_snapshot: rentals.renter_snapshot
            })
            .from(rentals)
            .leftJoin(costumes, eq(rentals.costume_id, costumes.id))
            .where(whereConditions)
            .limit(limit)
            .offset(offset)
            .orderBy(desc(rentals.created_at)) // Most recent first
            .execute();

        // If no rentals found, return early
        if (rentalResults.length === 0) {
            return c.json({
                success: true,
                data: {
                    rentals: [],
                    pagination: {
                        total: totalCount,
                        totalPages: totalPages,
                        currentPage: page,
                        limit: limit,
                        hasNextPage: false,
                        hasPreviousPage: false
                    }
                },
                message: totalCount === 0 ? "No rentals found" : "No rentals found for this page"
            });
        }

        // Collect rental IDs for batch payment status query
        const rentalIds = rentalResults.map(rental => rental.id);

        // Get payment info for all fetched rentals in one batch query
        const paymentsData = await db
            .select({
                rental_id: rentalPaymentHistory.rental_id,
                status: rentalPaymentHistory.status,
                amount: rentalPaymentHistory.amount,
                payment_type: rentalPaymentHistory.payment_type,
                created_at: rentalPaymentHistory.created_at,
                updated_at: rentalPaymentHistory.updated_at
            })
            .from(rentalPaymentHistory)
            .where(inArray(rentalPaymentHistory.rental_id, rentalIds))
            .orderBy(desc(rentalPaymentHistory.created_at))
            .execute();

        // Group payments by rental_id for efficient lookup
        const paymentsByRentalId = paymentsData.reduce((acc: Record<string, any[]>, payment) => {
            if (!acc[payment.rental_id]) {
                acc[payment.rental_id] = [];
            }
            acc[payment.rental_id]?.push(payment);
            return acc;
        }, {});

        // Format rentals with payment information
        const formattedRentals = rentalResults.map(rental => {
            // Get payments for this rental
            const rentalPayments = paymentsByRentalId[rental.id] || [];

            // Find the most recent payment to determine status
            const latestPayment = rentalPayments[0]; // Already sorted by created_at desc

            // Calculate total amount paid (only successful payments)
            const totalPaid = rentalPayments
                .filter(p => p.status === 'paid' || p.status === 'succeeded')
                .reduce((sum, payment) => sum + parseFloat(payment.amount || '0'), 0);

            // Calculate remaining balance
            const totalAmount = parseFloat(rental.total_amount || '0');
            const remainingBalance = totalAmount - totalPaid;

            // Determine payment status
            let paymentStatus = 'unpaid';
            if (latestPayment) {
                paymentStatus = latestPayment.status;
            }
            if (totalPaid >= totalAmount) {
                paymentStatus = 'paid';
            } else if (totalPaid > 0) {
                paymentStatus = 'partial';
            }

            return {
                // Basic rental info
                id: rental.id,
                reference_code: rental.reference_code,
                status: rental.status,

                // Financial info
                total_amount: rental.total_amount,
                rental_amount: rental.rental_amount,
                security_deposit: rental.security_deposit,
                extension_fee: rental.extension_fee,
                damage_cost: rental.damage_cost,
                amount_paid: totalPaid.toFixed(2),
                remaining_balance: remainingBalance.toFixed(2),
                payment_status: paymentStatus,

                // Schedule info
                start_date: rental.start_date?.toISOString(),
                end_date: rental.end_date?.toISOString(),
                actual_return_date: rental.actual_return_date?.toISOString(),
                extended_days: rental.extended_days,

                // Status dates
                accepted_at: rental.accepted_at?.toISOString(),
                created_at: rental.created_at?.toISOString(),
                updated_at: rental.updated_at?.toISOString(),

                // Logistics
                pickup_location: rental.pickup_location,
                delivery_method: rental.delivery_method,
                special_instructions: rental.special_instructions,

                // Condition tracking
                damage_reported: rental.damage_reported,
                initial_condition_notes: rental.initial_condition_notes,
                return_condition_notes: rental.return_condition_notes,

                // Additional notes
                notes: rental.notes,

                // Related data
                costume: rental.costume,
                costume_snapshot: rental.costume_snapshot,
                renter_snapshot: rental.renter_snapshot,

                // Payment history summary
                payments: rentalPayments.map(payment => ({
                    status: payment.status,
                    amount: payment.amount,
                    payment_type: payment.payment_type,
                    created_at: payment.created_at?.toISOString(),
                    updated_at: payment.updated_at?.toISOString()
                }))
            };
        });

        // Construct the response with enhanced pagination info
        return c.json({
            success: true,
            data: {
                rentals: formattedRentals,
                pagination: {
                    total: totalCount,
                    totalPages: totalPages,
                    currentPage: page,
                    limit: limit,
                    hasNextPage: page < totalPages,
                    hasPreviousPage: page > 1,
                    offset: offset
                },
                filters: {
                    status: statusFilter || null,
                    applied_status_filter: statusFilter && rentalStatusEnum.enumValues.includes(statusFilter as any)
                }
            },
            message: `Found ${formattedRentals.length} rental${formattedRentals.length !== 1 ? 's' : ''}`
        });

    } catch (error) {
        console.error("Error fetching rentals:", error);

        // Enhanced error response
        return c.json({
            success: false,
            data: {
                rentals: [],
                pagination: {
                    total: 0,
                    totalPages: 0,
                    currentPage: 1,
                    limit: 10,
                    hasNextPage: false,
                    hasPreviousPage: false
                }
            },
            message: error instanceof Error ? error.message : "An error occurred while fetching rentals",
            error: {
                type: error instanceof Error ? error.constructor.name : 'Unknown',
                details: error instanceof Error ? error.message : 'An unknown error occurred'
            }
        }, 500);
    }
};

/**
 * Get all rental requests for a specific lender (costume owner) with pagination and filtering options
 * EXCLUDES rentals with 'pending' status
 * @param c Hono Context containing request data
 * @returns JSON response with rental requests data and pagination info
 */
const getLenderRentals = async (c: Context): Promise<any> => {
    try {
        // Extract lender ID from route parameters
        const lenderId = c.req.param('user_id'); // This is the lender's user ID

        // Validate lenderId parameter
        if (!lenderId) {
            return c.json({
                success: false,
                data: {
                    rental_requests: [],
                    pagination: {
                        current_page: 1,
                        total_pages: 0,
                        total_count: 0,
                        has_next: false,
                        has_prev: false
                    },
                    summary: {
                        total_requests: 0,
                        status_filter: 'all',
                        lender_id: ''
                    }
                },
                message: "Lender ID parameter is required"
            }, 400);
        }

        // Extract pagination and filter params from query with defaults
        const page = Math.max(1, parseInt(c.req.query('page') || '1', 10));
        const limit = Math.min(50, Math.max(1, parseInt(c.req.query('limit') || '10', 10)));
        const statusFilter = c.req.query('status');

        // Calculate pagination offset
        const offset = (page - 1) * limit;

        // Build query conditions - EXCLUDE pending status
        let whereConditions = and(
            eq(costumes.lender_uid, lenderId),
            ne(rentals.status, 'pending') // Exclude pending rentals
        );

        // Add status filter if provided and valid (but still exclude pending)
        if (statusFilter && statusFilter !== 'all' && rentalStatusEnum.enumValues.includes(statusFilter as any)) {
            if (statusFilter !== 'pending') {
                whereConditions = and(
                    whereConditions,
                    eq(rentals.status, statusFilter as any)
                ) as any;
            }
        }

        // Execute count query for pagination
        const [countResult] = await db
            .select({ value: count() })
            .from(rentals)
            .innerJoin(costumes, eq(rentals.costume_id, costumes.id))
            .where(whereConditions)
            .execute();

        const totalCount = Number(countResult?.value || 0);
        const totalPages = Math.ceil(totalCount / limit);

        // Main query to get rental requests with costume and renter data
        const rentalResults = await db
            .select({
                // Rental fields
                id: rentals.id,
                reference_code: rentals.reference_code,
                status: rentals.status,
                total_amount: rentals.total_amount,
                rental_amount: rentals.rental_amount,
                security_deposit: rentals.security_deposit,
                start_date: rentals.start_date,
                end_date: rentals.end_date,
                actual_return_date: rentals.actual_return_date,
                extended_days: rentals.extended_days,
                extension_fee: rentals.extension_fee,
                accepted_at: rentals.accepted_at,
                accepted_by: rentals.accepted_by,
                damage_reported: rentals.damage_reported,
                damage_cost: rentals.damage_cost,
                pickup_location: rentals.pickup_location,
                delivery_method: rentals.delivery_method,
                special_instructions: rentals.special_instructions,
                initial_condition_notes: rentals.initial_condition_notes,
                return_condition_notes: rentals.return_condition_notes,
                notes: rentals.notes,
                created_at: rentals.created_at,
                updated_at: rentals.updated_at,

                // Costume data
                costume: {
                    id: costumes.id,
                    name: costumes.name,
                    brand: costumes.brand,
                    category: costumes.category,
                    sizes: costumes.sizes,
                    rental_price: costumes.rental_price,
                    security_deposit: costumes.security_deposit,
                    main_images: costumes.main_images,
                    description: costumes.description,

                },

                // Snapshots for historical reference
                costume_snapshot: rentals.costume_snapshot,
                renter_snapshot: rentals.renter_snapshot,

                // GCash payment details
                payment_gcash_number: rentals.payment_gcash_number,
                refund_gcash_number: rentals.refund_gcash_number,
                refund_account_name: rentals.refund_account_name
            })
            .from(rentals)
            .innerJoin(costumes, eq(rentals.costume_id, costumes.id))
            .where(whereConditions)
            .limit(limit)
            .offset(offset)
            .orderBy(desc(rentals.created_at)) // Most recent first
            .execute();

        // If no rentals found, return early
        if (rentalResults.length === 0) {
            return c.json({
                success: true,
                data: {
                    rental_requests: [],
                    pagination: {
                        current_page: page,
                        total_pages: totalPages,
                        total_count: totalCount,
                        has_next: false,
                        has_prev: false
                    },
                    summary: {
                        total_requests: totalCount,
                        status_filter: statusFilter || 'all',
                        lender_id: lenderId
                    }
                },
                message: totalCount === 0 ? "No rental requests found" : "No rental requests found for this page"
            });
        }

        // Get lender information from business info
        let lenderInfo: any | null = null;
        if (lenderId) {
            [lenderInfo] = await db
                .select({

                    // Business info
                    business_name: user_business_info.business_name,
                    business_type: user_business_info.business_type,
                    business_email: user_business_info.business_email,
                    business_phone: user_business_info.business_phone_number,
                    business_profile_image: user_business_info.business_profile_image,
                    business_description: user_business_info.business_description
                })
                .from(users)
                .leftJoin(
                    user_business_info,
                    eq(users.uid, user_business_info.user_uid)
                )
                .where(eq(users.uid, lenderId))
                .limit(1)
                .execute();
        }

        // Collect rental IDs for batch payment status query
        const rentalIds = rentalResults.map(rental => rental.id);

        // Get payment info for all fetched rentals in one batch query
        const paymentsData = await db
            .select({
                rental_id: rentalPaymentHistory.rental_id,
                status: rentalPaymentHistory.status,
                amount: rentalPaymentHistory.amount,
                payment_type: rentalPaymentHistory.payment_type,
                created_at: rentalPaymentHistory.created_at,
                updated_at: rentalPaymentHistory.updated_at
            })
            .from(rentalPaymentHistory)
            .where(inArray(rentalPaymentHistory.rental_id, rentalIds))
            .orderBy(desc(rentalPaymentHistory.created_at))
            .execute();

        // Group payments by rental_id for efficient lookup
        const paymentsByRentalId = paymentsData.reduce((acc: Record<string, any[]>, payment) => {
            if (!acc[payment.rental_id]) {
                acc[payment.rental_id] = [];
            }
            acc[payment.rental_id]?.push(payment);
            return acc;
        }, {});

        // Calculate duration helper function
        const calculateDurationDays = (startDate: Date, endDate: Date): number => {
            const timeDiff = endDate.getTime() - startDate.getTime();
            return Math.ceil(timeDiff / (1000 * 3600 * 24)) + 1; // +1 to include both start and end days
        };

        // Format rental requests according to your interface
        const formattedRentalRequests = rentalResults.map(rental => {
            // Get payments for this rental
            const rentalPayments = paymentsByRentalId[rental.id] || [];

            // Calculate payment summary
            const paidPayments = rentalPayments.filter(p =>
                p.status === 'paid' || p.status === 'succeeded'
            );
            const totalPaid = paidPayments.reduce((sum, payment) =>
                sum + parseFloat(payment.amount || '0'), 0
            );
            const totalAmount = parseFloat(rental.total_amount || '0');
            const pendingAmount = totalAmount - totalPaid;

            // Determine payment status
            let paymentStatus: "unpaid" | "partially_paid" | "fully_paid" = 'unpaid';
            if (totalPaid >= totalAmount) {
                paymentStatus = 'fully_paid';
            } else if (totalPaid > 0) {
                paymentStatus = 'partially_paid';
            }

            // Get last payment date
            const lastPaymentDate = paidPayments.length > 0
                ? paidPayments[0].created_at?.toISOString()
                : '';

            // Calculate duration
            const durationDays = calculateDurationDays(rental.start_date, rental.end_date);

            // Get costume image from main_images
            let costumeImage = '';
            if (rental.costume.main_images) {
                costumeImage = rental.costume.main_images.front || rental.costume.main_images.back || '';
            }

            return {
                id: rental.id,
                reference_code: rental.reference_code,
                status: rental.status as "pending" | "confirmed" | "cancelled" | "completed",
                rental_amount: rental.rental_amount,
                security_deposit: rental.security_deposit,
                total_amount: rental.total_amount,
                start_date: rental.start_date.toISOString(),
                end_date: rental.end_date.toISOString(),
                duration_days: durationDays,
                pickup_location: rental.pickup_location || '',
                delivery_method: (rental.delivery_method as "pickup" | "delivery") || "pickup",
                special_instructions: rental.special_instructions,

                // Costume info matching your interface
                costume: {
                    id: rental.costume.id,
                    name: rental.costume.name,
                    brand: rental.costume.brand,
                    category: rental.costume.category,
                    sizes: rental.costume.sizes,
                    image: costumeImage
                },

                // Renter info from snapshot
                renter: {
                    uid: rental.renter_snapshot.uid,
                    name: rental.renter_snapshot.name,
                    email: rental.renter_snapshot.email,
                    phone: rental.renter_snapshot.phone || '',
                    address: rental.renter_snapshot.address || ''
                },

                // Lender name
                lender_name: lenderInfo?.business_name as any || 'Unknown Lender',

                // Payment summary
                payment_summary: {
                    status: paymentStatus,
                    total_paid: totalPaid.toFixed(2),
                    pending_amount: Math.max(0, pendingAmount).toFixed(2),
                    payment_count: paidPayments.length,
                    last_payment_date: lastPaymentDate
                },

                created_at: rental.created_at.toISOString(),
                updated_at: rental.updated_at.toISOString()
            };
        });

        // Construct the response
        return c.json({
            success: true,
            data: {
                rental_requests: formattedRentalRequests,
                pagination: {
                    current_page: page,
                    total_pages: totalPages,
                    total_count: totalCount,
                    has_next: page < totalPages,
                    has_prev: page > 1
                },
                summary: {
                    total_requests: totalCount,
                    status_filter: statusFilter || 'all',
                    lender_id: lenderId
                }
            },
            message: `Found ${formattedRentalRequests.length} rental request${formattedRentalRequests.length !== 1 ? 's' : ''}`
        });

    } catch (error) {
        console.error("Error fetching lender rentals:", error);

        return c.json({
            success: false,
            data: {
                rental_requests: [],
                pagination: {
                    current_page: 1,
                    total_pages: 0,
                    total_count: 0,
                    has_next: false,
                    has_prev: false
                },
                summary: {
                    total_requests: 0,
                    status_filter: 'all',
                    lender_id: ''
                }
            },
            message: error instanceof Error ? error.message : "An error occurred while fetching lender rentals",
            error: {
                type: error instanceof Error ? error.constructor.name : 'Unknown',
                details: error instanceof Error ? error.message : 'An unknown error occurred'
            }
        }, 500);
    }
};


/**
 * Get detailed rental information by rental ID
 * @param c Hono Context containing request data
 * @returns JSON response with detailed rental data
 */
const getRentalById = async (c: Context): Promise<any> => {
    try {
        // Extract rental ID from route parameters
        const rentalId = c.req.param('rental_id');

        // Validate rentalId parameter
        if (!rentalId) {
            return c.json({
                success: false,
                data: null,
                message: "Rental ID parameter is required"
            }, 400);
        }

        // Main query to get rental with costume data
        const [rentalResult] = await db
            .select({
                // Rental fields
                id: rentals.id,
                reference_code: rentals.reference_code,
                status: rentals.status,
                total_amount: rentals.total_amount,
                rental_amount: rentals.rental_amount,
                security_deposit: rentals.security_deposit,
                start_date: rentals.start_date,
                end_date: rentals.end_date,
                actual_return_date: rentals.actual_return_date,
                extended_days: rentals.extended_days,
                extension_fee: rentals.extension_fee,
                accepted_at: rentals.accepted_at,
                accepted_by: rentals.accepted_by,
                damage_reported: rentals.damage_reported,
                damage_cost: rentals.damage_cost,
                pickup_location: rentals.pickup_location,
                delivery_method: rentals.delivery_method,
                special_instructions: rentals.special_instructions,
                initial_condition_notes: rentals.initial_condition_notes,
                return_condition_notes: rentals.return_condition_notes,
                notes: rentals.notes,
                renter_uid: rentals.renter_uid,
                costume_id: rentals.costume_id,
                created_at: rentals.created_at,
                updated_at: rentals.updated_at,
                // Snapshots for historical reference
                costume_snapshot: rentals.costume_snapshot,
                renter_snapshot: rentals.renter_snapshot,
                // GCash payment details
                payment_gcash_number: rentals.payment_gcash_number,
                refund_gcash_number: rentals.refund_gcash_number,
                refund_account_name: rentals.refund_account_name,
                return_proof: rentals.return_proof // ✅ include return proof
            })
            .from(rentals)
            .where(eq(rentals.id, rentalId))
            .execute();

        // If rental not found, return 404
        if (!rentalResult) {
            return c.json({
                success: false,
                data: null,
                message: "Rental not found"
            }, 404);
        }

        // Get costume details - only select fields that are actually used in the response
        const [costumeDetails] = await db
            .select({
                id: costumes.id,
                name: costumes.name,
                brand: costumes.brand,
                category: costumes.category,
                sizes: costumes.sizes,
                rental_price: costumes.rental_price,
                security_deposit: costumes.security_deposit,
                main_images: costumes.main_images,
                description: costumes.description,
                lender_uid: costumes.lender_uid,

                gender: costumes.gender,

                tags: costumes.tags,
                additional_images: costumes.additional_images,
                is_available: costumes.is_available
            })
            .from(costumes)
            .where(eq(costumes.id, rentalResult.costume_id))
            .execute();

        // Get lender information from business info
        let lenderInfo = null;
        if (costumeDetails?.lender_uid) {
            [lenderInfo] = await db
                .select({
                    // User info
                    uid: users.uid,
                    full_name: users.full_name,
                    email: users.email,
                    phone: users.phone_number,
                    profile_image: users.profile_image,
                    // Business info
                    business_name: user_business_info.business_name,
                    business_type: user_business_info.business_type,
                    business_email: user_business_info.business_email,
                    business_phone: user_business_info.business_phone_number,
                    business_profile_image: user_business_info.business_profile_image,
                    business_description: user_business_info.business_description
                })
                .from(users)
                .leftJoin(
                    user_business_info,
                    eq(users.uid, user_business_info.user_uid)
                )
                .where(eq(users.uid, costumeDetails.lender_uid))
                .limit(1)
                .execute();
        }

        // Get renter information (for current data rather than just snapshot)
        let renterInfo = null;
        if (rentalResult.renter_uid) {
            [renterInfo] = await db
                .select({
                    uid: users.uid,
                    full_name: users.full_name,
                    email: users.email,
                    phone: users.phone_number,
                    profile_image: users.profile_image,
                })
                .from(users)
                .where(eq(users.uid, rentalResult.renter_uid))
                .limit(1)
                .execute();
        }

        // Get payment info for this rental
        // Get payment info for this rental
        const paymentsData = await db
            .select({
                id: rentalPaymentHistory.id,
                reference_code: rentalPaymentHistory.reference_code,
                status: rentalPaymentHistory.status,
                amount: rentalPaymentHistory.amount,
                payment_type: rentalPaymentHistory.payment_type,
                payment_method: rentalPaymentHistory.payment_method,
                payment_reference: rentalPaymentHistory.payment_reference,
                processed_at: rentalPaymentHistory.processed_at,
                receipt_url: rentalPaymentHistory.receipt_url,
                receipt_number: rentalPaymentHistory.receipt_number,
                description: rentalPaymentHistory.description,
                processor_notes: rentalPaymentHistory.processor_notes,
                // PayMongo specific fields
                paymongo_payment_intent_id: rentalPaymentHistory.paymongo_payment_intent_id,
                paymongo_source_id: rentalPaymentHistory.paymongo_source_id,
                session_id: rentalPaymentHistory.session_id,
                checkout_url: rentalPaymentHistory.checkout_url,
                gateway_status: rentalPaymentHistory.gateway_status as any,
                session_expires_at: rentalPaymentHistory.session_expires_at,
                metadata: rentalPaymentHistory.metadata,
                created_at: rentalPaymentHistory.created_at,
                updated_at: rentalPaymentHistory.updated_at
            })
            .from(rentalPaymentHistory)
            .where(eq(rentalPaymentHistory.rental_id, rentalId))
            .orderBy(desc(rentalPaymentHistory.created_at))
            .execute();

        // Calculate payment summary
        // Filter payments by status using the correct enum values from schema
        const paidPayments = paymentsData.filter(p =>
            p.status === 'paid' ||
            (p.gateway_status === 'succeeded' && p.status !== 'refunded' && p.status !== 'partial_refund')
        );

        const refundedPayments = paymentsData.filter(p =>
            p.status === 'refunded' ||
            p.status === 'partial_refund' ||
            p.status === 'cancelled'
        );

        // Calculate totals correctly
        const totalPaid = paidPayments.reduce((sum, payment) => {
            // Skip refund type payments when calculating total paid
            if (payment.payment_type === 'refund') return sum;
            return sum + parseFloat(payment.amount || '0');
        }, 0);

        // For refunds, only count those with refund payment_type
        const totalRefunded = paymentsData
            .filter(p => p.payment_type === 'refund' || p.status === 'refunded' || p.status === 'partial_refund')
            .reduce((sum, payment) => sum + parseFloat(payment.amount || '0'), 0);

        const totalAmount = parseFloat(rentalResult.total_amount || '0');
        const pendingAmount = Math.max(0, totalAmount - totalPaid);

        // Find active payment session if any
        const activeSession = paymentsData.find(p =>
            p.status === 'pending' &&
            p.session_id &&
            p.checkout_url &&
            p.session_expires_at &&
            new Date(p.session_expires_at) > new Date()
        );

        // Determine payment status
        let paymentStatus: "unpaid" | "partially_paid" | "fully_paid" = 'unpaid';
        if (totalPaid >= totalAmount) {
            paymentStatus = 'fully_paid';
        } else if (totalPaid > 0) {
            paymentStatus = 'partially_paid';
        }

        // Calculate duration
        const calculateDurationDays = (startDate: Date, endDate: Date): number => {
            const timeDiff = endDate.getTime() - startDate.getTime();
            return Math.ceil(timeDiff / (1000 * 3600 * 24)) + 1; // +1 to include both start and end days
        };
        const durationDays = calculateDurationDays(rentalResult.start_date, rentalResult.end_date);

        // Get costume images
        let costumeMainImage = '';
        let costumeImages: string[] = [];

        if (costumeDetails?.main_images) {
            costumeMainImage = costumeDetails.main_images.front || costumeDetails.main_images.back || '';

            // Add main images to the array
            if (costumeDetails.main_images.front) {
                costumeImages.push(costumeDetails.main_images.front);
            }
            if (costumeDetails.main_images.back) {
                costumeImages.push(costumeDetails.main_images.back);
            }
        }

        // Add additional images if available
        if (costumeDetails?.additional_images && Array.isArray(costumeDetails.additional_images)) {
            const additionalImageUrls = costumeDetails.additional_images.map(img => img.url);
            costumeImages = [...costumeImages, ...additionalImageUrls];
        }

        // Format payments for response
        const formattedPayments = paymentsData.map(payment => ({
            id: payment.id,
            reference_code: payment.reference_code,
            status: payment.status,
            amount: payment.amount,
            payment_type: payment.payment_type,
            payment_method: payment.payment_method,
            payment_reference: payment.payment_reference || null,
            description: payment.description || null,
            processed_at: payment.processed_at ? payment.processed_at.toISOString() : null,
            receipt_url: payment.receipt_url || null,
            receipt_number: payment.receipt_number || null,
            processor_notes: payment.processor_notes || null,
            // PayMongo specific fields
            paymongo_data: {
                payment_intent_id: payment.paymongo_payment_intent_id || null,
                source_id: payment.paymongo_source_id || null,
                session_id: payment.session_id || null,
                checkout_url: payment.checkout_url || null,
                gateway_status: payment.gateway_status || null,
                session_expires_at: payment.session_expires_at ? payment.session_expires_at.toISOString() : null,
            },
            metadata: payment.metadata || {},
            created_at: payment.created_at.toISOString(),
            updated_at: payment.updated_at.toISOString()
        }));

        // Format rental data for response
        const formattedRental = {
            id: rentalResult.id,
            reference_code: rentalResult.reference_code,
            status: rentalResult.status,

            // Timing details
            start_date: rentalResult.start_date.toISOString(),
            end_date: rentalResult.end_date.toISOString(),
            actual_return_date: rentalResult.actual_return_date ? rentalResult.actual_return_date.toISOString() : null,
            duration_days: durationDays,

            // Financial details
            rental_amount: rentalResult.rental_amount,
            security_deposit: rentalResult.security_deposit,
            total_amount: rentalResult.total_amount,
            extended_days: rentalResult.extended_days || 0,
            extension_fee: rentalResult.extension_fee || '0',
            damage_reported: rentalResult.damage_reported,
            damage_cost: rentalResult.damage_cost || '0',

            // Logistics
            pickup_location: rentalResult.pickup_location || '',
            delivery_method: rentalResult.delivery_method || 'pickup',
            special_instructions: rentalResult.special_instructions || '',

            // Condition tracking
            initial_condition_notes: rentalResult.initial_condition_notes || '',
            return_condition_notes: rentalResult.return_condition_notes || '',
            notes: rentalResult.notes || '',

            // Acceptance info
            accepted_at: rentalResult.accepted_at ? rentalResult.accepted_at.toISOString() : null,
            accepted_by: rentalResult.accepted_by || null,

            // Costume details
            costume: {
                id: costumeDetails?.id || rentalResult.costume_snapshot.id,
                name: costumeDetails?.name || rentalResult.costume_snapshot.name,
                brand: costumeDetails?.brand || rentalResult.costume_snapshot.brand,
                category: costumeDetails?.category || rentalResult.costume_snapshot.category,
                sizes: costumeDetails?.sizes || rentalResult.costume_snapshot.sizes,
                rental_price: costumeDetails?.rental_price || rentalResult.costume_snapshot.rental_price,
                security_deposit: costumeDetails?.security_deposit || rentalResult.costume_snapshot.security_deposit,
                description: costumeDetails?.description || '',
                themes: costumeDetails?.tags || [],
                gender: costumeDetails?.gender || null,
                main_image: costumeMainImage,
                images: costumeImages,
                availability_status: costumeDetails?.is_available || 'available'
            },

            // People involved
            renter: {
                uid: renterInfo?.uid || rentalResult.renter_snapshot.uid,
                name: renterInfo?.full_name || rentalResult.renter_snapshot.name,
                email: renterInfo?.email || rentalResult.renter_snapshot.email,
                phone: renterInfo?.phone || rentalResult.renter_snapshot.phone || '',
                profile_image: renterInfo?.profile_image || null
            },
            lender: {
                uid: lenderInfo?.uid || rentalResult.costume_snapshot.lender_info.uid,
                name: lenderInfo?.full_name || rentalResult.costume_snapshot.lender_info.name,
                email: lenderInfo?.email || rentalResult.costume_snapshot.lender_info.email || '',
                phone: lenderInfo?.phone || rentalResult.costume_snapshot.lender_info.phone || '',
                profile_image: lenderInfo?.profile_image || null
            },

            // Payment details
            payment_summary: {
                status: paymentStatus,
                total_paid: totalPaid.toFixed(2),
                pending_amount: pendingAmount.toFixed(2),
                total_refunded: totalRefunded.toFixed(2),
                payment_count: paidPayments.length,
                refund_count: refundedPayments.length,
                last_payment_date: paidPayments.length > 0 ? paidPayments[0]?.created_at.toISOString() : null,
                has_active_session: !!activeSession,
                active_session: activeSession ? {
                    id: activeSession.id,
                    session_id: activeSession.session_id || '',
                    checkout_url: activeSession.checkout_url || '',
                    expires_at: activeSession.session_expires_at?.toISOString() || '',
                    amount: activeSession.amount || '0'
                } : null
            },
            payments: formattedPayments,

            // GCash payment details
            payment_gcash_number: rentalResult.payment_gcash_number || null,
            refund_gcash_number: rentalResult.refund_gcash_number || null,
            refund_account_name: rentalResult.refund_account_name || null,

            // Snapshots (raw data)
            costume_snapshot: rentalResult.costume_snapshot,
            renter_snapshot: rentalResult.renter_snapshot,
            // ✅ include return proof in response
            return_proof: rentalResult.return_proof,

            // Timestamps
            created_at: rentalResult.created_at.toISOString(),
            updated_at: rentalResult.updated_at.toISOString()
        };

        // Construct the response
        return c.json({
            success: true,
            data: formattedRental,
            message: "Rental details retrieved successfully"
        });

    } catch (error) {
        console.error("Error fetching rental by ID:", error);
        return c.json({
            success: false,
            data: null,
            message: error instanceof Error ? error.message : "An error occurred while fetching rental details",
            error: {
                type: error instanceof Error ? error.constructor.name : 'Unknown',
                details: error instanceof Error ? error.message : 'An unknown error occurred'
            }
        }, 500);
    }
};


// Helper function to map PayMongo gateway status

const mapGatewayStatus = (paymongoStatus: string) => {
    const validStatuses = [
        'awaiting_payment_method',
        'awaiting_next_action',
        'processing',
        'succeeded',
        'requires_payment_method',
        'cancelled',
        'pending'
    ];

    return validStatuses.includes(paymongoStatus) ? paymongoStatus : 'pending';
};


// Updated confirmPayment function using reference_code from query params
const confirmPayment = async (c: Context) => {
    try {
        console.log('=== Starting payment confirmation process ===');

        // Get reference_code from query parameters
        const reference_code = c.req.param('reference_code');
        console.log('Received reference_code from query params:', reference_code);

        // ═══════════════════════════════════════════════════════════════
        // 🔍 VALIDATION
        // ═══════════════════════════════════════════════════════════════
        if (!reference_code) {
            console.error('Missing required parameter: reference_code');
            return c.json({
                success: false,
                message: 'reference_code is required for payment confirmation',
                missing_parameters: ['reference_code']
            }, 400);
        }

        // ═══════════════════════════════════════════════════════════════
        // 🔎 FIND PAYMENT RECORD BY REFERENCE_CODE
        // ═══════════════════════════════════════════════════════════════
        console.log('Looking up payment record by reference_code:', reference_code);

        const existingPayment = await db.query.rentalPaymentHistory.findFirst({
            where: eq(rentalPaymentHistory.reference_code, reference_code),
            with: {
                rental: {
                    with: {
                        costume: true
                    }
                }
            }
        });

        if (!existingPayment) {
            console.error('Payment record not found for reference_code:', reference_code);
            return c.json({
                success: false,
                message: 'Payment record not found',
                error: 'No payment record exists for the provided reference_code'
            }, 404);
        }

        console.log('Found payment record:', {
            payment_id: existingPayment.id,
            rental_id: existingPayment.rental_id,
            current_status: existingPayment.status,
            reference_code: reference_code,
            paymongo_payment_intent_id: existingPayment.paymongo_payment_intent_id
        });

        // Get the actual session_id from the payment record
        const session_id = existingPayment.paymongo_payment_intent_id;

        if (!session_id) {
            console.error('No PayMongo payment intent ID found for reference_code:', reference_code);
            return c.json({
                success: false,
                message: 'Payment session not found',
                error: 'No PayMongo payment intent ID associated with this payment record'
            }, 404);
        }

        console.log('Using PayMongo payment intent ID as session_id:', session_id);

        // ═══════════════════════════════════════════════════════════════
        // ✅ CHECK IF PAYMENT IS ALREADY PAID
        // ═══════════════════════════════════════════════════════════════
        if (existingPayment.status === 'paid') {
            console.log('Payment already paid, returning existing data');
            return c.json({
                success: true,
                message: 'Payment has already been confirmed',
                data: {
                    payment_id: existingPayment.id,
                    reference_code: existingPayment.reference_code,
                    rental_id: existingPayment.rental_id,
                    status: 'paid',
                    amount: existingPayment.amount,
                    currency: existingPayment.currency,
                    processed_at: existingPayment.processed_at,
                    payment_method: existingPayment.payment_method,
                    rental: {
                        id: existingPayment.rental_id,
                        status: existingPayment.rental.status,
                        costume_name: existingPayment.rental.costume_snapshot?.name || 'Unknown Costume',
                        customer_name: existingPayment.rental.renter_snapshot?.name || 'Unknown Customer',
                        reference_code: existingPayment.rental.reference_code
                    }
                },
                already_paid: true
            }, 200);
        }

        // ═══════════════════════════════════════════════════════════════
        // 🔍 SESSION EXPIRY CHECK
        // ═══════════════════════════════════════════════════════════════
        if (existingPayment.session_expires_at && existingPayment.session_expires_at < new Date()) {
            console.warn('Payment session has expired');

            await db
                .update(rentalPaymentHistory)
                .set({
                    status: 'expired',
                    gateway_status: 'cancelled',
                    updated_at: new Date()
                })
                .where(eq(rentalPaymentHistory.id, existingPayment.id));

            return c.json({
                success: false,
                message: 'Payment session has expired',
                error: 'Please create a new payment session',
                data: {
                    session_expired_at: existingPayment.session_expires_at,
                    current_time: new Date()
                }
            }, 410);
        }

        // ═══════════════════════════════════════════════════════════════
        // 💳 GET PAYMENT STATUS FROM PAYMONGO
        // ═══════════════════════════════════════════════════════════════
        console.log('Fetching payment details from PayMongo for session:', session_id);

        let paymentSessionResponse;
        try {
            paymentSessionResponse = await getPaymentDetails(session_id);
        } catch (error: any) {
            console.error('Failed to get payment details from PayMongo:', error);

            // Handle network/service errors
            if (error.message?.includes('network') || error.message?.includes('timeout')) {
                console.log('Network error detected');

                if (existingPayment.status === 'processing') {
                    return c.json({
                        success: false,
                        message: 'Unable to verify payment status due to network issues',
                        error: 'Please try again in a few moments',
                        retry_after: 30
                    }, 503);
                }
            }

            return c.json({
                success: false,
                message: 'Payment verification failed',
                error: error.message || 'Unable to verify payment status'
            }, 502);
        }

        if (!paymentSessionResponse) {
            console.error('Payment details not found for session:', session_id);
            return c.json({
                success: false,
                message: 'Payment session not found or expired',
                error: 'Please create a new payment session'
            }, 404);
        }

        console.log('Payment details retrieved:', paymentSessionResponse);

        // ═══════════════════════════════════════════════════════════════
        // 🔄 STATUS MAPPING AND VALIDATION
        // ═══════════════════════════════════════════════════════════════
        const paymentStatus = paymentSessionResponse.status; // 'paid', 'pending', etc.
        const newGatewayStatus = mapGatewayStatus(paymentStatus === 'paid' ? 'succeeded' : paymentStatus);

        console.log('Status mapping:', {
            payment_service_status: paymentStatus,
            mapped_gateway_status: newGatewayStatus,
            current_status: existingPayment.status
        });

        // Check if status actually changed
        if (existingPayment.status === paymentStatus && existingPayment.gateway_status === newGatewayStatus) {
            console.log('Payment status unchanged:', paymentStatus);
            return c.json({
                success: true,
                message: 'Payment status is already up to date',
                data: {
                    payment_id: existingPayment.id,
                    reference_code: existingPayment.reference_code,
                    rental_id: existingPayment.rental_id,
                    current_status: paymentStatus,
                    amount: existingPayment.amount,
                    currency: existingPayment.currency,
                    last_checked: new Date()
                },
                no_changes: true
            }, 200);
        }

        // ═══════════════════════════════════════════════════════════════
        // 🔄 PREPARE UPDATE DATA
        // ═══════════════════════════════════════════════════════════════
        const updateData: any = {
            status: paymentStatus,
            gateway_status: newGatewayStatus,
            gateway_status_updated_at: new Date(),
            updated_at: new Date(),
        };

        // If payment succeeded, add processed info
        if (paymentStatus === 'paid') {
            updateData.processed_at = new Date();
            updateData.payment_reference = session_id;
            updateData.processor_notes = `Payment confirmed via PayMongo. Amount: ₱${paymentSessionResponse.amount}. Method: ${existingPayment.payment_method}`;
        }

        // Update metadata with payment service response
        const existingMetadata = existingPayment.metadata || {};
        updateData.metadata = {
            ...existingMetadata,
            payment_service_response: paymentSessionResponse,
            last_status_check: new Date().toISOString(),
            status_check_method: 'paymongo_payment_details',
            payment_method_details: {
                type: existingPayment.payment_method,
                amount: paymentSessionResponse.amount,
                currency: paymentSessionResponse.currency
            }
        };

        // Add status change event record
        const statusChangeEvent = {
            event_type: 'status_update',
            event_id: randomUUID(),
            timestamp: new Date().toISOString(),
            data: {
                previous_status: existingPayment.status,
                new_status: paymentStatus,
                previous_gateway_status: existingPayment.gateway_status,
                new_gateway_status: newGatewayStatus,
                payment_service_status: paymentStatus,
                updated_via: 'payment_confirmation',
                session_id: session_id,
                rental_id: existingPayment.rental_id,
                amount: paymentSessionResponse.amount,
                reference_code: reference_code
            }
        };

        const existingWebhooks = existingPayment.webhook_events || [];
        updateData.webhook_events = [...existingWebhooks, statusChangeEvent];

        console.log('Updating payment record with:', {
            payment_id: existingPayment.id,
            old_status: existingPayment.status,
            new_status: paymentStatus,
            update_fields: Object.keys(updateData)
        });

        // ═══════════════════════════════════════════════════════════════
        // 💾 UPDATE PAYMENT RECORD
        // ═══════════════════════════════════════════════════════════════
        const [updatedPayment] = await db
            .update(rentalPaymentHistory)
            .set(updateData)
            .where(eq(rentalPaymentHistory.id, existingPayment.id))
            .returning();

        console.log('Payment record updated successfully');

        // ═══════════════════════════════════════════════════════════════
        // 🎯 UPDATE RENTAL STATUS IF PAYMENT SUCCEEDED
        // ═══════════════════════════════════════════════════════════════
        let updatedRental = existingPayment.rental as any;
        if (paymentStatus === 'paid') {
            console.log('Payment succeeded, updating rental status to confirmed...');

            [updatedRental] = await db
                .update(rentals)
                .set({
                    status: 'confirmed',
                    updated_at: new Date()
                })
                .where(eq(rentals.id, existingPayment.rental_id))
                .returning();

            console.log('Rental status updated to confirmed');

            // TODO: Send notification to customer and business owner
            // You can implement socket notifications here if needed
        }

        // ═══════════════════════════════════════════════════════════════
        // 📤 RETURN SUCCESS RESPONSE
        // ═══════════════════════════════════════════════════════════════
        const response = {
            success: true,
            message: `Payment status updated successfully from ${existingPayment.status} to ${paymentStatus}`,
            data: {
                payment_id: updatedPayment?.id,
                reference_code: updatedPayment?.reference_code,
                session_id: session_id,
                rental_id: existingPayment.rental_id,
                status_change: {
                    previous_status: existingPayment.status,
                    current_status: paymentStatus,
                    payment_service_status: paymentStatus
                },
                payment_details: {
                    amount: paymentSessionResponse.amount,
                    currency: paymentSessionResponse.currency,
                    processed_at: updateData.processed_at,
                    payment_method: existingPayment.payment_method,
                    payment_reference: updateData.payment_reference
                },
                rental: {
                    id: existingPayment.rental_id,
                    status: paymentStatus === 'paid' ? 'confirmed' : existingPayment.rental.status,
                    costume_name: existingPayment.rental.costume_snapshot?.name || 'Unknown Costume',
                    customer_name: existingPayment.rental.renter_snapshot?.name || 'Unknown Customer',
                    reference_code: existingPayment.rental.reference_code
                },
                updated_at: updateData.updated_at
            }
        };

        console.log('Payment confirmation completed successfully');
        return c.json(response, 200);

    } catch (error: any) {
        console.error('Error in confirmPayment:', error);

        // Enhanced error handling with specific error types
        if (error.message?.includes('reference_code')) {
            return c.json({
                success: false,
                message: 'Reference code validation error',
                error: error.message
            }, 400);
        }

        if (error.message?.includes('Payment') || error.message?.includes('payment')) {
            return c.json({
                success: false,
                message: 'Payment service error',
                error: error.message
            }, 502);
        }

        if (error.message?.includes('database') || error.code) {
            return c.json({
                success: false,
                message: 'Database error occurred',
                error: 'Please try again later'
            }, 500);
        }

        return c.json({
            success: false,
            message: 'Failed to confirm payment',
            error: error.message || 'An unexpected error occurred'
        }, 500);
    }
};





// Get payment details after successful payment
export const getPaymentDetails = async (sessionId: string) => {
    try {
        console.log('Getting payment details for session:', sessionId);
        const paymentIntentResponse = await axios.get(
            `${PAYMONGO_API_URL}/payment_intents/${sessionId}`,
            {
                headers: {
                    'Authorization': getAuthHeader(),
                    'Content-Type': 'application/json'
                }
            }
        );
        const paymentIntent = paymentIntentResponse.data.data;
        const status = paymentIntent.attributes.status;
        let paymentDetails = {
            status: status === 'succeeded' ? 'paid' : status,
            amount: paymentIntent.attributes.amount / 100,
            currency: paymentIntent.attributes.currency,
            metadata: paymentIntent.attributes.metadata
        };
        if (status === 'succeeded') {
            try {
                const paymentsResponse = await axios.get(
                    `${PAYMONGO_API_URL}/payments?payment_intent=${sessionId}`,
                    {
                        headers: {
                            'Authorization': getAuthHeader(),
                            'Content-Type': 'application/json'
                        }
                    }
                );
                if (paymentsResponse.data.data && paymentsResponse.data.data.length > 0) {
                    const payment = paymentsResponse.data.data[0];

                }
            } catch (error: any) {
                console.error('Error fetching payment details:', error);
            }
        }
        return paymentDetails;
    } catch (error: any) {
        console.error('Error getting payment details:', error);
        throw error;
    }
};

// Get payment session endpoint
const getPaymentSession = async (c: Context) => {
    const sessionId = c.req.param('sessionId');
    try {
        console.log('Getting payment session for:', sessionId);
        const paymentDetails = await getPaymentDetails(sessionId);
        return c.json({
            success: true,
            sessionId,
            status: paymentDetails.status,

            paymentDetails,
            message: `Payment status: ${paymentDetails.status}`
        }, 200);
    } catch (error: any) {
        console.error('Error fetching payment session:', error);
        return c.json({
            success: false,
            message: 'Failed to fetch payment session',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        }, 500);
    }
};








export default { createRentalRequest, confirmPayment, getMyRentals, getLenderRentals, getRentalById, getRentalRejections, getTransactionsRentals, getAllRentalRejections, getPaymentSession, updateRentalRequestStatus, getBookedDateRanges, sendReturnProof };