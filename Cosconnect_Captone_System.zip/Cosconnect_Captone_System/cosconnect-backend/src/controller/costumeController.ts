import type { Context } from "hono"
import { and, desc, eq, count, sql, inArray } from "drizzle-orm"
import db from "../db/supabase/db_connect"
import { users } from "../schema/users.js"
import { CostumeAddOn, costumeAddOns, costumes, type NewCostume } from "@/schema/costumes"
import { costumeFormSchema, CostumeFormValues } from "@/lib/zodSchema/costumeSchema"


const editCostumeDataById = async (c: Context): Promise<Response> => {
    try {
        const costumeId = c.req.param('id');
        if (!costumeId) {
            return c.json({ error: 'Costume ID is required' }, 400);
        }

        // Get the update data from request body
        const updateData: any = await c.req.json();

        // Remove id if it exists in the payload to prevent updating the primary key
        delete updateData.id;

        // Add updated_at timestamp
        updateData.updated_at = new Date();

        // Update the costume in the database
        const [updatedCostume] = await db
            .update(costumes)
            .set(updateData)
            .where(eq(costumes.id, costumeId))
            .returning();

        if (!updatedCostume) {
            return c.json({ error: 'Costume not found' }, 404);
        }

        return c.json({
            success: true,
            data: updatedCostume
        });

    } catch (error) {
        console.error('Error updating costume:', error);
        return c.json({
            success: false,
            error: 'Failed to update costume',
            details: error instanceof Error ? error.message : 'Unknown error'
        }, 500);
    }
}

interface PaginationParams {
    page: number;
    limit: number;
}

interface PaginatedResponse<T> {
    data: T[];
    pagination: {
        total: number;
        page: number;
        limit: number;
        totalPages: number;
        hasNextPage: boolean;
        hasPreviousPage: boolean;
    };
}

const DEFAULT_PAGINATION: PaginationParams = {
    page: 1,
    limit: 10,
};

const getMyCostumes = async (c: Context): Promise<Response> => {
    try {
        // Get lender_uid from URL params
        const lender_uid = c.req.param("lenderId"); // or use "lender_uid" if that's your route param name

        if (!lender_uid) {
            return c.json({
                success: false,
                error: "Lender UID is required"
            }, 400);
        }

        // Validate UUID format
        const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
        if (!uuidRegex.test(lender_uid)) {
            return c.json({
                success: false,
                error: "Invalid lender UID format"
            }, 400);
        }

        // Parse pagination params from query string
        const query = c.req.query();
        const page = Math.max(1, Number(query.page) || DEFAULT_PAGINATION.page);
        const limit = Math.min(100, Math.max(1, Number(query.limit) || DEFAULT_PAGINATION.limit));
        const offset = (page - 1) * limit;

        // Check if lender exists in users table
        const lenderExists = await db
            .select({ uid: users.uid })
            .from(users)
            .where(eq(users.uid, lender_uid))
            .limit(1);

        if (lenderExists.length === 0) {
            return c.json({
                success: false,
                error: "Lender not found"
            }, 404);
        }

        // Count total costumes for this lender
        const countResult = await db
            .select({ count: sql<number>`count(*)::int` })
            .from(costumes)
            .where(eq(costumes.lender_uid, lender_uid));

        const totalCount = countResult[0]?.count ?? 0;

        // If no costumes found, return early
        if (totalCount === 0) {
            return c.json({
                success: true,
                data: [],
                pagination: {
                    total: 0,
                    page,
                    limit,
                    totalPages: 0,
                    hasNextPage: false,
                    hasPreviousPage: false,
                },
            });
        }

        // Fetch paginated costumes created by this lender
        const costumesData = await db
            .select()
            .from(costumes)
            .where(eq(costumes.lender_uid, lender_uid))
            .orderBy(desc(costumes.created_at))
            .limit(limit)
            .offset(offset);

        // Get add-ons for all fetched costumes
        let addOnsData: CostumeAddOn[] = [];

        if (costumesData.length > 0) {
            const costumeIds = costumesData.map(costume => costume.id);

            addOnsData = await db
                .select()
                .from(costumeAddOns)
                .where(inArray(costumeAddOns.costume_id, costumeIds))
                .orderBy(costumeAddOns.name);
        }

        // Group add-ons by costume_id for easier mapping
        const addOnsByCostume = addOnsData.reduce((acc, addOn) => {
            if (!acc[addOn.costume_id]) {
                acc[addOn.costume_id] = [];
            }
            acc[addOn.costume_id]?.push(addOn);
            return acc;
        }, {} as Record<string, CostumeAddOn[]>);

        // Combine costumes with their add-ons
        const costumesWithAddOns = costumesData.map(costume => ({
            ...costume,
            addOns: addOnsByCostume[costume.id] || []
        }));

        // Calculate pagination info
        const totalPages = Math.ceil(totalCount / limit);

        const response: PaginatedResponse<typeof costumesWithAddOns[0]> = {
            data: costumesWithAddOns,
            pagination: {
                total: totalCount,
                page,
                limit,
                totalPages,
                hasNextPage: page < totalPages,
                hasPreviousPage: page > 1,
            },
        };

        return c.json({
            success: true,
            ...response
        });

    } catch (error: any) {
        console.error("Error in getMyCostumes:", error);

        // Log the full error in development
        if (process.env.NODE_ENV === "development") {
            console.error("Full error details:", {
                message: error.message,
                stack: error.stack,
                cause: error.cause
            });
        }

        const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";

        return c.json(
            {
                success: false,
                error: "Failed to fetch costumes",
                ...(process.env.NODE_ENV === "development" && {
                    details: errorMessage,
                    stack: error.stack
                }),
            },
            500
        );
    }
};


/**
 * Custom error classes for better error handling
 */
class CostumeCreationError extends Error {
    constructor(
        message: string,
        public statusCode = 500,
        public code?: string,
    ) {
        super(message)
        this.name = "CostumeCreationError"
    }
}

class ValidationError extends CostumeCreationError {
    constructor(
        message: string,
        public errors?: any[],
    ) {
        super(message, 400, "VALIDATION_ERROR")
        this.name = "ValidationError"
    }
}

/**
 * Utility functions
 */
const isValidUUID = (uuid: string): boolean => {
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
    return uuidRegex.test(uuid)
}

const sanitizeString = (input: string | undefined | null, maxLength = 255): string => {
    if (!input) return ""
    return input.trim().slice(0, maxLength)
}

/**
 * Validates that the lender user exists in the database
 */
const validateLenderExists = async (lenderUid: string, requestId: string) => {
    if (!isValidUUID(lenderUid)) {
        throw new ValidationError("Invalid lender user ID format")
    }

    try {
        const lenderUser = await db
            .select({ uid: users.uid, username: users.username })
            .from(users)
            .where(eq(users.uid, lenderUid))
            .limit(1)

        if (!lenderUser || lenderUser.length === 0) {
            throw new CostumeCreationError("Lender user not found", 404, "LENDER_NOT_FOUND")
        }

        console.log(`[${requestId}] Lender user validated:`, lenderUser[0]?.username)
        return lenderUser[0]
    } catch (error) {
        if (error instanceof CostumeCreationError) throw error

        console.error(`[${requestId}] Database error while checking lender user:`, error)
        throw new CostumeCreationError("Database error while validating lender user", 500, "DB_ERROR")
    }
}

/**
 * Maps form data to database costume schema
 */
const mapToCostumeData = (
    validatedData: CostumeFormValues,
    lenderUid: string,
    requestBody: any
): NewCostume => {
    // Handle pricing based on listing type
    const rentalPrice = validatedData.listingType === "rent" || validatedData.listingType === "both"
        ? validatedData.price
        : "0"

    const salePrice = validatedData.listingType === "sale" || validatedData.listingType === "both"
        ? validatedData.sale_price || "0"
        : "0"

    return {
        // Basic information
        name: sanitizeString(validatedData.name, 255),
        brand: sanitizeString(validatedData.brand, 100),
        category: sanitizeString(validatedData.category, 100),
        description: sanitizeString(validatedData.description, 2000),
        gender: validatedData.gender,
        sizes: validatedData.sizes,
        tags: validatedData.tags || [],

        // Pricing and listing type
        listing_type: validatedData.listingType,
        rental_price: rentalPrice,
        sale_price: salePrice,
        security_deposit: validatedData.security_deposit || "0",
        discount_percentage: validatedData.discount
            ? Math.max(0, Math.min(100, Number.parseInt(validatedData.discount, 10) || 0))
            : 0,
        extended_days_price: validatedData.extended_days || "0",

        // Handle main images (front and back)
        main_images: {
            front: requestBody.mainImages?.front || "",
            back: requestBody.mainImages?.back || ""
        },
        // Handle additional images
        additional_images: (requestBody.additionalImages || []).map((img: any, index: number) => ({
            url: img.url || "",
            alt_text: img.alt_text || `Additional image ${index + 1} for ${validatedData.name}`,
            order: index + 1
        })),

        // References and status
        lender_uid: lenderUid,
        status: "active",
        is_available: true,
    }
}

/**
 * Maps add-on form data to database schema
 */
const mapToAddOnData = (addOns: NonNullable<CostumeFormValues['addOns']>, costumeId: string) => {
    return addOns.map((addOn: any) => ({
        costume_id: costumeId,
        name: sanitizeString(addOn.name, 100),
        description: sanitizeString(addOn.description, 500),
        price: Math.max(0, Number(addOn.price) || 0).toString(),
        image_url: null, // TODO: Handle image upload from addOn.image
        category: "accessory", // Default category
        is_included: false, // Default to paid add-on
        is_active: true,
    }))
}

/**
 * Main costume creation handler
 */
const createCostume = async (c: Context) => {
    const requestId = crypto.randomUUID()
    const startTime = Date.now()

    try {
        console.log(`[${requestId}] Starting costume creation request`)

        // Validate request context
        if (!c?.req) {
            throw new CostumeCreationError("Invalid request context", 400, "INVALID_CONTEXT")
        }

        // Parse request body
        let requestBody: any
        try {
            requestBody = await c.req.json()
            console.log(`[${requestId}] Request body parsed successfully`)
        } catch (parseError) {
            console.error(`[${requestId}] Failed to parse request body:`, parseError)
            throw new ValidationError("Invalid JSON in request body")
        }

        // Validate with Zod schema
        console.log(`[${requestId}] Starting schema validation`)
        const validationResult = costumeFormSchema.safeParse(requestBody)

        if (!validationResult.success) {
            console.error(`[${requestId}] Validation failed:`, validationResult.error.errors)
            throw new ValidationError("Validation failed", validationResult.error.errors)
        }

        const validatedData = validationResult.data
        console.log(`[${requestId}] Schema validation successful`)


        if (!requestBody.lenderUser?.uid) {
            throw new ValidationError("Lender user ID is required")
        }

        // Validate lender exists
        await validateLenderExists(requestBody.lenderUser.uid, requestId)

        // Prepare data for database insertion
        const costumeData = mapToCostumeData(validatedData, requestBody.lenderUser.uid, requestBody)
        console.log(`[${requestId}] Costume data prepared for insertion`)

        // Execute database transaction
        const result = await db.transaction(async (tx) => {
            // Insert costume
            const costumeResult = await tx
                .insert(costumes)
                .values(costumeData)
                .returning()

            if (!costumeResult?.[0]) {
                throw new CostumeCreationError("Failed to create costume", 500, "INSERTION_FAILED")
            }

            const newCostume = costumeResult[0]
            console.log(`[${requestId}] Costume created with ID: ${newCostume.id}`)

            // Insert add-ons if any (only for sale/both listing types)
            let addOnsCount = 0
            if (validatedData.addOns && validatedData.addOns.length > 0) {
                const addOnData = mapToAddOnData(validatedData.addOns, newCostume.id)
                await tx.insert(costumeAddOns).values(addOnData)
                addOnsCount = addOnData.length
                console.log(`[${requestId}] ${addOnsCount} add-ons created successfully`)
            }

            return { costume: newCostume, addOnsCount }
        })

        // Calculate request duration
        const duration = Date.now() - startTime
        console.log(`[${requestId}] Request completed successfully in ${duration}ms`)

        // Return success response
        return c.json(
            {
                success: true,
                message: "Costume created successfully",
                data: {
                    id: result.costume.id,
                    name: result.costume.name,
                    category: result.costume.category,
                    listing_type: result.costume.listing_type,
                    status: result.costume.status,
                    addOnsCount: result.addOnsCount,
                    created_at: result.costume.created_at,
                },
                requestId,
                duration: `${duration}ms`,
            },
            201,
        )
    } catch (error) {
        return handleError(error, requestId, Date.now() - startTime, c)
    }
}

/**
 * Centralized error handling
 */
const handleError = (error: unknown, requestId: string, duration: number, c: Context) => {
    console.error(`[${requestId}] Error in createCostume:`, {
        error: error instanceof Error ? {
            message: error.message,
            name: error.name,
            stack: error.stack,
        } : error,
        duration: `${duration}ms`,
        timestamp: new Date().toISOString(),
    })

    const baseResponse = {
        success: false,
        requestId,
        duration: `${duration}ms`,
    }

    // Handle validation errors
    if (error instanceof ValidationError) {
        return c.json({
            ...baseResponse,
            message: error.message,
            errors: error.errors,
        },)
    }

    // Handle custom costume creation errors
    if (error instanceof CostumeCreationError) {
        return c.json({
            ...baseResponse,
            message: error.message,
            code: error.code,
        },)
    }

    // Handle database constraint errors
    if (error instanceof Error) {
        if (error.message.includes("duplicate key") || error.message.includes("unique constraint")) {
            return c.json({
                ...baseResponse,
                message: "Costume with this name already exists",
                code: "DUPLICATE_COSTUME",
            }, 409)
        }

        if (error.message.includes("foreign key") || error.message.includes("referenced")) {
            return c.json({
                ...baseResponse,
                message: "Invalid lender user reference",
                code: "INVALID_REFERENCE",
            }, 400)
        }
    }

    // Generic server error
    return c.json({
        ...baseResponse,
        message: "Internal server error occurred while creating costume",
        code: "INTERNAL_ERROR",
    }, 500)
}


const getMarketplaceCostumes = async (c: Context): Promise<Response> => {
    try {
        const { page = '1', limit = '10' } = c.req.query();
        const currentPage = Math.max(parseInt(page) || 1, 1);
        const itemsPerPage = Math.min(Math.max(parseInt(limit) || 10, 1), 100);
        const offset = (currentPage - 1) * itemsPerPage;

        const [costumesResult, totalCountResult] = await Promise.all([
            // Get only costume data
            db
                .select()
                .from(costumes)
                .where(
                    and(
                        eq(costumes.status, 'active'),
                        eq(costumes.is_available, true)
                    )
                )
                .orderBy(desc(costumes.created_at))
                .limit(itemsPerPage)
                .offset(offset),

            // Get total count
            db
                .select({ count: count() })
                .from(costumes)
                .where(
                    and(
                        eq(costumes.status, 'active'),
                        eq(costumes.is_available, true)
                    )
                )
        ]);

        const totalCount = Number(totalCountResult[0]?.count) || 0;
        const totalPages = Math.ceil(totalCount / itemsPerPage);

        // Transform data for marketplace display
        const marketplaceCostumes = costumesResult.map((costume) => {
            const pricing: any = {};

            if (costume.listing_type === 'rent' || costume.listing_type === 'both') {
                pricing.rental = {
                    price: costume.rental_price,
                    security_deposit: costume.security_deposit,
                };
            }

            if (costume.listing_type === 'sale' || costume.listing_type === 'both') {
                pricing.sale = {
                    price: costume.sale_price,
                    discount_percentage: costume.discount_percentage,
                };
            }

            return {
                id: costume.id,
                name: costume.name,
                brand: costume.brand,
                category: costume.category,
                gender: costume.gender,
                sizes: costume.sizes,
                listing_type: costume.listing_type,
                pricing,
                main_images: costume.main_images,
                view_count: costume.view_count,
                favorite_count: costume.favorite_count,
                created_at: costume.created_at,
                tags: costume.tags
            };
        });

        return c.json({
            success: true,
            data: {
                costumes: marketplaceCostumes,
                pagination: {
                    page: currentPage,
                    limit: itemsPerPage,
                    total_count: totalCount,
                    total_pages: totalPages,
                    has_next_page: currentPage < totalPages,
                    has_previous_page: currentPage > 1,
                }
            },
            message: `Retrieved ${marketplaceCostumes.length} costumes`,
        }, 200);

    } catch (error) {
        console.error('Error fetching marketplace costumes:', error);
        return c.json({
            success: false,
            message: 'Failed to fetch marketplace costumes',
            data: null,
        }, 500);
    }
};




export default { createCostume, getMarketplaceCostumes, getMyCostumes, editCostumeDataById }