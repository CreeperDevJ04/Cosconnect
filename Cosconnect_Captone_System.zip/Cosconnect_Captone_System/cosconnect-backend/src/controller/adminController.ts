import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from "@firebase/auth";
import type { Context } from 'hono';
import { z } from "zod";
import { auth, clientAuth, db } from "../db/firebase/config";
import nodemailer from 'nodemailer';
import crypto from 'crypto';



// OTP storage (in production, use Redis or another persistent store)
const otpStore: Record<string, { otp: string; expires: number; tempToken: string }> = {};

// Input validation schemas
const emailSchema = z.string().email();
const passwordSchema = z.string().min(8, 'Password must be at least 8 characters long');
const phoneSchema = z.string().optional();
const nameSchema = z.string().min(2, 'Name must be at least 2 characters');
const otpSchema = z.string().regex(/^\d{6}$/, 'OTP must be a 6-digit number');
const statusSchema = z.enum(['approved', 'rejected', 'pending']);
const idSchema = z.string().min(1, 'ID is required');

// Configure nodemailer transporter
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER ,
        pass: process.env.EMAIL_PASSWORD || ''
    }
});

/**
 * Send OTP email to user
 * @param email User email
 * @param otp Generated OTP
 */
const sendOTPEmail = async (email: string, otp: string): Promise<boolean> => {
    try {
        const mailOptions = {
            from: process.env.EMAIL_USER ,
            to: email,
            subject: 'Your OTP Code',
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <h2 style="color: #333;">Your Verification Code</h2>
                    <p>Your OTP code is: <strong>${otp}</strong></p>
                    <p>This code will expire in 10 minutes.</p>
                    <p>If you didn't request this code, please ignore this email.</p>
                    <p style="color: #666; font-size: 12px; margin-top: 20px;">
                        This is an automated message, please do not reply.
                    </p>
                </div>
            `
        };

        await transporter.sendMail(mailOptions);
        return true;
    } catch (error) {
        console.error('Error sending OTP email:', error);
        return false;
    }
};

/**
 * Generate a 6-digit OTP and store it with expiration
 * @param email User email
 * @param tempToken Temporary token for session
 * @returns Generated OTP
 */
const generateOTP = (email: string, tempToken: string): string => {
    const otp = crypto.randomInt(100000, 999999).toString();
    // Store OTP with 10-minute expiration
    otpStore[email] = {
        otp,
        tempToken,
        expires: Date.now() + 10 * 60 * 1000 // 10 minutes
    };
    return otp;
};

// Resend OTP
const resendOTP = async (c: Context) => {
    try {
        const body: { email: string } = await c.req.json();
        const { email } = body;

        if (!email) {
            return c.json({
                success: false,
                message: 'Email is required'
            }, 400);
        }

        // Validate email format
        try {
            emailSchema.parse(email);
        } catch (error) {
            if (error instanceof z.ZodError) {
                return c.json({
                    success: false,
                    message: error.errors[0]?.message || 'Invalid email format'
                }, 400);
            }
            return c.json({ success: false, message: 'Invalid email format' }, 400);
        }

        // Check if user exists
        const userQuery = await db.collection('users')
            .where('email', '==', email)
            .limit(1)
            .get();

        if (userQuery.empty) {
            return c.json({
                success: false,
                message: 'User not found'
            }, 404);
        }

        const userDoc = userQuery.docs[0];
        if (!userDoc) {
            return c.json({
                success: false,
                message: 'User document not found'
            }, 404);
        }

        const userData = userDoc.data();
        if (!userData) {
            return c.json({
                success: false,
                message: 'User data not found'
            }, 404);
        }

        if (userData.role !== 'admin') {
            return c.json({
                success: false,
                message: 'Unauthorized access'
            }, 403);
        }

        // Generate new OTP
        const tempToken = userDoc.id;
        const otp = generateOTP(email, tempToken);

        // Send OTP email
        const emailSent = await sendOTPEmail(email, otp);

        if (!emailSent) {
            return c.json({
                success: false,
                message: 'Failed to send OTP email'
            }, 500);
        }

        return c.json({
            success: true,
            message: 'New verification code sent to your email',
            tempToken
        });
    } catch (error: any) {
        console.error('Resend OTP Error:', error);
        return c.json({
            success: false,
            message: error.message || 'Failed to resend verification code'
        }, 500);
    }
};

/**
 * Initial admin sign-in with email and password
 * @param c Hono context
 */
const initiateAdminSignIn = async (c: Context) => {
    try {
        const body = await c.req.json();
        const { email, password } = body;

        // Validate inputs
        try {
            emailSchema.parse(email);
            passwordSchema.parse(password);
        } catch (error) {
            if (error instanceof z.ZodError) {
                return c.json({
                    success: false,
                    message: error.errors[0]?.message
                }, 400);
            }
            return c.json({ success: false, message: 'Invalid input' }, 400);
        }

        try {
            // First, verify credentials with Firebase Auth
            const userCredential = await signInWithEmailAndPassword(clientAuth, email, password);

            // Check if user is admin in Firestore
            const userDoc = await db.collection('users').doc(userCredential.user.uid).get();
            const userData = userDoc.data();

            if (!userDoc.exists || userData?.role !== 'admin') {
                return c.json({ success: false, message: 'Unauthorized access' }, 403);
            }

            // Generate and send OTP
            const tempToken = userCredential.user.uid;
            const otp = generateOTP(email, tempToken);
            const emailSent = await sendOTPEmail(email, otp);

            if (!emailSent) {
                return c.json({
                    success: false,
                    message: 'Failed to send OTP email'
                }, 500);
            }

            // Return temporary session token
            return c.json({
                success: true,
                message: 'OTP sent to your email',
                tempToken
            });

        } catch (error) {
            console.error('Sign-in error:', error);
            return c.json({
                success: false,
                message: 'Invalid credentials'
            }, 401);
        }
    } catch (error) {
        console.error('Admin Sign In Error:', error);
        return c.json({
            success: false,
            message: error instanceof Error ? error.message : 'An unexpected error occurred'
        }, 500);
    }
};

/**
 * Verify OTP and complete admin sign-in
 * @param c Hono context
 */
const verifyAdminOTP = async (c: Context) => {
    try {
        const body = await c.req.json();
        const { email, otp, tempToken } = body;

        // Validate inputs
        try {
            emailSchema.parse(email);
            otpSchema.parse(otp);
            if (!tempToken) throw new Error('Temporary token is required');
        } catch (error) {
            if (error instanceof z.ZodError) {
                return c.json({
                    success: false,
                    message: error.errors[0]?.message
                }, 400);
            }
            return c.json({
                success: false,
                message: error instanceof Error ? error.message : 'Invalid input'
            }, 400);
        }

        // Verify OTP
        const storedOTP = otpStore[email];
        if (!storedOTP) {
            return c.json({ success: false, message: 'No OTP request found' }, 400);
        }

        // Verify tempToken matches
        if (storedOTP.tempToken !== tempToken) {
            return c.json({ success: false, message: 'Invalid session' }, 401);
        }

        // Verify OTP
        if (storedOTP.otp !== otp) {
            return c.json({ success: false, message: 'Invalid OTP' }, 400);
        }

        // Check if OTP is expired
        if (Date.now() > storedOTP.expires) {
            delete otpStore[email];
            return c.json({ success: false, message: 'OTP has expired' }, 400);
        }

        // Clean up used OTP
        delete otpStore[email];

        // Fetch complete user data
        const userDoc = await db.collection('users').doc(tempToken).get();
        const userData = userDoc.data();

        if (!userDoc.exists || userData?.role !== 'admin') {
            return c.json({ success: false, message: 'User not found or unauthorized' }, 404);
        }

        // Update last login
        await db.collection('users').doc(tempToken).update({
            lastLogin: new Date().toISOString()
        });

        // Return complete user data for the session
        return c.json({
            success: true,
            message: 'Authentication successful',
            user: {
                id: userDoc.id,
                ...userData
            }
        });

    } catch (error) {
        console.error('OTP Verification Error:', error);
        return c.json({
            success: false,
            message: error instanceof Error ? error.message : 'An unexpected error occurred'
        }, 500);
    }
};

/**
 * Create a new admin user
 * @param c Hono context
 */
const createAdmin = async (c: Context) => {
    try {
        const body = await c.req.json();
        const { email, password, phoneNumber, adminName } = body;

        // Validate inputs
        try {
            emailSchema.parse(email);
            passwordSchema.parse(password);
            nameSchema.parse(adminName);
            if (phoneNumber) phoneSchema.parse(phoneNumber);
        } catch (error: any) {
            if (error instanceof z.ZodError) {
                return c.json({
                    success: false,
                    message: error.errors[0]?.message
                }, 400);
            }
            return c.json({ success: false, message: 'Invalid input' }, 400);
        }

        // Check if user already exists in Firestore
        const existingUser = await db.collection('users')
            .where('email', '==', email)
            .limit(1)
            .get();

        if (!existingUser.empty) {
            return c.json({ success: false, message: 'User with this email already exists' }, 409);
        }

        // Create user in Firebase Authentication
        const userCredential = await createUserWithEmailAndPassword(clientAuth, email, password);
        const user = userCredential.user;

        // Create user document in Firestore
        const userData = {
            uid: user.uid,
            email: user.email,
            adminName,
            phoneNumber: phoneNumber || null,
            role: 'admin',
            active: true, // Changed from false to true for immediate access
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            lastLogin: null
        };

        await db.collection('users').doc(user.uid).set(userData);

        return c.json({
            success: true,
            message: 'Admin created successfully',
            user: userData
        });
    } catch (error) {
        console.error('Create Admin Error:', error);
        return c.json({
            success: false,
            message: error instanceof Error ? error.message : 'An unexpected error occurred'
        }, 500);
    }
};

/**
 * Get all borrowers with pagination and total count
 */
const getAllCreatedBorrowers = async (c: Context) => {
    try {
        // Extract pagination parameters from query
        const page = Number(c.req.query('page')) || 1;
        const limit = Number(c.req.query('limit')) || 10;
        const startAfter = c.req.query('startAfter'); // For cursor-based pagination

        // Create base query
        let query = db.collection('users')
            .where('role', '==', 'borrower')
            .orderBy('createdAt', 'desc') // Assuming you have a createdAt field
            .limit(limit);

        // Apply cursor-based pagination if startAfter is provided
        if (startAfter) {
            const lastDocSnapshot = await db.collection('users').doc(startAfter).get();
            if (lastDocSnapshot.exists) {
                query = query.startAfter(lastDocSnapshot);
            }
        }

        // Execute query
        const borrowersSnapshot = await query.get();

        // Get total count for pagination info
        const totalCountSnapshot = await db.collection('users')
            .where('role', '==', 'borrower')
            .count()
            .get();

        const totalCount = totalCountSnapshot.data().count;
        const totalPages = Math.ceil(totalCount / limit);

        // Map the data and include document IDs
        const borrowers = borrowersSnapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));

        // Get the ID of the last document for cursor-based pagination
        const lastDoc = borrowersSnapshot.docs[borrowersSnapshot.docs.length - 1];
        const lastDocId = lastDoc?.id || null;

        return c.json({
            success: true,
            borrowers,
            totalBorrowers: totalCount, // Added total count specifically
            pagination: {
                total: totalCount,
                page,
                limit,
                totalPages,
                hasMore: page < totalPages,
                lastDocId
            }
        });
    } catch (error) {
        console.error("Error getting all created borrowers:", error);
        return c.json({
            success: false,
            message: error instanceof Error ? error.message : 'An unexpected error occurred'
        }, 500);
    }
}

/**
 * Get all lenders with pagination and total count
 */
const getAllCreatedLenders = async (c: Context) => {
    try {
        // Extract pagination parameters from query
        const page = Number(c.req.query('page')) || 1;
        const limit = Number(c.req.query('limit')) || 10;
        const startAfter = c.req.query('startAfter'); // For cursor-based pagination

        // Create base query with proper indexes
        let query = db.collection('users')
            .where('role', '==', 'lender')
            .orderBy('createdAt', 'desc')
            .limit(limit);

        // Apply cursor-based pagination if startAfter is provided
        if (startAfter) {
            const lastDocSnapshot = await db.collection('users').doc(startAfter).get();
            if (lastDocSnapshot.exists) {
                query = query.startAfter(lastDocSnapshot);
            }
        }

        // Execute query with Promise.all for concurrent requests
        const [lendersSnapshot, totalCountSnapshot] = await Promise.all([
            query.get(),
            db.collection('users').where('role', '==', 'lender').count().get()
        ]);

        const totalCount = totalCountSnapshot.data().count;
        const totalPages = Math.ceil(totalCount / limit);

        // Map the data and include document IDs
        const lenders = lendersSnapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));

        // Get the ID of the last document for cursor-based pagination
        const lastDoc = lendersSnapshot.docs[lendersSnapshot.docs.length - 1];
        const lastDocId = lastDoc?.id || null;

        return c.json({
            success: true,
            lenders,
            totalLenders: totalCount,
            pagination: {
                total: totalCount,
                page,
                limit,
                totalPages,
                hasMore: page < totalPages,
                lastDocId
            }
        });
    } catch (error) {
        console.error("Error getting all created lenders:", error);
        return c.json({
            success: false,
            message: error instanceof Error ? error.message : 'An unexpected error occurred'
        }, 500);
    }
}

const updateBorrowerStatus = async (c: Context) => {
    try {
        const body = await c.req.json();
        const { borrowerId, status } = body;

        // Validate inputs
        try {
            idSchema.parse(borrowerId);
            statusSchema.parse(status);
        } catch (error) {
            if (error instanceof z.ZodError) {
                return c.json({
                    success: false,
                    message: error.errors[0]?.message || 'Invalid input data'
                }, 400);
            }
            return c.json({ success: false, message: 'Invalid input data' }, 400);
        }

        // First query all borrowers to ensure the collection and role filtering works
        const borrowersQuery = await db.collection('users').where('role', '==', 'borrower').get();

        if (borrowersQuery.empty) {
            return c.json({
                success: false,
                message: 'No borrowers found in the system'
            }, 404);
        }

        // Check if our specific borrower exists in the results
        let borrowerExists = false;
        let borrowerData = null;

        borrowersQuery.forEach(doc => {
            if (doc.id === borrowerId) {
                borrowerExists = true;
                borrowerData = doc.data();
            }
        });

        if (!borrowerExists) {
            // If not found in the initial query, try direct lookup
            const directLookup = await db.collection('users').doc(borrowerId).get();

            if (!directLookup.exists) {
                return c.json({
                    success: false,
                    message: 'Borrower with specified ID not found'
                }, 404);
            }

            borrowerData = directLookup.data();

            // Check if the directly looked up user is actually a borrower
            if (borrowerData?.role !== 'borrower') {
                return c.json({
                    success: false,
                    message: 'User exists but is not a borrower'
                }, 400);
            }
        }

        // Update borrower status
        await db.collection('users').doc(borrowerId).update({
            status,
            updatedAt: new Date().toISOString()
        });

        return c.json({
            success: true,
            message: 'Borrower status updated successfully',
            data: {
                borrowerId,
                status,
                updatedAt: new Date().toISOString()
            }
        });

    } catch (error) {
        console.error("Error updating borrower status:", error);
        return c.json({
            success: false,
            message: error instanceof Error ? error.message : 'An unexpected error occurred while updating borrower status'
        }, 500);
    }
};

const updateLenderStatus = async (c: Context) => {
    try {
        const body = await c.req.json();
        const { lenderId, status } = body;

        // Validate inputs
        try {
            idSchema.parse(lenderId);
            statusSchema.parse(status);
        } catch (error) {
            if (error instanceof z.ZodError) {
                return c.json({
                    success: false,
                    message: error.errors[0]?.message || 'Invalid input data'
                }, 400);
            }
            return c.json({ success: false, message: 'Invalid input data' }, 400);
        }

        // First query all lenders to ensure the collection and role filtering works
        const lendersQuery = await db.collection('users').where('role', '==', 'lender').get();

        if (lendersQuery.empty) {
            return c.json({
                success: false,
                message: 'No lenders found in the system'
            }, 404);
        }

        // Check if our specific lender exists in the results
        let lenderExists = false;
        let lenderData = null;

        lendersQuery.forEach(doc => {
            if (doc.id === lenderId) {
                lenderExists = true;
                lenderData = doc.data();
            }
        });

        if (!lenderExists) {
            // If not found in the initial query, try direct lookup
            const directLookup = await db.collection('users').doc(lenderId).get();

            if (!directLookup.exists) {
                return c.json({
                    success: false,
                    message: 'Lender with specified ID not found'
                }, 404);
            }

            lenderData = directLookup.data();

            // Check if the directly looked up user is actually a lender
            if (lenderData?.role !== 'lender') {
                return c.json({
                    success: false,
                    message: 'User exists but is not a lender'
                }, 400);
            }
        }

        // Update lender status
        await db.collection('users').doc(lenderId).update({
            status,
            updatedAt: new Date().toISOString()
        });

        return c.json({
            success: true,
            message: 'Lender status updated successfully',
            data: {
                lenderId,
                status,
                updatedAt: new Date().toISOString()
            }
        });

    } catch (error) {
        console.error("Error updating lender status:", error);
        return c.json({
            success: false,
            message: error instanceof Error ? error.message : 'An unexpected error occurred while updating lender status'
        }, 500);
    }
};

const deleteBorrowerAccount = async (c: Context) => {
    try {
        const body = await c.req.json();
        const { borrowerId, reason } = body;
        console.log("Borrower ID:", borrowerId);
        console.log("Reason:", reason);
        // Validate inputs
        try {
            idSchema.parse(borrowerId);
        } catch (error) {
            if (error instanceof z.ZodError) {
                return c.json({
                    success: false,
                    message: error.errors[0]?.message || 'Invalid input data'
                }, 400);
            }
            return c.json({ success: false, message: 'Invalid input data' }, 400);
        }

        // First query to check if the borrower exists
        const borrowersQuery = await db.collection('users').where('role', '==', 'borrower').get();

        if (borrowersQuery.empty) {
            return c.json({
                success: false,
                message: 'No borrowers found in the system'
            }, 404);
        }

        // Find the borrower by ID
        let borrowerExists = false;
        let borrowerData = null;

        borrowersQuery.forEach(doc => {
            if (doc.id === borrowerId) {
                borrowerExists = true;
                borrowerData = doc.data();
            }
        });

        if (!borrowerExists) {
            // Direct lookup as fallback
            const directLookup = await db.collection('users').doc(borrowerId).get();

            if (!directLookup.exists) {
                return c.json({
                    success: false,
                    message: 'Borrower with specified ID not found'
                }, 404);
            }

            borrowerData = directLookup.data();

            if (borrowerData?.role !== 'borrower') {
                return c.json({
                    success: false,
                    message: 'User exists but is not a borrower'
                }, 400);
            }
        }

        // Get borrower email for notification
        const email = borrowerData?.email;
        if (!email) {
            return c.json({
                success: false,
                message: 'Borrower email not found, cannot send deletion notification'
            }, 400);
        }

        // Save deletion record to a separate collection for audit purposes
        await db.collection('deletedAccounts').add({
            userId: borrowerId,
            email,
            role: 'borrower',
            reason,
            deletedAt: new Date().toISOString(),
            originalData: borrowerData
        });

        // Send deletion notification email
        const emailSent = await sendDeletionEmail(email, reason);

        // Delete the borrower account
        await db.collection('users').doc(borrowerId).delete();

        // If user auth needs to be deleted as well, uncomment this:
        // try {
        //     await auth.deleteUser(borrowerId);
        // } catch (authError) {
        //     console.error("Error deleting auth user:", authError);
        // }

        return c.json({
            success: true,
            message: 'Borrower account deleted successfully',
            data: {
                borrowerId,
                emailSent,
                deletedAt: new Date().toISOString()
            }
        });

    } catch (error) {
        console.error("Error deleting borrower account:", error);
        return c.json({
            success: false,
            message: error instanceof Error ? error.message : 'An unexpected error occurred while deleting borrower account'
        }, 500);
    }
};

// New function for deleting lender account
const deleteLenderAccount = async (c: Context) => {
    try {
        const body = await c.req.json();
        const { lenderId, reason } = body;

        // Validate inputs
        try {
            idSchema.parse(lenderId);
        } catch (error) {
            if (error instanceof z.ZodError) {
                return c.json({
                    success: false,
                    message: error.errors[0]?.message || 'Invalid input data'
                }, 400);
            }
            return c.json({ success: false, message: 'Invalid input data' }, 400);
        }

        // First query to check if the lender exists
        const lendersQuery = await db.collection('users').where('role', '==', 'lender').get();

        if (lendersQuery.empty) {
            return c.json({
                success: false,
                message: 'No lenders found in the system'
            }, 404);
        }

        // Find the lender by ID
        let lenderExists = false;
        let lenderData = null;

        lendersQuery.forEach(doc => {
            if (doc.id === lenderId) {
                lenderExists = true;
                lenderData = doc.data();
            }
        });

        if (!lenderExists) {
            // Direct lookup as fallback
            const directLookup = await db.collection('users').doc(lenderId).get();

            if (!directLookup.exists) {
                return c.json({
                    success: false,
                    message: 'Lender with specified ID not found'
                }, 404);
            }

            lenderData = directLookup.data();

            if (lenderData?.role !== 'lender') {
                return c.json({
                    success: false,
                    message: 'User exists but is not a lender'
                }, 400);
            }
        }

        // Get lender email for notification
        const email = lenderData?.email;
        if (!email) {
            return c.json({
                success: false,
                message: 'Lender email not found, cannot send deletion notification'
            }, 400);
        }

        // Save deletion record to a separate collection for audit purposes
        await db.collection('deletedAccounts').add({
            userId: lenderId,
            email,
            role: 'lender',
            reason,
            deletedAt: new Date().toISOString(),
            originalData: lenderData
        });

        // Send deletion notification email
        const emailSent = await sendDeletionEmail(email, reason);

        // Delete the lender account
        await db.collection('users').doc(lenderId).delete();

        // If user auth needs to be deleted as well, uncomment this:
        // try {
        //     await auth.deleteUser(lenderId);
        // } catch (authError) {
        //     console.error("Error deleting auth user:", authError);
        // }

        return c.json({
            success: true,
            message: 'Lender account deleted successfully',
            data: {
                lenderId,
                emailSent,
                deletedAt: new Date().toISOString()
            }
        });

    } catch (error) {
        console.error("Error deleting lender account:", error);
        return c.json({
            success: false,
            message: error instanceof Error ? error.message : 'An unexpected error occurred while deleting lender account'
        }, 500);
    }
};

// Email sending function for account deletion
const sendDeletionEmail = async (email: string, reason: string) => {
    try {
        // Configure nodemailer transporter (update with your email service details)
        const transporter = nodemailer.createTransport({
            // Example for Gmail
            service: 'gmail',
            auth: {
                user: process.env.EMAIL_USER,
                pass: process.env.EMAIL_PASSWORD
            }
        });

        const emailTemplate = `
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Account Deletion Notification</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    line-height: 1.6;
                    color: #333;
                    max-width: 600px;
                    margin: 0 auto;
                    padding: 20px;
                }
                .header {
                    background-color: #f44336;
                    color: white;
                    padding: 20px;
                    text-align: center;
                    border-radius: 5px 5px 0 0;
                }
                .content {
                    background-color: #f9f9f9;
                    padding: 20px;
                    border-left: 1px solid #ddd;
                    border-right: 1px solid #ddd;
                    border-bottom: 1px solid #ddd;
                    border-radius: 0 0 5px 5px;
                }
                .footer {
                    text-align: center;
                    margin-top: 20px;
                    font-size: 12px;
                    color: #777;
                }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>Account Deletion Notification</h1>
            </div>
            <div class="content">
                <p>Dear User,</p>
                
                <p>We regret to inform you that your account with our service has been deleted.</p>
                
                <p><strong>Reason for deletion:</strong> ${reason || 'Administrative decision'}</p>
                
                <p>If you believe this action was taken in error or would like to discuss this further, please contact our support team at <a href="mailto:support@example.com">support@example.com</a>.</p>
                
                <p>We appreciate your understanding.</p>
                
                <p>Best regards,<br>
                The Support Team</p>
            </div>
            <div class="footer">
                <p>This is an automated message. Please do not reply to this email.</p>
                <p>&copy; ${new Date().getFullYear()} Your Company Name. All rights reserved.</p>
            </div>
        </body>
        </html>
        `;

        // Send email
        const info = await transporter.sendMail({
            from: `"Account Services" <${process.env.EMAIL_USER}>`,
            to: email,
            subject: "Your Account Has Been Deleted",
            html: emailTemplate
        });

        console.log("Email sent: %s", info.messageId);
        return true;
    } catch (error) {
        console.error("Error sending deletion email:", error);
        return false;
    }
};



export default {
    initiateAdminSignIn,
    verifyAdminOTP,
    createAdmin,
    getAllCreatedBorrowers,
    getAllCreatedLenders,
    updateBorrowerStatus,
    updateLenderStatus,
    deleteBorrowerAccount,
    deleteLenderAccount,
    resendOTP
};