import { eq, and, sql } from "drizzle-orm"
import type { Context } from "hono"
import db from "../db/supabase/db_connect"
import { tags } from "../schema/tags"

/**
 * Get all active tags with pagination
 * @param c - Hono Context
 * @returns JSON response with tags and pagination
 */
const getAllTags = async (c: Context) => {
    try {
        // Get pagination parameters
        const page = Math.max(1, parseInt(c.req.query('page') || '1'))
        const limit = Math.min(100, Math.max(1, parseInt(c.req.query('limit') || '10')))
        const offset = (page - 1) * limit

        // Get total count
        const totalResult = await db
            .select({ count: sql<number>`count(*)` })
            .from(tags)
            .where(eq(tags.status, 'active'))

        const total = totalResult[0]?.count || 0

        // Get paginated tags
        const tagsData = await db
            .select()
            .from(tags)
            .where(eq(tags.status, 'active'))
            .orderBy(tags.createdAt)
            .limit(limit)
            .offset(offset)

        const totalPages = Math.ceil(total / limit)

        return c.json({
            success: true,
            data: {
                tags: tagsData,
                pagination: {
                    total,
                    page,
                    limit,
                    totalPages,
                    hasNextPage: page < totalPages,
                    hasPrevPage: page > 1
                }
            }
        })

    } catch (error) {
        console.error('[getAllTags] Error fetching tags:', error)
        return c.json({
            success: false,
            message: 'Failed to fetch tags',
            error: error instanceof Error ? error.message : 'Unknown error'
        }, 500)
    }
}

/**
 * Get tags by category slug with pagination
 * @param c - Hono Context
 * @returns JSON response with tags and pagination
 */
const getTagsByCategory = async (c: Context) => {
    try {
        const categorySlug = c.req.param('category')

        if (!categorySlug) {
            return c.json({
                success: false,
                message: 'Category slug is required'
            }, 400)
        }

        // Get pagination parameters
        const page = Math.max(1, parseInt(c.req.query('page') || '1'))
        const limit = Math.min(100, Math.max(1, parseInt(c.req.query('limit') || '10')))
        const offset = (page - 1) * limit

        // Get total count
        const totalResult = await db
            .select({ count: sql<number>`count(*)` })
            .from(tags)
            .where(and(
                eq(tags.status, 'active'),
                eq(tags.category, categorySlug)
            ))

        const total = totalResult[0]?.count || 0

        // Get paginated tags by category
        const tagsData = await db
            .select()
            .from(tags)
            .where(and(
                eq(tags.status, 'active'),
                eq(tags.category, categorySlug)
            ))
            .orderBy(tags.createdAt)
            .limit(limit)
            .offset(offset)

        const totalPages = Math.ceil(total / limit)

        return c.json({
            success: true,
            data: {
                tags: tagsData,
                category: categorySlug,
                pagination: {
                    total,
                    page,
                    limit,
                    totalPages,
                    hasNextPage: page < totalPages,
                    hasPrevPage: page > 1
                }
            }
        })

    } catch (error) {
        console.error('[getTagsByCategory] Error fetching tags by category:', error)
        return c.json({
            success: false,
            message: 'Failed to fetch tags by category',
            error: error instanceof Error ? error.message : 'Unknown error'
        }, 500)
    }
}

/**
 * Get a single tag by ID
 * @param c - Hono Context
 * @returns JSON response with tag data
 */
const getTagById = async (c: Context) => {
    try {
        const tagId = c.req.param('id')

        if (!tagId) {
            return c.json({
                success: false,
                message: 'Tag ID is required'
            }, 400)
        }

        const [tag] = await db
            .select()
            .from(tags)
            .where(eq(tags.id, tagId))
            .limit(1)

        if (!tag) {
            return c.json({
                success: false,
                message: 'Tag not found'
            }, 404)
        }

        return c.json({
            success: true,
            data: tag
        })

    } catch (error) {
        console.error('[getTagById] Error fetching tag:', error)
        return c.json({
            success: false,
            message: 'Failed to fetch tag',
            error: error instanceof Error ? error.message : 'Unknown error'
        }, 500)
    }
}

/**
 * Get a single tag by slug
 * @param c - Hono Context
 * @returns JSON response with tag data
 */
const getTagBySlug = async (c: Context) => {
    try {
        const slug = c.req.param('slug')

        if (!slug) {
            return c.json({
                success: false,
                message: 'Tag slug is required'
            }, 400)
        }

        const [tag] = await db
            .select()
            .from(tags)
            .where(eq(tags.slug, slug))
            .limit(1)

        if (!tag) {
            return c.json({
                success: false,
                message: 'Tag not found'
            }, 404)
        }

        return c.json({
            success: true,
            data: tag
        })

    } catch (error) {
        console.error('[getTagBySlug] Error fetching tag:', error)
        return c.json({
            success: false,
            message: 'Failed to fetch tag',
            error: error instanceof Error ? error.message : 'Unknown error'
        }, 500)
    }
}

export default {
    getAllTags,
    getTagsByCategory,
    getTagById,
    getTagBySlug
}