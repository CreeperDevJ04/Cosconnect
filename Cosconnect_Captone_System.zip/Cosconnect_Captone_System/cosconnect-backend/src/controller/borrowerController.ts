import { BorrowerData } from "@/lib/types/borrower";
import { Identification } from "@/types/lenderTypes";
import { signInWithEmailAndPassword } from "@firebase/auth";
import type { Context } from 'hono';
import nodemailer from 'nodemailer';
import { auth, clientAuth } from "../db/firebase/config";
import { db } from "../db/firebase/firebaseAdmin";
import { transporter } from "@/lib/nodemailer/transporter";




// Define the user type



// OTP utility functions
const generateOTP = (): string => {
    return Math.floor(100000 + Math.random() * 900000).toString();
};

const storeOTP = async (email: string, otp: string): Promise<void> => {
    const expiresAt = new Date();
    expiresAt.setMinutes(expiresAt.getMinutes() + 10); // OTP valid for 10 minutes

    // Generate a unique ID for the OTP record
    const otpId = `${email}_${Date.now()}`;

    // Store OTP in Firestore with expiration time
    await db.collection("otpCodes").doc(otpId).set({
        email,
        otp,
        expiresAt: expiresAt.toISOString(),
        createdAt: new Date().toISOString(),
        attempts: 0,
        isUsed: false
    });
};

const verifyOTP = async (email: string, userOtp: string): Promise<{ isValid: boolean; message: string }> => {
    try {
        console.log("email", email);
        console.log("userOtp", userOtp);

        // Find OTP record for this email
        const otpSnapshot = await db.collection("otpCodes")
            .where("email", "==", email)
            .where("otp", "==", userOtp)
            .get();

        if (otpSnapshot.empty) {
            // Check if user exists in auth and delete if verification fails
            try {
                const user = await auth.getUserByEmail(email);
                if (user) {
                    await auth.deleteUser(user.uid);
                }
            } catch (error) {
                // User doesn't exist in auth, which is fine
            }
            return {
                isValid: false,
                message: "Invalid verification code. Please try again."
            };
        }

        const otpDoc = otpSnapshot.docs[0];
        if (!otpDoc) {
            // Check if user exists in auth and delete if verification fails
            try {
                const user = await auth.getUserByEmail(email);
                if (user) {
                    await auth.deleteUser(user.uid);
                }
            } catch (error) {
                // User doesn't exist in auth, which is fine
            }
            return {
                isValid: false,
                message: "No OTP document found. Please request a new verification code."
            };
        }

        const otpData = otpDoc.data();
        const expiresAt = new Date(otpData.expiresAt);

        // Check if OTP is expired
        if (expiresAt < new Date()) {
            // Check if user exists in auth and delete if verification fails
            try {
                const user = await auth.getUserByEmail(email);
                if (user) {
                    await auth.deleteUser(user.uid);
                }
            } catch (error) {
                // User doesn't exist in auth, which is fine
            }
            return {
                isValid: false,
                message: "Verification code has expired. Please request a new code."
            };
        }

        // Check if OTP is already used
        if (otpData.isUsed) {
            // Check if user exists in auth and delete if verification fails
            try {
                const user = await auth.getUserByEmail(email);
                if (user) {
                    await auth.deleteUser(user.uid);
                }
            } catch (error) {
                // User doesn't exist in auth, which is fine
            }
            return {
                isValid: false,
                message: "This verification code has already been used. Please request a new code."
            };
        }

        // Mark OTP as used
        await otpDoc.ref.update({ isUsed: true });

        return {
            isValid: true,
            message: "OTP verified successfully"
        };
    } catch (error) {
        console.error("Error verifying OTP:", error);
        // Check if user exists in auth and delete if verification fails
        try {
            const user = await auth.getUserByEmail(email);
            if (user) {
                await auth.deleteUser(user.uid);
            }
        } catch (authError) {
            // User doesn't exist in auth, which is fine
        }
        return {
            isValid: false,
            message: "An error occurred while verifying the code. Please try again."
        };
    }
};

const sendOTPEmail = async (userData: { email: string, fullName: string }, otp: string): Promise<void> => {
    const mailOptions = {
        from: process.env.EMAIL_USER ,
        to: userData.email,
        subject: 'CosConnect Email Verification Code',
        html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2>Verify Your Email Address</h2>
                <p>Hello ${userData.fullName},</p>
                <p>Thank you for registering with CosConnect. To complete your registration, please use the following verification code:</p>
                <div style="background-color: #f4f4f4; padding: 15px; text-align: center; font-size: 24px; font-weight: bold; letter-spacing: 5px; margin: 20px 0;">
                    ${otp}
                </div>
                <p>This code will expire in 10 minutes.</p>
                <p>If you didn't request this code, please ignore this email.</p>
                <p>Best regards,<br>The CosConnect Team</p>
            </div>
        `
    };

    await transporter.sendMail(mailOptions);
};

// Request OTP for email verification
const requestOTP = async (c: Context) => {
    try {
        const body: { email: string, fullName: string } = await c.req.json();
        const { email, fullName } = body;

        if (!email) {
            return c.json({
                success: false,
                message: 'Email is required'
            }, 400);
        }

        // Generate and store OTP
        const otp = generateOTP();
        await storeOTP(email, otp);

        // Send OTP email
        await sendOTPEmail({ email, fullName }, otp);

        return c.json({
            success: true,
            message: 'Verification code sent to your email'
        });
    } catch (error: any) {
        console.error('OTP Request Error:', error);
        return c.json({
            success: false,
            message: error.message || 'Failed to send verification code'
        }, 500);
    }
};



// Resend OTP
const resendOTP = async (c: Context) => {
    try {
        const body: { email: string, fullName: string } = await c.req.json();
        const { email, fullName } = body;

        if (!email) {
            return c.json({
                success: false,
                message: 'Email is required'
            }, 400);
        }

        // Generate and store new OTP
        const otp = generateOTP();
        await storeOTP(email, otp);

        // Send OTP email
        await sendOTPEmail({ email, fullName }, otp);

        return c.json({
            success: true,
            message: 'New verification code sent to your email'
        });
    } catch (error: any) {
        console.error('Resend OTP Error:', error);
        return c.json({
            success: false,
            message: error.message || 'Failed to resend verification code'
        }, 500);
    }
};


// Function to send account under review email
const sendAccountUnderReviewEmail = async (userData: { email: string, fullName: string }) => {
    try {
        // Email content
        const mailOptions = {
            from: '"CosConnect" <cosconnectme@gmail.com>',
            to: userData.email,
            subject: 'CosConnect Account Under Review - Status Update',
            html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        
        <img src="[Your Logo URL]" alt="CosConnect Logo" style="max-width: 200px; margin: 20px 0;">
        
        <h2 style="color: #2E5A88; border-bottom: 1px solid #eeeeee; padding-bottom: 10px;">Your CosConnect Account is Under Review</h2>
        
        <p>Dear ${userData.fullName},</p>
        
        <p>We're reaching out to inform you that your CosConnect borrower account is still under review by our verification team.</p>
        
        <div style="background-color: #f9f9f9; border-left: 4px solid #FF9800; padding: 15px; margin: 20px 0;">
          <h3 style="color: #FF9800; margin-top: 0;">Account Status: PENDING REVIEW</h3>
          <p>Our team is currently reviewing your application and the verification documents you've provided. This process ensures that all CosConnect users meet our platform's security and verification standards.</p>
        </div>
        
        <h3 style="color: #2E5A88;">What This Means</h3>
        
        <ul style="padding-left: 20px;">
          <li>Your account access is temporarily limited until the verification process is complete.</li>
          <li>You will not be able to sign in or access borrower features until your account is approved.</li>
          <li>Our team is working diligently to process all applications as quickly as possible.</li>
        </ul>
        
        <h3 style="color: #2E5A88;">Next Steps</h3>
        
        <ol style="padding-left: 20px;">
          <li><strong>Be Patient</strong><br>The review process typically takes 1-3 business days to complete.</li>
          <li><strong>Check Your Email</strong><br>You'll receive a notification at this email address once our review is complete.</li>
          <li><strong>Review Outcome</strong><br>You'll be notified of one of the following outcomes:
            <ul>
              <li><strong>Approved:</strong> Your account will be fully activated, allowing complete access to the platform.</li>
              <li><strong>Additional Information Required:</strong> We may request specific additional documentation.</li>
              <li><strong>Rejected:</strong> We'll provide detailed feedback explaining the decision.</li>
            </ul>
          </li>
        </ol>
        
        <div style="background-color: #f0f7ff; border: 1px solid #d0e3ff; border-radius: 5px; padding: 15px; margin: 20px 0;">
          <h3 style="color: #2E5A88; margin-top: 0;">Important Tips</h3>
          <p>While waiting for your account approval:</p>
          <ul style="padding-left: 20px;">
            <li>Check your spam/junk email folders regularly</li>
            <li>Ensure your contact information is up to date</li>
            <li>Don't create multiple accounts as this may delay your verification</li>
          </ul>
        </div>
        
        <div style="background-color: #f0f7ff; border: 1px solid #d0e3ff; border-radius: 5px; padding: 15px; margin: 20px 0;">
          <h3 style="color: #2E5A88; margin-top: 0;">Need Assistance?</h3>
          <p>If you have questions about your application status:</p>
          <p>📱 <strong>Phone:</strong> 09215186108<br>
          📧 <strong>Email:</strong> <a href="mailto:cosconnectme@gmail.com" style="color: #2E5A88;">cosconnectme@gmail.com</a></p>
        </div>
        
        <p>Thank you for your patience and understanding as we complete this necessary verification process. We look forward to welcoming you to the CosConnect community soon.</p>
        
        <p>Best regards,</p>
        
        <p><strong>The CosConnect Team</strong></p>
        
        <div style="border-top: 1px solid #eeeeee; padding-top: 15px; margin-top: 20px; font-size: 12px; color: #888888;">
          <p>This is an automated message. Please do not reply directly to this email.</p>
          <p>© 2025 CosConnect. All rights reserved.</p>
          <p>If you believe you've received this message in error, please contact our support team.</p>
        </div>
        
        </div>
        `
        };

        // Send the email
        const info = await transporter.sendMail(mailOptions);
        console.log('Account under review notification email sent:', info.messageId);
        return true;
    } catch (error) {
        console.error('Error sending account under review email:', error);
        return false;
    }
};


// Function to send borrower registration confirmation email
const sendBorrowerRegistrationEmail = async (userData: { email: string, fullName: string }) => {
    try {
        // Email content
        const mailOptions = {
            from: '"CosConnect" <cosconnectme@gmail.com>',
            to: userData.email,
            subject: 'CosConnect Borrower Registration Confirmation - Verification in Progress',
            html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        
        <img src="[Your Logo URL]" alt="CosConnect Logo" style="max-width: 200px; margin: 20px 0;">
        
        <h2 style="color: #2E5A88; border-bottom: 1px solid #eeeeee; padding-bottom: 10px;">Thank You for Registering with CosConnect!</h2>
        
        <p>Dear ${userData.fullName},</p>
        
        <p>We're delighted to confirm that your borrower registration with CosConnect has been successfully received. Thank you for choosing our platform to access financing opportunities.</p>
        
        <div style="background-color: #f9f9f9; border-left: 4px solid #2E5A88; padding: 15px; margin: 20px 0;">
          <h3 style="color: #2E5A88; margin-top: 0;">Verification Status: PENDING</h3>
          <p>Your application is currently under review by our verification team. We are carefully examining the personal details and identification documents you've provided to ensure compliance with our platform standards and security requirements.</p>
        </div>
        
        <h3 style="color: #2E5A88;">What Happens Next?</h3>
        
        <ol style="padding-left: 20px;">
          <li><strong>Review Process (Up to 3 Business Days)</strong><br>Our team will thoroughly review your application and verification documents.</li>
          <li><strong>Verification Outcome</strong><br>You will receive an email notification with one of the following outcomes:
            <ul>
              <li><strong>Approved:</strong> Your account will be activated, allowing you to access borrower features and loan opportunities.</li>
              <li><strong>Additional Information Required:</strong> We may request specific additional documentation to complete your verification.</li>
              <li><strong>Not Approved:</strong> We'll provide detailed feedback explaining the decision and how you might address any issues.</li>
            </ul>
          </li>
        </ol>
        
        <h3 style="color: #2E5A88;">Important Information</h3>
        
        <ul style="padding-left: 20px;">
          <li>Please check your email regularly, including spam/junk folders.</li>
          <li>Do not create multiple accounts while your application is under review.</li>
          <li>The email with your verification results will be sent from <strong>cosconnectme@gmail.com</strong>.</li>
        </ul>
        
        <div style="background-color: #f0f7ff; border: 1px solid #d0e3ff; border-radius: 5px; padding: 15px; margin: 20px 0;">
          <h3 style="color: #2E5A88; margin-top: 0;">Need Assistance?</h3>
          <p>Our support team is ready to help with any questions about your application:</p>
          <p>📱 <strong>Phone:</strong> 09215186108<br>
          📧 <strong>Email:</strong> <a href="mailto:cosconnectme@gmail.com" style="color: #2E5A88;">cosconnectme@gmail.com</a></p>
        </div>
        
        <p>We appreciate your patience during the verification process and look forward to potentially welcoming you as a verified borrower on the CosConnect platform.</p>
        
        <p>Warm regards,</p>
        
        <p><strong>The CosConnect Team</strong></p>
        
        <div style="border-top: 1px solid #eeeeee; padding-top: 15px; margin-top: 20px; font-size: 12px; color: #888888;">
          <p>This is an automated message. Please do not reply directly to this email.</p>
          <p>© 2025 CosConnect. All rights reserved.</p>
        </div>
        
        </div>
        `
        };

        // Send the email
        const info = await transporter.sendMail(mailOptions);
        console.log('Borrower registration confirmation email sent:', info.messageId);
        return true;
    } catch (error) {
        console.error('Error sending borrower registration confirmation email:', error);
        return false;
    }
};

const userBorrowerSignUp = async (c: Context) => {
    try {
        const body: BorrowerData = await c.req.json();
        const { personalInfo, identification, otpCode } = body;

        // Validate OTP first before proceeding
        if (!otpCode) {
            return c.json({
                success: false,
                message: 'Email verification code is required'
            }, 400);
        }

        // Verify OTP
        const otpVerification = await verifyOTP(personalInfo.email, otpCode);
        if (!otpVerification.isValid) {
            return c.json({
                success: false,
                message: otpVerification.message
            }, 400);
        }

        // Check if email already exists in Firebase Auth
        try {
            const userByEmail = await auth.getUserByEmail(personalInfo.email);
            if (userByEmail) {
                return c.json({
                    success: false,
                    message: 'Email already in use. Please use a different email address.'
                }, 400);
            }
        } catch (error: any) {
            // Error means user doesn't exist, which is what we want
            if (error.code !== 'auth/user-not-found') {
                throw error;
            }
        }


        // Check if username already exists in Firestore
        const usernameToCheck = personalInfo.username.toLowerCase();
        const usernameSnapshot = await db.collection("users")
            .where("username", "==", usernameToCheck)
            .limit(1)
            .get();

        if (!usernameSnapshot.empty) {
            return c.json({
                success: false,
                message: 'Username already exists. Please choose a different username.'
            }, 400);
        }

        // Validate Personal Info
        const requiredPersonalFields = [
            'email', 'password', 'fullName', 'username', 'phoneNumber', 'address'
        ];
        const missingPersonalFields = requiredPersonalFields.filter(
            field => !personalInfo[field as keyof typeof personalInfo]
        );

        if (missingPersonalFields.length > 0) {
            return c.json({
                success: false,
                message: `Missing personal info fields: ${missingPersonalFields.join(', ')}`
            }, 400);
        }

        // Validate Identification
        if (identification.hasValidId) {
            if (!identification.validIdType || !identification.validIdNumber || !identification.validIdFile) {
                return c.json({
                    success: false,
                    message: 'Valid ID information is incomplete'
                }, 400);
            }
        } else {
            if (!identification.secondaryIdType1 || !identification.secondaryIdFile1 ||
                !identification.secondaryIdType2 || !identification.secondaryIdFile2) {
                return c.json({
                    success: false,
                    message: 'Secondary ID information is incomplete'
                }, 400);
            }
        }

        // Validate password length
        if (personalInfo.password.length < 6) {
            return c.json({
                success: false,
                message: 'Password must be at least 6 characters'
            }, 400);
        }

        // Create Firebase Auth user - ONLY AFTER OTP VERIFICATION
        const userRecord = await auth.createUser({
            email: personalInfo.email,
            password: personalInfo.password,
            displayName: personalInfo.username.toLowerCase(),
            emailVerified: false
        });

        // Set custom claims for the user
        await auth.setCustomUserClaims(userRecord.uid, {
            role: 'borrower'
        });

        // Prepare user data for Firestore, ensuring no undefined values
        const userDataWithoutSensitive = {
            email: personalInfo.email,
            fullName: personalInfo.fullName,
            username: personalInfo.username.toLowerCase(),
            phoneNumber: personalInfo.phoneNumber,
            address: personalInfo.address,
            city: personalInfo.city || '',
            barangay: personalInfo.barangay || '',
            province: personalInfo.province || '',
            zipCode: personalInfo.zipCode || '',
            region: personalInfo.region || '',
            street: personalInfo.street || '',
            country: "Philippines",
            uid: userRecord.uid,
            role: 'borrower',
            status: 'pending',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            isVerified: false,
            lastAccountStatusEmailSent: Date.now(),
            // Handle identification data
            hasValidId: identification.hasValidId,
            ...(identification.hasValidId ? {
                validIdType: identification.validIdType || null,
                validIdNumber: identification.validIdNumber || null,
                validIdFile: identification.validIdFile || null
            } : {
                secondaryIdType1: identification.secondaryIdType1 || null,
                secondaryIdFile1: identification.secondaryIdFile1 || null,
                secondaryIdType2: identification.secondaryIdType2 || null,
                secondaryIdFile2: identification.secondaryIdFile2 || null
            })
        };

        // Store user details in Firestore with ignoreUndefinedProperties
        await db.collection("users").doc(userRecord.uid).set(userDataWithoutSensitive, { merge: true });

        // Send registration confirmation email
        await sendBorrowerRegistrationEmail({
            email: personalInfo.email,
            fullName: personalInfo.fullName
        });

        return c.json({
            success: true,
            message: 'Borrower account created successfully. Please check your email for confirmation.',
            uid: userRecord.uid
        });
    } catch (error: any) {
        console.error('Borrower Signup Error:', error);
        return c.json({
            success: false,
            message: error.message || 'Borrower signup failed'
        }, 400);
    }
};

const userBorrowerSignIn = async (c: Context) => {
    try {
        const { email, password } = await c.req.json();

        if (!email || !password) {
            return c.json({
                success: false,
                message: 'Email and password are required'
            }, 400);
        }

        try {
            // First verify credentials using Firebase client auth
            const userCredential = await signInWithEmailAndPassword(clientAuth, email, password);
            const firebaseUser = userCredential.user;

            if (!firebaseUser) {
                return c.json({
                    success: false,
                    message: 'Authentication failed'
                }, 401);
            }

            // Get user from admin SDK to verify role and get additional data
            const userRecord = await auth.getUser(firebaseUser.uid);

            // Get Firestore data
            const userData = await db.collection("users").doc(firebaseUser.uid).get();

            if (!userData.exists) {
                return c.json({
                    success: false,
                    message: 'User data not found'
                }, 404);
            }

            const userDataObj = userData.data();

            // Check if account status is pending
            if (userDataObj?.status === "pending") {
                // Check if we should send a reminder email (if last email was sent more than 12 hours ago)
                const lastEmailSent = userDataObj.lastAccountStatusEmailSent || 0;
                const twelveHoursInMs = 12 * 60 * 60 * 1000;
                const currentTime = Date.now();

                if ((currentTime - lastEmailSent) > twelveHoursInMs) {
                    // Send reminder email
                    await sendAccountUnderReviewEmail({
                        email: email,
                        fullName: userDataObj?.fullName || "Valued User"
                    });

                    // Update the lastEmailSent timestamp
                    await db.collection("users").doc(firebaseUser.uid).update({
                        lastAccountStatusEmailSent: currentTime
                    });
                }

                return c.json({
                    success: false,
                    message: 'Your account is currently under review. Our team will email you once your application has been approved or rejected. Please check your inbox including spam folders.',
                    status: 'under-review',
                    reviewData: { fullName: userDataObj?.fullName, email: userDataObj?.email }
                }, 403);
            }


            // Verify user is a borrower
            const customClaims = userRecord.customClaims || {};
            if (customClaims.role !== 'borrower') {
                return c.json({
                    success: false,
                    message: 'Access denied. This account is not registered as a borrower.'
                }, 403);
            }

            // Create custom token with role claim
            const customToken = await auth.createCustomToken(firebaseUser.uid, {
                role: 'borrower'
            });

            // Set user in context
            const user = {
                uid: firebaseUser.uid,
                email: userRecord.email || null,
                fullName: userDataObj?.fullName,
                username: userDataObj?.username,
                phoneNumber: userDataObj?.phoneNumber,
                address: userDataObj?.address,
                role: 'borrower' as const,
                identification: {
                    hasValidId: userDataObj?.hasValidId,
                    validIdType: userDataObj?.validIdType,
                    validIdNumber: userDataObj?.validIdNumber,
                    validIdFile: userDataObj?.validIdFile,
                    secondaryIdType1: userDataObj?.secondaryIdType1,
                    secondaryIdFile1: userDataObj?.secondaryIdFile1,
                    secondaryIdType2: userDataObj?.secondaryIdType2,
                    secondaryIdFile2: userDataObj?.secondaryIdFile2,
                } as Identification
            };




            return c.json({
                success: true,
                message: 'Borrower signed in successfully',
                idToken: await firebaseUser.getIdToken(),
                customToken,
                user
            });

        } catch (authError: any) {
            console.error('Authentication Error:', authError);
            return c.json({
                success: false,
                message: 'Invalid email or password',
                status: "invalid-credentials"
            }, 401);
        }
    } catch (error: any) {
        console.error('Borrower Sign In Error:', error);
        return c.json({
            success: false,
            message: error.message || 'An unexpected error occurred during sign in',
            status: "unexpected-error"
        }, 500);
    }
};


const getProfileInfoBorrower = async (c: Context) => {
    try {
        // Get username from query parameters
        const username = c.req.param('username')?.toLowerCase(); // Convert to lowercase for case-insensitive comparison
        console.log("user", username)
        // Validate username
        if (!username) {
            return c.json({
                success: false,
                message: 'Username is required',
                status: 'missing-parameter'
            }, 400);
        }

        // Get user document from Firestore using username
        const usersSnapshot = await db.collection('users')
            .where('username', '==', username)
            .where('role', '==', 'borrower')
            .limit(1)
            .get();

        // Check if user exists
        if (usersSnapshot.empty) {
            return c.json({
                success: false,
                message: 'Borrower not found',
                status: 'not-found'
            }, 404);
        }

        // Get the first (and should be only) document
        const userDoc = usersSnapshot.docs[0];
        const userData = userDoc?.data();

        // Return success response with user data
        return c.json({
            success: true,
            message: 'Borrower data retrieved successfully',
            data: {
                id: userDoc?.id,
                uid: userDoc?.id,
                ...userData
            },
            status: 'success'
        });

    } catch (error: any) {
        console.error('Error getting borrower data:', error);

        // Handle specific Firebase errors
        if (error.code === 'permission-denied') {
            return c.json({
                success: false,
                message: 'You do not have permission to access this resource',
                status: 'permission-denied'
            }, 403);
        }

        // Generic error response
        return c.json({
            success: false,
            message: 'An error occurred while fetching borrower data',
            status: 'server-error',
            error: error.message
        }, 500);
    }
};



export default { userBorrowerSignUp, userBorrowerSignIn, resendOTP, requestOTP, getProfileInfoBorrower };