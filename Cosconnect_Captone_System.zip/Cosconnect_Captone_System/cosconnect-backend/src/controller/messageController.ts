import type { Context } from 'hono';
import { z } from 'zod';
import { eq, and, or, desc, inArray, sql, ne, asc } from 'drizzle-orm';
import db from '../db/supabase/db_connect';
import { conversations, messages, user_role_enum } from '@/schema/conversation';
import { user_addresses, user_business_info, users } from '@/db-schema';
import { io } from '..';
import { userSocketMap } from '@/socket/chatSocketHandler';
import { admin } from '@/schema/admin';



// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

const emitToUser = (userId: string, event: string, data: any): boolean => {
    const socketIds = userSocketMap[userId];
    if (!socketIds || socketIds.size === 0) return false;
    socketIds.forEach(socketId => io.to(socketId).emit(event, data));
    return true;
};


/**
 * POST /messages
 * Send a message and create conversation if needed
 */
const sendMessage = async (c: Context) => {
    try {
        const body = await c.req.json();

        const {
            sender_id,
            sender_role,
            receiver_id,
            receiver_role,
            message_type,
            message,
            content,
            image_url,
        } = body;
        console.log("body", body)
        const messageContent = message || content;

        // Validation
        if (!sender_id || !sender_role || !receiver_id || !receiver_role) {
            return c.json({
                success: false,
                message: 'Sender and receiver information is required',
            }, 400);
        }

        const allowedRoles = ['admin', 'lender', 'borrower'];
        if (!allowedRoles.includes(sender_role) || !allowedRoles.includes(receiver_role)) {
            return c.json({
                success: false,
                message: 'Invalid role provided',
            }, 400);
        }

        if (!message_type || !['text', 'image'].includes(message_type)) {
            return c.json({
                success: false,
                message: 'Valid message_type is required (text or image)',
            }, 400);
        }

        // Updated validation: text messages require content, image messages require image_url
        // But both can have optional additional data
        if (message_type === 'text' && !messageContent?.trim()) {
            return c.json({
                success: false,
                message: 'Message content is required for text messages',
            }, 400);
        }

        if (message_type === 'image' && !image_url?.trim()) {
            return c.json({
                success: false,
                message: 'Image URL is required for image messages',
            }, 400);
        }

        // Prevent self-messaging
        if (sender_id === receiver_id && sender_role === receiver_role) {
            return c.json({
                success: false,
                message: 'Cannot send message to yourself',
            }, 400);
        }

        // Normalize users for database lookup/insert
        const normalized = normalizeUserPair(
            sender_id,
            sender_role,
            receiver_id,
            receiver_role
        );

        console.log('🔹 Normalized conversation pair:', normalized);

        // Try to find existing conversation
        let conversation = await db
            .select()
            .from(conversations)
            .where(
                and(
                    eq(conversations.user1_id, normalized.user1_id),
                    eq(conversations.user1_role, normalized.user1_role as any),
                    eq(conversations.user2_id, normalized.user2_id),
                    eq(conversations.user2_role, normalized.user2_role as any)
                )
            )
            .limit(1)
            .then((rows) => rows[0]);

        // Create if doesn't exist
        if (!conversation) {
            console.log('🆕 Creating new conversation');
            try {
                const result = await db
                    .insert(conversations)
                    .values(normalized as any)
                    .returning();
                conversation = result[0];
                console.log('✅ Conversation created:', conversation?.id);
            } catch (error: any) {
                // Race condition: another request created it
                if (error.code === '23505') {
                    console.log('⚠️ Race condition - fetching existing conversation');
                    const result = await db
                        .select()
                        .from(conversations)
                        .where(
                            and(
                                eq(conversations.user1_id, normalized.user1_id),
                                eq(conversations.user1_role, normalized.user1_role as any),
                                eq(conversations.user2_id, normalized.user2_id),
                                eq(conversations.user2_role, normalized.user2_role as any)
                            )
                        )
                        .limit(1);
                    conversation = result[0];
                } else {
                    throw error;
                }
            }
        }

        // Insert message - FIXED: Store both content and image_url if provided
        const result = await db
            .insert(messages)
            .values({
                conversation_id: conversation?.id as string,
                sender_id,
                sender_role: sender_role as any,
                message_type: message_type as any,
                // Store content if it exists and is not empty (for both text and image messages)
                content: messageContent?.trim() ? messageContent.trim() : null,
                // Store image_url if it exists and is not empty
                image_url: image_url?.trim() ? image_url.trim() : null,
            })
            .returning();

        const newMessage = result[0];
        console.log('✅ Message sent:', newMessage?.id);

        // Update conversation timestamp
        await db
            .update(conversations)
            .set({ updated_at: new Date() })
            .where(eq(conversations.id, conversation?.id as string));

        return c.json(
            {
                success: true,
                message: 'Message sent successfully',
                data: {
                    id: newMessage?.id,
                    conversation_id: conversation?.id,
                    sender_id,
                    sender_role,
                    receiver_id,
                    receiver_role,
                    message_type,
                    content: newMessage?.content,
                    image_url: newMessage?.image_url,
                    is_read: newMessage?.is_read,
                    is_seen: newMessage?.is_seen,
                    created_at: newMessage?.created_at,
                },
            },
            201
        );
    } catch (error: any) {
        console.error('❌ sendMessage error:', error);
        return c.json(
            {
                success: false,
                message: 'Failed to send message',
                error: process.env.NODE_ENV === 'development' ? error.message : undefined,
            },
            500
        );
    }
};

/**
 * Get partner information with role-based profile image
 */
const getPartnerInfo = async (partnerId: string, partnerRole: string): Promise<any | null> => {
    try {
        // Get user basic info
        const [user] = await db
            .select({
                id: users.id,
                uid: users.uid,
                username: users.username,
                first_name: users.first_name,
                last_name: users.last_name,
                full_name: users.full_name,
                profile_image: users.profile_image,
            })
            .from(users)
            .where(eq(users.uid, partnerId))
            .limit(1);

        if (!user) {
            console.warn(`⚠️ User not found: ${partnerId}`);
            return null;
        }

        let profileImage = user.profile_image;
        let displayName = user.username;

        // If role is lender, get business info
        if (partnerRole.toLowerCase() === 'lender') {
            const [business] = await db
                .select({
                    business_name: user_business_info.business_name,
                    business_profile_image: user_business_info.business_profile_image,
                })
                .from(user_business_info)
                .where(eq(user_business_info.user_uid, user.uid))
                .limit(1);

            // Use business profile image if available
            profileImage = business?.business_profile_image || user.profile_image;
            // Use business name for lenders
            displayName = business?.business_name || user.username;
        }

        // Construct full name
        const fullName = user.full_name ||
            (user.first_name && user.last_name
                ? `${user.first_name} ${user.last_name}`.trim()
                : user.first_name || user.last_name || user.username);

        return {
            id: user.uid,
            username: user.username,
            first_name: user.first_name,
            last_name: user.last_name,
            full_name: fullName,
            display_name: displayName,
            profile_image: profileImage,
        };
    } catch (error) {
        console.error("❌ getPartnerInfo error:", error);
        return null;
    }
};

/**
 * Normalizes user pair to ensure consistent ordering
 */
const normalizeUserPair = (
    senderId: string,
    senderRole: string,
    receiverId: string,
    receiverRole: string
) => {
    const sender = `${senderId}${senderRole}`;
    const receiver = `${receiverId}${receiverRole}`;

    if (sender < receiver) {
        return {
            user1_id: senderId,
            user1_role: senderRole,
            user2_id: receiverId,
            user2_role: receiverRole,
        };
    } else {
        return {
            user1_id: receiverId,
            user1_role: receiverRole,
            user2_id: senderId,
            user2_role: senderRole,
        };
    }
};

/**
 * GET /conversations/:userId?role=borrower
 * Get all conversations for a user with partner info and last message
 */
export const getContacts = async (c: Context) => {
    try {
        const userId = c.req.param('userId');
        const userRole = c.req.query('role');
        const limit = parseInt(c.req.query('limit') || '20');
        const offset = parseInt(c.req.query('offset') || '0');
        // Validation
        if (!userId) {
            return c.json({
                success: false,
                message: 'User ID is required',
            }, 400);
        }

        const allowedRoles = ['admin', 'lender', 'borrower'];
        if (!userRole || !allowedRoles.includes(userRole)) {
            return c.json({
                success: false,
                message: 'Valid role query parameter is required (admin, lender, or borrower)',
            }, 400);
        }

        // Find conversations where user is either user1 or user2 with matching role
        const userConversations = await db
            .select()
            .from(conversations)
            .where(
                or(
                    and(
                        eq(conversations.user1_id, userId),
                        eq(conversations.user1_role, userRole as any)
                    ),
                    and(
                        eq(conversations.user2_id, userId),
                        eq(conversations.user2_role, userRole as any)
                    )
                )
            )
            .orderBy(desc(conversations.updated_at))
            .limit(limit)
            .offset(offset);

        // Enrich conversations with partner info and last message
        const enrichedConversations = await Promise.all(
            userConversations.map(async (conv) => {
                // Determine who the partner is
                const isUser1 = conv.user1_id === userId && conv.user1_role === userRole;
                const partnerId = isUser1 ? conv.user2_id : conv.user1_id;
                const partnerRole = isUser1 ? conv.user2_role : conv.user1_role;

                // Get partner info with role-based profile image
                const partnerInfo = await getPartnerInfo(partnerId, partnerRole);

                // Get last message
                const [lastMessage] = await db
                    .select({
                        id: messages.id,
                        sender_id: messages.sender_id,
                        sender_role: messages.sender_role,
                        message_type: messages.message_type,
                        content: messages.content,
                        image_url: messages.image_url,
                        is_read: messages.is_read,
                        created_at: messages.created_at,
                    })
                    .from(messages)
                    .where(eq(messages.conversation_id, conv.id))
                    .orderBy(desc(messages.created_at))
                    .limit(1);

                // Count unread messages from partner
                const unreadMessages = await db
                    .select({ count: sql<number>`cast(count(*) as int)` })
                    .from(messages)
                    .where(
                        and(
                            eq(messages.conversation_id, conv.id),
                            eq(messages.sender_id, partnerId),
                            eq(messages.is_read, false)
                        )
                    );

                const unreadCount = unreadMessages[0]?.count || 0;

                return {
                    conversation_id: conv.id,
                    partner: partnerInfo,
                    partner_role: partnerRole,
                    last_message: lastMessage || null,
                    unread_count: unreadCount,
                    updated_at: conv.updated_at,
                    created_at: conv.created_at,
                };
            })
        );

        return c.json({
            success: true,
            message: 'Conversations retrieved successfully',
            data: enrichedConversations,
            pagination: {
                limit,
                offset,
                total: enrichedConversations.length,
            },
        });

    } catch (error: any) {
        console.error('❌ getContacts error:', error);
        return c.json(
            {
                success: false,
                message: 'Failed to retrieve conversations',
                error: process.env.NODE_ENV === 'development' ? error.message : undefined,
            },
            500
        );
    }
};

/**
 * GET /messages/conversation/:userId/:partnerId?userRole=borrower&partnerRole=lender
 * Get conversation and messages between two users
 */
export const getConversation = async (c: Context) => {
    try {
        const userId = c.req.param("userId");
        const partnerId = c.req.param("partnerId");
        const userRole = c.req.query("userRole")?.toLowerCase();
        const partnerRole = c.req.query("partnerRole")?.toLowerCase();
        const limit = Math.min(parseInt(c.req.query("limit") || "50", 10), 100);
        const offset = parseInt(c.req.query("offset") || "0", 10);

        // Validation
        if (!userId || !partnerId) {
            return c.json(
                { success: false, message: "User ID and Partner ID required" },
                400
            );
        }

        const allowedRoles = ["admin", "lender", "borrower"];
        if (
            !userRole ||
            !partnerRole ||
            !allowedRoles.includes(userRole) ||
            !allowedRoles.includes(partnerRole)
        ) {
            return c.json(
                { success: false, message: "Valid user and partner roles required" },
                400
            );
        }

        // Normalize user pair
        const normalized = normalizeUserPair(
            userId,
            userRole,
            partnerId,
            partnerRole
        );

        // Find existing conversation
        const [conversation] = await db
            .select()
            .from(conversations)
            .where(
                and(
                    eq(conversations.user1_id, normalized.user1_id),
                    eq(conversations.user1_role, normalized.user1_role as any),
                    eq(conversations.user2_id, normalized.user2_id),
                    eq(conversations.user2_role, normalized.user2_role as any)
                )
            )
            .limit(1);

        // Get partner info
        const partnerInfo = await getPartnerInfo(partnerId, partnerRole);

        if (!partnerInfo) {
            return c.json(
                { success: false, message: "Partner not found" },
                404
            );
        }

        // Return empty if conversation doesn't exist
        if (!conversation) {
            console.log("⚠️ Conversation not found - returning empty");

            return c.json({
                success: true,
                data: {
                    conversation_id: null,
                    messages: [],
                    partner_info: partnerInfo,
                    conversation_stats: {
                        total_messages: 0,
                        unread_count: 0,
                    },
                },
                pagination: {
                    limit,
                    offset,
                    hasMore: false,
                },
            });
        }

        // Fetch messages
        const conversationMessages = await db
            .select({
                id: messages.id,
                conversation_id: messages.conversation_id,
                sender_id: messages.sender_id,
                sender_role: messages.sender_role,
                content: messages.content,
                image_url: messages.image_url,
                message_type: messages.message_type,
                is_read: messages.is_read,
                is_seen: messages.is_seen,
                created_at: messages.created_at,
            })
            .from(messages)
            .where(eq(messages.conversation_id, conversation.id))
            .orderBy(asc(messages.created_at))
            .limit(limit)
            .offset(offset);

        // Calculate stats
        const totalMessages = conversationMessages.length;
        const unreadCount = conversationMessages.filter(
            (msg) => !msg.is_read && msg.sender_id !== userId
        ).length;

        return c.json({
            success: true,
            data: {
                conversation_id: conversation.id,
                messages: conversationMessages,
                partner_info: partnerInfo,
                conversation_stats: {
                    total_messages: totalMessages,
                    unread_count: unreadCount,
                },
            },
            pagination: {
                limit,
                offset,
                hasMore: conversationMessages.length === limit,
            },
        });
    } catch (error: any) {
        console.error("❌ getConversation error:", error);
        return c.json(
            {
                success: false,
                message: "Failed to fetch conversation",
                error: process.env.NODE_ENV === "development" ? error.message : undefined,
            },
            500
        );
    }
};

/**
 * PATCH /messages/:messageId/read
 * Mark a message as read
 */
export const markMessageAsRead = async (c: Context) => {
    try {
        const messageId = c.req.param('messageId');

        if (!messageId) {
            return c.json({
                success: false,
                message: 'Message ID is required',
            }, 400);
        }

        const [updatedMessage] = await db
            .update(messages)
            .set({
                is_read: true,
                is_seen: true
            })
            .where(eq(messages.id, messageId))
            .returning();

        if (!updatedMessage) {
            return c.json({
                success: false,
                message: 'Message not found',
            }, 404);
        }

        return c.json({
            success: true,
            message: 'Message marked as read',
            data: updatedMessage,
        });
    } catch (error: any) {
        console.error('❌ markMessageAsRead error:', error);
        return c.json(
            {
                success: false,
                message: 'Failed to mark message as read',
                error: process.env.NODE_ENV === 'development' ? error.message : undefined,
            },
            500
        );
    }
};



/**
 * Delete a message (soft delete)
 */
export const deleteMessage = async (c: Context) => {
    try {
        const messageId = c.req.param('messageId');
        const userId = c.req.query('userId');

        if (!messageId || !userId) {
            return c.json({
                success: false,
                error: 'Message ID and User ID required',
            }, 400);
        }

        // 1️⃣ Get message
        const [message] = await db
            .select()
            .from(messages)
            .where(eq(messages.id, messageId))
            .limit(1);

        if (!message) {
            return c.json({ success: false, error: 'Message not found' }, 404);
        }

        // 2️⃣ Verify sender
        if (message.sender_id !== userId) {
            return c.json({ success: false, error: 'Unauthorized' }, 403);
        }

        // 3️⃣ Soft delete
        await db
            .update(messages)
            .set({
                content: null,
                image_url: null,
            })
            .where(eq(messages.id, messageId));

        // 4️⃣ Get conversation to find receiver
        const [conversation] = await db
            .select()
            .from(conversations)
            .where(eq(conversations.id, message.conversation_id))
            .limit(1);

        const receiverId = conversation?.user1_id === userId
            ? conversation?.user2_id
            : conversation?.user1_id;

        emitToUser(receiverId || '', 'messageDeleted', {
            messageId,
            deletedBy: userId,
        });

        return c.json({
            success: true,
            message: 'Message deleted successfully',
        }, 200);

    } catch (error: any) {
        console.error('❌ deleteMessage error:', error);
        return c.json({
            success: false,
            error: 'Failed to delete message',
            details: process.env.NODE_ENV === 'development' ? error.message : undefined,
        }, 500);
    }
};

/**
 * Mark message as seen
 */
export const markMessageSeen = async (c: Context) => {
    try {
        const body = await c.req.json();
        const { messageIds, userId } = body;

        if (!messageIds || !Array.isArray(messageIds) || messageIds.length === 0) {
            return c.json({
                success: false,
                error: 'Message IDs array required',
            }, 400);
        }

        await db
            .update(messages)
            .set({ is_seen: true })
            .where(inArray(messages.id, messageIds));

        // Get conversation to find partner
        const [firstMsg] = await db
            .select()
            .from(messages)
            .where(eq(messages.id, messageIds[0]))
            .limit(1);

        if (firstMsg) {
            emitToUser(firstMsg.sender_id, 'messageSeen', {
                messageIds,
                seenBy: userId,
            });
        }

        return c.json({
            success: true,
            message: 'Messages marked as seen',
        }, 200);

    } catch (error: any) {
        console.error('❌ markMessageSeen error:', error);
        return c.json({
            success: false,
            error: 'Failed to mark messages as seen',
        }, 500);
    }
};

// ============================================================================
// EXPORTS
// ============================================================================

export default {
    sendMessage,
    getContacts,
    getConversation,
    deleteMessage,
    markMessageSeen,
};