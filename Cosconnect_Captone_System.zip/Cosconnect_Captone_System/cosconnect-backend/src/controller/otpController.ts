import type { Context } from "hono"
import { eq, and, desc, gt, lt } from "drizzle-orm"
import db from "../db/supabase/db_connect"
import { users } from "../schema/users"
import { otp_codes } from "../schema/otp-code"
import nodemailer from "nodemailer"
import { sendOtpEmail } from "./userController"

// =============================================================================
// CONFIGURATION
// =============================================================================
const OTP_CONFIG = {
    EXPIRY_MINUTES: 10,
    RATE_LIMIT_MINUTES: 1,
    EMAIL_TIMEOUT: 15000,
} as const

const IS_PRODUCTION = process.env.NODE_ENV === 'production'

// =============================================================================
// OPTIMIZED EMAIL TRANSPORTER - Singleton with connection pooling
// =============================================================================
let transporter: nodemailer.Transporter | null = null

const getTransporter = (): nodemailer.Transporter => {
    if (!transporter) {
        console.log('📧 Initializing email transporter with connection pooling')
        transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: process.env.EMAIL_USER ,
                pass: process.env.EMAIL_PASSWORD || ''
            },
            pool: true,
            maxConnections: 5,
            maxMessages: 100,
            connectionTimeout: 10000,
            greetingTimeout: 10000,
            socketTimeout: 15000,
        })
    }
    return transporter
}

// =============================================================================
// OPTIMIZED UTILITY FUNCTIONS
// =============================================================================

const generateOTP = (): string => {
    return Math.floor(100000 + Math.random() * 900000).toString()
}

const createTimeout = (ms: number): Promise<never> => {
    return new Promise((_, reject) =>
        setTimeout(() => reject(new Error(`Timeout after ${ms}ms`)), ms)
    )
}



// =============================================================================
// CLEANUP FUNCTION (Run periodically via cron job)
// =============================================================================

/**
 * OPTIMIZED: Delete expired OTPs to keep table small
 * Run this every hour via cron job
 */
export const cleanupExpiredOTPs = async (): Promise<number> => {
    const result = await db
        .delete(otp_codes)
        .where(lt(otp_codes.expires_at, new Date()))  // Changed this line
        .returning({ id: otp_codes.id })

    console.log(`🧹 Cleaned up ${result.length} expired OTPs`)
    return result.length
}
// =============================================================================
// SHUTDOWN HANDLER
// =============================================================================

export const closeTransporter = () => {
    if (transporter) {
        transporter.close()
        transporter = null
        console.log('📧 Email transporter closed')
    }
}

// ============================================================================
// VERIFY OTP CODE (EMAIL-BASED VERSION)
// ============================================================================
export const verifyOtpCode = async (c: Context): Promise<Response> => {
    try {
        const body = await c.req.json();
        const { email, otp } = body;

        // Basic validation
        if (!email || !otp || typeof email !== 'string' || typeof otp !== 'string') {
            return c.json({ success: false, error: 'Email and OTP are required' }, 400);
        }

        // Sanitize
        const sanitizedEmail = email.toLowerCase().trim();
        const sanitizedOtp = otp.trim();

        // Find valid OTP record
        const [otpRecord] = await db
            .select()
            .from(otp_codes)
            .where(
                and(
                    eq(otp_codes.email, sanitizedEmail),
                    eq(otp_codes.otp_code, sanitizedOtp),
                    eq(otp_codes.is_used, false)
                )
            )
            .orderBy(desc(otp_codes.created_at))
            .limit(1);

        // Check if OTP exists
        if (!otpRecord) {
            return c.json({ success: false, error: 'Invalid or expired OTP' }, 400);
        }

        // Check expiration
        const now = new Date();
        if (!otpRecord.expires_at || otpRecord.expires_at < now) {
            return c.json({
                success: false,
                error: 'OTP has expired. Please request a new one.'
            }, 400);
        }

        // Mark OTP as used
        await db
            .update(otp_codes)
            .set({ is_used: true })
            .where(eq(otp_codes.id, otpRecord.id));

        console.log(`✅ OTP verified successfully for ${sanitizedEmail}`);

        return c.json({
            success: true,
            message: 'OTP verified successfully',
            data: {
                email: sanitizedEmail,
                verifiedAt: new Date().toISOString()
            }
        });

    } catch (error) {
        console.error('❌ Error in verifyOtpCode:', error);
        return c.json({
            success: false,
            error: 'Internal server error'
        }, 500);
    }
};

export const sendOtpCode = async (c: Context): Promise<Response> => {
    try {
        const { email } = await c.req.json();
        if (!email)
            return c.json({ success: false, message: 'Email is required' }, 400);

        const otp = generateOTP();
        const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

        // Save OTP in DB
        await db.insert(otp_codes).values({
            email,
            otp_code: otp,
            expires_at: expiresAt,
            is_used: false
        });

        // Send OTP email
        const emailSent = await sendOtpEmail(email, otp);
        if (!emailSent)
            return c.json({ success: false, message: 'Failed to send OTP email' }, 500);

        return c.json({
            success: true,
            message: 'OTP sent successfully',
            expiresAt: expiresAt.toISOString()
        });
    } catch (error) {
        console.error('💥 sendOtpCode Error:', error);
        return c.json({ success: false, message: 'Internal server error' }, 500);
    }
};

/**
 * Resend OTP Code (alias for sendOtpCode)
 * This is the same function as sendOtpCode since it handles both cases
 */
const resendOtpCode = sendOtpCode

// =============================================================================
// EXPORTS
// =============================================================================
export default {

    verifyOtpCode,
    resendOtpCode
}

