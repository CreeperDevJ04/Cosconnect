import type { Context } from "hono"
import { and, desc, eq, count, sql, asc, or } from "drizzle-orm"
import db from "../db/supabase/db_connect"
import { users, user_business_info, business_addresses } from "../schema/users.js"
import { costumeAddOns, costumes, type NewCostume } from "@/schema/costumes"
import { costumeFormSchema, CostumeFormValues } from "@/lib/zodSchema/costumeSchema"
import { rentals } from "@/db-schema"

/**
 * Custom error classes for better error handling
 */
class CostumeCreationError extends Error {
    constructor(
        message: string,
        public statusCode = 500,
        public code?: string,
    ) {
        super(message)
        this.name = "CostumeCreationError"
    }
}

/**
 * Utility functions
 */
const isValidUUID = (uuid: string): boolean => {
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
    return uuidRegex.test(uuid)
}

const sanitizeString = (input: string | undefined | null, maxLength = 255): string => {
    if (!input) return ""
    return input.trim().slice(0, maxLength)
}

const safeJsonParse = (jsonString: any, fallback: any = null) => {
    if (!jsonString) return fallback
    try {
        return typeof jsonString === "string" ? JSON.parse(jsonString) : jsonString
    } catch (error) {
        console.warn("[v0] JSON parse error:", error, "Input:", jsonString)
        return fallback
    }
}

const getMarketplaceCostumes = async (c: Context): Promise<Response> => {
    try {
        const { page = '1', limit = '10' } = c.req.query();
        const currentPage = Math.max(parseInt(page) || 1, 1);
        const itemsPerPage = Math.min(Math.max(parseInt(limit) || 10, 1), 100);
        const offset = (currentPage - 1) * itemsPerPage;

        const [costumesResult, totalCountResult] = await Promise.all([
            // Get only costume data
            db
                .select()
                .from(costumes)
                .where(
                    and(
                        eq(costumes.status, 'active'),
                        eq(costumes.is_available, true)
                    )
                )
                .orderBy(desc(costumes.created_at))
                .limit(itemsPerPage)
                .offset(offset),

            // Get total count
            db
                .select({ count: count() })
                .from(costumes)
                .where(
                    and(
                        eq(costumes.status, 'active'),
                        eq(costumes.is_available, true)
                    )
                )
        ]);

        const totalCount = Number(totalCountResult[0]?.count) || 0;
        const totalPages = Math.ceil(totalCount / itemsPerPage);

        // Transform data for marketplace display
        const marketplaceCostumes = costumesResult.map((costume) => {
            const pricing: any = {};

            if (costume.listing_type === 'rent' || costume.listing_type === 'both') {
                pricing.rental = {
                    price: costume.rental_price,
                    security_deposit: costume.security_deposit,
                };
            }

            if (costume.listing_type === 'sale' || costume.listing_type === 'both') {
                pricing.sale = {
                    price: costume.sale_price,
                    discount_percentage: costume.discount_percentage,
                };
            }

            return {
                id: costume.id,
                name: costume.name,
                brand: costume.brand,
                category: costume.category,
                gender: costume.gender,
                sizes: costume.sizes,
                listing_type: costume.listing_type,
                pricing,
                main_images: costume.main_images,
                view_count: costume.view_count,
                favorite_count: costume.favorite_count,
                created_at: costume.created_at,
                tags: costume.tags
            };
        });

        return c.json({
            success: true,
            data: {
                costumes: marketplaceCostumes,
                pagination: {
                    page: currentPage,
                    limit: itemsPerPage,
                    total_count: totalCount,
                    total_pages: totalPages,
                    has_next_page: currentPage < totalPages,
                    has_previous_page: currentPage > 1,
                }
            },
            message: `Retrieved ${marketplaceCostumes.length} costumes`,
        }, 200);

    } catch (error) {
        console.error('Error fetching marketplace costumes:', error);
        return c.json({
            success: false,
            message: 'Failed to fetch marketplace costumes',
            data: null,
        }, 500);
    }
};

/**
 * Get costume by ID with complete lender information, add-ons, and booked dates
 * @param c Hono context
 * @returns Costume details with lender info, add-ons, and booked dates if found, error otherwise
 */
const getCostumeById = async (c: Context) => {
    try {
        const { id } = c.req.param()
        console.log("[v0] Fetching costume with ID:", id)

        if (!id) {
            return c.json({ success: false, message: "Costume ID is required" }, 400)
        }

        // Validate UUID format
        if (!isValidUUID(id)) {
            return c.json({ success: false, message: "Invalid costume ID format" }, 400)
        }

        console.log("[v0] Searching for costume with ID:", id)

        // Get costume details with lender info
        const costumesResult = await db
            .select({
                // Costume fields
                id: costumes.id,
                name: costumes.name,
                brand: costumes.brand,
                category: costumes.category,
                description: costumes.description,
                gender: costumes.gender,
                sizes: costumes.sizes,
                tags: costumes.tags,
                listing_type: costumes.listing_type,
                rental_price: costumes.rental_price,
                sale_price: costumes.sale_price,
                security_deposit: costumes.security_deposit,
                discount_percentage: costumes.discount_percentage,
                extended_days_price: costumes.extended_days_price,
                main_images: costumes.main_images,
                additional_images: costumes.additional_images,
                view_count: costumes.view_count,
                favorite_count: costumes.favorite_count,
                created_at: costumes.created_at,
                updated_at: costumes.updated_at,
                lender_uid: costumes.lender_uid,
                // Status fields
                status: costumes.status,
                is_available: costumes.is_available,
                // User basic info
                user_email: users.email,
                user_name: users.username,
                user_profile_image: users.profile_image,
                // Business info (may be null)
                business_name: user_business_info.business_name,
                business_description: user_business_info.business_description,
                business_type: user_business_info.business_type,
                business_email: user_business_info.business_email,
                business_phone: user_business_info.business_phone_number,
                business_profile_image: user_business_info.business_profile_image,
                business_background_image: user_business_info.business_background_image,
                // Business address fields (may be null)
                address_street: business_addresses.street,
                address_barangay: business_addresses.barangay,
                address_city: business_addresses.city,
                address_province: business_addresses.province,
                address_region: business_addresses.region,
                address_zip_code: business_addresses.zip_code,
                address_country: business_addresses.country,
            })
            .from(costumes)
            .innerJoin(users, eq(costumes.lender_uid, users.uid))
            .leftJoin(user_business_info, eq(users.uid, user_business_info.user_uid))
            .leftJoin(business_addresses, eq(user_business_info.id, business_addresses.business_info_id))
            .where(and(
                eq(costumes.id, id),
                eq(costumes.status, 'active')
            ))
            .limit(1)

        if (!costumesResult || costumesResult.length === 0) {
            console.log("[v0] Costume not found for ID:", id)
            return c.json({ success: false, message: "Costume not found" }, 404)
        }

        const costumeData = costumesResult[0]
        console.log("[v0] Found costume:", costumeData?.id)

        // Get add-ons in parallel with the main query
        const [addOnsResult, bookedDates] = await Promise.all([
            // Get add-ons
            db.select()
                .from(costumeAddOns)
                .where(and(
                    eq(costumeAddOns.costume_id, id),
                    eq(costumeAddOns.is_active, true)
                ))
                .orderBy(asc(costumeAddOns.name)),

            // Get booked dates
            db.select({
                start_date: rentals.start_date,
                end_date: rentals.end_date,
            })
                .from(rentals)
                .where(and(
                    eq(rentals.costume_id, id),
                    or(
                        eq(rentals.status, 'confirmed'),
                        eq(rentals.status, 'accepted'),
                        eq(rentals.status, 'delivered')
                    )
                ))
                .orderBy(asc(rentals.start_date))
        ]);

        // Generate an array of all booked dates
        const bookedDateSet = new Set<string>();
        bookedDates.forEach(rental => {
            if (!rental.start_date || !rental.end_date) return;

            const start = new Date(rental.start_date);
            const end = new Date(rental.end_date);

            // Reset time part to avoid timezone issues
            start.setHours(0, 0, 0, 0);
            end.setHours(0, 0, 0, 0);

            // Add all dates in the range (inclusive)
            for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
                const dateStr = d.toISOString().split('T')[0]; // Format: YYYY-MM-DD
                bookedDateSet.add(dateStr || '');
            }
        });

        // Format the response
        const response = {
            success: true,
            message: "Costume details retrieved successfully",
            data: {
                ...costumeData,
                add_ons: addOnsResult || [],
                booked_dates: Array.from(bookedDateSet).sort() // Sort dates chronologically
            }
        };

        return c.json(response, 200);

    } catch (error: any) {
        console.error("Error in getCostumeById:", error);
        return c.json(
            {
                success: false,
                message: "Failed to fetch costume details",
                error: process.env.NODE_ENV === 'development' ? error.message : undefined
            },
            500
        );
    }
};

export default {
    getMarketplaceCostumes,
    getCostumeById
};
