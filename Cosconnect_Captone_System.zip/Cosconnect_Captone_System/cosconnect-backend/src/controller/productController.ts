
import type { Context } from 'hono';
import nodemailer from 'nodemailer';
import { z } from "zod";
import { db } from "../db/firebase/config";
import { and, desc, eq, sql } from 'drizzle-orm';
import { costumes } from '@/db-schema';
/* import { costumeSchema } from '@/lib/zodSchema/costumeSchema';
 */

// Configure nodemailer transporter
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER ,
        pass: process.env.EMAIL_PASSWORD || ''
    }
});

const createCategory = async (c: Context) => {
    try {
        const body = await c.req.json();

        // Validate required fields using zod
        const categorySchema = z.object({
            categoryName: z.string().min(1, "Category name is required"),
            adminDetails: z.object({
                adminId: z.string(),
                adminName: z.string(),
                adminEmail: z.string().email(),
                adminRole: z.string()
            })
        });

        try {
            categorySchema.parse(body);
        } catch (error) {
            return c.json({
                success: false,
                message: "Invalid category data",
                error: error instanceof Error ? error.message : "Validation error"
            }, 400);
        }

        // Check if category already exists
        const existingCategory = await db.collection('category')
            .where('categoryName', '==', body.categoryName)
            .get();

        if (!existingCategory.empty) {
            return c.json({
                success: false,
                message: "Category already exists"
            }, 409);
        }

        // Prepare category data
        const categoryData = {
            categoryName: body.categoryName,
            slug: body.categoryName.toLowerCase().replace(/ /g, '-'),
            status: 'active',
            // ... existing code ...
            productListingCount: 0,    // Number of times this tag is used in product listings
            totalRentalCount: 0,       // Total number of times products with this tag were rented
            adminDetails: {
                adminId: body.adminDetails.adminId,
                adminName: body.adminDetails.adminName,
                adminEmail: body.adminDetails.adminEmail,
                adminRole: body.adminDetails.adminRole
            },
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };

        // Store in Firestore
        const docRef = await db.collection('category').add(categoryData);

        return c.json({
            success: true,
            message: "Category created successfully",
            category: {
                id: docRef.id,
                ...categoryData
            }
        });

    } catch (error) {
        console.error('Create Category Error:', error);
        return c.json({
            success: false,
            message: error instanceof Error ? error.message : "An unexpected error occurred"
        }, 500);
    }
}


const getAllCategories = async (c: Context) => {
    try {
        // Get pagination from query
        const page = parseInt(c.req.query('page') || '1');
        const limit = parseInt(c.req.query('limit') || '10');

        // Calculate pagination
        const offset = (page - 1) * limit;

        // Build query to get all categories
        const query = db.collection('category')  // Updated collection name to 'categories'
            .orderBy('createdAt', 'desc');

        // Get data and count in parallel for better performance
        const [snapshot, totalSnapshot] = await Promise.all([
            query.limit(limit).offset(offset).get(),
            query.count().get()
        ]);

        const total = totalSnapshot.data().count;
        const categories = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));

        return c.json({
            success: true,
            data: {
                categories,
                pagination: {
                    total,
                    page,
                    limit,
                    totalPages: Math.ceil(total / limit),
                    hasMore: offset + categories.length < total
                }
            }
        });

    } catch (error) {
        console.error('Get Categories Error:', error);
        return c.json({
            success: false,
            message: error instanceof Error ? error.message : "An unexpected error occurred"
        }, 500);
    }
}


const updateCategoryById = async (c: Context) => {
    try {
        const categoryId = c.req.param('categoryId');
        const { categoryName, status } = await c.req.json();
        console.log("categoryId", categoryId)
        console.log("categoryName", categoryName)
        console.log("status", status)
        // Validate required fields
        if (!categoryId || !categoryName) {
            return c.json({
                success: false,
                message: "Category ID and name are required"
            }, 400);
        }

        // First check if category exists using categoryId
        const categoryRef = db.collection('category').doc(categoryId);
        const categoryDoc = await categoryRef.get();

        if (!categoryDoc.exists) {
            return c.json({
                success: false,
                message: "Category not found"
            }, 404);
        }

        const currentData = categoryDoc.data();

        // Only check for duplicate name if the name is being changed
        if (categoryName !== currentData?.categoryName) {
            const duplicateCheck = await db.collection('category')
                .where('categoryName', '==', categoryName)
                .get();

            if (!duplicateCheck.empty) {
                return c.json({
                    success: false,
                    message: "Category name already exists"
                }, 409);
            }
        }

        // Prepare update data
        const updateData = {
            categoryName,
            status: status || currentData?.status, // Keep existing status if not provided
            updatedAt: new Date().toISOString()
        };

        // Update the category
        await categoryRef.update(updateData);

        // Get the updated document
        const updatedDoc = await categoryRef.get();
        const updatedCategory = {
            id: updatedDoc.id,
            ...updatedDoc.data()
        };

        return c.json({
            success: true,
            message: "Category updated successfully",
            category: updatedCategory
        });

    } catch (error) {
        console.error('Update Category Error:', error);
        return c.json({
            success: false,
            message: error instanceof Error ? error.message : "An unexpected error occurred"
        }, 500);
    }
}

const deleteCategoryById = async (c: Context) => {
    try {
        const categoryId = c.req.param('categoryId');

        if (!categoryId) {
            return c.json({
                success: false,
                message: "Category ID is required"
            }, 400);
        }

        // Check if category exists and get its data
        const categoryRef = db.collection('category').doc(categoryId);
        const categoryDoc = await categoryRef.get();

        if (!categoryDoc.exists) {
            return c.json({
                success: false,
                message: "Category not found"
            }, 404);
        }

        const categoryData = categoryDoc.data();

        // Check if category is being used in products
        if (categoryData?.productListingCount > 0) {
            return c.json({
                success: false,
                message: "Cannot delete category as it is being used in active product listings",
                activeListings: categoryData?.productListingCount
            }, 409);
        }

        // Perform the delete operation
        await categoryRef.delete();

        return c.json({
            success: true,
            message: "Category deleted successfully",
            deletedCategory: {
                id: categoryId,
                ...categoryData
            }
        });

    } catch (error) {
        console.error('Delete Category Error:', error);
        return c.json({
            success: false,
            message: error instanceof Error ? error.message : "An unexpected error occurred"
        }, 500);
    }
}


const createTags = async (c: Context) => {
    try {
        const body = await c.req.json();

        // Validate required fields using zod
        const tagSchema = z.object({
            tagName: z.string().min(1, "Tag name is required"),
            adminDetails: z.object({
                adminId: z.string(),
                adminName: z.string(),
                adminEmail: z.string().email(),
                adminRole: z.string()
            })
        });

        try {
            tagSchema.parse(body);
        } catch (error) {
            return c.json({
                success: false,
                message: "Invalid tag data",
                error: error instanceof Error ? error.message : "Validation error"
            }, 400);
        }

        // Check if tag already exists
        const existingTag = await db.collection('tags')
            .where('tagName', '==', body.tagName)
            .get();

        if (!existingTag.empty) {
            return c.json({
                success: false,
                message: "Tag already exists"
            }, 409);
        }

        // Prepare tag data
        const tagData = {
            tagName: body.tagName,
            status: 'active',
            // ... existing code ...
            productListingCount: 0,    // Number of times this tag is used in product listings
            totalRentalCount: 0,       // Total number of times products with this tag were rented
            adminDetails: {
                adminId: body.adminDetails.adminId,
                adminName: body.adminDetails.adminName,
                adminEmail: body.adminDetails.adminEmail,
                adminRole: body.adminDetails.adminRole
            },
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };

        // Store in Firestore
        const docRef = await db.collection('tags').add(tagData);

        return c.json({
            success: true,
            message: "Tag created successfully",
            tag: {
                id: docRef.id,
                ...tagData
            }
        });

    } catch (error) {
        console.error('Create Tag Error:', error);
        return c.json({
            success: false,
            message: error instanceof Error ? error.message : "An unexpected error occurred"
        }, 500);
    }
}

const getAllTags = async (c: Context) => {
    try {
        // Get pagination from query
        const page = parseInt(c.req.query('page') || '1');
        const limit = parseInt(c.req.query('limit') || '10');

        // Calculate pagination
        const offset = (page - 1) * limit;

        // Build query without adminId filter
        const query = db.collection('tags')
            .orderBy('createdAt', 'desc');

        // Get data and count in parallel for better performance
        const [snapshot, totalSnapshot] = await Promise.all([
            query.limit(limit).offset(offset).get(),
            query.count().get()
        ]);

        const total = totalSnapshot.data().count;
        const tags = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));

        return c.json({
            success: true,
            data: {
                tags,
                pagination: {
                    total,
                    page,
                    limit,
                    totalPages: Math.ceil(total / limit),
                    hasMore: offset + tags.length < total
                }
            }
        });

    } catch (error) {
        console.error('Get Tags Error:', error);
        return c.json({
            success: false,
            message: error instanceof Error ? error.message : "An unexpected error occurred"
        }, 500);
    }
}

const updateTagsById = async (c: Context) => {
    try {
        const tagId = c.req.param('tagId');
        const { tagName, status } = await c.req.json();

        // Validate required fields
        if (!tagId || !tagName) {
            return c.json({
                success: false,
                message: "Tag ID and name are required"
            }, 400);
        }

        // Check if tag exists
        const tagRef = db.collection('tags').doc(tagId);
        const tagDoc = await tagRef.get();

        if (!tagDoc.exists) {
            return c.json({
                success: false,
                message: "Tag not found"
            }, 404);
        }

        const currentData = tagDoc.data();

        // Check for duplicate name if name is being changed
        if (tagName !== currentData?.tagName) {
            const duplicateCheck = await db.collection('tags')
                .where('tagName', '==', tagName)
                .get();

            if (!duplicateCheck.empty) {
                return c.json({
                    success: false,
                    message: "Tag name already exists"
                }, 409);
            }
        }

        // Convert boolean status to text status
        let textStatus = currentData?.status;
        if (status === false) {
            textStatus = 'inactive';
        } else if (status === true) {
            textStatus = 'active';
        }

        // Update tag
        const updateData = {
            tagName,
            status: textStatus,
            updatedAt: new Date().toISOString()
        };

        await tagRef.update(updateData);

        // Get updated document
        const updatedDoc = await tagRef.get();
        const updatedTag = {
            id: updatedDoc.id,
            ...updatedDoc.data()
        };

        return c.json({
            success: true,
            message: "Tag updated successfully",
            tag: updatedTag
        });

    } catch (error) {
        console.error('Update Tag Error:', error);
        return c.json({
            success: false,
            message: error instanceof Error ? error.message : "An unexpected error occurred"
        }, 500);
    }
}


const deleteTagsById = async (c: Context) => {
    try {
        const tagId = c.req.param('tagId');

        if (!tagId) {
            return c.json({
                success: false,
                message: "Tag ID is required"
            }, 400);
        }

        // Check if tag exists and get its data
        const tagRef = db.collection('tags').doc(tagId);
        const tagDoc = await tagRef.get();

        if (!tagDoc.exists) {
            return c.json({
                success: false,
                message: "Tag not found"
            }, 404);
        }

        const tagData = tagDoc.data();

        // Check if tag is being used in products (if productListingCount > 0)
        if (tagData?.productListingCount > 0) {
            return c.json({
                success: false,
                message: "Cannot delete tag as it is being used in active product listings",
                activeListings: tagData?.productListingCount
            }, 409);
        }

        // Perform the delete operation
        await tagRef.delete();

        return c.json({
            success: true,
            message: "Tag deleted successfully",
            deletedTag: {
                id: tagId,
                ...tagData
            }
        });

    } catch (error) {
        console.error('Delete Tag Error:', error);
        return c.json({
            success: false,
            message: error instanceof Error ? error.message : "An unexpected error occurred"
        }, 500);
    }
}


// Cosplay tags data - expanded to include more relevant cosplay tags
const COSPLAY_TAGS = [
    // Anime & Manga
    "Anime", "Manga", "My Hero Academia", "Attack on Titan", "Naruto", "One Piece", "Demon Slayer",
    "Tokyo Revengers", "Jujutsu Kaisen", "Chainsaw Man", "Sailor Moon", "Dragon Ball", "Genshin Impact",
    "Bleach", "Hunter x Hunter", "Fullmetal Alchemist", "JoJo's Bizarre Adventure", "Death Note",
    "Evangelion", "Cowboy Bebop", "Haikyuu", "Spy x Family", "Black Clover", "Blue Lock",
    "Fire Force", "Dr. Stone", "Made in Abyss", "Re:Zero", "Konosuba", "Sword Art Online",
    "Fate Series", "Studio Ghibli", "Persona", "One Punch Man", "Tokyo Ghoul", "Violet Evergarden",
    "Attack on Titan", "Bungo Stray Dogs", "Miss Kobayashi's Dragon Maid", "Kill la Kill",

    // Video Games
    "Video Games", "Final Fantasy", "Overwatch", "League of Legends", "Valorant",
    "Minecraft", "Pokémon", "The Legend of Zelda", "Resident Evil", "The Witcher",
    "Halo", "Mass Effect", "Kingdom Hearts", "Destiny", "Cyberpunk 2077", "Grand Theft Auto",
    "Borderlands", "God of War", "Metal Gear Solid", "Dark Souls", "Elden Ring", "Fallout",
    "BioShock", "Assassin's Creed", "Street Fighter", "Call of Duty", "Apex Legends",
    "Fortnite", "PUBG", "Monster Hunter", "Animal Crossing", "Fire Emblem", "Persona",
    "Nier: Automata", "Horizon Zero Dawn", "Death Stranding", "Hollow Knight", "Among Us",

    // Movies & TV
    "Movies", "TV Shows", "Marvel", "Star Wars", "Harry Potter", "Game of Thrones",
    "Stranger Things", "Lord of the Rings", "Disney", "The Mandalorian",
    "DC", "The Witcher Series", "Westworld", "Dune", "Avatar", "Star Trek",
    "Jurassic Park", "Indiana Jones", "Matrix", "Transformers", "Pirates of the Caribbean",
    "Fast & Furious", "John Wick", "Alien", "Predator", "Terminator", "Doctor Who",
    "Breaking Bad", "The Walking Dead", "Vikings", "The Boys", "Squid Game", "Money Heist",
    "The Umbrella Academy", "Wednesday", "Peaky Blinders", "The Last of Us",

    // Comic Books
    "Comic Books", "Marvel Comics", "DC Comics", "Batman", "Spider-Man", "Avengers", "X-Men",
    "Superman", "Wonder Woman", "The Flash", "Green Lantern", "Aquaman", "Justice League",
    "Deadpool", "Captain America", "Iron Man", "Thor", "Black Panther", "Hulk", "Punisher",
    "Guardians of the Galaxy", "Harley Quinn", "Joker", "Catwoman", "Black Widow", "Doctor Strange",
    "Venom", "Daredevil", "Green Arrow", "Hellboy", "Spawn", "The Boys Comics", "Invincible",
    "Teenage Mutant Ninja Turtles", "Ghost Rider", "Scarlet Witch", "Vision", "Winter Soldier",

    // VTubers
    "VTuber", "Hololive", "Nijisanji", "Virtual YouTuber", "VShojo", "Independent VTuber",
    "Gawr Gura", "Amelia Watson", "Calliope Mori", "Inugami Korone", "Usada Pekora",
    "Kizuna AI", "Ironmouse", "Projekt Melody", "Zentreya", "Nyanners", "Veibae",
    "Ouro Kronii", "Mori Calliope", "Takanashi Kiara", "Ninomae Ina'nis", "Hakos Baelz",

    // K-pop/J-pop
    "K-pop", "J-pop", "BTS", "BLACKPINK", "TWICE", "EXO", "Stray Kids", "SEVENTEEN",
    "ITZY", "NCT", "Red Velvet", "ENHYPEN", "TXT", "IVE", "aespa", "NewJeans",
    "BABYMETAL", "ONE OK ROCK", "AKB48", "ARASHI", "LiSA", "Perfume", "YOASOBI",

    // Styles & Types
    "Traditional", "Original", "Handmade", "Armor", "Weapon Prop", "Wig", "Full Costume",
    "Accessories", "Mask", "Bodysuit", "Magical Girl Outfit", "Mecha", "Fantasy", "Sci-Fi", "Steampunk",
    "Cyberpunk", "Gothic", "Lolita", "Victorian", "Medieval", "Futuristic", "Post-Apocalyptic",
    "Military", "School Uniform", "Kimono", "Yukata", "Hanfu", "Qipao", "Superhero", "Villain Outfit",
    "Casual Cosplay", "Genderbend", "Crossplay", "Group Cosplay", "Couple Cosplay", "Chibi Version",
    "Maid Outfit", "Butler Outfit", "Nurse Outfit", "Police Uniform", "Pirate", "Witch/Wizard",
    "Fairy", "Elf", "Orc", "Dwarf", "Animal Ears", "Kigurumi", "Fursuit", "Monster Girl/Boy",

    // Events
    "Convention", "Halloween", "Cosplay Competition", "Photoshoot", "Comicon", "Anime Expo",
    "Comic Con", "Cosplay Contest", "Halloween Party", "Anime Convention", "Gaming Convention",
    "Cosplay Masquerade", "Performance", "Runway Show", "Cosplay Ball", "Festival", "Parade",
    "Charity Event", "Meet and Greet", "Live Stream", "TikTok", "Instagram Cosplay", "YouTube Cosplay",

    // Materials & Features
    "Premium", "Deluxe", "Limited Edition", "Custom Size", "Prop Included", "Wig Included",
    "Beginner Friendly", "Professional Grade", "Battle Damage", "Authentic",
    "LED Lights", "Sound Effects", "Moving Parts", "Weathered", "Distressed", "Foam Armor",
    "EVA Foam", "Worbla", "3D Printed", "Leather", "Fabric", "Cotton", "Polyester", "Latex",
    "Silicone", "Resin Cast", "Metal Components", "PVC", "Spandex", "Plus Size", "Petite Size",
    "Adjustable", "Machine Washable", "Heat Resistant", "Water Resistant", "Quick Shipping",
    "Made to Order", "Ready to Wear", "Costest", "Budget Friendly", "High-End",

    // Character Types
    "Hero", "Villain", "Princess", "Warrior", "Mage", "Ninja", "Robot",
    "Monster", "Demon", "Angel", "Ghost", "Vampire", "Werewolf", "Zombie",
    "Knight", "Samurai", "Pirate", "Cowboy", "Spy", "Detective", "Superhero",
    "Supervillain", "Anti-Hero", "Sorcerer", "Witch", "Wizard", "Necromancer",
    "Assassin", "Thief", "Archer", "Gunslinger", "Bard", "Cleric", "Paladin",
    "Barbarian", "Druid", "Monk", "Ranger", "Rogue", "Warlock", "Summoner",
    "Shapeshifter", "Fairy", "Elf", "Dwarf", "Orc", "Goblin", "Dragon", "Phoenix",
    "Kitsune", "Yokai", "Deity", "God/Goddess", "Mythological Creature"
];

export const storeCosplayTagsData = async (c: Context) => {
    try {

        const batch = db.batch();
        const tagsCollection = db.collection("tags");

        // Current timestamp as string in ISO format
        const currentTimestamp = new Date().toISOString();

        // Create documents for each tag with a generated ID
        COSPLAY_TAGS.forEach((tag) => {
            const tagDoc = tagsCollection.doc();
            batch.set(tagDoc, {
                tagName: tag,
                slug: tag.toLowerCase().replace(/\s+/g, '-').replace(/[':]/g, ''),
                category: getCategoryForTag(tag),
                status: "active",
                productListingCount: 0,
                totalRentalCount: 0,
                createdAt: currentTimestamp,
                updatedAt: currentTimestamp,
                adminDetails: {
                    adminId: "iXxjvBlE2FSgNp9xxmDiDPY7rdC3",
                    adminName: "CosConect Admin",
                    adminEmail: "cosconnectme@gmail.com",
                    adminRole: "admin"
                }
            });
        });

        await batch.commit();

        return c.json({
            success: true,
            message: `Successfully stored ${COSPLAY_TAGS.length} cosplay tags in the database.`,
            count: COSPLAY_TAGS.length
        }, 201);
    } catch (error) {
        console.error("Error storing cosplay tags:", error);
        return c.json({
            success: false,
            message: "Failed to store cosplay tags in the database.",
            error: error instanceof Error ? error.message : "Unknown error"
        }, 500);
    }
};

// Helper function to determine the category of a tag
function getCategoryForTag(tag: string): string {
    const categories = {
        anime: [
            "Anime", "Manga", "My Hero Academia", "Attack on Titan", "Naruto", "One Piece", "Demon Slayer",
            "Tokyo Revengers", "Jujutsu Kaisen", "Chainsaw Man", "Sailor Moon", "Dragon Ball", "Genshin Impact",
            "Bleach", "Hunter x Hunter", "Fullmetal Alchemist", "JoJo's Bizarre Adventure", "Death Note",
            "Evangelion", "Cowboy Bebop", "Haikyuu", "Spy x Family", "Black Clover", "Blue Lock",
            "Fire Force", "Dr. Stone", "Made in Abyss", "Re:Zero", "Konosuba", "Sword Art Online",
            "Fate Series", "Studio Ghibli", "One Punch Man", "Tokyo Ghoul", "Violet Evergarden",
            "Bungo Stray Dogs", "Miss Kobayashi's Dragon Maid", "Kill la Kill"
        ],

        games: [
            "Video Games", "Final Fantasy", "Overwatch", "League of Legends", "Valorant",
            "Minecraft", "Pokémon", "The Legend of Zelda", "Resident Evil", "The Witcher",
            "Halo", "Mass Effect", "Kingdom Hearts", "Destiny", "Cyberpunk 2077", "Grand Theft Auto",
            "Borderlands", "God of War", "Metal Gear Solid", "Dark Souls", "Elden Ring", "Fallout",
            "BioShock", "Assassin's Creed", "Street Fighter", "Call of Duty", "Apex Legends",
            "Fortnite", "PUBG", "Monster Hunter", "Animal Crossing", "Fire Emblem", "Persona",
            "Nier: Automata", "Horizon Zero Dawn", "Death Stranding", "Hollow Knight", "Among Us"
        ],

        movies_tv: [
            "Movies", "TV Shows", "Marvel", "Star Wars", "Harry Potter", "Game of Thrones",
            "Stranger Things", "Lord of the Rings", "Disney", "The Mandalorian",
            "DC", "The Witcher Series", "Westworld", "Dune", "Avatar", "Star Trek",
            "Jurassic Park", "Indiana Jones", "Matrix", "Transformers", "Pirates of the Caribbean",
            "Fast & Furious", "John Wick", "Alien", "Predator", "Terminator", "Doctor Who",
            "Breaking Bad", "The Walking Dead", "Vikings", "The Boys", "Squid Game", "Money Heist",
            "The Umbrella Academy", "Wednesday", "Peaky Blinders", "The Last of Us"
        ],

        comics: [
            "Comic Books", "Marvel Comics", "DC Comics", "Batman", "Spider-Man", "Avengers", "X-Men",
            "Superman", "Wonder Woman", "The Flash", "Green Lantern", "Aquaman", "Justice League",
            "Deadpool", "Captain America", "Iron Man", "Thor", "Black Panther", "Hulk", "Punisher",
            "Guardians of the Galaxy", "Harley Quinn", "Joker", "Catwoman", "Black Widow", "Doctor Strange",
            "Venom", "Daredevil", "Green Arrow", "Hellboy", "Spawn", "The Boys Comics", "Invincible",
            "Teenage Mutant Ninja Turtles", "Ghost Rider", "Scarlet Witch", "Vision", "Winter Soldier"
        ],

        vtubers: [
            "VTuber", "Hololive", "Nijisanji", "Virtual YouTuber", "VShojo", "Independent VTuber",
            "Gawr Gura", "Amelia Watson", "Calliope Mori", "Inugami Korone", "Usada Pekora",
            "Kizuna AI", "Ironmouse", "Projekt Melody", "Zentreya", "Nyanners", "Veibae",
            "Ouro Kronii", "Mori Calliope", "Takanashi Kiara", "Ninomae Ina'nis", "Hakos Baelz"
        ],

        kpop_jpop: [
            "K-pop", "J-pop", "BTS", "BLACKPINK", "TWICE", "EXO", "Stray Kids", "SEVENTEEN",
            "ITZY", "NCT", "Red Velvet", "ENHYPEN", "TXT", "IVE", "aespa", "NewJeans",
            "BABYMETAL", "ONE OK ROCK", "AKB48", "ARASHI", "LiSA", "Perfume", "YOASOBI"
        ],

        styles: [
            "Traditional", "Original", "Handmade", "Armor", "Weapon Prop", "Wig", "Full Costume",
            "Accessories", "Mask", "Bodysuit", "Magical Girl Outfit", "Mecha", "Fantasy", "Sci-Fi", "Steampunk",
            "Cyberpunk", "Gothic", "Lolita", "Victorian", "Medieval", "Futuristic", "Post-Apocalyptic",
            "Military", "School Uniform", "Kimono", "Yukata", "Hanfu", "Qipao", "Superhero", "Villain Outfit",
            "Casual Cosplay", "Genderbend", "Crossplay", "Group Cosplay", "Couple Cosplay", "Chibi Version",
            "Maid Outfit", "Butler Outfit", "Nurse Outfit", "Police Uniform", "Pirate", "Witch/Wizard",
            "Fairy", "Elf", "Orc", "Dwarf", "Animal Ears", "Kigurumi", "Fursuit", "Monster Girl/Boy"
        ],

        events: [
            "Convention", "Halloween", "Cosplay Competition", "Photoshoot", "Comicon", "Anime Expo",
            "Comic Con", "Cosplay Contest", "Halloween Party", "Anime Convention", "Gaming Convention",
            "Cosplay Masquerade", "Performance", "Runway Show", "Cosplay Ball", "Festival", "Parade",
            "Charity Event", "Meet and Greet", "Live Stream", "TikTok", "Instagram Cosplay", "YouTube Cosplay"
        ],

        features: [
            "Premium", "Deluxe", "Limited Edition", "Custom Size", "Prop Included", "Wig Included",
            "Beginner Friendly", "Professional Grade", "Battle Damage", "Authentic",
            "LED Lights", "Sound Effects", "Moving Parts", "Weathered", "Distressed", "Foam Armor",
            "EVA Foam", "Worbla", "3D Printed", "Leather", "Fabric", "Cotton", "Polyester", "Latex",
            "Silicone", "Resin Cast", "Metal Components", "PVC", "Spandex", "Plus Size", "Petite Size",
            "Adjustable", "Machine Washable", "Heat Resistant", "Water Resistant", "Quick Shipping",
            "Made to Order", "Ready to Wear", "Costest", "Budget Friendly", "High-End"
        ],

        character_types: [
            "Hero", "Villain", "Princess", "Warrior", "Mage", "Ninja", "Robot",
            "Monster", "Demon", "Angel", "Ghost", "Vampire", "Werewolf", "Zombie",
            "Knight", "Samurai", "Pirate", "Cowboy", "Spy", "Detective", "Superhero",
            "Supervillain", "Anti-Hero", "Sorcerer", "Witch", "Wizard", "Necromancer",
            "Assassin", "Thief", "Archer", "Gunslinger", "Bard", "Cleric", "Paladin",
            "Barbarian", "Druid", "Monk", "Ranger", "Rogue", "Warlock", "Summoner",
            "Shapeshifter", "Fairy", "Elf", "Dwarf", "Orc", "Goblin", "Dragon", "Phoenix",
            "Kitsune", "Yokai", "Deity", "God/Goddess", "Mythological Creature"
        ]
    };

    for (const [category, tags] of Object.entries(categories)) {
        if (tags.includes(tag)) {
            return category;
        }
    }

    return "other";
}



const getAllProducts = async (c: Context) => {
    try {
        // Get query parameters with defaults
        const page = parseInt(c.req.query('page') || '1');
        const limit = Math.min(parseInt(c.req.query('limit') || '10'), 50); // Cap at 50 items per page
        const lenderId = c.req.param('lenderId');

        // Validate parameters
        if (page < 1 || isNaN(page)) {
            return c.json({ success: false, message: 'Invalid page number' }, 400);
        }
        if (limit < 1 || isNaN(limit)) {
            return c.json({ success: false, message: 'Invalid limit value' }, 400);
        }
        if (!lenderId) {
            return c.json({ success: false, message: 'LenderId is required' }, 400);
        }

        // Calculate offset
        const offset = (page - 1) * limit;

        // Create base query
        let query = db.collection('products')
            .where('lenderUser.uid', '==', lenderId)
            .orderBy('createdAt', 'desc'); // Latest products first

        // Get total count for pagination
        const totalSnapshot = await query.count().get();
        const total = totalSnapshot.data().count;

        // Get paginated results
        const snapshot = await query
            .limit(limit)
            .offset(offset)
            .get();

        // Transform documents
        const products = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data(),
            createdAt: doc.data().createdAt,
            updatedAt: doc.data().updatedAt
        }));

        // Calculate pagination metadata
        const totalPages = Math.ceil(total / limit);
        const hasMore = page < totalPages;
        const hasNext = page < totalPages;
        const hasPrev = page > 1;

        return c.json({
            success: true,
            data: {
                products,
                pagination: {
                    currentPage: page,
                    totalPages,
                    totalItems: total,
                    itemsPerPage: limit,
                    hasMore,
                    hasNext,
                    hasPrev
                }
            }
        });
    } catch (error) {
        console.error('Get All Products Error:', error);
        return c.json({
            success: false,
            message: error instanceof Error ? error.message : 'An unexpected error occurred'
        }, 500);
    }
};

/**
 * Retrieves all products with optional filtering and pagination
 * 
 * @param c - Hono Context
 * @returns JSON response with products and pagination metadata
 */
const getAllProductsForBorrowers = async (c: Context) => {
    try {
        // Get all products
        const productsRef = db.collection('products');
        const snapshot = await productsRef.get();

        // Transform documents to array
        const products = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));

        return c.json({
            success: true,
            data: {
                products,
                total: products.length
            }
        });
    } catch (error) {
        console.error('Get All Products Error:', error);
        return c.json({
            success: false,
            message: error instanceof Error ? error.message : 'An unexpected error occurred'
        }, 500);
    }
};

const getProductById = async (c: Context) => {
    try {
        // Validate input parameter
        const productId = c.req.param('productId');
        if (!productId || productId.trim() === '') {
            return c.json({ success: false, message: 'Product ID is required' }, 400);
        }

        // Get product document with error handling
        const productRef = db.collection('products').doc(productId);
        const product = await productRef.get();

        // Check if product exists
        if (!product.exists) {
            return c.json({ success: false, message: 'Product not found' }, 404);
        }

        // Format the response with consistent structure
        const productData = product.data();
        return c.json({
            success: true,
            data: {
                id: product.id,
                ...productData,
                createdAt: productData?.createdAt,
                updatedAt: productData?.updatedAt
            }
        });
    } catch (error) {
        console.error('Get Product By ID Error:', error);
        return c.json({
            success: false,
            message: error instanceof Error ? error.message : 'An unexpected error occurred'
        }, 500);
    }
}

// Email request schema for validation
const emailRequestSchema = z.object({
    email: z.string().email('Invalid email format')
});

const deleteProductById = async (C: Context) => {
    try {
        const productId = C.req.param("productId");

        if (!productId) {
            return C.json({ success: false, message: "Product ID is required" }, 400);
        }

        // Validate email from request body
        const body = await C.req.json();
        const emailValidation = emailRequestSchema.safeParse(body);

        if (!emailValidation.success) {
            return C.json({
                success: false,
                message: "Invalid email format",
                errors: emailValidation.error.errors
            }, 400);
        }

        const { email } = emailValidation.data;

        // Reference to the product document
        const productRef = db.collection('products').doc(productId);

        // Get the product document before deletion for email notification
        const productDoc = await productRef.get();

        if (!productDoc.exists) {
            return C.json({
                success: false,
                message: `Product with ID ${productId} not found or already deleted`
            }, 404);
        }

        const productData = productDoc.data();

        // Delete the product document
        await productRef.delete();

        // Prepare and send email notification
        await sendDeletionEmail(email, productData);

        return C.json({
            success: true,
            message: `Product ${productId} successfully deleted`,
            deletedProduct: productData
        }, 200);

    } catch (error: any) {
        console.error("Error deleting product:", error);

        // Determine appropriate error message and status code
        if (error instanceof z.ZodError) {
            return C.json({
                success: false,
                message: "Validation error",
                errors: error.errors
            }, 400);
        }

        // Handle Firebase errors
        if (error.code) {
            // Firebase specific error codes
            switch (error.code) {
                case 'permission-denied':
                    return C.json({
                        success: false,
                        message: "You don't have permission to delete this product"
                    }, 403);
                case 'unavailable':
                    return C.json({
                        success: false,
                        message: "Service temporarily unavailable, please try again later"
                    }, 503);
                default:
                    return C.json({
                        success: false,
                        message: `Firebase error: ${error.message}`
                    }, 500);
            }
        }

        return C.json({
            success: false,
            message: "Failed to delete product due to server error"
        }, 500);
    }
};

/**
 * Sends an email notification about the product deletion
 * @param email Recipient email address
 * @param productData Data of the deleted product
 */
const sendDeletionEmail = async (email: string, productData: any) => {
    try {
        const formattedDate = new Date().toLocaleString();

        // Format product details for email
        const productDetails = `
            <ul>
                <li><strong>Name:</strong> ${productData.name || 'N/A'}</li>
                <li><strong>Brand:</strong> ${productData.brand || 'N/A'}</li>
                <li><strong>Category:</strong> ${productData.category || 'N/A'}</li>
                <li><strong>Price:</strong> $${productData.regularPrice || 0}</li>
                <li><strong>Size:</strong> ${productData.selectedSize || 'N/A'}</li>
                <li><strong>Color:</strong> ${productData.selectedColor || 'N/A'}</li>
                <li><strong>Status:</strong> ${productData.status || 'N/A'}</li>
            </ul>
        `;

        // Create email message
        const mailOptions = {
            from: process.env.EMAIL_USER ,
            to: email,
            subject: 'Product Deletion Confirmation',
            html: `
                <div style="font-family: Arial, sans-serif; padding: 20px; color: #333;">
                    <h2 style="color: #e63946;">Product Deletion Confirmation</h2>
                    <p>Hello,</p>
                    <p>We are confirming that the following product has been successfully deleted from our system on ${formattedDate}:</p>
                    
                    <div style="background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0;">
                        ${productDetails}
                    </div>
                    
                    <p>If you did not request this deletion or have any questions, please contact our support team immediately.</p>
                    
                    <p style="margin-top: 30px;">Best regards,<br>Your Company Support Team</p>
                </div>
            `
        };

        // Send the email
        await transporter.sendMail(mailOptions);
        console.log(`Deletion notification email sent to ${email}`);

    } catch (emailError) {
        // Log email error but don't fail the deletion process
        console.error("Failed to send deletion notification email:", emailError);
    }
};


/**
 * Get all costumes for a specific lender with pagination
 * @param c Hono Context
 * @returns JSON response with paginated costumes
 */
const getMyProductsByLenderId = async (c: any): Promise<any> => {
    try {
        // Get query parameters
        const lenderId = c.req.param('lenderId');
        const page = parseInt(c.req.query('page') || '1', 10);
        const limit = Math.min(50, parseInt(c.req.query('limit') || '10', 10));

        // Simple validation
        if (isNaN(page) || page < 1) {
            return c.json({
                success: false,
                message: 'Invalid page number'
            }, 400);
        }

        if (isNaN(limit) || limit < 1 || limit > 50) {
            return c.json({
                success: false,
                message: 'Limit must be between 1 and 50'
            }, 400);
        }

        if (!lenderId) {
            return c.json({
                success: false,
                message: 'Lender ID is required'
            }, 400);
        }

        // Calculate offset
        const offset = (page - 1) * limit;

        // Get total count
        const totalCount = await db
            .collection('costumes')
            .where('lender_uid', '==', lenderId)
            .count()
            .get()
            .then(doc => Number(doc.data().count || 0));

        // Get paginated results
        const result = await db
            .collection('costumes')
            .where('lender_uid', '==', lenderId)
            .orderBy('created_at', 'desc')
            .limit(limit)
            .offset(offset)
            .get();
        // Calculate pagination m
        // etadata
        const totalPages = Math.ceil(totalCount / limit);

        return c.json({
            success: true,
            data: {
                items: result,
                pagination: {
                    total: totalCount,
                    page: page,
                    limit: limit,
                    totalPages: totalPages,
                    hasNextPage: page < totalPages,
                    hasPreviousPage: page > 1
                }
            }
        });

    } catch (error) {
        console.error('Error fetching costumes:', error);
        return c.json({
            success: false,
            message: 'Failed to fetch costumes',
            error: error instanceof Error ? error.message : 'Unknown error'
        }, 500);
    }
};


// Update the export
export default {
    createCategory,
    getAllCategories,
    updateCategoryById,
    createTags,
    getAllTags,
    updateTagsById,
    deleteTagsById,
    deleteCategoryById,
    storeCosplayTagsData,


    getAllProducts,
    getProductById,

    deleteProductById,
    getAllProductsForBorrowers,


    getMyProductsByLenderId
}
