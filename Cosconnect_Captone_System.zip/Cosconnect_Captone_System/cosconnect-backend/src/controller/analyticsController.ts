// controllers/analytics.controller.ts
import { Context } from 'hono';
import { users } from '../schema/users';
import { rentals } from '../schema/rentals';
import { rentalPaymentHistory } from '@/db-schema';
import { sql, count, gte, inArray } from 'drizzle-orm';
import db from '@/db/supabase/db_connect';

/**
 * Platform Fee Configuration
 */
const PLATFORM_FEES = {
    PROCESSING_FEE_RATE: 0.03,  // 3% processing fee for borrowers (on rental + extension fees)
    COMMISSION_RATE: 0.05       // 5% commission for platform from lenders (on their earnings)
};

/**
 * Analytics for Admin Dashboard
 * Returns all necessary data for charts and statistics
 */
const getAnalytics = async (c: Context): Promise<Response> => {
    try {
        // Execute all queries in parallel
        const [userStats, rentalStats, revenueStats, monthlyStats] = await Promise.all([
            getUserStats(),
            getRentalStats(),
            getRevenueStats(),
            getMonthlyStats()
        ]);

        return c.json({
            success: true,
            data: {
                users: userStats,
                rentals: rentalStats,
                revenue: revenueStats,
                charts: {
                    monthly: monthlyStats
                }
            }
        });

    } catch (error) {
        console.error('Analytics Error:', error);
        return c.json(
            {
                success: false,
                message: 'Failed to fetch analytics',
                error: error instanceof Error ? error.message : 'Unknown error'
            },
            500
        );
    }
};

/**
 * Get User Statistics - OPTIMIZED
 */
const getUserStats = async () => {
    const [counts, thisMonth] = await Promise.all([
        // Total user counts by role
        db.select({
            total: count(),
            borrowers: sql<number>`COUNT(*) FILTER (WHERE 'borrower' = ANY(${users.role}))`,
            lenders: sql<number>`COUNT(*) FILTER (WHERE 'lender' = ANY(${users.role}))`,
            both: sql<number>`COUNT(*) FILTER (WHERE 'borrower' = ANY(${users.role}) AND 'lender' = ANY(${users.role}))`
        }).from(users),

        // This month new users
        db.select({ count: count() })
            .from(users)
            .where(gte(users.created_at, sql`date_trunc('month', CURRENT_TIMESTAMP)`))
    ]);

    return {
        total: Number(counts[0]?.total || 0),
        borrowers: Number(counts[0]?.borrowers || 0),
        lenders: Number(counts[0]?.lenders || 0),
        bothRoles: Number(counts[0]?.both || 0),
        thisMonth: Number(thisMonth[0]?.count || 0)
    };
};

/**
 * Get Rental Statistics - OPTIMIZED
 */
const getRentalStats = async () => {
    const [counts, thisMonth] = await Promise.all([
        // Total rentals by all statuses
        db.select({
            total: count(),
            pending: sql<number>`COUNT(*) FILTER (WHERE ${rentals.status} = 'pending')`,
            confirmed: sql<number>`COUNT(*) FILTER (WHERE ${rentals.status} = 'confirmed')`,
            accepted: sql<number>`COUNT(*) FILTER (WHERE ${rentals.status} = 'accepted')`,
            delivered: sql<number>`COUNT(*) FILTER (WHERE ${rentals.status} = 'delivered')`,
            returned: sql<number>`COUNT(*) FILTER (WHERE ${rentals.status} = 'returned')`,
            completed: sql<number>`COUNT(*) FILTER (WHERE ${rentals.status} = 'completed')`,
            cancelled: sql<number>`COUNT(*) FILTER (WHERE ${rentals.status} = 'cancelled')`,
            rejected: sql<number>`COUNT(*) FILTER (WHERE ${rentals.status} = 'rejected')`,
            overdue: sql<number>`COUNT(*) FILTER (WHERE ${rentals.status} = 'overdue')`
        }).from(rentals),

        // This month rentals
        db.select({ count: count() })
            .from(rentals)
            .where(gte(rentals.created_at, sql`date_trunc('month', CURRENT_TIMESTAMP)`))
    ]);

    return {
        total: Number(counts[0]?.total || 0),
        pending: Number(counts[0]?.pending || 0),
        confirmed: Number(counts[0]?.confirmed || 0),
        accepted: Number(counts[0]?.accepted || 0),
        delivered: Number(counts[0]?.delivered || 0),
        returned: Number(counts[0]?.returned || 0),
        completed: Number(counts[0]?.completed || 0),
        cancelled: Number(counts[0]?.cancelled || 0),
        rejected: Number(counts[0]?.rejected || 0),
        overdue: Number(counts[0]?.overdue || 0),
        thisMonth: Number(thisMonth[0]?.count || 0)
    };
};

/**
 * Get Revenue Statistics from RETURNED/COMPLETED Rentals - WITH CORRECT FEES
 * Only counts rentals with status 'returned' or 'completed'
 * 
 * CORRECTED Financial Model:
 * 1. Borrower pays: Rental Fee + Security Deposit + Processing Fee (3% of Rental Fee)
 * 2. Lender earns: Rental Fee + Extension Fees + Damage Fees
 * 3. Platform deducts: 5% commission from Lender's earnings
 * 4. Lender receives: Lender's earnings - Platform commission
 * 5. Platform earns: Processing Fee (from borrower) + Commission (from lender's earnings)
 * 
 * Example:
 * Rental Fee: ₱3,750
 * Security Deposit: ₱1,500
 * Extension Fee: ₱0
 * Damage Fee: ₱0
 * 
 * Borrower Pays:
 * - Rental Fee: ₱3,750
 * - Security Deposit: ₱1,500
 * - Processing Fee (3%): ₱112.50 (3% of ₱3,750)
 * - Total: ₱5,362.50
 * 
 * Lender's Earnings (before commission): ₱3,750
 * Platform Commission (5%): ₱187.50 (5% of ₱3,750)
 * Lender Receives: ₱3,562.50
 * 
 * Platform Revenue: ₱112.50 + ₱187.50 = ₱300.00
 */
const getRevenueStats = async () => {
    const [allTime, thisMonth, breakdown] = await Promise.all([
        // All time revenue from returned/completed rentals
        db.select({
            totalRentalFees: sql<string>`COALESCE(SUM(CAST(${rentals.rental_amount} AS DECIMAL)), 0)`,
            totalDeposits: sql<string>`COALESCE(SUM(CAST(${rentals.security_deposit} AS DECIMAL)), 0)`,
            totalExtensionFees: sql<string>`COALESCE(SUM(CAST(${rentals.extension_fee} AS DECIMAL)), 0)`,
            totalDamageFees: sql<string>`COALESCE(SUM(CAST(${rentals.damage_cost} AS DECIMAL)), 0)`,
            totalGrossRevenue: sql<string>`COALESCE(SUM(CAST(${rentals.total_amount} AS DECIMAL)), 0)`,
            count: count()
        })
            .from(rentals)
            .where(inArray(rentals.status, ['returned', 'completed'])),

        // This month revenue from returned/completed rentals
        db.select({
            monthlyRentalFees: sql<string>`COALESCE(SUM(CAST(${rentals.rental_amount} AS DECIMAL)), 0)`,
            monthlyDeposits: sql<string>`COALESCE(SUM(CAST(${rentals.security_deposit} AS DECIMAL)), 0)`,
            monthlyExtensionFees: sql<string>`COALESCE(SUM(CAST(${rentals.extension_fee} AS DECIMAL)), 0)`,
            monthlyDamageFees: sql<string>`COALESCE(SUM(CAST(${rentals.damage_cost} AS DECIMAL)), 0)`,
            monthlyGrossRevenue: sql<string>`COALESCE(SUM(CAST(${rentals.total_amount} AS DECIMAL)), 0)`,
            count: count()
        })
            .from(rentals)
            .where(sql`
                ${rentals.status} IN ('returned', 'completed')
                AND ${rentals.returned_at} >= date_trunc('month', CURRENT_TIMESTAMP)
            `),

        // Detailed breakdown by rental status
        db.select({
            returnedRevenue: sql<string>`COALESCE(SUM(CAST(${rentals.total_amount} AS DECIMAL)) FILTER (WHERE ${rentals.status} = 'returned'), 0)`,
            completedRevenue: sql<string>`COALESCE(SUM(CAST(${rentals.total_amount} AS DECIMAL)) FILTER (WHERE ${rentals.status} = 'completed'), 0)`,
            returnedCount: sql<number>`COUNT(*) FILTER (WHERE ${rentals.status} = 'returned')`,
            completedCount: sql<number>`COUNT(*) FILTER (WHERE ${rentals.status} = 'completed')`,
            // Payout tracking
            payoutsCompleted: sql<number>`COUNT(*) FILTER (WHERE ${rentals.payout_completed_at} IS NOT NULL)`,
            refundsCompleted: sql<number>`COUNT(*) FILTER (WHERE ${rentals.refund_completed_at} IS NOT NULL)`,
            pendingPayouts: sql<number>`COUNT(*) FILTER (WHERE ${rentals.status} IN ('returned', 'completed') AND ${rentals.payout_completed_at} IS NULL)`,
            pendingRefunds: sql<number>`COUNT(*) FILTER (WHERE ${rentals.status} IN ('returned', 'completed') AND ${rentals.refund_completed_at} IS NULL)`
        })
            .from(rentals)
    ]);

    // Calculate totals
    const totalRentalFees = parseFloat(allTime[0]?.totalRentalFees || '0');
    const totalDeposits = parseFloat(allTime[0]?.totalDeposits || '0');
    const totalExtensionFees = parseFloat(allTime[0]?.totalExtensionFees || '0');
    const totalDamageFees = parseFloat(allTime[0]?.totalDamageFees || '0');
    const totalGrossRevenue = parseFloat(allTime[0]?.totalGrossRevenue || '0');

    // CORRECTED CALCULATIONS:

    // 1. Lender's earnings (before commission) = rental fees + extension fees + damage fees
    //    Note: Security deposits are excluded as they're refundable to borrowers
    const lenderEarningsBeforeCommission = totalRentalFees + totalExtensionFees + totalDamageFees;

    // 2. Processing fee: 3% on rental fees + extension fees (charged to borrowers)
    const processingFees = (totalRentalFees + totalExtensionFees) * PLATFORM_FEES.PROCESSING_FEE_RATE;

    // 3. Platform commission: 5% on lender's earnings (deducted from lenders)
    const platformCommissions = lenderEarningsBeforeCommission * PLATFORM_FEES.COMMISSION_RATE;

    // 4. Lender payout = lender's earnings - platform commission
    const lenderPayout = lenderEarningsBeforeCommission - platformCommissions;

    // 5. Platform revenue = processing fees (from borrowers) + commissions (from lenders)
    const platformRevenue = processingFees + platformCommissions;

    // 6. Total collected from borrowers = gross revenue + processing fees
    const totalCollected = totalGrossRevenue + processingFees;

    return {
        totalRevenue: totalGrossRevenue,
        totalCollected: totalCollected, // Total amount collected from borrowers (including processing fees)
        platformRevenue: platformRevenue, // Platform's actual revenue
        lenderPayout: lenderPayout, // Amount to be paid to lenders (after commission)
        lenderEarningsBeforeCommission: lenderEarningsBeforeCommission, // Lender's earnings before platform commission
        totalTransactions: Number(allTime[0]?.count || 0),
        thisMonthRevenue: parseFloat(thisMonth[0]?.monthlyGrossRevenue || '0'),
        thisMonthTransactions: Number(thisMonth[0]?.count || 0),
        breakdown: {
            rentalFees: totalRentalFees,
            securityDeposits: totalDeposits,
            extensionFees: totalExtensionFees,
            damageFees: totalDamageFees,
            processingFees: processingFees, // 3% from borrowers on rental+extension fees
            platformCommissions: platformCommissions // 5% from lender's earnings
        },
        fees: {
            processingFeeRate: PLATFORM_FEES.PROCESSING_FEE_RATE,
            commissionRate: PLATFORM_FEES.COMMISSION_RATE,
            totalProcessingFees: processingFees,
            totalCommissions: platformCommissions
        },
        byStatus: {
            returned: {
                revenue: parseFloat(breakdown[0]?.returnedRevenue || '0'),
                count: Number(breakdown[0]?.returnedCount || 0)
            },
            completed: {
                revenue: parseFloat(breakdown[0]?.completedRevenue || '0'),
                count: Number(breakdown[0]?.completedCount || 0)
            }
        },
        payoutStatus: {
            completed: Number(breakdown[0]?.payoutsCompleted || 0),
            pending: Number(breakdown[0]?.pendingPayouts || 0)
        },
        refundStatus: {
            completed: Number(breakdown[0]?.refundsCompleted || 0),
            pending: Number(breakdown[0]?.pendingRefunds || 0)
        }
    };
};

/**
 * Get Monthly Statistics for Charts (Last 12 months)
 * UPDATED: Revenue from returned/completed rentals with CORRECTED fees
 */
const getMonthlyStats = async () => {
    interface MonthlyStatsRow {
        month: string;
        label: string;
        users_total: string | number;
        users_borrowers: string | number;
        users_lenders: string | number;
        rentals_total: string | number;
        rentals_completed: string | number;
        rentals_returned: string | number;
        rentals_pending: string | number;
        revenue_total: string | number;
        revenue_rental_fees: string | number;
        revenue_extension_fees: string | number;
        revenue_damage_fees: string | number;
        transactions_count: string | number;
    }

    const monthlyData = await db.execute<any>(sql`
        WITH months AS (
            SELECT 
                date_trunc('month', CURRENT_TIMESTAMP - (interval '1 month' * generate_series(0, 11)))::date AS month_start,
                to_char(date_trunc('month', CURRENT_TIMESTAMP - (interval '1 month' * generate_series(0, 11))), 'Mon YYYY') AS label
        ),
        user_stats AS (
            SELECT 
                date_trunc('month', created_at)::date AS month,
                COUNT(*) AS total_users,
                COUNT(*) FILTER (WHERE 'borrower' = ANY(role)) AS borrowers,
                COUNT(*) FILTER (WHERE 'lender' = ANY(role)) AS lenders
            FROM users
            WHERE created_at >= date_trunc('month', CURRENT_TIMESTAMP - interval '11 months')
            GROUP BY date_trunc('month', created_at)::date
        ),
        rental_stats AS (
            SELECT 
                date_trunc('month', created_at)::date AS month,
                COUNT(*) AS total_rentals,
                COUNT(*) FILTER (WHERE status = 'completed') AS completed,
                COUNT(*) FILTER (WHERE status = 'returned') AS returned,
                COUNT(*) FILTER (WHERE status = 'pending') AS pending
            FROM rentals
            WHERE created_at >= date_trunc('month', CURRENT_TIMESTAMP - interval '11 months')
            GROUP BY date_trunc('month', created_at)::date
        ),
        revenue_stats AS (
            SELECT 
                date_trunc('month', COALESCE(returned_at, completed_at, created_at))::date AS month,
                COUNT(*) FILTER (WHERE status IN ('returned', 'completed')) AS transaction_count,
                COALESCE(SUM(CAST(total_amount AS DECIMAL)) FILTER (WHERE status IN ('returned', 'completed')), 0) AS total_revenue,
                COALESCE(SUM(CAST(rental_amount AS DECIMAL)) FILTER (WHERE status IN ('returned', 'completed')), 0) AS rental_fees,
                COALESCE(SUM(CAST(extension_fee AS DECIMAL)) FILTER (WHERE status IN ('returned', 'completed')), 0) AS extension_fees,
                COALESCE(SUM(CAST(damage_cost AS DECIMAL)) FILTER (WHERE status IN ('returned', 'completed')), 0) AS damage_fees
            FROM rentals
            WHERE COALESCE(returned_at, completed_at, created_at) >= date_trunc('month', CURRENT_TIMESTAMP - interval '11 months')
            GROUP BY date_trunc('month', COALESCE(returned_at, completed_at, created_at))::date
        )
        SELECT 
            m.month_start::text AS month,
            m.label,
            COALESCE(u.total_users, 0) AS users_total,
            COALESCE(u.borrowers, 0) AS users_borrowers,
            COALESCE(u.lenders, 0) AS users_lenders,
            COALESCE(r.total_rentals, 0) AS rentals_total,
            COALESCE(r.completed, 0) AS rentals_completed,
            COALESCE(r.returned, 0) AS rentals_returned,
            COALESCE(r.pending, 0) AS rentals_pending,
            COALESCE(rv.total_revenue, 0) AS revenue_total,
            COALESCE(rv.rental_fees, 0) AS revenue_rental_fees,
            COALESCE(rv.extension_fees, 0) AS revenue_extension_fees,
            COALESCE(rv.damage_fees, 0) AS revenue_damage_fees,
            COALESCE(rv.transaction_count, 0) AS transactions_count
        FROM months m
        LEFT JOIN user_stats u ON m.month_start = u.month
        LEFT JOIN rental_stats r ON m.month_start = r.month
        LEFT JOIN revenue_stats rv ON m.month_start = rv.month
        ORDER BY m.month_start DESC
    `);

    return (monthlyData as MonthlyStatsRow[]).map((row) => {
        const rentalFees = parseFloat(String(row.revenue_rental_fees));
        const extensionFees = parseFloat(String(row.revenue_extension_fees));
        const damageFees = parseFloat(String(row.revenue_damage_fees));
        const totalRevenue = parseFloat(String(row.revenue_total));

        // CORRECTED: Calculate fees for this month
        const lenderEarnings = rentalFees + extensionFees + damageFees;
        const processingFees = (rentalFees + extensionFees) * PLATFORM_FEES.PROCESSING_FEE_RATE;
        const platformCommissions = lenderEarnings * PLATFORM_FEES.COMMISSION_RATE;

        return {
            month: row.month.substring(0, 7), // YYYY-MM format
            label: row.label,
            users: {
                total: Number(row.users_total),
                borrowers: Number(row.users_borrowers),
                lenders: Number(row.users_lenders)
            },
            rentals: {
                total: Number(row.rentals_total),
                completed: Number(row.rentals_completed),
                returned: Number(row.rentals_returned),
                pending: Number(row.rentals_pending)
            },
            revenue: {
                total: totalRevenue,
                rentalFees: rentalFees,
                extensionFees: extensionFees,
                damageFees: damageFees,
                processingFees: processingFees,
                platformCommissions: platformCommissions,
                platformRevenue: processingFees + platformCommissions,
                transactionCount: Number(row.transactions_count)
            }
        };
    }).reverse(); // Reverse to get oldest to newest
};

export default {
    getAnalytics
};