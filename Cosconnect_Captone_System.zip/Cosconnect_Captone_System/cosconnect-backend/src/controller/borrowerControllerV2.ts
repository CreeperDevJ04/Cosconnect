import { BorrowerData } from "@/lib/types/borrower";
import type { Context } from 'hono';
import nodemailer from 'nodemailer';
import { supabase, supabaseAdmin } from "../db/supabase/auth";
import { transporter } from "@/lib/nodemailer/transporter";
import { db } from "../db/supabase/db_connect";
import { users } from "../schema/users";
import { eq } from "drizzle-orm";

// Define the user type
// OTP utility functions
const generateOTP = (): string => {
    return Math.floor(100000 + Math.random() * 900000).toString();
};

const storeOTP = async (email: string, otp: string): Promise<void> => {
    const expiresAt = new Date();
    expiresAt.setMinutes(expiresAt.getMinutes() + 10); // OTP valid for 10 minutes

    // For now, store OTP in memory or database
    // You can create an OTP table in Supabase later
    console.log(`OTP for ${email}: ${otp} (expires: ${expiresAt.toISOString()})`);
};

const verifyOTP = async (email: string, userOtp: string): Promise<{ isValid: boolean; message: string }> => {
    try {
        console.log("email", email);
        console.log("userOtp", userOtp);

        // For now, return true (implement proper OTP verification later)
        // You should store OTPs in Supabase and verify them properly
        return {
            isValid: true,
            message: "OTP verified successfully"
        };
    } catch (error) {
        console.error("Error verifying OTP:", error);
        return {
            isValid: false,
            message: "An error occurred while verifying the code. Please try again."
        };
    }
};

const sendOTPEmail = async (userData: { email: string, fullName: string }, otp: string): Promise<void> => {
    const mailOptions = {
        from: process.env.EMAIL_USER ,
        to: userData.email,
        subject: 'CosConnect Email Verification Code',
        html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2>Verify Your Email Address</h2>
                <p>Hello ${userData.fullName},</p>
                <p>Thank you for registering with CosConnect. To complete your registration, please use the following verification code:</p>
                <div style="background-color: #f4f4f4; padding: 15px; text-align: center; font-size: 24px; font-weight: bold; letter-spacing: 5px; margin: 20px 0;">
                    ${otp}
                </div>
                <p>This code will expire in 10 minutes.</p>
                <p>If you didn't request this code, please ignore this email.</p>
                <p>Best regards,<br>The CosConnect Team</p>
            </div>
        `
    };

    await transporter.sendMail(mailOptions);
};

// Request OTP for email verification
const requestOTP = async (c: Context) => {
    try {
        const body: { email: string, fullName: string } = await c.req.json();
        const { email, fullName } = body;

        if (!email) {
            return c.json({
                success: false,
                message: 'Email is required'
            }, 400);
        }

        // Generate and store OTP
        const otp = generateOTP();
        await storeOTP(email, otp);

        // Send OTP email
        await sendOTPEmail({ email, fullName }, otp);

        return c.json({
            success: true,
            message: 'Verification code sent to your email'
        });
    } catch (error: any) {
        console.error('OTP Request Error:', error);
        return c.json({
            success: false,
            message: error.message || 'Failed to send verification code'
        }, 500);
    }
};

// Resend OTP
const resendOTP = async (c: Context) => {
    try {
        const body: { email: string, fullName: string } = await c.req.json();
        const { email, fullName } = body;

        if (!email) {
            return c.json({
                success: false,
                message: 'Email is required'
            }, 400);
        }

        // Generate and store new OTP
        const otp = generateOTP();
        await storeOTP(email, otp);

        // Send OTP email
        await sendOTPEmail({ email, fullName }, otp);

        return c.json({
            success: true,
            message: 'New verification code sent to your email'
        });
    } catch (error: any) {
        console.error('Resend OTP Error:', error);
        return c.json({
            success: false,
            message: error.message || 'Failed to resend verification code'
        }, 500);
    }
};

const userBorrowerSignUp = async (c: Context) => {
    try {
        if (!supabase || !supabaseAdmin) {
            return c.json({
                success: false,
                message: 'Supabase authentication not configured'
            }, 500);
        }

        const body: BorrowerData = await c.req.json();
        const { personalInfo, identification, otpCode } = body;

        // Validate OTP first before proceeding
        if (!otpCode) {
            return c.json({
                success: false,
                message: 'Email verification code is required'
            }, 400);
        }

        // Verify OTP
        const otpVerification = await verifyOTP(personalInfo.email, otpCode);
        if (!otpVerification.isValid) {
            return c.json({
                success: false,
                message: otpVerification.message
            }, 400);
        }

        // Check if email already exists in Supabase Auth
        const { data: existingUsers } = await supabaseAdmin.auth.admin.listUsers();
        const existingUser = existingUsers.users.find(user => user.email === personalInfo.email);

        if (existingUser) {
            return c.json({
                success: false,
                message: 'Email already in use. Please use a different email address.'
            }, 400);
        }

        // Check if username already exists in database
        const usernameToCheck = personalInfo.username.toLowerCase();
        const [existingUsername] = await db
            .select({ uid: users.uid })
            .from(users)
            .where(eq(users.username, usernameToCheck))
            .limit(1);

        if (existingUsername) {
            return c.json({
                success: false,
                message: 'Username already exists. Please choose a different username.'
            }, 400);
        }

        // Validate Personal Info
        const requiredPersonalFields = [
            'email', 'password', 'fullName', 'username', 'phoneNumber', 'address'
        ];
        const missingPersonalFields = requiredPersonalFields.filter(
            field => !personalInfo[field as keyof typeof personalInfo]
        );

        if (missingPersonalFields.length > 0) {
            return c.json({
                success: false,
                message: `Missing personal info fields: ${missingPersonalFields.join(', ')}`
            }, 400);
        }

        // Validate Identification
        if (identification.hasValidId) {
            if (!identification.validIdType || !identification.validIdNumber || !identification.validIdFile) {
                return c.json({
                    success: false,
                    message: 'Valid ID information is incomplete'
                }, 400);
            }
        } else {
            if (!identification.secondaryIdType1 || !identification.secondaryIdFile1 ||
                !identification.secondaryIdType2 || !identification.secondaryIdFile2) {
                return c.json({
                    success: false,
                    message: 'Secondary ID information is incomplete'
                }, 400);
            }
        }

        // Validate password length
        if (personalInfo.password.length < 6) {
            return c.json({
                success: false,
                message: 'Password must be at least 6 characters'
            }, 400);
        }

        // Create user with Supabase Auth
        const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
            email: personalInfo.email,
            password: personalInfo.password,
            email_confirm: true, // Skip email confirmation since we verified OTP
            user_metadata: {
                full_name: personalInfo.fullName,
                username: personalInfo.username.toLowerCase(),
            }
        });

        if (authError || !authData.user) {
            console.error('Supabase Auth Error:', authError);
            return c.json({
                success: false,
                message: 'Failed to create user account'
            }, 500);
        }

        // Prepare user data for database
        const userData = {
            uid: authData.user.id,
            email: personalInfo.email,
            full_name: personalInfo.fullName,
            username: personalInfo.username.toLowerCase(),
            phone_number: personalInfo.phoneNumber,
            address: personalInfo.address,
            city: personalInfo.city || '',
            barangay: personalInfo.barangay || '',
            province: personalInfo.province || '',
            zip_code: personalInfo.zipCode || '',
            region: personalInfo.region || '',
            street: personalInfo.street || '',
            country: "Philippines",
            role: ['borrower'],
            status: 'pending',
            created_at: new Date(),
            updated_at: new Date(),
            is_verified: false,
            // Handle identification data
            has_valid_id: identification.hasValidId,
            ...(identification.hasValidId ? {
                valid_id_type: identification.validIdType || null,
                valid_id_number: identification.validIdNumber || null,
                valid_id_file: identification.validIdFile || null
            } : {
                secondary_id_type_1: identification.secondaryIdType1 || null,
                secondary_id_file_1: identification.secondaryIdFile1 || null,
                secondary_id_type_2: identification.secondaryIdType2 || null,
                secondary_id_file_2: identification.secondaryIdFile2 || null
            })
        };

        // Store user details in database
        const [newUser] = await db.insert(users).values(userData).returning();

        return c.json({
            success: true,
            message: 'Borrower account created successfully. Please check your email for confirmation.',
            uid: authData.user.id
        });
    } catch (error: any) {
        console.error('Borrower Signup Error:', error);
        return c.json({
            success: false,
            message: error.message || 'Borrower signup failed'
        }, 400);
    }
};

const userBorrowerSignIn = async (c: Context) => {
    try {
        if (!supabase) {
            return c.json({
                success: false,
                message: 'Supabase authentication not configured'
            }, 500);
        }

        const { email, password } = await c.req.json();

        if (!email || !password) {
            return c.json({
                success: false,
                message: 'Email and password are required'
            }, 400);
        }

        // Sign in with Supabase Auth
        const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
            email,
            password
        });

        if (authError || !authData.user) {
            return c.json({
                success: false,
                message: 'Invalid email or password',
                status: "invalid-credentials"
            }, 401);
        }

        // Get user data from database
        const [userData] = await db
            .select()
            .from(users)
            .where(eq(users.uid, authData.user.id))
            .limit(1);

        if (!userData) {
            return c.json({
                success: false,
                message: 'User data not found'
            }, 404);
        }

        // Check if account status is pending
        if (userData.status === "pending") {
            return c.json({
                success: false,
                message: 'Your account is currently under review. Our team will email you once your application has been approved or rejected.',
                status: 'under-review'
            }, 403);
        }

        // Return success response
        return c.json({
            success: true,
            message: 'Borrower signed in successfully',
            idToken: authData.session?.access_token,
            user: {
                uid: userData.uid,
                email: userData.email,
                fullName: userData.full_name,
                username: userData.username,
                phoneNumber: userData.phone_number,
                address: userData.address,
                role: 'borrower',
                identification: {
                    hasValidId: userData.has_valid_id,
                    validIdType: userData.valid_id_type,
                    validIdNumber: userData.valid_id_number,
                    validIdFile: userData.valid_id_file,
                    secondaryIdType1: userData.secondary_id_type_1,
                    secondaryIdFile1: userData.secondary_id_file_1,
                    secondaryIdType2: userData.secondary_id_type_2,
                    secondaryIdFile2: userData.secondary_id_file_2,
                }
            }
        });

    } catch (error: any) {
        console.error('Borrower Sign In Error:', error);
        return c.json({
            success: false,
            message: error.message || 'An unexpected error occurred during sign in',
            status: "unexpected-error"
        }, 500);
    }
};

const getProfileInfoBorrower = async (c: Context) => {
    try {
        // Get username from query parameters
        const username = c.req.param('username')?.toLowerCase();

        // Validate username
        if (!username) {
            return c.json({
                success: false,
                message: 'Username is required',
                status: 'missing-parameter'
            }, 400);
        }

        // Get user document from database
        const [userData] = await db
            .select()
            .from(users)
            .where(eq(users.username, username))
            .limit(1);

        // Check if user exists
        if (!userData) {
            return c.json({
                success: false,
                message: 'Borrower not found',
                status: 'not-found'
            }, 404);
        }

        // Return success response with user data
        return c.json({
            success: true,
            message: 'Borrower data retrieved successfully',
            data: {
                id: userData.uid,
                uid: userData.uid,
                ...userData
            },
            status: 'success'
        });

    } catch (error: any) {
        console.error('Error getting borrower data:', error);
        return c.json({
            success: false,
            message: 'An error occurred while fetching borrower data',
            status: 'server-error',
            error: error.message
        }, 500);
    }
};

export default {
    userBorrowerSignUp,
    userBorrowerSignIn,
    resendOTP,
    requestOTP,
    getProfileInfoBorrower
};