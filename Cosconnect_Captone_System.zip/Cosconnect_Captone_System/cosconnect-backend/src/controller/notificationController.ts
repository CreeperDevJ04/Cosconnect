// src/services/notificationService.ts
import { eq, and, desc, isNull, count, inArray, or } from "drizzle-orm";
import db from "../db/supabase/db_connect";
import { notifications } from "../schema/notifications";
import { users, user_business_info } from "../schema/users";
import type {
    NewNotification,
    NotificationType,
    RecipientRole
} from "../schema/notifications";
import { Context } from "hono";

// ═══════════════════════════════════════════════════════════════
// 📝 TYPE DEFINITIONS
// ═══════════════════════════════════════════════════════════════
interface CreateNotificationInput {
    recipientId: string;
    recipientRole?: RecipientRole;
    senderId?: string | null;
    senderRole?: RecipientRole;
    senderType?: "user" | "admin" | "system";
    type: NotificationType;
    title: string;
    message: string;
    costumeId?: string;
    postId?: string;
    rentalId?: string;
    paymentId?: string;
    messageId?: string;
    metadata?: Record<string, unknown>;
    expiresAt?: Date;
}

interface UpdateNotificationStatusInput {
    notificationId: string;
    status: "READ" | "ARCHIVED";
}

interface GetNotificationsInput {
    userId: string;
    role?: RecipientRole;
    status?: "UNREAD" | "READ" | "ARCHIVED";
    limit?: number;
}

// ═══════════════════════════════════════════════════════════════
// 🔧 HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════
/**
 * Get the appropriate email based on user's current role
 */
async function getRecipientEmail(
    userId: string,
    role: RecipientRole = "borrower"
): Promise<string> {
    try {
        // Get user data
        const [user] = await db
            .select({
                email: users.email,
                businessEmail: user_business_info.business_email,
            })
            .from(users)
            .leftJoin(user_business_info, eq(users.uid, user_business_info.user_uid))
            .where(eq(users.uid, userId))
            .limit(1);

        if (!user) {
            throw new Error(`User not found: ${userId}`);
        }

        // Return business email if role is lender and business email exists
        if (role === "lender" && user.businessEmail) {
            return user.businessEmail;
        }

        // Otherwise return user's primary email
        return user.email;
    } catch (error) {
        console.error("❌ Error fetching recipient email:", error);
        throw new Error("Failed to fetch recipient email");
    }
}

// ═══════════════════════════════════════════════════════════════
// 🔔 NOTIFICATION SERVICE
// ═══════════════════════════════════════════════════════════════
export const notificationService = {
    /**
     * Create a new notification
     */
    async create(input: CreateNotificationInput) {
        try {
            // Get the appropriate email for the recipient
            const recipientEmail = await getRecipientEmail(
                input.recipientId,
                input.recipientRole || "borrower"
            );

            const [notification] = await db
                .insert(notifications)
                .values({
                    recipient_id: input.recipientId,
                    recipient_role: input.recipientRole || "borrower",
                    recipient_email: recipientEmail,
                    sender_id: input.senderId || null,
                    sender_role: input.senderRole || null,
                    sender_type: input.senderType || "system",
                    type: input.type,
                    title: input.title,
                    message: input.message,
                    costume_id: input.costumeId || null,
                    post_id: input.postId || null,
                    rental_id: input.rentalId || null,
                    payment_id: input.paymentId || null,
                    message_id: input.messageId || null,
                    metadata: input.metadata || {},
                    expires_at: input.expiresAt || null,
                })
                .returning();

            return notification;
        } catch (error) {
            console.error("❌ Error creating notification:", error);
            throw new Error("Failed to create notification");
        }
    },

    /**
     * Get notifications for a user
     */
    async getByUser(input: GetNotificationsInput) {
        try {
            const conditions: any[] = [
                eq(notifications.recipient_id, input.userId),
                eq(notifications.is_deleted, false),
            ];

            if (input.role) {
                conditions.push(
                    or(
                        eq(notifications.recipient_role, input.role),
                        inArray(notifications.type, [
                            "LENDER_VERIFICATION_PENDING",
                            "LENDER_VERIFICATION_APPROVED",
                            "LENDER_VERIFICATION_REJECTED",
                        ] as any),
                    ),
                );
            }

            if (input.status) {
                conditions.push(eq(notifications.status, input.status));
            }

            const userNotifications = await db
                .select()
                .from(notifications)
                .where(and(...conditions))
                .orderBy(desc(notifications.created_at))
                .limit(input.limit || 50);

            return userNotifications;
        } catch (error) {
            console.error("❌ Error fetching notifications:", error);
            throw new Error("Failed to fetch notifications");
        }
    },

    /**
     * Mark notification as read
     */
    async markAsRead(notificationId: string) {
        try {
            const [updated] = await db
                .update(notifications)
                .set({
                    status: "READ",
                    read_at: new Date(),
                })
                .where(eq(notifications.id, notificationId))
                .returning();

            return updated;
        } catch (error) {
            console.error("❌ Error marking notification as read:", error);
            throw new Error("Failed to mark notification as read");
        }
    },

    /**
     * Mark multiple notifications as read
     */
    async markMultipleAsRead(notificationIds: string[]) {
        try {
            await db
                .update(notifications)
                .set({
                    status: "READ",
                    read_at: new Date(),
                })
                .where(
                    and(
                        eq(notifications.id as any, notificationIds[0]),
                        // Add more conditions for other IDs
                    )
                );

            return { success: true, count: notificationIds.length };
        } catch (error) {
            console.error("❌ Error marking notifications as read:", error);
            throw new Error("Failed to mark notifications as read");
        }
    },

    /**
     * Archive notification
     */
    async archive(notificationId: string) {
        try {
            const [updated] = await db
                .update(notifications)
                .set({
                    status: "ARCHIVED",
                    archived_at: new Date(),
                })
                .where(eq(notifications.id, notificationId))
                .returning();

            return updated;
        } catch (error) {
            console.error("❌ Error archiving notification:", error);
            throw new Error("Failed to archive notification");
        }
    },

    /**
     * Soft delete notification
     */
    async delete(notificationId: string) {
        try {
            const [deleted] = await db
                .update(notifications)
                .set({
                    is_deleted: true,
                })
                .where(eq(notifications.id, notificationId))
                .returning();

            return deleted;
        } catch (error) {
            console.error("❌ Error deleting notification:", error);
            throw new Error("Failed to delete notification");
        }
    },

    /**
     * Get unread count for user
     */
    async getUnreadCount(userId: string, role?: RecipientRole) {
        try {
            const conditions: any[] = [
                eq(notifications.recipient_id, userId),
                eq(notifications.status, "UNREAD"),
                eq(notifications.is_deleted, false),
            ];

            if (role) {
                conditions.push(
                    or(
                        eq(notifications.recipient_role, role),
                        inArray(notifications.type, [
                            "LENDER_VERIFICATION_PENDING",
                            "LENDER_VERIFICATION_APPROVED",
                            "LENDER_VERIFICATION_REJECTED",
                        ] as any),
                    ),
                );
            }

            const result = await db
                .select()
                .from(notifications)
                .where(and(...conditions));

            return result.length;
        } catch (error) {
            console.error("❌ Error getting unread count:", error);
            throw new Error("Failed to get unread count");
        }
    },

    /**
     * Mark all notifications as read for a user
     */
    async markAllAsRead(userId: string, role?: RecipientRole) {
        try {
            const conditions = [
                eq(notifications.recipient_id, userId),
                eq(notifications.status, "UNREAD"),
            ];

            if (role) {
                conditions.push(eq(notifications.recipient_role, role));
            }

            await db
                .update(notifications)
                .set({
                    status: "READ",
                    read_at: new Date(),
                })
                .where(and(...conditions));

            return { success: true };
        } catch (error) {
            console.error("❌ Error marking all as read:", error);
            throw new Error("Failed to mark all notifications as read");
        }
    },

    /**
     * Delete expired notifications (cleanup job)
     */
    async deleteExpired() {
        try {
            const now = new Date();

            await db
                .update(notifications)
                .set({
                    is_deleted: true,
                })
                .where(
                    and(
                        eq(notifications.is_deleted, false),
                        isNull(notifications.expires_at)
                    )
                );

            return { success: true };
        } catch (error) {
            console.error("❌ Error deleting expired notifications:", error);
            throw new Error("Failed to delete expired notifications");
        }
    },
};

// ═══════════════════════════════════════════════════════════════
// 🎯 NOTIFICATION TEMPLATES (Optional Helper)
// ═══════════════════════════════════════════════════════════════
export const notificationTemplates = {
    rentalRequest: (lenderName: string, costumeName: string) => ({
        title: "New Rental Request",
        message: `${lenderName} has requested to rent your costume "${costumeName}".`,
    }),

    rentalApproved: (borrowerName: string, costumeName: string) => ({
        title: "Rental Approved",
        message: `Your rental request for "${costumeName}" has been approved by ${borrowerName}.`,
    }),

    rentalRejected: (costumeName: string, reason?: string) => ({
        title: "Rental Request Rejected",
        message: `Your rental request for "${costumeName}" has been rejected.${reason ? ` Reason: ${reason}` : ""}`,
    }),

    rentalDelivered: (costumeName: string, lenderName: string) => ({
        title: "Costume Delivered",
        message: `Your rented costume "${costumeName}" has been delivered by ${lenderName}.`,
    }),

    rentalReturned: (costumeName: string, returnerName?: string) => ({
        title: "Costume Returned",
        message: `The costume "${costumeName}" has been returned${returnerName ? ` by ${returnerName}` : ""}.`,
    }),

    paymentSuccess: (amount: number, costumeName: string) => ({
        title: "Payment Successful",
        message: `Your payment of ₱${amount.toFixed(2)} for "${costumeName}" was successful.`,
    }),

    lenderVerificationApproved: () => ({
        title: "Lender Account Approved",
        message: "Congratulations! Your lender account has been verified and approved.",
    }),

    lenderVerificationRejected: (reason: string) => ({
        title: "Lender Application Rejected",
        message: `Your lender application has been rejected. Reason: ${reason}`,
    }),
};



interface GetNotificationsQueryParams {
    role?: string;
    email?: string;
    page?: string;
    limit?: string;
}

export const getMyNotifications = async (c: Context): Promise<Response> => {
    try {
        // Parse query params
        const query = c.req.query() as GetNotificationsQueryParams;
        const role = query.role as RecipientRole | undefined;
        const email = query.email;
        const page = Math.max(1, parseInt(query.page || "1", 10));
        const limit = Math.min(50, Math.max(1, parseInt(query.limit || "10", 10)));
        const offset = (page - 1) * limit;

        if (!email) {
            return c.json({ success: false, message: "Email is required" }, 400);
        }

        // Build filter: by recipient email + not deleted
        const conditions: any[] = [
            eq(notifications.recipient_email, email),
            eq(notifications.is_deleted, false),
        ];
        if (role) {
            conditions.push(
                or(
                    eq(notifications.recipient_role, role),
                    inArray(notifications.type, [
                        "LENDER_VERIFICATION_PENDING",
                        "LENDER_VERIFICATION_APPROVED",
                        "LENDER_VERIFICATION_REJECTED",
                        "RENTAL_REQUEST",
                    ] as any),
                ),
            );
        }

        // Fetch notifications and total count in parallel
        const [items, totalCountResult] = await Promise.all([
            db
                .select()
                .from(notifications)
                .where(and(...conditions))
                .orderBy(desc(notifications.created_at))
                .limit(limit)
                .offset(offset),
            db
                .select({ count: count() })
                .from(notifications)
                .where(and(...conditions)),
        ]);

        const total = Number(totalCountResult[0]?.count || 0);
        const totalPages = Math.ceil(total / limit);

        // 🔹 Extract and clean unique sender IDs (remove null)
        const senderIds = Array.from(
            new Set(
                items
                    .map((n) => n.sender_id)
                    .filter((id): id is string => typeof id === "string" && id.length > 0),
            ),
        );

        let senderUsers: any[] = [];
        let senderBusinessInfo: any[] = [];

        if (senderIds.length > 0) {
            // Borrower user info
            senderUsers = await db
                .select()
                .from(users)
                .where(inArray(users.uid, senderIds));

            // Lender business info
            senderBusinessInfo = await db
                .select()
                .from(user_business_info)
                .where(inArray(user_business_info.user_uid, senderIds));
        }

        // 🔹 Combine notification + sender info
        const itemsWithSender = items.map((n) => {
            const senderUser = senderUsers.find((u) => u.uid === n.sender_id);
            const businessInfo = senderBusinessInfo.find(
                (b) => b.user_uid === n.sender_id,
            );

            let senderName: string | null = null;

            if (n.sender_role === "lender") {
                senderName =
                    businessInfo?.business_name ||
                    senderUser?.full_name ||
                    [senderUser?.first_name, senderUser?.last_name].filter(Boolean).join(" ") ||
                    senderUser?.username ||
                    "Unknown Lender";
            } else {
                senderName =
                    senderUser?.full_name ||
                    [senderUser?.first_name, senderUser?.last_name].filter(Boolean).join(" ") ||
                    senderUser?.username ||
                    "Unknown User";
            }

            return {
                ...n,
                sender: {
                    id: n.sender_id,
                    role: n.sender_role,
                    name: senderName,
                },
            };
        });

        return c.json({
            success: true,
            data: {
                items: itemsWithSender,
                pagination: {
                    total,
                    page,
                    limit,
                    totalPages,
                    hasNextPage: page < totalPages,
                    hasPreviousPage: page > 1,
                },
            },
        });
    } catch (error) {
        console.error("❌ Error fetching notifications:", error);
        return c.json(
            {
                success: false,
                message: "Failed to fetch notifications",
                error: error instanceof Error ? error.message : "Unknown error",
            },
            500,
        );
    }
};



// Delete a single notification
const deleteNotification = async (c: Context): Promise<Response> => {
    try {
        const notificationId = c.req.param('id');
        if (!notificationId) {
            return c.json(
                { success: false, message: 'Notification ID is required' },
                400
            );
        }

        await notificationService.delete(notificationId);

        return c.json({
            success: true,
            message: 'Notification deleted successfully'
        });
    } catch (error) {
        console.error('Error deleting notification:', error);
        return c.json(
            {
                success: false,
                message: 'Failed to delete notification',
                error: error instanceof Error ? error.message : 'Unknown error'
            },
            500
        );
    }
};

// Mark a single notification as read
const markAsRead = async (c: Context): Promise<Response> => {
    try {
        const notificationId = c.req.param('id');
        if (!notificationId) {
            return c.json(
                { success: false, message: 'Notification ID is required' },
                400
            );
        }

        const updatedNotification = await notificationService.markAsRead(notificationId);

        return c.json({
            success: true,
            data: updatedNotification
        });
    } catch (error) {
        console.error('Error marking notification as read:', error);
        return c.json(
            {
                success: false,
                message: 'Failed to mark notification as read',
                error: error instanceof Error ? error.message : 'Unknown error'
            },
            500
        );
    }
};

// Mark all notifications as read for a user
const markAllAsRead = async (c: Context): Promise<Response> => {
    try {
        const userId = c.get('userId'); // Assuming you have user ID in context
        const role = c.get('userRole') as RecipientRole; // Assuming you have user role in context

        await notificationService.markAllAsRead(userId, role);

        return c.json({
            success: true,
            message: 'All notifications marked as read'
        });
    } catch (error) {
        console.error('Error marking all notifications as read:', error);
        return c.json(
            {
                success: false,
                message: 'Failed to mark all notifications as read',
                error: error instanceof Error ? error.message : 'Unknown error'
            },
            500
        );
    }
};

// Get unread notification count for a user
const getUnreadCount = async (c: Context): Promise<Response> => {
    try {
        const query = c.req.query();
        const email = query.email as string;
        const role = query.role as RecipientRole | undefined;

        if (!email) {
            return c.json(
                { success: false, message: "Email is required" },
                400
            );
        }

        // Build conditions
        const conditions: any[] = [
            eq(notifications.recipient_email, email),
            eq(notifications.status, "UNREAD"),
            eq(notifications.is_deleted, false),
        ];

        if (role) {
            conditions.push(
                or(
                    eq(notifications.recipient_role, role),
                    inArray(notifications.type, [
                        "LENDER_VERIFICATION_PENDING",
                        "LENDER_VERIFICATION_APPROVED",
                        "LENDER_VERIFICATION_REJECTED",
                        "RENTAL_REQUEST",
                    ] as any),
                ),
            );
        }

        // Get count
        const result = await db
            .select({ count: count() })
            .from(notifications)
            .where(and(...conditions));

        const unreadCount = Number(result[0]?.count || 0);

        return c.json({
            success: true,
            data: { unreadCount }
        });
    } catch (error) {
        console.error("❌ Error getting unread count:", error);
        return c.json(
            {
                success: false,
                message: "Failed to get unread count",
                error: error instanceof Error ? error.message : "Unknown error",
            },
            500
        );
    }
};


export default { getMyNotifications, deleteNotification, markAsRead, markAllAsRead, getUnreadCount };