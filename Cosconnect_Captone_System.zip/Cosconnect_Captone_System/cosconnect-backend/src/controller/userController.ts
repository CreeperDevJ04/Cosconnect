// controllers/userController.ts
import { SwitchRoleResponse } from '@/types/userType';
import { and, desc, eq, or, gt } from 'drizzle-orm';
import type { Context } from 'hono';
import db from '../db/supabase/db_connect';
import {
    business_addresses,
    user_addresses,
    user_business_info,
    user_documents,
    users,
    type NewUserAddress
} from '../schema/users.js';
import type { BorrowerPersonalInfoFormDataType } from '../types/borrowerType.js';
import nodemailer from 'nodemailer';
import { otp_codes } from '@/schema/otp-code';


// ============================================================================
// EMAIL CONFIGURATION
// ============================================================================
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER ,
        pass: process.env.EMAIL_PASSWORD || ''
    }
});

// ============================================================================
// OTP GENERATOR
//  ============================================================================
const generateOTP = (): string =>
    Math.floor(100000 + Math.random() * 900000).toString();

// ============================================================================
// EMAIL SENDER
// ============================================================================
export const sendOtpEmail = async (email: string, otp: string): Promise<boolean> => {
    const mailOptions = {
        from: process.env.EMAIL_USER ,
        to: email,
        subject: 'Your OTP Code',
        html: `
            <div style="font-family: Arial, sans-serif; padding: 20px;">
                <h2>Your Verification Code</h2>
                <div style="background: #007bff; color: white; font-size: 32px; padding: 20px; text-align: center; border-radius: 8px; letter-spacing: 8px;">
                    ${otp}
                </div>
                <p style="color: #666; margin-top: 20px;">This code expires in 10 minutes.</p>
            </div>
        `
    };

    try {
        await transporter.sendMail(mailOptions);
        return true;
    } catch (error) {
        console.error('❌ Failed to send OTP email:', error);
        return false;
    }
};

// ============================================================================
// CONTROLLER: SEND OTP CODE
// ============================================================================
export const sendOtpCode = async (c: Context): Promise<Response> => {
    try {
        const { email } = await c.req.json();
        if (!email)
            return c.json({ success: false, message: 'Email is required' }, 400);

        const otp = generateOTP();
        const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

        // Save OTP in DB
        await db.insert(otp_codes).values({
            email,
            otp_code: otp,
            expires_at: expiresAt,
            is_used: false
        });

        // Send OTP email
        const emailSent = await sendOtpEmail(email, otp);
        if (!emailSent)
            return c.json({ success: false, message: 'Failed to send OTP email' }, 500);

        return c.json({
            success: true,
            message: 'OTP sent successfully',
            expiresAt: expiresAt.toISOString()
        });
    } catch (error) {
        console.error('💥 sendOtpCode Error:', error);
        return c.json({ success: false, message: 'Internal server error' }, 500);
    }
};


const getUserDataById = async (c: Context) => {
    try {
        const user_id = c.req.param('user_id');
        if (!user_id) {
            return c.json({ error: 'user_id is required' }, 400);
        }

        // User core info
        const user = await db.query.users.findFirst({
            where: eq(users.uid, user_id),
        });
        if (!user) {
            return c.json({ error: 'User not found' }, 404);
        }

        // Borrower side: addresses + documents
        const addresses = await db.query.user_addresses.findMany({
            where: eq(user_addresses.user_uid, user.uid),
        });
        const documents = await db.query.user_documents.findMany({
            where: eq(user_documents.user_uid, user.uid),
        });

        // Lender side: business info + addresses
        const businessInfo = await db.query.user_business_info.findFirst({
            where: eq(user_business_info.user_uid, user.uid),
        });

        let businessAddresses = [] as any;
        if (businessInfo) {
            businessAddresses = await db.query.business_addresses.findMany({
                where: eq(business_addresses.business_info_id, businessInfo.id),
            });
        }

        // Shape nested response
        const response: any = {
            userInfo: {
                uid: user.uid,
                id: user.id,
                username: user.username,
                email: user.email,
                phone_number: user.phone_number,
                full_name: user.full_name,
                first_name: user.first_name,
                middle_name: user.middle_name,
                last_name: user.last_name,
                role: user.role,
                current_role: user.current_role,
                status: user.status,
                is_online: user.is_online,
                created_at: user.created_at,
                updated_at: user.updated_at,
            },
            borrowerInfo: {
                addresses,
                documents,
            },
            lenderInfo: businessInfo
                ? {
                    ...businessInfo,
                    addresses: businessAddresses,
                }
                : null,
        };

        return c.json(response, 200);
    } catch (error: any) {
        console.error(error);
        return c.json(
            { error: 'Failed to fetch user data', details: error.message },
            500
        );
    }
};

// SINGLE FUNCTION FOR ROLE-AWARE USER FETCH
const getUserDataByIdWithRole = async (c: Context): Promise<Response> => {
    try {
        const user_id = c.req.query("user_id");
        const role = c.req.query("role");

        // Input validation
        if (!user_id || !role) {
            return c.json(
                {
                    success: false,
                    error: "Missing required fields",
                    message: "Both user_id and role are required",
                    required_fields: ["user_id", "role"]
                },
                400
            );
        }

        if (!["borrower", "lender", 'admin'].includes(role)) {
            return c.json(
                {
                    success: false,
                    error: "Invalid role",
                    message: "Role must be either 'borrower' or 'lender'",
                    allowed_roles: ["borrower", "lender", "admin"]
                },
                400
            );
        }

        // 1. Fetch base user data - try both uid and id fields
        const userData = await db
            .select()
            .from(users)
            .where(or(eq(users.id, user_id), eq(users.uid, user_id)))
            .limit(1);

        if (userData.length === 0) {
            return c.json(
                {
                    success: false,
                    error: "User not found",
                    message: `No user found with ID: ${user_id}`
                },
                404
            );
        }

        const user = userData[0];

        // Ensure user.uid is not null/undefined before proceeding
        if (!user?.uid) {
            return c.json(
                {
                    success: false,
                    error: "Invalid user data",
                    message: "User UID is missing"
                },
                500
            );
        }

        // Check if user has the requested role
        if (!user.role.includes(role)) {
            return c.json(
                {
                    success: false,
                    error: "Role not authorized",
                    message: `User does not have '${role}' role`,
                    user_roles: user.role
                },
                403
            );
        }

        // Helper function to structure user profile data
        const formatUserProfile = (user: any) => ({
            ...user,
            profile: {
                personal: {
                    full_name: user.full_name,
                    first_name: user.first_name,
                    middle_name: user.middle_name,
                    last_name: user.last_name,
                    bio: user.bio,
                    profile_image: user.profile_image,
                    profile_background: user.profile_background,
                    birth_date: user.birth_date || null, // add this
                },
                contact: {
                    email: user.email,
                    phone_number: user.phone_number,
                    email_verified: user.email_verified,
                    phone_verified: user.phone_verified,
                },
                status: {
                    role: user.role,
                    current_role: user.current_role,
                    status: user.status,
                    is_online: user.is_online,
                    last_seen: user.last_seen,
                }
            }
        });

        // 2. Role-based data enrichment
        if (role === "lender") {
            // LENDER LOGIC: Return only business data
            const businessInfoData = await db
                .select()
                .from(user_business_info)
                .where(eq(user_business_info.user_uid, user.uid))
                .limit(1);

            if (businessInfoData.length === 0) {
                // Lender exists but has no business info yet
                return c.json({
                    success: true,
                    data: {
                        business: null,
                        metadata: {
                            role: role,
                            has_business_info: false,
                            created_at: user.created_at,
                            updated_at: user.updated_at
                        }
                    }
                });
            }

            const businessInfo = businessInfoData[0];

            // Fetch business addresses
            const businessAddresses = await db
                .select()
                .from(business_addresses)
                .where(eq(business_addresses.business_info_id, businessInfo?.id as string));

            // Fetch business-related documents
            const businessDocuments = await db
                .select()
                .from(user_documents)
                .where(
                    and(
                        eq(user_documents.user_uid, user.uid),
                        // Filter for business-related document types
                        or(
                            eq(user_documents.document_type, 'BUSINESS_PERMIT'),
                            eq(user_documents.document_type, 'DTI_CERTIFICATE'),
                            eq(user_documents.document_type, 'STOREFRONT_PHOTO')
                        )
                    )
                );

            return c.json({
                success: true,
                data: {
                    business: {
                        info: {
                            ...businessInfo,
                            verification: {
                                is_verified: businessInfo?.is_verified,
                                verified_at: businessInfo?.verified_at,
                                verified_by: businessInfo?.verified_by,
                                rejection_reason: businessInfo?.rejection_reason,
                            }
                        },
                        addresses: businessAddresses.map(addr => ({
                            ...addr,
                            full_address: addr.business_address,
                            location: {
                                street: addr.street,
                                barangay: addr.barangay,
                                city: addr.city,
                                province: addr.province,
                                region: addr.region,
                                zip_code: addr.zip_code,
                                country: addr.country,
                            }
                        })),
                        documents: businessDocuments.map(doc => ({
                            ...doc,
                            verification: {
                                is_verified: doc.is_verified,
                                verified_at: doc.verified_at,
                                verified_by: doc.verified_by,
                                rejection_reason: doc.rejection_reason,
                            }
                        })),
                        statistics: {
                            total_addresses: businessAddresses.length,
                            total_documents: businessDocuments.length,
                            verified_documents: businessDocuments.filter(doc => doc.is_verified).length,
                        }
                    },
                    metadata: {
                        role: role,
                        has_business_info: true,
                        created_at: user.created_at,
                        updated_at: user.updated_at
                    }
                }
            });

        } else if (role === "borrower") {
            // BORROWER LOGIC: Return only user data (no business info)

            // Fetch personal addresses for the borrower
            const addresses = await db
                .select()
                .from(user_addresses)
                .where(eq(user_addresses.user_uid, user.uid));

            // Fetch personal documents for the borrower (exclude business documents)
            const documents = await db
                .select()
                .from(user_documents)
                .where(
                    and(
                        eq(user_documents.user_uid, user.uid),
                        // Filter for personal/borrower document types (exclude business documents)
                        or(
                            eq(user_documents.document_type, 'VALID_ID'),
                            eq(user_documents.document_type, 'SELFIE_WITH_ID'),
                            eq(user_documents.document_type, 'SECONDARY_ID_1'),
                            eq(user_documents.document_type, 'SECONDARY_ID_2')
                        )
                    )
                );

            return c.json({
                success: true,
                data: {
                    user: formatUserProfile(user),
                    personal: {
                        addresses: addresses.map(addr => ({
                            ...addr,
                            full_address: addr.address,
                            location: {
                                street: addr.street,
                                barangay: addr.barangay,
                                city: addr.city,
                                province: addr.province,
                                region: addr.region,
                                zip_code: addr.zip_code,
                                country: addr.country,
                            },
                            address_info: {
                                type: addr.address_type,
                                is_primary: addr.is_primary,
                            }
                        })),
                        documents: documents.map(doc => ({
                            ...doc,
                            id_info: {
                                id_type: doc.id_type,
                                id_number: doc.id_number,
                                has_valid_id: doc.has_valid_id,
                            },
                            verification: {
                                is_verified: doc.is_verified,
                                verified_at: doc.verified_at,
                                verified_by: doc.verified_by,
                                rejection_reason: doc.rejection_reason,
                            }
                        })),
                        statistics: {
                            total_addresses: addresses.length,
                            primary_addresses: addresses.filter(addr => addr.is_primary).length,
                            total_documents: documents.length,
                            verified_documents: documents.filter(doc => doc.is_verified).length,
                            valid_id_documents: documents.filter(doc => doc.has_valid_id).length,
                        }
                    },
                    metadata: {
                        role: role,
                        created_at: user.created_at,
                        updated_at: user.updated_at
                    }
                }
            });
        }

        // This should never be reached due to validation above
        return c.json({
            success: false,
            error: "Invalid role specified",
            message: "An unexpected error occurred with role validation"
        }, 400);

    } catch (error: any) {
        console.error("Error in getUserDataByIdWithRole:", error);
        return c.json(
            {
                success: false,
                error: "Internal Server Error",
                message: "An unexpected error occurred while fetching user data",
                ...(process.env.NODE_ENV === 'development' && {
                    details: error.message,
                    stack: error.stack
                })
            },
            500
        );
    }
};

// Define the proper response type
interface UserResponse {
    success: boolean;
    message?: string;
    data?: {
        user_id: string;
        username: string;
        email: string;
        roles: string[];
        current_role: string;
        status: string;
        can_switch_roles: boolean;
        email_verified: boolean;
        phone_verified: boolean;
        profile_image: string | null;
        bio: string | null;
        created_at: Date;
        updated_at: Date;
        personal_info: {
            full_name: string | null;
            first_name: string | null;
            middle_name: string | null;
            last_name: string | null;
            phone_number: string;
            profile_image: string | null;
            bio?: string | null;          // add this
            birth_date?: string | null;   // add this (or Date | null if you return Date)
        };
        address_information?: {
            address: string | null;
            street: string | null;
            zip_code: string | null;
            barangay: string | null;
            province: string | null;
            region: string | null;
            country: string | null;
            city: any;
        };
        identification_info: {
            has_valid_documents: boolean;
            documents: any[];
        };
        subscription_info: {
            is_premium: boolean;
            subscription_type: string | null;
            subscription_status: string;
            subscription_start_date: Date | null;
            subscription_end_date: Date | null;
            subscription_payment_id: string | null;
            subscription_reference: string | null;
            subscription_session_id: string | null;
        };
        business_info?: {
            id: string;
            business_name: string | null;
            business_description: string | null;
            business_type: string | null;
            business_email: string | null;
            business_phone_number: string | null;
            business_telephone: string | null;
            business_profile_image: string | null;
            business_background_image: string | null;
            upload_business_permit: string | null;
            business_permit_file: string | null;
            upload_dti_certificate: string | null;
            upload_storefront_photo: string | null;
            terms_and_conditions: string | null;
            is_verified: boolean;
            verified_at: Date | null;
            verified_by: string | null;
            rejection_reason: string | null;
            created_at: Date;
            updated_at: Date;
            address?: {
                business_address: string | null;
                street: string | null;
                zip_code: string | null;
                barangay: string | null;
                province: string | null;
                region: string | null;
                country: string | null;
                city: any;
            };
        };
    };
}

/**
 * Get comprehensive user data with roles, addresses, documents, and business info
 * Uses proper joins with the normalized schema
 */
const getUserRoles = async (c: Context): Promise<Response> => {
    try {
        const userId = c.req.param("userId");

        if (!userId) {
            return c.json({
                success: false,
                message: "User ID is required",
            }, 400);
        }

        // Execute the query with proper error handling
        const result = await db.transaction(async (tx) => {
            // Get user with personal address
            const userWithAddress = await tx
                .select({
                    // User fields
                    user_uid: users.uid,
                    user_id: users.id,
                    username: users.username,
                    email: users.email,
                    phone_number: users.phone_number,
                    full_name: users.full_name,
                    first_name: users.first_name,
                    middle_name: users.middle_name,
                    last_name: users.last_name,
                    bio: users.bio,
                    birth_date: users.birth_date,
                    profile_image: users.profile_image,
                    profile_background: users.profile_background,
                    role: users.role,
                    current_role: users.current_role,
                    status: users.status,
                    email_verified: users.email_verified,
                    phone_verified: users.phone_verified,
                    created_at: users.created_at,
                    updated_at: users.updated_at,
                    // Premium subscription fields
                    is_premium: users.is_premium,
                    subscription_type: users.subscription_type,
                    subscription_status: users.subscription_status,
                    subscription_start_date: users.subscription_start_date,
                    subscription_end_date: users.subscription_end_date,
                    subscription_payment_id: users.subscription_payment_id,
                    subscription_reference: users.subscription_reference,
                    subscription_session_id: users.subscription_session_id,
                    // Address fields
                    address_id: user_addresses.id,
                    address: user_addresses.address,
                    street: user_addresses.street,
                    zip_code: user_addresses.zip_code,
                    barangay: user_addresses.barangay,
                    province: user_addresses.province,
                    region: user_addresses.region,
                    country: user_addresses.country,
                    city: user_addresses.city,
                })
                .from(users)
                .leftJoin(
                    user_addresses,
                    and(
                        eq(users.uid, user_addresses.user_uid),
                        eq(user_addresses.is_primary, true)
                    )
                )
                .where(eq(users.uid, userId));

            if (!userWithAddress || userWithAddress.length === 0) {
                return null;
            }

            const userData = userWithAddress[0];

            // Get business info with addresses if user is a lender
            let businessInfo = null;
            const userRoles = Array.isArray(userData?.role) ? userData?.role : [userData?.role || 'borrower'];

            if (userRoles?.includes('lender')) {
                const businessData = await tx
                    .select({
                        // Business info fields
                        business_id: user_business_info.id,
                        business_name: user_business_info.business_name,
                        business_description: user_business_info.business_description,
                        business_type: user_business_info.business_type,
                        business_email: user_business_info.business_email,
                        business_phone_number: user_business_info.business_phone_number,
                        business_telephone: user_business_info.business_telephone,
                        business_profile_image: user_business_info.business_profile_image,
                        business_background_image: user_business_info.business_background_image,
                        upload_business_permit: user_business_info.upload_business_permit,
                        business_permit_file: user_business_info.business_permit_file,
                        upload_dti_certificate: user_business_info.upload_dti_certificate,
                        upload_storefront_photo: user_business_info.upload_storefront_photo,
                        terms_and_conditions: user_business_info.terms_and_conditions,
                        business_is_verified: user_business_info.is_verified,
                        business_verified_at: user_business_info.verified_at,
                        business_verified_by: user_business_info.verified_by,
                        business_rejection_reason: user_business_info.rejection_reason,
                        business_created_at: user_business_info.created_at,
                        business_updated_at: user_business_info.updated_at,
                        // Business address fields
                        business_address_id: business_addresses.id,
                        business_address: business_addresses.business_address,
                        business_street: business_addresses.street,
                        business_zip_code: business_addresses.zip_code,
                        business_barangay: business_addresses.barangay,
                        business_province: business_addresses.province,
                        business_region: business_addresses.region,
                        business_country: business_addresses.country,
                        business_city: business_addresses.city,
                    })
                    .from(user_business_info)
                    .leftJoin(
                        business_addresses,
                        and(
                            eq(user_business_info.id, business_addresses.business_info_id),
                            eq(business_addresses.is_primary, true)
                        )
                    )
                    .where(eq(user_business_info.user_uid, userId));

                if (businessData && businessData.length > 0) {
                    businessInfo = businessData[0];
                }
            }

            // Get all user documents
            const userDocuments = await tx
                .select()
                .from(user_documents)
                .where(eq(user_documents.user_uid, userId));

            return {
                user: userData,
                businessInfo,
                documents: userDocuments || []
            };
        });

        if (!result) {
            return c.json({
                success: false,
                message: "User not found",
            }, 404);
        }

        const { user, businessInfo, documents } = result as any;

        // Safely handle user roles
        const userRoles = Array.isArray(user?.role) ? user?.role : [user?.role || 'borrower'];
        const isLender = userRoles?.includes('lender');

        // Transform documents into a map by type with proper null checks
        const documentsByType = documents.reduce((acc: any, doc: any) => {
            if (doc && doc.id) {
                acc[doc.document_type] = {
                    id: doc.id,
                    document_type: doc.document_type,
                    id_type: doc.id_type,
                    id_number: doc.id_number,
                    file_url: doc.file_url,
                    is_verified: doc.is_verified || false,
                };
            }
            return acc;
        }, {} as Record<string, any>);

        // Check if user has valid documents
        const hasValidDocuments = Object.values(documentsByType).some((doc: any) => doc?.is_verified === true);

        // Initialize base response object with required fields
        const response: UserResponse = {
            success: true,
            data: {
                user_id: user?.user_uid || '',
                username: user?.username || '',
                email: user?.email || '',
                roles: userRoles as any,
                current_role: user?.current_role || 'borrower',
                status: user?.status || 'active',
                can_switch_roles: isLender as any &&
                    user?.status === 'verified' &&
                    (businessInfo?.business_is_verified as any === true),
                email_verified: user?.email_verified || false,
                phone_verified: user?.phone_verified || false,
                profile_image: user?.profile_image || null,
                bio: user?.bio || null,
                created_at: user?.created_at as any || null,
                updated_at: user?.updated_at as any || null,
                personal_info: {
                    full_name: user?.full_name || null,
                    first_name: user?.first_name || null,
                    middle_name: user?.middle_name || null,
                    last_name: user?.last_name || null,
                    phone_number: user?.phone_number || '',
                    profile_image: user?.profile_image || null,
                    bio: user?.bio || null,
                    birth_date: user?.birth_date ? new Date(user.birth_date).toISOString().slice(0, 10) : null,
                },
                subscription_info: {
                    is_premium: user?.is_premium || false,
                    subscription_type: user?.subscription_type || null,
                    subscription_status: user?.subscription_status || 'inactive',
                    subscription_start_date: user?.subscription_start_date || null,
                    subscription_end_date: user?.subscription_end_date || null,
                    subscription_payment_id: user?.subscription_payment_id || null,
                    subscription_reference: user?.subscription_reference || null,
                    subscription_session_id: user?.subscription_session_id || null,
                },
                identification_info: {
                    has_valid_documents: hasValidDocuments,
                    documents: Object.values(documentsByType),
                },
                // Initialize optional fields with undefined to satisfy type checking
                address_information: undefined,
                business_info: undefined
            }
        };

        // Add address information if user has address data
        if (user?.address_id) {
            response.data = {
                ...response.data as any,
                address_information: {
                    address: user?.address || null,
                    street: user?.street || null,
                    zip_code: user?.zip_code || null,
                    barangay: user?.barangay || null,
                    province: user?.province || null,
                    region: user?.region || null,
                    country: user.country || null,
                    city: user.city || null,
                }
            };
        }

        // Add business info if it exists
        if (businessInfo?.business_id) {
            response.data!.business_info = {
                id: businessInfo.business_id,
                business_name: businessInfo.business_name || null,
                business_description: businessInfo.business_description || null,
                business_type: businessInfo.business_type || null,
                business_email: businessInfo.business_email || null,
                business_phone_number: businessInfo.business_phone_number || null,
                business_telephone: businessInfo.business_telephone || null,
                business_profile_image: businessInfo.business_profile_image || null,
                business_background_image: businessInfo.business_background_image || null,
                upload_business_permit: businessInfo.upload_business_permit || null,
                business_permit_file: businessInfo.business_permit_file || null,
                upload_dti_certificate: businessInfo.upload_dti_certificate || null,
                upload_storefront_photo: businessInfo.upload_storefront_photo || null,
                terms_and_conditions: businessInfo.terms_and_conditions || null,
                is_verified: Boolean(businessInfo.business_is_verified),
                verified_at: businessInfo.business_verified_at || null,
                verified_by: businessInfo.business_verified_by || null,
                rejection_reason: businessInfo.business_rejection_reason || null,
                created_at: businessInfo.business_created_at,
                updated_at: businessInfo.business_updated_at,
            };

            // Add business address if it exists
            if (businessInfo.business_address_id) {
                response.data!.business_info.address = {
                    business_address: businessInfo.business_address || null,
                    street: businessInfo.business_street || null,
                    zip_code: businessInfo.business_zip_code || null,
                    barangay: businessInfo.business_barangay || null,
                    province: businessInfo.business_province || null,
                    region: businessInfo.business_region || null,
                    country: businessInfo.business_country || null,
                    city: businessInfo.business_city || null,
                };
            }
        }

        return c.json(response);
    } catch (error) {
        console.error('Error in getUserRoles:', error);
        return c.json({
            success: false,
            message: "Internal server error while fetching user data",
        }, 500);
    }
};

/**
 * Switch between borrower and lender roles with enhanced validation
 * Includes proper business verification checks
 */
const switchRole = async (c: Context): Promise<Response> => {
    try {
        const userId: string | undefined = c.req.param("userId");
        console.log('User ID from params:', userId);

        // Get targetRole from query parameters
        const targetRole = c.req.query('targetRole');
        console.log('Target role from query:', targetRole);

        // Remove the request body parsing since we're using query params now

        if (!userId?.trim()) {
            return c.json(
                {
                    success: false,
                    message: "User ID is required and cannot be empty",
                } as SwitchRoleResponse,
                400,
            );
        }

        if (!targetRole || !["borrower", "lender"].includes(targetRole)) {
            return c.json(
                {
                    success: false,
                    message: "Valid target role (borrower or lender) is required",
                } as SwitchRoleResponse,
                400,
            );
        }

        const userQuery = await db
            .select({
                uid: users.uid,
                role: users.role,
                current_role: users.current_role,
                status: users.status,
            })
            .from(users)
            .where(eq(users.uid, userId));

        if (!userQuery.length) {
            return c.json(
                {
                    success: false,
                    message: "User not found",
                } as SwitchRoleResponse,
                404,
            );
        }

        const user = userQuery[0];

        if (!user?.role || !Array.isArray(user.role) || !user.role.includes(targetRole)) {
            return c.json(
                {
                    success: false,
                    message: `You don't have ${targetRole} role. Please apply for ${targetRole} role first.`,
                } as SwitchRoleResponse,
                400,
            );
        }

        if (targetRole === "lender") {
            if (user.status !== "verified") {
                const statusMessage =
                    user.status === "pending_verification"
                        ? "Your lender application is still under review"
                        : "Your lender account must be verified before switching to lender role";

                return c.json(
                    {
                        success: false,
                        message: statusMessage,
                    } as SwitchRoleResponse,
                    400,
                );
            }

            // Check if business info is verified
            const businessInfoQuery = await db
                .select({ is_verified: user_business_info.is_verified })
                .from(user_business_info)
                .where(eq(user_business_info.user_uid, userId));

            if (!businessInfoQuery.length || !Boolean(businessInfoQuery[0]?.is_verified)) {
                return c.json(
                    {
                        success: false,
                        message: "Your business information must be verified before switching to lender role",
                    } as SwitchRoleResponse,
                    400,
                );
            }
        }

        if (user.current_role === targetRole) {
            return c.json({
                success: true,
                message: `You are already in ${targetRole} role`,
                data: {
                    current_role: user.current_role,
                    available_roles: user.role && Array.isArray(user.role) ? user.role : ["borrower"],
                    status: user.status,
                },
            } as SwitchRoleResponse);
        }

        const updateResult = await db
            .update(users)
            .set({
                current_role: targetRole,
                updated_at: new Date(),
            })
            .where(eq(users.uid, userId))
            .returning({
                current_role: users.current_role,
                role: users.role,
                status: users.status,
            });

        if (!updateResult.length) {
            return c.json(
                {
                    success: false,
                    message: "Failed to update user record",
                } as SwitchRoleResponse,
                500,
            );
        }

        const updatedUser = updateResult[0];

        return c.json({
            success: true,
            message: `Successfully switched to ${targetRole} role`,
            data: {
                current_role: updatedUser?.current_role || "borrower",
                available_roles: updatedUser?.role && Array.isArray(updatedUser.role) ? updatedUser.role : ["borrower"],
                status: updatedUser?.status || "pending_verification",
            },
        } as SwitchRoleResponse);
    } catch (error) {
        console.error("[v0] Switch role error:", error);
        return c.json(
            {
                success: false,
                message: "Internal server error while switching roles",
            } as SwitchRoleResponse,
            500,
        );
    }
};


/**
 * Get user data by username or user ID
 * Enhanced to support role switching and better data structure
 */
const getUserData = async (c: Context) => {
    console.log("🔄 [getUserData] Function started")

    try {
        const username = c.req.param("username")
        const userId = c.req.param("user_id")

        console.log("📋 [getUserData] Parameters - username:", username, "user_id:", userId)

        if (!username && !userId) {
            console.log("❌ [getUserData] Missing both username and user_id")
            return c.json(
                {
                    success: false,
                    message: "Either username or user_id is required",
                },
                400,
            )
        }

        // Validate UUID format if user_id is provided
        if (userId) {
            const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
            if (!uuidRegex.test(userId)) {
                console.log("❌ [getUserData] Invalid UUID format:", userId)
                return c.json(
                    {
                        success: false,
                        message: "User ID must be a valid UUID format",
                    },
                    400,
                )
            }
        }

        console.log("🔍 [getUserData] Fetching user data from database...")

        // Build the where condition based on available parameter
        const whereCondition = userId ? eq(users.uid, userId) : eq(users.username, username!)

        const userData = await db.transaction(async (tx) => {
            // Get basic user info
            const user = await tx
                .select({
                    uid: users.uid,
                    id: users.id,
                    username: users.username,
                    email: users.email,
                    phone_number: users.phone_number,
                    full_name: users.full_name,
                    first_name: users.first_name,
                    middle_name: users.middle_name,
                    last_name: users.last_name,
                    bio: users.bio,
                    birth_date: users.birth_date,
                    profile_image: users.profile_image,
                    profile_background: users.profile_background,
                    role: users.role,
                    current_role: users.current_role,
                    status: users.status,
                    is_online: users.is_online,
                    email_verified: users.email_verified,
                    phone_verified: users.phone_verified,
                    last_seen: users.last_seen,
                    created_at: users.created_at,
                    updated_at: users.updated_at,
                })
                .from(users)
                .where(whereCondition)
                .limit(1)
                .then((rows) => rows[0])

            if (!user) {
                return null
            }

            // Get primary address (personal address)
            const primaryAddress = await tx
                .select()
                .from(user_addresses)
                .where(
                    and(
                        eq(user_addresses.user_uid, user.uid),
                        eq(user_addresses.is_primary, true),
                        eq(user_addresses.address_type, "personal"),
                    ),
                )
                .limit(1)
                .then((rows) => rows[0])

            // Get identification documents
            const validIdDoc = await tx
                .select()
                .from(user_documents)
                .where(and(eq(user_documents.user_uid, user.uid), eq(user_documents.document_type, "VALID_ID")))
                .limit(1)
                .then((rows) => rows[0])

            const selfieDoc = await tx
                .select()
                .from(user_documents)
                .where(and(eq(user_documents.user_uid, user.uid), eq(user_documents.document_type, "SELFIE_WITH_ID")))
                .limit(1)
                .then((rows) => rows[0])

            // Get business info if user has lender role
            let businessInfo = null
            let businessAddress = null

            if (user.role.includes("lender")) {
                businessInfo = await tx
                    .select()
                    .from(user_business_info)
                    .where(eq(user_business_info.user_uid, user.uid))
                    .limit(1)
                    .then((rows) => rows[0] || null)

                if (businessInfo) {
                    businessAddress = await tx
                        .select()
                        .from(business_addresses)
                        .where(
                            and(eq(business_addresses.business_info_id, businessInfo.id), eq(business_addresses.is_primary, true)),
                        )
                        .limit(1)
                        .then((rows) => rows[0])
                }
            }

            return {
                user,
                primaryAddress,
                validIdDoc,
                selfieDoc,
                businessInfo,
                businessAddress,
            }
        })

        if (!userData || !userData.user) {
            console.log("❌ [getUserData] User not found")
            return c.json(
                {
                    success: false,
                    message: "User not found",
                },
                404,
            )
        }

        const { user, primaryAddress, validIdDoc, selfieDoc, businessInfo, businessAddress } = userData

        console.log("✅ [getUserData] User data fetched successfully")

        const response: any = {
            success: true,
            message: "User data retrieved successfully",
            data: {
                user_id: user.uid,
                username: user.username,
                email: user.email,
                roles: user.role as any[],
                current_role: user.current_role as any,
                status: user.status,
                can_switch_roles: user.role.length > 1, // Can switch if has multiple roles
                personal_info: {
                    full_name: user.full_name || "",
                    first_name: user.first_name || "",
                    middle_name: user.middle_name,
                    last_name: user.last_name || "",
                    username: user.username,
                    phone_number: user.phone_number,
                    profile_image: user.profile_image,
                    profile_background: user.profile_background,
                    bio: user.bio,
                    birth_date: user.birth_date ? new Date(user.birth_date).toISOString().slice(0, 10) : null,
                },
                address_information: {
                    street: primaryAddress?.street || "",
                    zip_code: primaryAddress?.zip_code || "",
                    barangay: primaryAddress?.barangay || "",
                    province: primaryAddress?.province || "",
                    region: primaryAddress?.region || "",
                    country: primaryAddress?.country || "Philippines",
                    city: primaryAddress?.city || { id: "", name: "" },
                },
                identification_info: {
                    has_valid_id: validIdDoc?.has_valid_id || false,
                    valid_id_type: validIdDoc?.id_type || "NATIONAL_ID",
                    valid_id_number: validIdDoc?.id_number || "",
                    valid_id_file: validIdDoc?.file_url || "",
                    selfie_with_id: selfieDoc?.file_url || "",
                },
                // Only include business info if user has lender role
                ...(user.role.includes("lender") &&
                    businessInfo && {
                    business_info: {
                        business_name: businessInfo.business_name,
                        business_description: businessInfo.business_description,
                        business_type: businessInfo.business_type,
                        business_phone_number: businessInfo.business_phone_number,
                        business_telephone: businessInfo.business_telephone,
                        business_address: businessAddress?.business_address,
                        street: businessAddress?.street,
                        barangay: businessAddress?.barangay,
                        city: businessAddress?.city,
                        province: businessAddress?.province,
                        region: businessAddress?.region,
                        zip_code: businessAddress?.zip_code,
                        country: businessAddress?.country,
                        business_permit_file: businessInfo.business_permit_file,
                        upload_dti_certificate: businessInfo.upload_dti_certificate,
                        upload_storefront_photo: businessInfo.upload_storefront_photo,
                        terms_and_conditions: businessInfo.terms_and_conditions as "Accepted",
                    },
                }),
                terms_and_conditions: businessInfo?.terms_and_conditions as "Accepted",
            },
        }

        return c.json(response, 200)
    } catch (error) {
        console.error("💥 [getUserData] Unexpected error:", error)

        // Handle database connection errors
        if (
            error instanceof Error &&
            (error.message.includes("connection") ||
                error.message.includes("timeout") ||
                error.message.includes("ECONNREFUSED"))
        ) {
            return c.json(
                {
                    success: false,
                    message: "Database connection error",
                },
                503,
            )
        }

        // Handle network errors
        if (error instanceof Error && error.message.includes("network")) {
            return c.json(
                {
                    success: false,
                    message: "Network error occurred",
                },
                503,
            )
        }

        // Handle any other unexpected errors
        return c.json(
            {
                success: false,
                message:
                    process.env.NODE_ENV === "development"
                        ? error instanceof Error
                            ? error.message
                            : "Unknown error occurred"
                        : "An unexpected error occurred",
            },
            500,
        )
    }
}

/** 
 * Update user personal information
 * Handles user profile fields from the modal form
 */
const updatePersonalInfo = async (c: Context) => {
    try {
        console.log('\x1b[36m[DEBUG] Starting updatePersonalInfo...\x1b[0m');

        // Get user ID from request parameters
        const userId = c.req.param('id');
        console.log('\x1b[33m[DEBUG] User ID from params:\x1b[0m', userId);

        if (!userId) {
            console.warn('\x1b[31m[WARN] Missing user ID in request.\x1b[0m');
            return c.json(
                {
                    status: 'error',
                    code: 'MISSING_USER_ID',
                    message: 'User ID is required in URL parameters',
                },
                400
            );
        }

        // Validate UUID format
        const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
        if (!uuidRegex.test(userId)) {
            console.warn('\x1b[31m[WARN] Invalid UUID format:\x1b[0m', userId);
            return c.json(
                {
                    status: 'error',
                    code: 'INVALID_USER_ID_FORMAT',
                    message: 'User ID must be a valid UUID format',
                },
                400
            );
        }

        // Parse request body
        const data = await c.req.json();
        console.log('\x1b[32m[DEBUG] Request data:\x1b[0m', data);

        // Start database transaction
        return await db.transaction(async (tx) => {
            // Check if user exists
            const existingUser = await tx
                .select()
                .from(users)
                .where(eq(users.uid, userId))
                .limit(1)
                .then(rows => rows[0]);

            if (!existingUser) {
                throw new Error('User not found');
            }

            // 1. Update user basic info
            const userUpdate: any = {
                updated_at: new Date(),
            };

            // Handle names
            if (data.first_name !== undefined) userUpdate.first_name = data.first_name?.trim() || null;
            if (data.middle_name !== undefined) userUpdate.middle_name = data.middle_name?.trim() || null;
            if (data.last_name !== undefined) userUpdate.last_name = data.last_name?.trim() || null;

            // Update full name if any name field was updated
            if (data.first_name !== undefined || data.middle_name !== undefined || data.last_name !== undefined) {
                const firstName = data.first_name ?? existingUser.first_name ?? '';
                const middleName = data.middle_name ?? existingUser.middle_name ?? '';
                const lastName = data.last_name ?? existingUser.last_name ?? '';

                userUpdate.full_name = `${firstName} ${middleName} ${lastName}`
                    .replace(/\s+/g, ' ')
                    .trim();
            }

            // Handle birth date
            if (data.birth_date !== undefined) {
                if (data.birth_date) {
                    const birthDate = new Date(data.birth_date);
                    if (!isNaN(birthDate.getTime()) && birthDate <= new Date()) {
                        userUpdate.birth_date = birthDate;
                    } else {
                        throw new Error('Invalid birth date');
                    }
                } else {
                    userUpdate.birth_date = null;
                }
            }

            // Handle phone number
            if (data.phone_number !== undefined) {
                if (data.phone_number) {
                    const phoneRegex = /^\+?[\d\s\-\(\)]+$/;
                    if (!phoneRegex.test(data.phone_number)) {
                        throw new Error('Invalid phone number format');
                    }
                    userUpdate.phone_number = data.phone_number.trim();
                } else {
                    userUpdate.phone_number = null;
                }
            }

            // Handle bio and profile images
            if (data.bio !== undefined) userUpdate.bio = data.bio?.trim() || null;
            if (data.profile_image !== undefined) userUpdate.profile_image = data.profile_image || null;
            if (data.profile_background !== undefined) userUpdate.profile_background = data.profile_background || null;

            // Update user record if there are changes
            if (Object.keys(userUpdate).length > 1) { // More than just updated_at
                console.log('\x1b[34m[DB] Updating user record...\x1b[0m');
                await tx
                    .update(users)
                    .set(userUpdate)
                    .where(eq(users.uid, userId));
            }

            // 2. Update or create address
            const hasAddressData = data.region || data.province || data.municipal_city ||
                data.barangay || data.street_address || data.postal_code;

            if (hasAddressData) {
                console.log('\x1b[34m[DB] Updating address information...\x1b[0m');
                console.log('\x1b[35m[DEBUG] Address data received:\x1b[0m', {
                    region: data.region,
                    province: data.province,
                    municipal_city: data.municipal_city,
                    barangay: data.barangay,
                    street_address: data.street_address,
                    postal_code: data.postal_code
                });

                const addressData: any = {
                    region: data.region?.trim() || null,
                    province: data.province?.trim() || null,
                    city: data.municipal_city?.trim()
                        ? { id: 'custom', name: data.municipal_city.trim() }
                        : null,
                    barangay: data.barangay?.trim() || null,
                    street: data.street_address?.trim() || null,
                    zip_code: data.postal_code?.trim() || null,
                    updated_at: new Date()
                };

                // Build full address string
                const addressParts = [
                    data.street_address?.trim(),
                    data.barangay?.trim(),
                    data.municipal_city?.trim(),
                    data.province?.trim(),
                    data.region?.trim(),
                    data.postal_code?.trim()
                ].filter(Boolean);

                addressData.address = addressParts.length > 0 ? addressParts.join(', ') : null;

                const existingAddress = await tx
                    .select()
                    .from(user_addresses)
                    .where(and(
                        eq(user_addresses.user_uid, userId),
                        eq(user_addresses.address_type, 'personal')
                    ))
                    .limit(1)
                    .then(rows => rows[0]);

                if (existingAddress) {
                    // Update existing address
                    console.log('\x1b[36m[DB] Updating existing address with ID:\x1b[0m', existingAddress.id);
                    await tx
                        .update(user_addresses)
                        .set(addressData)
                        .where(eq(user_addresses.id, existingAddress.id));
                    console.log('\x1b[32m[SUCCESS] Address updated successfully\x1b[0m');
                } else {
                    // Create new address
                    console.log('\x1b[36m[DB] Creating new address...\x1b[0m');
                    await tx.insert(user_addresses).values({
                        ...addressData,
                        user_uid: userId,
                        address_type: 'personal',
                        is_primary: true,
                        country: 'Philippines', // Default country
                        created_at: new Date()
                    });
                    console.log('\x1b[32m[SUCCESS] Address created successfully\x1b[0m');
                }
            }

            // 3. Handle documents
            if (Array.isArray(data.documents) && data.documents.length > 0) {
                console.log(`\x1b[34m[DB] Processing ${data.documents.length} document updates...\x1b[0m`);

                for (const doc of data.documents) {
                    if (!doc.document_type) {
                        console.warn('\x1b[33m[WARN] Skipping document without document_type\x1b[0m', doc);
                        continue;
                    }

                    // Validate required fields
                    if (!doc.file_url) {
                        console.error(`\x1b[31m[ERROR] Document ${doc.document_type} missing required file_url\x1b[0m`);
                        throw new Error(`Document ${doc.document_type} is missing required file_url`);
                    }

                    // Document types that can have id_type and id_number
                    // VALID_ID, SECONDARY_ID_1, SECONDARY_ID_2 require them
                    // SELFIE_WITH_ID can optionally have them to reference which ID was used
                    const idDocumentTypes = ['VALID_ID', 'SECONDARY_ID_1', 'SECONDARY_ID_2', 'SELFIE_WITH_ID'];
                    const canHaveIdInfo = idDocumentTypes.includes(doc.document_type);

                    const docUpdate: any = {
                        document_type: doc.document_type,
                        file_url: doc.file_url.trim(),
                        file_name: doc.file_name?.trim() || null,
                        updated_at: new Date()
                    };

                    // Add id_type and id_number if the document type supports it and data is provided
                    if (canHaveIdInfo) {
                        docUpdate.id_type = doc.id_type || null;
                        docUpdate.id_number = doc.id_number?.trim() || null;
                    } else {
                        // Explicitly set to null for document types that don't support ID info
                        docUpdate.id_type = null;
                        docUpdate.id_number = null;
                    }

                    console.log(`\x1b[35m[DEBUG] Processing document:\x1b[0m`, {
                        document_type: doc.document_type,
                        has_file_url: !!doc.file_url,
                        has_id_type: !!doc.id_type,
                        has_id_number: !!doc.id_number,
                        can_have_id_info: canHaveIdInfo
                    });

                    // Check if document exists
                    const existingDoc = await tx
                        .select()
                        .from(user_documents)
                        .where(and(
                            eq(user_documents.user_uid, userId),
                            eq(user_documents.document_type, doc.document_type)
                        ))
                        .limit(1)
                        .then(rows => rows[0]);

                    if (existingDoc) {
                        // Update existing document
                        console.log(`\x1b[36m[DB] Updating existing document ${doc.document_type} with ID:\x1b[0m`, existingDoc.id);
                        await tx
                            .update(user_documents)
                            .set(docUpdate)
                            .where(eq(user_documents.id, existingDoc.id));
                        console.log(`\x1b[32m[SUCCESS] Document ${doc.document_type} updated successfully\x1b[0m`);
                    } else {
                        // Insert new document
                        console.log(`\x1b[36m[DB] Creating new document ${doc.document_type}...\x1b[0m`);
                        await tx.insert(user_documents).values({
                            ...docUpdate,
                            user_uid: userId,
                            created_at: new Date()
                        });
                        console.log(`\x1b[32m[SUCCESS] Document ${doc.document_type} created successfully\x1b[0m`);
                    }
                }
            }

            // Fetch and return updated user data
            const updatedUser = await tx
                .select()
                .from(users)
                .where(eq(users.uid, userId))
                .leftJoin(
                    user_addresses,
                    and(
                        eq(user_addresses.user_uid, users.uid),
                        eq(user_addresses.address_type, 'personal')
                    )
                )
                .leftJoin(
                    user_documents,
                    eq(user_documents.user_uid, users.uid)
                )
                .then(rows => {
                    if (!rows.length) return null;

                    const user = rows[0]?.users;
                    const address = rows[0]?.user_addresses;
                    const documents = rows
                        .filter(row => row.user_documents)
                        .map(row => row.user_documents);

                    return {
                        ...user,
                        address,
                        documents
                    };
                });

            if (!updatedUser) {
                throw new Error('Failed to fetch updated user data');
            }

            return c.json({
                status: 'success',
                code: 'USER_UPDATED',
                message: 'User information updated successfully',
                data: updatedUser
            });

        }).catch((error) => {
            console.error('\x1b[31m[ERROR] Transaction failed:\x1b[0m', error);

            // Handle specific error cases
            if (error.message.includes('User not found')) {
                return c.json(
                    {
                        status: 'error',
                        code: 'USER_NOT_FOUND',
                        message: 'User not found',
                    },
                    404
                );
            } else if (error.message.includes('Invalid phone number format')) {
                return c.json(
                    {
                        status: 'error',
                        code: 'INVALID_PHONE_FORMAT',
                        message: 'Invalid phone number format',
                    },
                    400
                );
            } else if (error.message.includes('Invalid birth date')) {
                return c.json(
                    {
                        status: 'error',
                        code: 'INVALID_BIRTH_DATE',
                        message: 'Birth date must be a valid date in the past',
                    },
                    400
                );
            } else if (error.message.includes('missing required file_url') || error.message.includes('Document')) {
                return c.json(
                    {
                        status: 'error',
                        code: 'INVALID_DOCUMENT',
                        message: error.message || 'Document is missing required information',
                    },
                    400
                );
            }

            // Default error response
            return c.json(
                {
                    status: 'error',
                    code: 'INTERNAL_SERVER_ERROR',
                    message: 'An error occurred while updating user information',
                    details: process.env.NODE_ENV === 'development' ? error.message : undefined
                },
                500
            );
        });

    } catch (error) {
        console.error('\x1b[31m[ERROR] Unhandled error in updatePersonalInfo:\x1b[0m', error);
        return c.json(
            {
                status: 'error',
                code: 'INTERNAL_SERVER_ERROR',
                message: 'An unexpected error occurred',
                details: process.env.NODE_ENV === 'development' && error instanceof Error
                    ? error.message
                    : undefined
            },
            500
        );
    }
};


// Export both the old function name for backward compatibility and the new unified function
export default {
    getUserData,
    updatePersonalInfo,
    getUserRoles,
    switchRole,
    getUserDataByIdWithRole,
    getUserDataById,
    sendOtpCode,
};