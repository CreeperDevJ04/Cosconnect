import type { Context } from 'hono';
import { z } from 'zod';
import { eq } from 'drizzle-orm';
import { createHmac } from 'crypto';
import { db } from '../db/supabase/db_connect';
import { users, user_business_info } from '../schema/users';
import { createSubscriptionPayment, processSubscriptionPaymentWebhook } from '@/services/paymentService';

// Zod schema for subscription payment validation
const subscriptionPaymentSchema = z.object({
    email: z.string().email({ message: 'Invalid email format' }).min(1, { message: 'Email is required' }),
    fullName: z.string().min(1, { message: 'Full name is required' }),
    phoneNumber: z.string().min(1, { message: 'Phone number is required' }),
    user_id: z.string().min(1, { message: 'User ID is required' }),
    subscriptionType: z.enum(['monthly', 'yearly']).optional().default('monthly')
});

// Helper function to check if user has an active premium subscription
const checkActivePremiumSubscription = (user: any) => {
    // Check if user is premium and has active subscription
    if (!user.is_premium || user.subscription_status !== 'active') {
        return {
            isActive: false,
            message: 'No active premium subscription',
            daysRemaining: 0
        };
    }

    // Check if subscription has an end date
    if (!user.subscription_end_date) {
        return {
            isActive: false,
            message: 'Subscription end date not found',
            daysRemaining: 0
        };
    }

    const now = new Date();
    const endDate = new Date(user.subscription_end_date);

    // Check if subscription has expired
    if (endDate <= now) {
        return {
            isActive: false,
            message: 'Premium subscription has expired',
            daysRemaining: 0
        };
    }

    // Calculate days remaining
    const timeDiff = endDate.getTime() - now.getTime();
    const daysRemaining = Math.ceil(timeDiff / (1000 * 3600 * 24));

    return {
        isActive: true,
        message: `Premium subscription is active with ${daysRemaining} days remaining`,
        daysRemaining
    };
};

const paySubscription = async (c: Context) => {
    try {
        const body = await c.req.json();
        console.log('[Pay Subscription] Request:', JSON.stringify(body, null, 2));

        // Validate input
        const validation = subscriptionPaymentSchema.safeParse(body);
        if (!validation.success) {
            return c.json({
                status: 'failed',
                message: 'Validation failed',
                errors: validation.error.errors.map(err => ({
                    field: err.path.join('.'),
                    message: err.message
                }))
            }, 400);
        }

        const { email, fullName, phoneNumber, user_id, subscriptionType } = validation.data;

        // Fetch user and business info
        const [user] = await db.select().from(users).where(eq(users.uid, user_id)).limit(1);
        if (!user) {
            return c.json({
                status: 'failed',
                message: 'User not found',
                error_code: 'USER_NOT_FOUND'
            }, 404);
        }

        // Check if user has an active premium subscription
        const hasActivePremium = checkActivePremiumSubscription(user);
        if (hasActivePremium.isActive) {
            return c.json({
                status: 'failed',
                message: hasActivePremium.message,
                error_code: 'SUBSCRIPTION_STILL_ACTIVE',
                data: {
                    current_subscription: {
                        type: user.subscription_type,
                        status: user.subscription_status,
                        expires_at: user.subscription_end_date,
                        days_remaining: hasActivePremium.daysRemaining
                    }
                }
            }, 400);
        }

        const [businessInfo] = user.role?.includes('lender')
            ? await db.select().from(user_business_info).where(eq(user_business_info.user_uid, user_id)).limit(1)
            : [null];

        // Create checkout session
        const result = await createSubscriptionPayment({
            email,
            fullName,
            phoneNumber,
            userId: user_id,
            subscriptionType,
            user,
            businessInfo
        });

        if (!result.success) {
            return c.json({
                status: 'failed',
                message: result.error || 'Failed to create checkout session'
            }, 500);
        }

        // Store session_id in the users table
        // Only update if user is not already premium or subscription is expired/inactive
        const canUpdateSession = !user.is_premium ||
            user.subscription_status === 'inactive' ||
            user.subscription_status === 'expired' ||
            user.subscription_status === 'cancelled';

        if (canUpdateSession && result.session_id) {
            try {
                await db.update(users)
                    .set({
                        subscription_session_id: result.session_id,
                        updated_at: new Date()
                    })
                    .where(eq(users.uid, user_id));

                console.log('[Pay Subscription] Session ID stored for user:', user_id);
            } catch (updateError) {
                console.error('[Pay Subscription] Failed to store session_id:', updateError);
                // Don't fail the request if session_id storage fails
            }
        } else {
            console.log('[Pay Subscription] Session ID not stored - user has active premium subscription');
        }

        return c.json({
            status: 'success',
            message: 'Checkout session created. Please complete payment.',
            data: {
                session_id: result.session_id,
                payment_intent_id: result.payment_intent_id,
                checkout_url: result.checkout_url,
                reference_number: result.reference_number,
                amount: result.amount,
                subscription_type: result.subscription_type,
                expires_at: result.expires_at,
                payment_status: 'pending'
            }
        }, 200);

    } catch (error: any) {
        console.error('[Pay Subscription] Error:', error);
        return c.json({
            status: 'error',
            message: error.message || 'Internal server error'
        }, 500);
    }
};

// Helper function to verify PayMongo webhook signature
const verifyWebhookSignature = (payload: string, signature: string, secret: string): boolean => {
    try {
        const expectedSignature = createHmac('sha256', secret)
            .update(payload, 'utf8')
            .digest('hex');

        // PayMongo sends signature in format: t=timestamp,v1=signature
        const signatureParts = signature.split(',');
        const versionedSignature = signatureParts.find(part => part.startsWith('v1='));

        if (!versionedSignature) {
            console.error('[Webhook] No v1 signature found');
            return false;
        }

        const receivedSignature = versionedSignature.split('=')[1];
        return expectedSignature === receivedSignature;
    } catch (error) {
        console.error('[Webhook] Signature verification error:', error);
        return false;
    }
};

// Webhook handler for subscription payment events
const subscriptionPaymentWebhook = async (c: Context) => {
    try {
        console.log('=== PAYMONGO WEBHOOK TRIGGERED ===');

        // Get webhook secret from environment
        const webhookSecret = process.env.PAYMONGO_WEBHOOK_SECRET;
        if (!webhookSecret) {
            console.error('[Webhook] Missing PAYMONGO_WEBHOOK_SECRET');
            return c.json({
                status: 'error',
                message: 'Webhook configuration error'
            }, 500);
        }

        // Get raw body for signature verification
        const rawBody = await c.req.text();
        const signature = c.req.header('paymongo-signature');

        console.log('[Webhook] Headers:', {
            'content-type': c.req.header('content-type'),
            'user-agent': c.req.header('user-agent'),
            'paymongo-signature': signature ? 'present' : 'missing'
        });

        // Verify webhook signature
        if (!signature) {
            console.error('[Webhook] Missing PayMongo signature');
            return c.json({
                status: 'error',
                message: 'Missing webhook signature'
            }, 400);
        }

        const isValidSignature = verifyWebhookSignature(rawBody, signature, webhookSecret);
        if (!isValidSignature) {
            console.error('[Webhook] Invalid signature');
            return c.json({
                status: 'error',
                message: 'Invalid webhook signature'
            }, 401);
        }

        console.log('[Webhook] Signature verified successfully');

        // Parse the webhook payload
        const webhookData = JSON.parse(rawBody);
        console.log('[1] Raw Webhook Body:', JSON.stringify(webhookData, null, 2));

        // PayMongo webhook structure: { data: { id, type, attributes: { type, data } } }
        const eventType = webhookData.data?.attributes?.type;
        const eventData = webhookData.data?.attributes?.data;

        console.log('[2] Extracted Event Data:', {
            webhookId: webhookData.data?.id,
            eventType,
            hasEventData: !!eventData,
            eventDataType: eventData?.type
        });

        if (!eventType || !eventData) {
            console.error('[ERROR] Missing required webhook fields:', { eventType, eventData });
            return c.json({
                status: 'failed',
                message: 'Invalid webhook payload structure'
            }, 400);
        }

        console.log(`[3] Processing event type: ${eventType}`);

        // Handle payment intent events
        if (eventType === 'payment_intent.payment.paid' || eventType === 'payment.paid') {
            const paymentIntentId = eventData.id;
            const metadata = eventData.attributes?.metadata;
            const paymentStatus = eventData.attributes?.status;
            const amount = eventData.attributes?.amount;

            console.log('[4] Payment Intent Data:', {
                paymentIntentId,
                status: paymentStatus,
                amount,
                currency: eventData.attributes?.currency,
                metadata: JSON.stringify(metadata, null, 2)
            });

            // Validate payment is actually successful
            if (paymentStatus !== 'succeeded' && paymentStatus !== 'paid') {
                console.log(`[SKIP] Payment not successful, status: ${paymentStatus}`);
                return c.json({
                    status: 'acknowledged',
                    message: `Payment status ${paymentStatus} acknowledged but not processed`
                }, 200);
            }

            // Check if this is a subscription payment
            if (!metadata?.payment_type || metadata.payment_type !== 'subscription') {
                console.log('[SKIP] Not a subscription payment');
                return c.json({
                    status: 'success',
                    message: 'Not a subscription payment - webhook acknowledged'
                }, 200);
            }

            // Validate required metadata
            if (!metadata.user_id || !metadata.subscription_type) {
                console.error('[ERROR] Missing required metadata:', {
                    user_id: metadata.user_id,
                    subscription_type: metadata.subscription_type
                });
                return c.json({
                    status: 'failed',
                    message: 'Missing required payment metadata (user_id or subscription_type)'
                }, 400);
            }

            console.log('[5] Processing subscription payment...');
            try {
                const result = await processSubscriptionPaymentWebhook(paymentIntentId, metadata);

                if (!result.success) {
                    console.error('[ERROR] Payment processing failed:', result.error);
                    return c.json({
                        status: 'failed',
                        message: result.error || 'Failed to process subscription payment'
                    }, 500);
                }

                console.log('[SUCCESS] User upgraded to premium:', {
                    userId: result.user?.uid,
                    subscriptionType: result.user?.subscription_type,
                    isPremium: result.user?.is_premium,
                    subscriptionStatus: result.user?.subscription_status
                });

                return c.json({
                    status: 'success',
                    message: 'User upgraded to premium successfully',
                    data: {
                        user_id: result.user?.uid,
                        is_premium: result.user?.is_premium,
                        subscription_type: result.user?.subscription_type,
                        subscription_status: result.user?.subscription_status,
                        subscription_start_date: result.user?.subscription_start_date,
                        subscription_end_date: result.user?.subscription_end_date,
                        payment_intent_id: paymentIntentId,
                        amount: amount ? amount / 100 : null // Convert from centavos to pesos
                    }
                }, 200);

            } catch (processingError: any) {
                console.error('[ERROR] Exception during payment processing:', processingError);
                return c.json({
                    status: 'error',
                    message: 'Internal error processing subscription payment'
                }, 500);
            }
        }

        // Handle failed payments
        if (eventType === 'payment_intent.payment.failed' || eventType === 'payment.failed') {
            console.log('[Webhook] Payment failed:', eventData.id);
            return c.json({
                status: 'acknowledged',
                message: 'Payment failed event acknowledged'
            }, 200);
        }

        // Handle cancelled payments
        if (eventType === 'payment_intent.cancelled' || eventType === 'payment.cancelled') {
            console.log('[Webhook] Payment cancelled:', eventData.id);
            return c.json({
                status: 'acknowledged',
                message: 'Payment cancelled event acknowledged'
            }, 200);
        }

        // Handle checkout session events
        if (eventType === 'checkout_session.payment.paid') {
            const sessionId = eventData.id;
            const paymentIntent = eventData.attributes?.payment_intent;

            console.log('[Webhook] Checkout session paid:', {
                sessionId,
                paymentIntentId: paymentIntent?.id
            });

            if (paymentIntent?.attributes?.metadata?.payment_type === 'subscription') {
                const result = await processSubscriptionPaymentWebhook(
                    paymentIntent.id,
                    paymentIntent.attributes.metadata
                );

                if (result.success) {
                    return c.json({
                        status: 'success',
                        message: 'Subscription payment processed via checkout session'
                    }, 200);
                }
            }
        }

        // Acknowledge other event types
        console.log(`[Webhook] Event ${eventType} acknowledged but not processed`);
        return c.json({
            status: 'acknowledged',
            message: `Event ${eventType} received and acknowledged`
        }, 200);

    } catch (error: any) {
        console.error('[Webhook] Processing error:', error);
        return c.json({
            status: 'error',
            message: 'Webhook processing failed'
        }, 500);
    }
};

const confirmSubscriptionPayment = async (c: Context) => {
    try {
        const session_id = c.req.param("session_id");
        console.log('[Confirm Subscription] Request:', { session_id });

        // Validate session_id
        if (!session_id) {
            return c.json({
                status: 'failed',
                message: 'Session ID is required'
            }, 400);
        }

        // Get PayMongo configuration
        const PAYMONGO_API_URL = 'https://api.paymongo.com/v1';
        const PAYMONGO_SECRET_KEY = process.env.PAYMONGO_SECRET_KEY;

        if (!PAYMONGO_SECRET_KEY) {
            return c.json({
                status: 'error',
                message: 'Payment service configuration error'
            }, 500);
        }

        // Retrieve checkout session from PayMongo
        const authHeader = `Basic ${Buffer.from(PAYMONGO_SECRET_KEY + ':').toString('base64')}`;

        const response = await fetch(`${PAYMONGO_API_URL}/checkout_sessions/${session_id}`, {
            method: 'GET',
            headers: {
                'Authorization': authHeader,
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            console.error('[Confirm Subscription] PayMongo API Error:', response.status, response.statusText);
            return c.json({
                status: 'failed',
                message: 'Failed to retrieve payment information'
            }, 500);
        }

        const checkoutData = await response.json();
        const session = checkoutData.data;

        console.log('[Confirm Subscription] Session data:', JSON.stringify(session, null, 2));

        // Extract payment information
        const paymentIntent = session.attributes.payment_intent;
        const paymentStatus = paymentIntent?.attributes?.status || 'unknown';
        const metadata = paymentIntent?.attributes?.metadata || {};
        const paymentIntentId = paymentIntent?.id || null;
        const userId = metadata.user_id;
        const subscriptionType = metadata.subscription_type || 'monthly';
        const referenceNumber = metadata.reference_code || session.attributes.reference_number;

        // Validate required metadata
        if (!userId) {
            console.error('[Confirm Subscription] Missing user_id in payment metadata');
            return c.json({
                status: 'failed',
                message: 'User ID not found in payment information'
            }, 400);
        }

        // Check if payment is successful
        const isPaid = paymentStatus === 'succeeded' || paymentStatus === 'paid';

        // Prepare response data
        const responseData = {
            session_id: session.id,
            payment_intent_id: paymentIntentId,
            payment_status: paymentStatus,
            amount: session.attributes.line_items?.[0]?.amount ?
                (session.attributes.line_items[0].amount / 100) : 0,
            currency: session.attributes.line_items?.[0]?.currency || 'PHP',
            subscription_type: subscriptionType,
            reference_number: referenceNumber,
            user_id: userId,
            created_at: session.attributes.created_at,
            expires_at: session.attributes.expires_at,
            checkout_url: session.attributes.checkout_url,
            is_paid: isPaid
        };

        console.log('[Confirm Subscription] Response data:', responseData);

        // If payment is successful, update user subscription
        if (isPaid && userId) {
            try {
                // Fetch user to check current status
                const [user] = await db.select().from(users).where(eq(users.uid, userId)).limit(1);

                if (!user) {
                    console.error('[Confirm Subscription] User not found:', userId);
                    return c.json({
                        status: 'failed',
                        message: 'User not found',
                        data: responseData
                    }, 404);
                }

                // Check if payment has already been processed (prevent duplicate updates)
                if (user.subscription_payment_id === paymentIntentId && user.is_premium) {
                    console.log('[Confirm Subscription] Payment already processed for user:', userId);
                    return c.json({
                        status: 'success',
                        message: 'Payment information retrieved successfully (already processed)',
                        data: {
                            ...responseData,
                            subscription_already_processed: true,
                            current_subscription: {
                                is_premium: user.is_premium,
                                subscription_type: user.subscription_type,
                                subscription_status: user.subscription_status,
                                subscription_start_date: user.subscription_start_date,
                                subscription_end_date: user.subscription_end_date
                            }
                        }
                    }, 200);
                }

                // Calculate subscription dates
                const startDate = new Date();
                const endDate = new Date();

                if (subscriptionType === 'monthly') {
                    endDate.setMonth(endDate.getMonth() + 1);
                } else if (subscriptionType === 'yearly') {
                    endDate.setFullYear(endDate.getFullYear() + 1);
                } else {
                    // Default to monthly if invalid type
                    console.warn('[Confirm Subscription] Invalid subscription type, defaulting to monthly:', subscriptionType);
                    endDate.setMonth(endDate.getMonth() + 1);
                }

                // Update user subscription
                const [updatedUser] = await db
                    .update(users)
                    .set({
                        is_premium: true,
                        subscription_type: subscriptionType,
                        subscription_status: 'active',
                        subscription_start_date: startDate,
                        subscription_end_date: endDate,
                        subscription_payment_id: paymentIntentId,
                        subscription_reference: referenceNumber || null,
                        subscription_session_id: session_id,
                        updated_at: new Date()
                    })
                    .where(eq(users.uid, userId))
                    .returning();

                if (!updatedUser) {
                    console.error('[Confirm Subscription] Failed to update user subscription');
                    return c.json({
                        status: 'failed',
                        message: 'Failed to update user subscription status',
                        data: responseData
                    }, 500);
                }

                console.log('[Confirm Subscription] User subscription updated successfully:', {
                    userId,
                    subscriptionType,
                    startDate,
                    endDate,
                    paymentIntentId
                });

                return c.json({
                    status: 'success',
                    message: 'Payment confirmed and subscription activated successfully',
                    data: {
                        ...responseData,
                        subscription_updated: true,
                        subscription: {
                            is_premium: updatedUser.is_premium,
                            subscription_type: updatedUser.subscription_type,
                            subscription_status: updatedUser.subscription_status,
                            subscription_start_date: updatedUser.subscription_start_date,
                            subscription_end_date: updatedUser.subscription_end_date,
                            subscription_payment_id: updatedUser.subscription_payment_id,
                            subscription_reference: updatedUser.subscription_reference
                        }
                    }
                }, 200);

            } catch (updateError: any) {
                console.error('[Confirm Subscription] Error updating user subscription:', updateError);
                // Return payment info even if update fails
                return c.json({
                    status: 'partial_success',
                    message: 'Payment confirmed but failed to update subscription. Please contact support.',
                    error: updateError.message,
                    data: responseData
                }, 500);
            }
        }

        // Return payment info if not paid yet
        return c.json({
            status: 'success',
            message: 'Payment information retrieved successfully',
            data: responseData
        }, 200);

    } catch (error: any) {
        console.error('[Confirm Subscription] Error:', error);
        return c.json({
            status: 'error',
            message: error.message || 'Internal server error'
        }, 500);
    }
};

export default { paySubscription, subscriptionPaymentWebhook, confirmSubscriptionPayment };