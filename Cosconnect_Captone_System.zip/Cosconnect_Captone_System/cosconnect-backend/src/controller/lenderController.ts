import { sendEmails } from '@/lib/emailTemplates/lenderEmailsTemplates';
import {
    DocumentType,
    LenderFormDataSchema,
    type DocumentData
} from '@/lib/zodSchema/lenderSchema';
import { desc, eq, sql } from 'drizzle-orm';
import type { Context } from 'hono';
import db from '../db/supabase/db_connect';
import {
    business_addresses,
    user_business_info,
    user_documents,
    users,
    type UserStatus
} from '../schema/users.js';
import { termsAndConditions, TermsAndConditionsPayload } from '@/schema/termscondition';

/**
 * Register lender account - adds lender role to existing user account
 */
const registerLenderAccount = async (c: Context) => {
    try {
        const userId = c.req.param("userId");

        if (!userId) {
            return c.json({
                success: false,
                message: 'User ID is required',
                code: 'MISSING_USER_ID'
            }, 400);
        }

        // Parse and validate request body
        const body = await c.req.json();
        const validation = LenderFormDataSchema.safeParse(body);

        if (!validation.success) {
            return c.json({
                success: false,
                message: 'Validation failed',
                code: 'VALIDATION_ERROR',
                errors: validation.error.issues.map(issue => ({
                    field: issue.path.join('.'),
                    message: issue.message,
                    code: issue.code
                }))
            }, 400);
        }

        const lenderData = validation.data;

        // Check if user exists
        const [existingUser] = await db
            .select()
            .from(users)
            .where(eq(users.uid, userId));

        if (!existingUser) {
            return c.json({
                success: false,
                message: 'User not found',
                code: 'USER_NOT_FOUND'
            }, 404);
        }

        // Check if user is already a verified lender
        const currentRoles = existingUser.role || ['borrower'];
        if (currentRoles.includes('lender') && existingUser.status === 'verified') {
            return c.json({
                success: false,
                message: 'You are already a verified lender',
                code: 'ALREADY_VERIFIED'
            }, 409);
        }

        // Check if application is pending
        if (currentRoles.includes('lender') && existingUser.status === 'pending_verification') {
            return c.json({
                success: false,
                message: 'Your lender application is already pending review',
                code: 'PENDING_REVIEW'
            }, 409);
        }

        // Execute registration in transaction
        const result = await db.transaction(async (tx) => {
            // 1. Update user profile and add lender role
            const updatedRoles = currentRoles.includes('lender')
                ? currentRoles
                : [...currentRoles, 'lender'];

            const [updatedUser] = await tx
                .update(users)
                .set({
                    full_name: lenderData.personal_info.full_name,
                    first_name: lenderData.personal_info.first_name,
                    last_name: lenderData.personal_info.last_name,
                    email: lenderData.personal_info.email,
                    phone_number: lenderData.personal_info.phone_number,
                    username: lenderData.personal_info.username,
                    role: updatedRoles,
                    current_role: existingUser.current_role || 'borrower',
                    status: 'pending_verification' as UserStatus,
                    rejected_message: null,
                    updated_at: new Date(),
                })
                .where(eq(users.uid, userId))
                .returning();

            if (!updatedUser) {
                throw new Error('Failed to update user');
            }

            // 2. Insert/update identification documents
            await insertDocument(tx, userId, DocumentType.VALID_ID, {
                id_type: lenderData.identification.valid_id_type,
                id_number: lenderData.identification.valid_id_number,
                file_url: lenderData.identification.valid_id_file,
                has_valid_id: lenderData.identification.has_valid_id,
            });

            await insertDocument(tx, userId, DocumentType.SELFIE_WITH_ID, {
                file_url: lenderData.identification.selfie_with_id,
                has_valid_id: lenderData.identification.has_valid_id,
            });

            // 3. Insert/update business information
            const [businessRecord] = await tx
                .insert(user_business_info)
                .values({
                    user_uid: userId,
                    business_name: lenderData.business_info.business_name,
                    business_description: lenderData.business_info.business_description,
                    business_type: lenderData.business_info.business_type,
                    business_email: lenderData.business_info.business_email,
                    business_phone_number: lenderData.business_info.business_phone_number,
                    business_telephone: lenderData.business_info.business_telephone || null,
                    business_profile_image: lenderData.business_info.business_profile_image || null,
                    business_background_image: lenderData.business_info.business_background_image || null,
                    business_permit_file: lenderData.business_info.business_permit_file || null,
                    upload_business_permit: lenderData.business_info.business_type === 'STORE'
                        ? lenderData.business_info.upload_business_permit : null,
                    upload_dti_certificate: lenderData.business_info.business_type === 'STORE'
                        ? lenderData.business_info.upload_dti_certificate : null,
                    upload_storefront_photo: lenderData.business_info.business_type === 'STORE'
                        ? lenderData.business_info.upload_storefront_photo : null,
                    terms_and_conditions: lenderData.terms_and_conditions,
                    is_verified: false,
                    created_at: new Date(),
                    updated_at: new Date(),
                })
                .onConflictDoUpdate({
                    target: user_business_info.user_uid,
                    set: {
                        business_name: lenderData.business_info.business_name,
                        business_description: lenderData.business_info.business_description,
                        business_type: lenderData.business_info.business_type,
                        business_email: lenderData.business_info.business_email,
                        business_phone_number: lenderData.business_info.business_phone_number,
                        business_telephone: lenderData.business_info.business_telephone || null,
                        business_profile_image: lenderData.business_info.business_profile_image || null,
                        business_background_image: lenderData.business_info.business_background_image || null,
                        business_permit_file: lenderData.business_info.business_permit_file || null,
                        upload_business_permit: lenderData.business_info.business_type === 'STORE'
                            ? lenderData.business_info.upload_business_permit : null,
                        upload_dti_certificate: lenderData.business_info.business_type === 'STORE'
                            ? lenderData.business_info.upload_dti_certificate : null,
                        upload_storefront_photo: lenderData.business_info.business_type === 'STORE'
                            ? lenderData.business_info.upload_storefront_photo : null,
                        terms_and_conditions: lenderData.terms_and_conditions,
                        is_verified: false,
                        updated_at: new Date(),
                    }
                })
                .returning();

            // 4. Insert business address
            await tx
                .insert(business_addresses)
                .values({
                    business_info_id: businessRecord?.id || '',
                    business_address: lenderData.business_info.business_address,
                    street: lenderData.business_info.street,
                    barangay: lenderData.business_info.barangay,
                    zip_code: lenderData.business_info.zip_code,
                    province: lenderData.business_info.province,
                    region: lenderData.business_info.region,
                    country: 'Philippines',
                    city: lenderData.business_info.city,
                    is_primary: true,
                    created_at: new Date(),
                    updated_at: new Date(),
                })
                .onConflictDoNothing();

            // 5. Handle store documents if business type is STORE
            if (lenderData.business_info.business_type === 'STORE') {
                await insertDocument(tx, userId, DocumentType.BUSINESS_PERMIT, {
                    file_url: lenderData.business_info.upload_business_permit,
                    has_valid_id: false,
                });

                await insertDocument(tx, userId, DocumentType.DTI_CERTIFICATE, {
                    file_url: lenderData.business_info.upload_dti_certificate,
                    has_valid_id: false,
                });

                await insertDocument(tx, userId, DocumentType.STOREFRONT_PHOTO, {
                    file_url: lenderData.business_info.upload_storefront_photo,
                    has_valid_id: false,
                });
            }

            return updatedUser;
        });

        // Send notification emails (non-blocking)
        try {
            await sendEmails(result);
        } catch (emailError) {
            console.error('Email sending failed:', emailError);
        }

        return c.json({
            success: true,
            message: 'Lender application submitted successfully! Your application is now under review.',
            data: {
                user_id: result.uid,
                username: result.username,
                email: result.email,
                roles: result.role,
                current_role: result.current_role,
                status: result.status,
                next_steps: 'You will be notified via email once your lender application is reviewed.'
            }
        }, 201);

    } catch (error) {
        console.error('Lender registration error:', error);
        return c.json({
            success: false,
            message: 'Internal server error. Please try again later.',
            code: 'INTERNAL_ERROR'
        }, 500);
    }
};

/**
 * Helper function to insert/update documents
 */
async function insertDocument(
    tx: any,
    userId: string,
    documentType: DocumentType,
    data: DocumentData
) {
    await tx
        .insert(user_documents)
        .values({
            user_uid: userId,
            document_type: documentType,
            id_type: data.id_type || null,
            id_number: data.id_number || null,
            file_url: data.file_url,
            has_valid_id: data.has_valid_id,
            is_verified: false,
            created_at: new Date(),
            updated_at: new Date(),
        })
        .onConflictDoUpdate({
            target: [user_documents.user_uid, user_documents.document_type],
            set: {
                id_type: data.id_type || null,
                id_number: data.id_number || null,
                file_url: data.file_url,
                has_valid_id: data.has_valid_id,
                is_verified: false,
                updated_at: new Date(),
            }
        });
}



const createLenderTermsCondition = async (c: Context) => {
    try {
        // Parse and validate the request body
        const body = await c.req.json<{
            userId: string;
            title: string;
            lastUpdated?: string;
            sections: Array<{
                id?: string;
                heading: string;
                content: string;
                lastUpdated?: string;
            }>;
        }>();

        // Validate required fields
        if (!body.userId) {
            return c.json({
                success: false,
                message: 'User ID is required',
                code: 'MISSING_USER_ID'
            }, 400);
        }

        if (!body.title) {
            return c.json({
                success: false,
                message: 'Title is required',
                code: 'VALIDATION_ERROR'
            }, 400);
        }

        // Ensure sections is an array
        if (!Array.isArray(body.sections) || body.sections.length === 0) {
            return c.json({
                success: false,
                message: 'Sections must be a non-empty array',
                code: 'VALIDATION_ERROR'
            }, 400);
        }

        // Check if terms already exist for this user
        const existingTerms = await db
            .select()
            .from(termsAndConditions)
            .where(eq(termsAndConditions.userId, body.userId))
            .limit(1);

        if (existingTerms.length > 0) {
            return c.json({
                success: false,
                message: 'Terms and conditions already exist for this user',
                code: 'TERMS_ALREADY_EXIST',
                data: {
                    existingTermsId: existingTerms[0]?.id
                }
            }, 409); // 409 Conflict for duplicate resource
        }

        // Format date to YYYY-MM-DD
        const formatDate = (dateString?: string): string => {
            try {
                const date = dateString ? new Date(dateString) : new Date();
                if (isNaN(date.getTime())) {
                    throw new Error('Invalid date');
                }
                return date.toISOString().split('T')[0] as any;
            } catch {
                return new Date().toISOString().split('T')[0] as any;
            }
        };

        // Process sections with validation
        const processedSections = body.sections.map(section => {
            if (!section.heading || !section.content) {
                throw new Error('Section heading and content are required');
            }
            return {
                id: section.id || crypto.randomUUID(),
                heading: section.heading,
                content: section.content,
                lastUpdated: formatDate(section.lastUpdated)
            };
        });

        // Create the terms and conditions
        const [newTerms] = await db
            .insert(termsAndConditions)
            .values({
                userId: body.userId,
                title: body.title,
                lastUpdated: formatDate(body.lastUpdated),
                sections: processedSections
            })
            .returning();

        return c.json({
            success: true,
            message: 'Terms and conditions created successfully',
            data: newTerms
        });

    } catch (error) {
        console.error('Error creating terms and conditions:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';

        // Handle validation errors
        if (errorMessage.includes('Section heading and content are required')) {
            return c.json({
                success: false,
                message: errorMessage,
                code: 'VALIDATION_ERROR'
            }, 400);
        }

        // Handle database unique constraint violations
        if (errorMessage.includes('duplicate key value violates unique constraint')) {
            return c.json({
                success: false,
                message: 'Terms and conditions already exist for this user',
                code: 'TERMS_ALREADY_EXIST'
            }, 409);
        }

        return c.json({
            success: false,
            message: 'Failed to create terms and conditions',
            code: 'INTERNAL_SERVER_ERROR',
            error: errorMessage
        }, 500);
    }
};

const getMyTermsConditionById = async (c: Context): Promise<Response> => {
    try {
        // Get the lender ID from URL parameters
        const lenderId = c.req.param('lenderId');

        // Validate lender ID
        if (!lenderId) {
            return c.json({
                success: false,
                message: 'Lender ID is required',
                code: 'MISSING_LENDER_ID'
            }, 400);
        }

        // Get the terms and conditions for the lender
        const terms = await db
            .select()
            .from(termsAndConditions)
            .where(eq(termsAndConditions.userId, lenderId))
            .orderBy(desc(termsAndConditions.updatedAt))
            .limit(1);

        // If no terms found
        if (terms.length === 0) {
            return c.json({
                success: false,
                message: 'No terms and conditions found for this lender',
                code: 'TERMS_NOT_FOUND'
            }, 404);
        }

        // Return the most recent terms
        return c.json({
            success: true,
            data: terms[0]
        });

    } catch (error) {
        console.error('Error fetching terms and conditions:', error);
        return c.json({
            success: false,
            message: 'Failed to fetch terms and conditions',
            code: 'INTERNAL_SERVER_ERROR',
            error: error instanceof Error ? error.message : 'Unknown error'
        }, 500);
    }
};

const updateTermsConditionById = async (c: Context): Promise<Response> => {
    try {
        const termsId = c.req.param('id');
        const body = await c.req.json<{
            title?: string;
            lastUpdated?: string;
            sections?: Array<{
                id?: string;
                heading: string;
                content: string;
                lastUpdated?: string;
            }>;
        }>();

        // Validate required fields
        if (!termsId) {
            return c.json({
                success: false,
                message: 'Terms ID is required',
                code: 'MISSING_TERMS_ID'
            }, 400);
        }

        // Check if terms exist
        const existingTerms = await db
            .select()
            .from(termsAndConditions)
            .where(eq(termsAndConditions.id, termsId))
            .limit(1);

        if (existingTerms.length === 0) {
            return c.json({
                success: false,
                message: 'Terms and conditions not found',
                code: 'TERMS_NOT_FOUND'
            }, 404);
        }

        // Format date to YYYY-MM-DD
        const formatDate = (dateString?: string): string => {
            try {
                const date = dateString ? new Date(dateString) : new Date();
                if (isNaN(date.getTime())) {
                    throw new Error('Invalid date');
                }
                return date.toISOString().split('T')[0] as any;
            } catch {
                return new Date().toISOString().split('T')[0] as any;
            }
        };

        // Prepare update data
        const updateData: {
            title?: string;
            lastUpdated: string;
            sections?: any[];
            updatedAt: Date;
        } = {
            lastUpdated: formatDate(body.lastUpdated),
            updatedAt: new Date()
        };

        if (body.title) {
            updateData.title = body.title;
        }

        if (body.sections) {
            if (!Array.isArray(body.sections) || body.sections.length === 0) {
                return c.json({
                    success: false,
                    message: 'Sections must be a non-empty array',
                    code: 'VALIDATION_ERROR'
                }, 400);
            }

            updateData.sections = body.sections.map(section => ({
                id: section.id || crypto.randomUUID(),
                heading: section.heading || '',
                content: section.content || '',
                lastUpdated: formatDate(section.lastUpdated)
            }));
        }

        // Update the terms and conditions
        const [updatedTerms] = await db
            .update(termsAndConditions)
            .set(updateData)
            .where(eq(termsAndConditions.id, termsId))
            .returning();

        return c.json({
            success: true,
            message: 'Terms and conditions updated successfully',
            data: updatedTerms
        });

    } catch (error) {
        console.error('Error updating terms and conditions:', error);
        return c.json({
            success: false,
            message: 'Failed to update terms and conditions',
            code: 'INTERNAL_SERVER_ERROR',
            error: error instanceof Error ? error.message : 'Unknown error'
        }, 500);
    }
};

export default { registerLenderAccount, createLenderTermsCondition, getMyTermsConditionById, updateTermsConditionById };