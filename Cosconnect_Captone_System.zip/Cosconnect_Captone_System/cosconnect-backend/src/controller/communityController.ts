import { user_business_info, users } from '@/db-schema';
import { community_comments, community_post_reactions, community_post_reports, community_posts } from '@/schema/community';
import { sendPostRemovalEmail } from '@/services/emailServices';
import { SQL, and, count, desc, eq, gt, ilike, inArray, isNull, or, sql } from 'drizzle-orm';
import type { Context } from 'hono';
import { z } from 'zod';
import db from '../db/supabase/db_connect';
import { createCommunityPostSchema } from '../lib/zodSchema/communityPostSchema';
import { notificationService } from './notificationController';


const getAllPosts = async (c: Context) => {
    try {
        // ==================== VALIDATION ====================
        const user_id = c.req.query("user_id");
        const user_role = c.req.query("user_role") as 'borrower' | 'lender' | "admin";
        console.log("userid", user_id)
        console.log("user_role", user_role)
        if (!user_id || !user_role || !['borrower', 'lender', "admin"].includes(user_role)) {
            return c.json(
                { success: false, message: "Valid user_id and user_role required" },
                400
            );
        }

        // ==================== PARAMETERS ====================
        const page = Math.max(1, parseInt(c.req.query("page") || "1", 10));
        const limit = Math.min(50, Math.max(1, parseInt(c.req.query("limit") || "10", 10)));
        const search = c.req.query("search")?.trim() || "";
        const onlyForSale = c.req.query("onlyForSale") === "true";
        const sortBy = c.req.query("sortBy") || "recent"; // recent | popular | random
        const offset = (page - 1) * limit;

        // ==================== BUILD FILTERS ====================
        const conditions: SQL<unknown>[] = [];

        if (onlyForSale) {
            conditions.push(eq(community_posts.is_for_sale, true));
        }

        if (search) {
            conditions.push(
                or(
                    ilike(community_posts.content, `%${search}%`),
                    ilike(community_posts.author_name, `%${search}%`)
                )!
            );
        }

        const whereClause = conditions.length > 0
            ? (conditions.length === 1 ? conditions[0] : and(...conditions)!)
            : undefined;

        // ==================== DETERMINE SORT ORDER ====================
        let orderBy;
        if (sortBy === "popular") {
            // Sort by engagement (likes + comments)
            orderBy = [
                desc(sql`${community_posts.heart_count} + ${community_posts.likes}`),
                desc(community_posts.created_at)
            ];
        } else if (sortBy === "random") {
            // Random order with seed for consistency within session
            orderBy = [sql`RANDOM()`];
        } else {
            // Default: most recent
            orderBy = [desc(community_posts.created_at)];
        }

        // ==================== FETCH POSTS ====================
        const baseQuery = db
            .select({
                id: community_posts.id,
                author_id: community_posts.author_id,
                author_name: community_posts.author_name,
                author_role: community_posts.author_role,
                author_avatar: community_posts.author_avatar,
                content: community_posts.content,
                images: community_posts.images,
                is_for_sale: community_posts.is_for_sale,
                heart_count: community_posts.heart_count,
                likes: community_posts.likes,
                created_at: community_posts.created_at,
                updated_at: community_posts.updated_at,
                report_count: community_posts.report_count,
                is_reported: community_posts.is_reported,
            })
            .from(community_posts);

        const filteredQuery = whereClause ? baseQuery.where(whereClause) : baseQuery;

        // Execute queries in parallel
        const [posts, countResult] = await Promise.all([
            filteredQuery
                .orderBy(...orderBy)
                .limit(limit)
                .offset(offset),
            db
                .select({ count: count() })
                .from(community_posts)
                .where(whereClause || sql`1=1`),
        ]);

        if (posts.length === 0) {
            return c.json({
                success: true,
                data: [],
                pagination: {
                    current_page: page,
                    per_page: limit,
                    total: 0,
                    total_pages: 0,
                    has_next_page: false,
                    has_previous_page: false,
                },
            });
        }

        const totalCount = countResult[0]?.count ?? 0;
        const totalPages = Math.ceil(totalCount / limit);

        // ==================== ENRICH POSTS ====================
        const enrichedPosts = await enrichPosts(posts, user_id, user_role);

        return c.json({
            success: true,
            data: enrichedPosts,
            pagination: {
                current_page: page,
                per_page: limit,
                total: totalCount,
                total_pages: totalPages,
                has_next_page: page < totalPages,
                has_previous_page: page > 1,
            },
            filters: {
                search: search || null,
                onlyForSale,
                sortBy,
            },
        });
    } catch (error) {
        console.error("Error fetching posts:", error);
        return c.json(
            {
                success: false,
                message: "Failed to fetch posts",
                error: error instanceof Error ? error.message : "Unknown error",
            },
            500
        );
    }
};

// ==================== ENRICH POSTS FUNCTION ====================
async function enrichPosts(
    posts: any[],
    currentUserId: string,
    currentUserRole: string
): Promise<any[]> {
    if (posts.length === 0) return [];

    const postIds = posts.map((p) => p.id);

    // ==================== FETCH REACTIONS FIRST ====================
    // Fetch all reactions first to get user IDs
    const allReactions = await db
        .select({
            post_id: community_post_reactions.post_id,
            reaction_type: community_post_reactions.reaction_type,
            user_uid: community_post_reactions.user_uid,
            user_role: community_post_reactions.user_role,
            reacted_at: community_post_reactions.reacted_at,
        })
        .from(community_post_reactions)
        .where(
            and(
                inArray(community_post_reactions.post_id, postIds),
                sql`${community_post_reactions.comment_id} IS NULL`
            )
        )
        .orderBy(desc(community_post_reactions.reacted_at));

    // Extract unique user IDs from reactions
    const reactionUserIds = Array.from(new Set(allReactions.map(r => r.user_uid)));

    // ==================== PARALLEL FETCH REST OF DATA ====================
    const [
        commentCounts,
        userReactions,
        authorInfos,
        reactionUserInfos
    ] = await Promise.all([
        // 1. Get comment counts per post
        db
            .select({
                post_id: community_comments.post_id,
                count: sql<number>`COUNT(*)::int`,
            })
            .from(community_comments)
            .where(inArray(community_comments.post_id, postIds))
            .groupBy(community_comments.post_id),

        // 2. Get current user's reactions
        db
            .select({
                post_id: community_post_reactions.post_id,
                reaction_type: community_post_reactions.reaction_type,
            })
            .from(community_post_reactions)
            .where(
                and(
                    inArray(community_post_reactions.post_id, postIds),
                    eq(community_post_reactions.user_uid, currentUserId),
                    eq(community_post_reactions.user_role, currentUserRole),
                    sql`${community_post_reactions.comment_id} IS NULL`
                )
            ),

        // 3. Get author info (both lenders and borrowers)
        getAuthorInfo(posts),

        // 4. Get reactor user info
        getReactionUserInfo(reactionUserIds),
    ]);

    // ==================== BUILD LOOKUP MAPS ====================
    const commentCountMap = new Map(commentCounts.map(c => [c.post_id, c.count]));
    const userReactionMap = new Map(userReactions.map(r => [r.post_id, r.reaction_type]));
    const authorInfoMap = authorInfos;
    const reactionUserMap = reactionUserInfos;

    // Group reactions by post
    const reactionsByPost = new Map<string, any[]>();
    const reactionCountsByPost = new Map<string, Record<string, number>>();

    allReactions.forEach((reaction) => {
        // Store all reactions
        if (!reactionsByPost.has(reaction.post_id)) {
            reactionsByPost.set(reaction.post_id, []);
        }
        reactionsByPost.get(reaction.post_id)!.push(reaction);

        // Count by type
        if (!reactionCountsByPost.has(reaction.post_id)) {
            reactionCountsByPost.set(reaction.post_id, {});
        }
        const counts = reactionCountsByPost.get(reaction.post_id)!;
        counts[reaction.reaction_type] = (counts[reaction.reaction_type] || 0) + 1;
    });

    // ==================== BUILD FINAL RESPONSE ====================
    return posts.map((post) => {
        const isOwnPost = post.author_id === currentUserId && post.author_role === currentUserRole;
        const authorInfo = authorInfoMap.get(post.author_id);
        const postReactions = reactionsByPost.get(post.id) || [];
        const reactionCounts = reactionCountsByPost.get(post.id) || {};
        const totalReactions = Object.values(reactionCounts).reduce((sum: number, count) => sum + count, 0);
        const userReaction = userReactionMap.get(post.id) || null;

        // Build reaction details with user info
        const reactionDetails = postReactions.map((reaction) => ({
            reaction_type: reaction.reaction_type,
            user_uid: reaction.user_uid,
            user_role: reaction.user_role,
            reacted_at: reaction.reacted_at,
            user: reactionUserMap.get(reaction.user_uid) || {
                uid: reaction.user_uid,
                name: "Anonymous",
                avatar: null,
            },
        }));

        return {
            // Post basic info
            id: post.id,
            author_id: post.author_id,
            author_name: post.author_name,
            author_role: post.author_role,
            author_avatar: post.author_avatar,
            content: post.content,
            images: post.images || [],
            is_for_sale: post.is_for_sale,
            created_at: post.created_at,
            updated_at: post.updated_at,

            // Legacy counts (for backward compatibility)
            heart_count: post.heart_count,
            likes: post.likes,

            // Flags
            is_own_post: isOwnPost,
            is_reported: post.is_reported,
            report_count: post.report_count,

            // Counts
            comment_count: commentCountMap.get(post.id) || 0,
            reaction_count: totalReactions,

            // Current user interaction
            user_has_reacted: !!userReaction,
            user_reaction_type: userReaction,

            // Author extended info
            author_info: authorInfo || null,

            // Reactions data
            reactions: {
                total: totalReactions,
                counts: reactionCounts, // { like: 10, love: 5, haha: 3 }
                user_reaction: userReaction, // 'like' | 'love' | null
                details: reactionDetails, // Array with full user info
            },
        };
    });
}

// ==================== HELPER: GET AUTHOR INFO ====================
async function getAuthorInfo(posts: any[]): Promise<Map<string, any>> {
    const lenderIds = posts.filter(p => p.author_role === 'lender').map(p => p.author_id);
    const borrowerIds = posts.filter(p => p.author_role === 'borrower').map(p => p.author_id);

    const [lenderInfos, borrowerInfos] = await Promise.all([
        lenderIds.length > 0
            ? db
                .select({
                    user_uid: user_business_info.user_uid,
                    business_name: user_business_info.business_name,
                    business_type: user_business_info.business_type,
                    business_profile_image: user_business_info.business_profile_image,
                })
                .from(user_business_info)
                .where(inArray(user_business_info.user_uid, lenderIds))
            : [],
        borrowerIds.length > 0
            ? db
                .select({
                    uid: users.uid,
                    full_name: users.full_name,
                    first_name: users.first_name,
                    last_name: users.last_name,
                    profile_image: users.profile_image,
                })
                .from(users)
                .where(inArray(users.uid, borrowerIds))
            : [],
    ]);

    const map = new Map<string, any>();

    lenderInfos.forEach((info) => {
        map.set(info.user_uid, {
            type: 'lender',
            business_name: info.business_name,
            business_type: info.business_type,
            business_profile_image: info.business_profile_image,
        });
    });

    borrowerInfos.forEach((info) => {
        map.set(info.uid, {
            type: 'borrower',
            full_name: info.full_name ||
                `${info.first_name || ''} ${info.last_name || ''}`.trim() ||
                'Unknown User',
            profile_image: info.profile_image,
        });
    });

    return map;
}

// ==================== HELPER: GET REACTION USER INFO ====================
async function getReactionUserInfo(userIds: string[]): Promise<Map<string, any>> {
    if (userIds.length === 0) return new Map();

    const userInfos = await db
        .select({
            uid: users.uid,
            full_name: users.full_name,
            first_name: users.first_name,
            last_name: users.last_name,
            profile_image: users.profile_image,
        })
        .from(users)
        .where(inArray(users.uid, userIds));

    return new Map(
        userInfos.map((user) => [
            user.uid,
            {
                uid: user.uid,
                name: user.full_name ||
                    `${user.first_name || ''} ${user.last_name || ''}`.trim() ||
                    'Anonymous',
                avatar: user.profile_image,
            },
        ])
    );
}


// Validation schema for the approve report request
const approveReportSchema = z.object({
    reportId: z.string().uuid(),
    postId: z.string().uuid(),
    postAuthorId: z.string().uuid(),
    postAuthorName: z.string(),
    reporterId: z.string().uuid(),
    reporterUsername: z.string(),
    reason: z.string(),
    postContent: z.string(),
    timestamp: z.string(),
    adminAction: z.literal('approved'),
    metadata: z.object({
        reportCreatedAt: z.string(),
        postCreatedAt: z.string(),
        currentStatus: z.string(),
    })
});

const approvedReportedPostRemovePost = async (c: Context) => {
    try {
        // Parse and validate request body
        const body = await c.req.json();
        const validatedData = approveReportSchema.parse(body);

        const {
            reportId,
            postId,
            postAuthorId,
            postAuthorName,
            reason,
            postContent,
        } = validatedData;

        // Start a transaction to ensure data consistency
        const result = await db.transaction(async (tx) => {
            // 1. Verify the post exists
            const [existingPost] = await tx
                .select()
                .from(community_posts)
                .where(eq(community_posts.id, postId))
                .limit(1);

            if (!existingPost) {
                throw new Error('Post not found');
            }

            // 2. Verify the report exists and is still pending/under_review
            const [existingReport] = await tx
                .select()
                .from(community_post_reports)
                .where(
                    and(
                        eq(community_post_reports.id, reportId),
                        eq(community_post_reports.post_id, postId)
                    )
                )
                .limit(1);

            if (!existingReport) {
                throw new Error('Report not found');
            }

            if (existingReport.status === 'resolved') {
                throw new Error('Report has already been resolved');
            }

            // 3. Get post author's email for notification
            const [postAuthor] = await tx
                .select({
                    email: users.email,
                    username: users.username,
                })
                .from(users)
                .where(eq(users.uid, postAuthorId))
                .limit(1);
            console.log("postAuthor", postAuthor)
            console.log("postAuthorId", postAuthorId)
            if (!postAuthor || !postAuthor.email) {
                throw new Error('Post author not found or email missing');
            }

            // 4. Update report status to 'resolved'
            const [updatedReport] = await tx
                .update(community_post_reports)
                .set({
                    status: 'resolved',
                    updated_at: new Date(),  // Changed from toISOString() to just new Date()
                })
                .where(eq(community_post_reports.id, reportId))
                .returning();

            // For hard delete:
            const [deletedPost] = await tx
                .delete(community_posts)
                .where(eq(community_posts.id, postId))
                .returning();

            return {
                updatedReport,
                deletedPost,
                postAuthorEmail: postAuthor.email,
                postAuthorUsername: postAuthor.username,
            };
        });

        // 6. Send email notification to post author (outside transaction)
        const emailSent = await sendPostRemovalEmail({
            recipientEmail: result.postAuthorEmail,
            recipientName: result.postAuthorUsername || postAuthorName,
            postContent: postContent,
            reportReason: reason,
            adminNotes: `Your post was reviewed and found to violate our community guidelines. The content has been removed from the platform.`
        });

        // 7. Log the action
        console.log('Post removed successfully:', {
            reportId,
            postId,
            postAuthorId,
            emailSent,
            timestamp: new Date().toISOString(),
        });

        return c.json({
            success: true,
            message: 'Post has been successfully removed and report resolved',
            data: {
                reportId: result.updatedReport?.id || '',
                reportStatus: result.updatedReport?.status || '',
                postId: result.deletedPost?.id || '',
                emailSent,
                removedAt: new Date().toISOString(),
            }
        }, 200);

    } catch (error) {
        console.error('Error approving reported post:', error);

        // Handle validation errors
        if (error instanceof z.ZodError) {
            return c.json({
                success: false,
                message: 'Invalid request data',
                errors: error.errors.map(err => ({
                    field: err.path.join('.'),
                    message: err.message
                }))
            }, 400);
        }

        // Handle specific error messages
        if (error instanceof Error) {
            const statusCode = error.message.includes('not found') ? 404 :
                error.message.includes('already been resolved') ? 409 : 500;

            return c.json({
                success: false,
                message: error.message,
            }, statusCode);
        }

        // Generic error response
        return c.json({
            success: false,
            message: 'Failed to process report approval',
            error: 'An unexpected error occurred'
        }, 500);
    }
}

// Schema for reaction validation
const ReactSchema = z.object({
    action: z.enum(['react', 'unreact']),
    user: z.object({
        uid: z.string().uuid(),
        role: z.enum(['borrower', 'lender']),
        name: z.string().optional(),
    }),
    postId: z.string().uuid().optional(),
    commentId: z.string().uuid().optional(),
    reactionType: z.enum(['like', 'love', 'haha', 'wow', 'sad', 'angry', 'heart']),
}).refine((data) => data.postId || data.commentId, {
    message: "Either postId or commentId must be provided",
});

interface ReactionResult {
    success: boolean;
    action: 'react' | 'unreact';
    reaction?: {
        id: string;
        reaction_type: string;
        reacted_at: Date;
    };
    previousReaction?: {
        reaction_type: string;
    };
    message: string;
}

/**
 * Universal reaction handler for both posts and comments
 */
const reactOnPost = async (c: Context) => {
    try {
        const body = await c.req.json();
        const parseResult = ReactSchema.safeParse(body);
        console.log("latest", body)
        if (!parseResult.success) {
            return c.json(
                {
                    success: false,
                    errors: parseResult.error.flatten(),
                    message: "Validation failed",
                },
                422
            );
        }

        const { action, user, postId, commentId, reactionType } = parseResult.data;

        // Determine target
        const isPost = !!postId;
        const targetId = (postId || commentId) as string;

        // Validate target exists and get author info
        const targetInfo = await validateTarget(targetId, isPost);

        if (!targetInfo.exists) {
            return c.json(
                {
                    success: false,
                    message: `${isPost ? 'Post' : 'Comment'} not found`,
                },
                404
            );
        }

        // Prevent self-reaction (same uid AND role)
        if (targetInfo.author_id === user.uid && targetInfo.author_role === user.role) {
            return c.json(
                {
                    success: false,
                    message: `You cannot react to your own ${isPost ? 'post' : 'comment'}`,
                    code: "SELF_REACT_NOT_ALLOWED",
                },
                400
            );
        }

        // Process reaction
        const result = await processReaction({
            action,
            userId: user.uid,
            userRole: user.role,
            postId: isPost ? targetId : targetInfo.post_id!,
            commentId: isPost ? null : targetId,
            reactionType,
        });

        return c.json(
            {
                success: true,
                data: {
                    targetType: isPost ? 'post' : 'comment',
                    targetId,
                    action: result.action,
                    reaction: result.reaction || null,
                    previousReaction: result.previousReaction || null,
                },
                message: result.message,
            },
            200
        );
    } catch (error: any) {
        console.error("Error processing reaction:", error);

        if (error instanceof Error) {
            if (error.message.includes("foreign key")) {
                return c.json(
                    { success: false, message: "Invalid reference" },
                    400
                );
            }
            if (error.message.includes("unique constraint")) {
                return c.json(
                    { success: false, message: "Duplicate reaction detected" },
                    409
                );
            }
        }

        return c.json(
            {
                success: false,
                message: "Failed to process reaction",
                error: process.env.NODE_ENV === "development" && error instanceof Error
                    ? error.message
                    : undefined,
            },
            500
        );
    }
};

/**
 * Validates target exists and returns author info
 */
async function validateTarget(
    targetId: string,
    isPost: boolean
): Promise<{
    exists: boolean;
    author_id?: string;
    author_role?: string;
    post_id?: string;
}> {
    if (isPost) {
        const [post] = await db
            .select({
                id: community_posts.id,
                author_id: community_posts.author_id,
                author_role: community_posts.author_role,
            })
            .from(community_posts)
            .where(eq(community_posts.id, targetId))
            .limit(1);

        return {
            exists: !!post,
            author_id: post?.author_id,
            author_role: post?.author_role,
        };
    } else {
        const [comment] = await db
            .select({
                id: community_comments.id,
                author_id: community_comments.author_id,
                author_role: community_comments.author_role,
                post_id: community_comments.post_id,
            })
            .from(community_comments)
            .where(eq(community_comments.id, targetId))
            .limit(1);

        return {
            exists: !!comment,
            author_id: comment?.author_id,
            author_role: comment?.author_role,
            post_id: comment?.post_id,
        };
    }
}

/**
 * Processes the reaction (add, update, or remove)
 */
async function processReaction(params: {
    action: 'react' | 'unreact';
    userId: string;
    userRole: string;
    postId: string;
    commentId: string | null;
    reactionType: string;
}): Promise<ReactionResult> {
    const { action, userId, userRole, postId, commentId, reactionType } = params;

    return await db.transaction(async (trx) => {
        // Build query to find existing reaction
        // IMPORTANT: Must match the unique constraint (post_id, comment_id, user_uid, user_role)
        const whereConditions = [
            eq(community_post_reactions.post_id, postId),
            eq(community_post_reactions.user_uid, userId),
            eq(community_post_reactions.user_role, userRole),
        ];

        // Add comment_id condition (null for posts, uuid for comments)
        if (commentId) {
            whereConditions.push(eq(community_post_reactions.comment_id, commentId));
        } else {
            whereConditions.push(sql`${community_post_reactions.comment_id} IS NULL`);
        }

        const [existingReaction] = await trx
            .select({
                id: community_post_reactions.id,
                reaction_type: community_post_reactions.reaction_type,
            })
            .from(community_post_reactions)
            .where(and(...whereConditions))
            .limit(1);

        if (action === 'unreact') {
            if (!existingReaction) {
                return {
                    success: true,
                    action: 'unreact',
                    message: "No reaction to remove",
                };
            }

            await trx
                .delete(community_post_reactions)
                .where(eq(community_post_reactions.id, existingReaction.id));

            return {
                success: true,
                action: 'unreact',
                message: "Reaction removed successfully",
            };
        }

        // action === 'react'
        if (existingReaction) {
            // Same reaction type - no change needed
            if (existingReaction.reaction_type === reactionType) {
                return {
                    success: true,
                    action: 'react',
                    message: "You already reacted with this type",
                    reaction: {
                        id: existingReaction.id,
                        reaction_type: existingReaction.reaction_type,
                        reacted_at: new Date(),
                    },
                };
            }

            // Update to new reaction type
            const [updatedReaction] = await trx
                .update(community_post_reactions)
                .set({
                    reaction_type: reactionType,
                    reacted_at: new Date(),
                })
                .where(eq(community_post_reactions.id, existingReaction.id))
                .returning({
                    id: community_post_reactions.id,
                    reaction_type: community_post_reactions.reaction_type,
                    reacted_at: community_post_reactions.reacted_at,
                });

            return {
                success: true,
                action: 'react',
                reaction: updatedReaction,
                previousReaction: existingReaction,
                message: "Reaction updated successfully",
            };
        }

        // Create new reaction
        const [newReaction] = await trx
            .insert(community_post_reactions)
            .values({
                post_id: postId,
                comment_id: commentId,
                user_uid: userId,
                user_role: userRole,
                reaction_type: reactionType,
                reacted_at: new Date(),
            })
            .returning({
                id: community_post_reactions.id,
                reaction_type: community_post_reactions.reaction_type,
                reacted_at: community_post_reactions.reacted_at,
            });

        return {
            success: true,
            action: 'react',
            reaction: newReaction,
            message: "Reaction added successfully",
        };
    });
}

/**
 * Sends notification to the content author
 */
/* async function sendReactionNotification(params: {
    targetType: any;
    targetId: string;
    targetAuthorId: string;
    targetAuthorRole: string;
    reactorId: string;
    reactorRole: string;
    reactorName: string;
    reactionType: string;
    wasUpdated: boolean;
}): Promise<void> {
    const {
        targetType,
        targetId,
        targetAuthorId,
        targetAuthorRole,
        reactorId,
        reactorRole,
        reactionType,
        reactorName,
        wasUpdated,
    } = params;

    const action = wasUpdated ? 'updated their reaction' : 'reacted';
    const emoji = getReactionEmoji(reactionType);

    await notificationService.create({
        recipientId: targetAuthorId,
        recipientRole: targetAuthorRole as 'borrower' | 'lender',
        senderId: reactorId,
        senderRole: reactorRole as 'borrower' | 'lender',
        senderType: "user",
        type: targetType === 'post' ? "COMMUNITY_POST" : "COMMUNITY_COMMENT" as any,
        title: `${reactorName} ${action} to your ${targetType}`,
        message: `${reactorName} reacted with ${emoji} ${reactionType} to your ${targetType}.`,
        postId: targetType === 'post' ? targetId : undefined,

        metadata: {
            action: wasUpdated ? 'update_reaction' : 'add_reaction',
            reactionType,
            reactorName,
            targetType,
        },
    });
}
 */
/**
 * Maps reaction type to emoji
 */
function getReactionEmoji(reactionType: string): string {
    const emojiMap: Record<string, string> = {
        like: '👍',
        love: '❤️',
        haha: '😂',
        wow: '😮',
        sad: '😢',
        angry: '😠',
        heart: '💖',
    };
    return emojiMap[reactionType] || '👍';
}

// Updated createPost function
const createPost = async (c: Context) => {
    try {
        // Parse and validate request body
        const body = await c.req.json();
        const parseResult = createCommunityPostSchema.safeParse(body);

        if (!parseResult.success) {
            return c.json(
                {
                    success: false,
                    errors: parseResult.error.flatten(),
                    message: "Validation failed",
                },
                422
            );
        }

        const data = parseResult.data;

        // Insert post
        const [newPost] = await db
            .insert(community_posts)
            .values({
                author_id: data.author.id,
                author_name: data.author.name,
                author_role: data.author.role,
                author_avatar: data.author.avatar,
                content: data.content,
                images: data.images,
                is_for_sale: data.isForSale || false,
            })
            .returning();

        console.log("newPost", data)

        // 🔔 Trigger notification using notificationService
        try {
            await notificationService.create({
                recipientId: data.author.id,
                recipientRole: data.author.role as any,  // Directly use the role from data
                senderId: data.author.id,
                senderRole: data.author.role as any,  // Directly use the role from data
                senderType: "user",
                type: "COMMUNITY_POST",
                title: "New Community Post",
                message: `${data.author.name} just posted in the community.`,
                postId: newPost?.id || "",  // Use the ID from the created post
                metadata: {
                    authorName: data.author.name,
                    contentPreview: data.content.substring(0, 100),
                    isForSale: data.isForSale,  // Use isForSale directly from data
                },
            });
        } catch (notificationError) {
            // Log error but don't fail the request
            console.error("Failed to create notification:", notificationError);
        }

        return c.json(
            {
                success: true,
                data: newPost,
                message: "Post created successfully",
            },
            201
        );
    } catch (error) {
        console.error("Error creating post:", error);
        return c.json(
            {
                success: false,
                error: "Failed to create post",
            },
            500
        );
    }
};


interface CommentPayload {
    post_id: string;
    parent_comment_id?: string;
    commenter: {
        user_id: string;
        username: string;
        user_avatar_url: string;
    };
    comment: {
        content: string;
        images?: string[];
    };
}

const commentOnPost = async (c: Context) => {
    try {
        const body = await c.req.json<CommentPayload>();

        // Basic validation - check required fields
        if (!body.post_id || !body.commenter?.user_id || !body.commenter?.username || !body.comment?.content) {
            return c.json(
                {
                    success: false,
                    message: "Missing required fields: post_id, commenter, or comment content",
                },
                400
            );
        }

        const { post_id, parent_comment_id, commenter, comment } = body;

        // Check if post exists
        const [post] = await db
            .select({ id: community_posts.id, author_id: community_posts.author_id })
            .from(community_posts)
            .where(eq(community_posts.id, post_id))
            .limit(1);

        if (!post) {
            return c.json(
                {
                    success: false,
                    message: "Post not found",
                },
                404
            );
        }

        // If replying to a comment, verify it exists and belongs to this post
        if (parent_comment_id) {
            const [parentComment] = await db
                .select({ id: community_comments.id, post_id: community_comments.post_id })
                .from(community_comments)
                .where(eq(community_comments.id, parent_comment_id))
                .limit(1);

            if (!parentComment || parentComment.post_id !== post_id) {
                return c.json(
                    {
                        success: false,
                        message: "Parent comment not found or does not belong to this post",
                    },
                    400
                );
            }
        }

        // Insert comment and get updated count in a transaction
        const result = await db.transaction(async (trx) => {
            const [newComment] = await trx
                .insert(community_comments)
                .values({
                    post_id,
                    parent_comment_id: parent_comment_id || null,
                    author_id: commenter.user_id,
                    author_name: commenter.username,
                    author_role: "",
                    author_avatar: commenter.user_avatar_url,
                    content: comment.content,
                    images: comment.images || [],
                })
                .returning();

            const countResult = await trx
                .select({ count: count() })
                .from(community_comments)
                .where(eq(community_comments.post_id, post_id));

            const commentCount = countResult[0]?.count ?? 0;

            return { newComment, commentCount };
        });

        // Send notification if commenter is not the post author
        if (post.author_id !== commenter.user_id) {
            notificationService.create({
                recipientId: post.author_id,
                recipientRole: "borrower",
                senderId: commenter.user_id,
                senderRole: "borrower",
                senderType: "user",
                type: "COMMUNITY_POST",
                title: "New comment on your post",
                message: `${commenter.username} commented: "${comment.content}"`,
                postId: post.id,
                metadata: {
                    commentId: result?.newComment?.id,
                    commentContent: comment.content,
                    commenterName: commenter.username,
                },
            }).catch((err) => {
                console.error("Failed to create notification:", err);
            });
        }

        return c.json(
            {
                success: true,
                data: {
                    comment: result.newComment,
                    commentCount: result.commentCount,
                },
                message: "Comment added successfully",
            },
            201
        );
    } catch (error) {
        console.error("Error commenting on post:", error);
        return c.json(
            {
                success: false,
                message: "Failed to add comment",
            },
            500
        );
    }
};

const deleteMyComment = async (c: Context) => {
    try {
        const comment_id = c.req.param('comment_id');

        console.log('Attempting to delete comment:', { comment_id });

        if (!comment_id) {
            console.error('Comment ID is required');
            return c.json(
                { success: false, message: "Comment ID is required" },
                400
            );
        }


        console.log('Deleting comment with ID:', comment_id);
        const result = await db
            .delete(community_comments)
            .where(
                and(
                    eq(community_comments.id, comment_id),

                )
            )
            .returning({ id: community_comments.id });

        if (result.length === 0) {
            console.error('Comment not found or not owned by user:', { comment_id, });
            return c.json(
                {
                    success: false,
                    message: "Comment not found or you don't have permission to delete it"
                },
                404
            );
        }

        console.log('Successfully deleted comment:', result[0]?.id);
        return c.json({
            success: true,
            message: "Comment deleted successfully",
            data: { deleted_comment_id: result[0]?.id }
        });

    } catch (error: any) {
        console.error("Error in deleteMyComment:", {
            error: error.message,
            stack: error.stack,
            timestamp: new Date().toISOString()
        });
        return c.json(
            {
                success: false,
                message: "Failed to delete comment",
                error: process.env.NODE_ENV === 'development' ? error.message : undefined
            },
            500
        );
    }
};

// Updated deletePostById function
const deletePostById = async (c: Context) => {
    try {
        const post_id = c.req.param("post_id");
        if (!post_id) {
            return c.json(
                {
                    success: false,
                    message: "Post ID is required",
                },
                400
            );
        }

        // Delete related comments first
        await db.delete(community_comments).where(eq(community_comments.post_id, post_id));

        // Delete the post
        const [deletedPost] = await db
            .delete(community_posts)
            .where(eq(community_posts.id, post_id))
            .returning();

        if (!deletedPost) {
            return c.json(
                {
                    success: false,
                    message: "Post not found",
                },
                404
            );
        }

        // 🔔 Create notification using notificationService (notify the post author)
        try {
            await notificationService.create({
                recipientId: deletedPost.author_id,
                recipientRole: "borrower",
                senderId: null,
                senderRole: "borrower",
                senderType: "system",
                type: "COMMUNITY_POST",
                title: "Your post was deleted",
                message: `Your post has been removed from the community.`,
                postId: deletedPost.id,
                metadata: {
                    reason: "Post deleted by moderator",
                    deletedAt: new Date().toISOString(),
                },
            });
        } catch (notificationError) {
            console.error("Failed to create notification:", notificationError);
        }

        return c.json({
            success: true,
            message: "Post deleted successfully",
            data: { id: deletedPost.id },
        });
    } catch (error) {
        console.error("Error deleting post:", error);
        return c.json(
            {
                success: false,
                message: "Failed to delete post",
                error: error instanceof Error ? error.message : "Unknown error",
            },
            500
        );
    }
};


// Update a community post
const updateMyPost = async (c: Context) => {
    try {
        // 1. Get post_id and user_id from query params
        const postId = c.req.param("post_id");

        if (!postId) {
            return c.json(
                { success: false, message: "Post ID is required" },
                400
            );
        }

        // 2. Parse request body
        const body = await c.req.json();
        const { content, images, is_for_sale } = body;

        // 3. Verify post exists and belongs to the user
        const [existingPost] = await db
            .select()
            .from(community_posts)
            .where(
                and(
                    eq(community_posts.id, postId),
                )
            )
            .limit(1);

        if (!existingPost) {
            return c.json(
                {
                    success: false,
                    message: "Post not found or you do not have permission to update it",
                },
                404
            );
        }

        // 4. Build update object
        const updateData: Partial<typeof community_posts.$inferInsert> = {
            updated_at: new Date(),
        };

        if (typeof content === "string") updateData.content = content;
        if (Array.isArray(images)) updateData.images = images;
        if (typeof is_for_sale === "boolean") updateData.is_for_sale = is_for_sale;

        // 5. Update post
        const [updatedPost] = await db
            .update(community_posts)
            .set(updateData)
            .where(
                and(
                    eq(community_posts.id, postId),
                )
            )
            .returning();

        return c.json({
            success: true,
            message: "Post updated successfully",
            data: updatedPost,
        });
    } catch (error) {
        console.error("Error updating post:", error);
        return c.json(
            {
                success: false,
                message: "Failed to update post",
                error: error instanceof Error ? error.message : "Unknown error",
            },
            500
        );
    }
};


const getCommentsOnThePost = async (c: Context) => {
    try {
        // Accept params from query or body
        let post_id = c.req.param('post_id');
        let limit = parseInt(c.req.query('limit') || '20', 10);
        let cursor = c.req.query('cursor');

        if (!post_id) {
            const body = await c.req.json().catch(() => undefined);
            post_id = body?.post_id;
            limit = body?.limit ? parseInt(body.limit, 10) : limit;
            cursor = body?.cursor;
        }

        // Validate post_id
        const idSchema = z.string().uuid({ message: 'Invalid post_id format' });
        const parseResult = idSchema.safeParse(post_id);
        if (!post_id) {
            return c.json({
                success: false,
                errors: { post_id: ['post_id is required'] },
                message: 'post_id is required'
            }, 422);
        }
        if (!parseResult.success) {
            return c.json({
                success: false,
                errors: parseResult.error.flatten(),
                message: 'Invalid post_id'
            }, 422);
        }

        // Validate limit
        if (isNaN(limit) || limit < 1 || limit > 100) limit = 20;

        // Build reply count subquery (Facebook-like: "View X replies")
        const replyCountSubquery = db
            .select({
                parent_comment_id: community_comments.parent_comment_id,
                reply_count: count(community_comments.id).as('reply_count')
            })
            .from(community_comments)
            .where(eq(community_comments.post_id, post_id as string))
            .groupBy(community_comments.parent_comment_id)
            .as('reply_counts');

        // Build where conditions - ONLY top-level comments (parent_comment_id is null)
        let whereConditions = [
            eq(community_comments.post_id, post_id as string),
            isNull(community_comments.parent_comment_id) // Only top-level comments
        ];

        // Cursor-based pagination
        if (cursor) {
            let cursorObj;
            try {
                cursorObj = typeof cursor === 'string' ? JSON.parse(cursor) : cursor;
            } catch {
                return c.json({
                    success: false,
                    message: 'Invalid cursor format. Must be JSON with created_at and id.'
                }, 422);
            }
            if (
                cursorObj &&
                typeof cursorObj.created_at !== 'undefined' &&
                typeof cursorObj.id !== 'undefined' &&
                cursorObj.created_at !== null &&
                cursorObj.id !== null
            ) {
                const createdAt = cursorObj.created_at || '1970-01-01T00:00:00.000Z';
                const id = cursorObj.id || '';
                whereConditions.push(
                    or(
                        gt(community_comments.created_at, createdAt) as SQL<unknown>,
                        and(
                            eq(community_comments.created_at, createdAt) as SQL<unknown>,
                            gt(community_comments.id, id) as SQL<unknown>
                        ) as SQL<unknown>
                    ) as SQL<unknown>
                );
            }
        }

        // Build query with reply count join
        whereConditions = whereConditions.filter(Boolean);
        const whereClause = and(...whereConditions);

        const comments = await db
            .select({
                id: community_comments.id,
                post_id: community_comments.post_id,
                parent_comment_id: community_comments.parent_comment_id,
                author_id: community_comments.author_id,
                author_name: community_comments.author_name,
                author_role: community_comments.author_role,
                author_avatar: community_comments.author_avatar,
                content: community_comments.content,
                images: community_comments.images,
                created_at: community_comments.created_at,
                updated_at: community_comments.updated_at,
                reply_count: sql<number>`COALESCE(${replyCountSubquery.reply_count}, 0)`
            })
            .from(community_comments)
            .leftJoin(
                replyCountSubquery,
                eq(community_comments.id, replyCountSubquery.parent_comment_id)
            )
            .where(whereClause)
            .orderBy(community_comments.created_at, community_comments.id)
            .limit(limit + 1);

        // Prepare pagination
        let nextCursor = null;
        let hasMore = false;
        let result = comments;
        if (comments.length > limit) {
            hasMore = true;
            const last = comments[limit - 1];
            if (last) {
                nextCursor = JSON.stringify({ created_at: last.created_at, id: last.id });
            }
            result = comments.slice(0, limit);
        }

        return c.json({
            success: true,
            data: result,
            nextCursor,
            hasMore,
            message: 'Top-level comments with reply counts fetched successfully'
        }, 200);
    } catch (error) {
        console.error('Error fetching comments:', error);
        return c.json({
            success: false,
            error: 'Failed to fetch comments'
        }, 500);
    }
};


// Report a post
const reportPost = async (c: Context) => {
    try {
        // 1. Validate request
        const body = await c.req.json();
        const schema = z.object({
            post_id: z.string().uuid('Post ID must be a valid UUID'),
            user_id: z.string().uuid('User ID must be a valid UUID'),
            reason: z.string().min(1, 'Reason is required').max(255, 'Reason must be less than 255 characters'),
            details: z.string().optional(),
        });

        const validation = schema.safeParse(body);
        if (!validation.success) {
            return c.json(
                { success: false, message: 'Validation failed', errors: validation.error.errors },
                400
            );
        }

        const { post_id, user_id, reason, details } = validation.data;

        // 2. Check if post exists
        const [post] = await db
            .select({
                id: community_posts.id,
                report_count: community_posts.report_count
            })
            .from(community_posts)
            .where(eq(community_posts.id, post_id))
            .limit(1);

        if (!post) {
            return c.json({ success: false, message: 'Post not found' }, 404);
        }

        // 3. Check if user exists
        const [user] = await db
            .select({
                uid: users.uid,
                username: users.username,
                email: users.email
            })
            .from(users)
            .where(eq(users.uid, user_id))
            .limit(1);

        if (!user) {
            return c.json({ success: false, message: 'User not found' }, 404);
        }

        // 4. Check for existing report (user can only report once per post)
        const [existingReport] = await db
            .select()
            .from(community_post_reports)
            .where(
                and(
                    eq(community_post_reports.post_id, post_id),
                    eq(community_post_reports.reporter_id, user_id)
                )
            )
            .limit(1);

        if (existingReport) {
            return c.json(
                {
                    success: false,
                    message: 'You have already reported this post',
                    report_id: existingReport.id
                },
                400
            );
        }

        // 5. Create report and update post report count in a transaction
        const result = await db.transaction(async (tx) => {
            // Insert new report
            const [newReport] = await tx
                .insert(community_post_reports)
                .values({
                    post_id,
                    reporter_id: user_id,
                    reason,
                    details: details || null,
                    status: 'pending',
                })
                .returning();

            // Update post report count and is_reported flag
            const [updatedPost] = await tx
                .update(community_posts)
                .set({
                    report_count: sql`${community_posts.report_count} + 1`,
                    is_reported: true,
                    updated_at: new Date(),
                })
                .where(eq(community_posts.id, post_id))
                .returning({
                    id: community_posts.id,
                    report_count: community_posts.report_count,
                });

            return { newReport, updatedPost };
        });

        return c.json({
            success: true,
            message: 'Post reported successfully',
            data: {
                report_id: result.newReport?.id,
                post_id: result.updatedPost?.id,
                total_reports: result.updatedPost?.report_count,
                reporter: {
                    username: user.username,
                    email: user.email,
                }
            }
        }, 201);

    } catch (error: any) {
        console.error('Error reporting post:', error);
        return c.json(
            {
                success: false,
                message: 'Failed to report post',
                error: error.message
            },
            500
        );
    }
};

// Get all reported posts with aggregated data
const getAllReportPosts = async (c: Context) => {
    try {
        // Get pagination and filter parameters
        const page = parseInt(c.req.query('page') || '1');
        const limit = parseInt(c.req.query('limit') || '10');
        const status = c.req.query('status') || 'all'; // pending, reviewed, resolved, dismissed, all
        const offset = (page - 1) * limit;

        // Build where clause for status filter
        const statusFilter = status !== 'all'
            ? eq(community_post_reports.status, status)
            : undefined;

        // Get total count of reports
        const [totalCount] = await db
            .select({ count: sql<number>`COUNT(*)` })
            .from(community_post_reports)
            .where(statusFilter);

        // Get paginated reports with post and reporter details
        const reports = await db
            .select({
                report: {
                    id: community_post_reports.id,
                    reason: community_post_reports.reason,
                    details: community_post_reports.details,
                    status: community_post_reports.status,
                    created_at: community_post_reports.created_at,
                    updated_at: community_post_reports.updated_at,
                },
                post: {
                    id: community_posts.id,
                    content: community_posts.content,
                    author_name: community_posts.author_name,
                    author_id: community_posts.author_id,
                    created_at: community_posts.created_at,
                },
                reporter: {
                    uid: users.uid,
                    username: users.username,
                    email: users.email,
                }
            })
            .from(community_post_reports)
            .leftJoin(
                community_posts,
                eq(community_post_reports.post_id, community_posts.id)
            )
            .leftJoin(
                users,
                eq(community_post_reports.reporter_id, users.uid)
            )
            .where(statusFilter)
            .orderBy(desc(community_post_reports.created_at))
            .limit(limit)
            .offset(offset);

        return c.json({
            success: true,
            data: {
                reports,
                pagination: {
                    total: Number(totalCount?.count) || 0,
                    page,
                    limit,
                    totalPages: Math.ceil((totalCount?.count || 0) / limit),
                },
                filters: {
                    status
                }
            },
            message: 'Reported posts fetched successfully'
        }, 200);

    } catch (error: any) {
        console.error('Error fetching reported posts:', error);
        return c.json({
            success: false,
            message: 'Failed to fetch reported posts',
            error: error.message
        }, 500);
    }
};




// Get current user's posts filtered by user_id (author_id) and user_role with cursor pagination
const getMyPosts = async (c: Context) => {
    try {
        const user_id = c.req.query('user_id');
        const user_role = c.req.query('user_role') as 'borrower' | 'lender' | undefined; // required; must match author_role
        const limitParam = c.req.query('limit');
        const cursor = c.req.query('cursor'); // base64-encoded JSON: { created_at: string, id: string }

        if (!user_id || !user_role || !['borrower', 'lender'].includes(user_role)) {
            return c.json({ success: false, message: 'Valid user_id and user_role are required' }, 400);
        }

        const limit = Math.min(50, Math.max(1, parseInt(limitParam || '10', 10)));

        // Build WHERE conditions (must match both author_id and author_role)
        const conditions: SQL<unknown>[] = [
            eq(community_posts.author_id, user_id),
            eq(community_posts.author_role, user_role),
        ];

        // Cursor condition: (created_at, id) < (cursorCreatedAt, cursorId)
        let cursorCreatedAt: Date | null = null;
        let cursorId: string | null = null;
        if (cursor) {
            try {
                const decoded = JSON.parse(Buffer.from(cursor, 'base64').toString('utf8')) as { created_at: string; id: string };
                cursorCreatedAt = new Date(decoded.created_at);
                cursorId = decoded.id;
                conditions.push(
                    sql`(${community_posts.created_at}, ${community_posts.id}) < (${cursorCreatedAt!.toISOString()}, ${cursorId!})`
                );
            } catch {
                // Ignore bad cursor; proceed without it
            }
        }

        const whereClause = and(...conditions)!;

        // Order newest first with stable tie-breaker by id
        const rows = await db
            .select({
                id: community_posts.id,
                author_id: community_posts.author_id,
                author_name: community_posts.author_name,
                author_role: community_posts.author_role,
                author_avatar: community_posts.author_avatar,
                content: community_posts.content,
                images: community_posts.images,
                is_for_sale: community_posts.is_for_sale,
                heart_count: community_posts.heart_count,
                likes: community_posts.likes,
                report_count: community_posts.report_count,
                is_reported: community_posts.is_reported,
                created_at: community_posts.created_at,
                updated_at: community_posts.updated_at,
            })
            .from(community_posts)
            .where(whereClause)
            .orderBy(desc(community_posts.created_at), desc(community_posts.id))
            .limit(limit + 1);

        const hasNextPage = rows.length > limit;
        const data = hasNextPage ? rows.slice(0, limit) : rows;

        const nextCursor = hasNextPage
            ? Buffer.from(
                JSON.stringify({
                    created_at: (data[data.length - 1]!.created_at as Date).toISOString?.() || data[data.length - 1]!.created_at,
                    id: data[data.length - 1]!.id,
                })
            ).toString('base64')
            : null;

        return c.json({
            success: true,
            data,
            pageInfo: {
                hasNextPage,
                nextCursor,
                limit,
            },
            filters: {
                user_id,
                user_role,
            }
        });
    } catch (error: any) {
        return c.json({ success: false, message: 'Failed to fetch posts', error: error.message }, 500);
    }
}


export default { createPost, getAllPosts, commentOnPost, getCommentsOnThePost, deletePostById, updateMyPost, reportPost, getAllReportPosts, approvedReportedPostRemovePost, deleteMyComment, reactOnPost, getMyPosts };
