import { eq, sql } from "drizzle-orm"
import type { Context } from "hono"
import db from "../db/supabase/db_connect"
import { categories } from "../schema/categories"

/**
 * Get all active categories with pagination
 * @param c - Hono Context
 * @returns JSON response with categories and pagination
 */
const getAllCategories = async (c: Context) => {
    try {
        // Get pagination parameters
        const page = Math.max(1, parseInt(c.req.query('page') || '1'))
        const limit = Math.min(100, Math.max(1, parseInt(c.req.query('limit') || '10')))
        const offset = (page - 1) * limit

        // Get total count
        const totalResult = await db
            .select({ count: sql<number>`count(*)` })
            .from(categories)
            .where(eq(categories.status, 'active'))

        const total = totalResult[0]?.count || 0

        // Get paginated categories
        const categoriesData = await db
            .select()
            .from(categories)
            .where(eq(categories.status, 'active'))
            .orderBy(categories.createdAt)
            .limit(limit)
            .offset(offset)

        const totalPages = Math.ceil(total / limit)

        return c.json({
            success: true,
            data: {
                categories: categoriesData,
                pagination: {
                    total,
                    page,
                    limit,
                    totalPages,
                    hasNextPage: page < totalPages,
                    hasPrevPage: page > 1
                }
            }
        })

    } catch (error) {
        console.error('[getAllCategories] Error fetching categories:', error)
        return c.json({
            success: false,
            message: 'Failed to fetch categories',
            error: error instanceof Error ? error.message : 'Unknown error'
        }, 500)
    }
}

/**
 * Get a single category by ID
 * @param c - Hono Context
 * @returns JSON response with category data
 */
const getCategoryById = async (c: Context) => {
    try {
        const categoryId = c.req.param('id')

        if (!categoryId) {
            return c.json({
                success: false,
                message: 'Category ID is required'
            }, 400)
        }

        const [category] = await db
            .select()
            .from(categories)
            .where(eq(categories.id, categoryId))
            .limit(1)

        if (!category) {
            return c.json({
                success: false,
                message: 'Category not found'
            }, 404)
        }

        return c.json({
            success: true,
            data: category
        })

    } catch (error) {
        console.error('[getCategoryById] Error fetching category:', error)
        return c.json({
            success: false,
            message: 'Failed to fetch category',
            error: error instanceof Error ? error.message : 'Unknown error'
        }, 500)
    }
}

/**
 * Get a single category by slug
 * @param c - Hono Context
 * @returns JSON response with category data
 */
const getCategoryBySlug = async (c: Context) => {
    try {
        const slug = c.req.param('slug')

        if (!slug) {
            return c.json({
                success: false,
                message: 'Category slug is required'
            }, 400)
        }

        const [category] = await db
            .select()
            .from(categories)
            .where(eq(categories.slug, slug))
            .limit(1)

        if (!category) {
            return c.json({
                success: false,
                message: 'Category not found'
            }, 404)
        }

        return c.json({
            success: true,
            data: category
        })

    } catch (error) {
        console.error('[getCategoryBySlug] Error fetching category:', error)
        return c.json({
            success: false,
            message: 'Failed to fetch category',
            error: error instanceof Error ? error.message : 'Unknown error'
        }, 500)
    }
}

export default {
    getAllCategories,
    getCategoryById,
    getCategoryBySlug
}