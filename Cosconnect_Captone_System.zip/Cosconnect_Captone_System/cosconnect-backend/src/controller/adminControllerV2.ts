import { and, count, desc, eq, gte, inArray, lte, sql } from "drizzle-orm"
import type { Context } from "hono"
import nodemailer from 'nodemailer'
import { z } from "zod"
import db from "../db/supabase/db_connect"
import { admin } from "../schema/admin"
import { user_business_info, users, type UserStatus } from "../schema/users"
import { community_post_reports } from "@/schema/community"
import { rentalPaymentHistory, rentals } from "@/db-schema"
import { user_documents } from '../schema/users'
import { sendLenderVerificationEmail } from "../services/rentalEmailService"
import { notificationService, notificationTemplates } from "./notificationController"


// Zod schema for validation
const UpdateAdminSchema = z.object({
    id: z.string().uuid(),
    full_name: z.string().min(1, "Full name is required"),
    username: z.string().min(1, "Username is required"),
    email: z.string().email("Invalid email format"),
    phone_number: z.string().optional().nullable(),
    profile_image: z.string().url().optional().nullable(),
});

const updateAdminInfo = async (c: Context) => {
    try {
        const body = await c.req.json();
        const parsed = UpdateAdminSchema.parse(body);

        const { id, full_name, username, email, phone_number, profile_image } = parsed;

        // Update the admin info in DB
        const [updatedAdmin] = await db
            .update(admin)
            .set({
                full_name,
                username,
                email,
                phone_number,
                profile_image,
                updated_at: new Date(),
            })
            .where(eq(admin.id, id))
            .returning();

        if (!updatedAdmin) {
            return c.json({ message: "Admin not found or update failed." }, 404);
        }

        return c.json({
            message: "Admin information updated successfully.",
            data: updatedAdmin,
        });
    } catch (error) {
        console.error("Error updating admin info:", error);

        if (error instanceof z.ZodError) {
            return c.json({ message: "Validation failed.", errors: error.errors }, 400);
        }

        return c.json({ message: "Internal server error." }, 500);
    }
};

/**
 * Verify a specific user document (VALID_ID or SELFIE_WITH_ID)
 * @param c - Hono Context
 */
const verifyUserDocument = async (c: Context) => {
    try {
        const userId = c.req.param("userId");
        const documentType = c.req.param("documentType");
        const adminId = c.get('userId'); // Get admin ID from auth middleware

        // Validate userId format
        const userIdValidation = idSchema.safeParse(userId);
        if (!userIdValidation.success) {
            return c.json(
                {
                    message: "Invalid user ID format. Must be a valid UUID.",
                    status: "fail",
                    statusCode: 400,
                    data: null,
                },
                400,
            );
        }

        // Validate document type
        const validDocumentTypes = ["VALID_ID", "SELFIE_WITH_ID"];
        if (!validDocumentTypes.includes(documentType)) {
            return c.json(
                {
                    message: "Invalid document type. Must be VALID_ID or SELFIE_WITH_ID.",
                    status: "fail",
                    statusCode: 400,
                    data: null,
                },
                400,
            );
        }

        // Check if user exists
        const [existingUser] = await db
            .select({ uid: users.uid, username: users.username })
            .from(users)
            .where(eq(users.uid, userId))
            .limit(1);

        if (!existingUser) {
            return c.json(
                {
                    message: "User not found",
                    status: "fail",
                    statusCode: 404,
                    data: null,
                },
                404,
            );
        }

        // Check if document exists
        const [existingDocument] = await db
            .select()
            .from(user_documents)
            .where(
                and(
                    eq(user_documents.user_uid, userId),
                    eq(user_documents.document_type, documentType as any)
                )
            )
            .limit(1);

        if (!existingDocument) {
            return c.json(
                {
                    message: `Document of type ${documentType} not found for this user`,
                    status: "fail",
                    statusCode: 404,
                    data: null,
                },
                404,
            );
        }

        // Check if document is already verified
        if (existingDocument.is_verified) {
            return c.json(
                {
                    message: `Document ${documentType} is already verified`,
                    status: "success",
                    statusCode: 200,
                    data: existingDocument,
                },
                200,
            );
        }

        const now = new Date();

        // Update document verification status
        const [updatedDocument] = await db
            .update(user_documents)
            .set({
                has_valid_id: true,
                is_verified: true,
                verified_at: now,
                verified_by: adminId,
                updated_at: now,
            })
            .where(eq(user_documents.id, existingDocument.id))
            .returning();

        if (!updatedDocument) {
            return c.json(
                {
                    message: "Failed to update document verification status",
                    status: "error",
                    statusCode: 500,
                    data: null,
                },
                500,
            );
        }

        console.log(`[verifyUserDocument] Document verification completed:`, {
            userId,
            documentType,
            documentId: updatedDocument.id,
            verifiedBy: adminId,
            timestamp: now.toISOString(),
        });

        return c.json(
            {
                message: `Document ${documentType} verified successfully`,
                status: "success",
                statusCode: 200,
                data: {
                    document: updatedDocument,
                    verifiedBy: adminId,
                    verifiedAt: now.toISOString(),
                },
            },
            200,
        );
    } catch (error) {
        console.error(`[verifyUserDocument] Error verifying document:`, error);

        return c.json(
            {
                message: "Internal server error occurred while verifying document",
                status: "error",
                statusCode: 500,
                data: null,
            },
            500,
        );
    }
};

/**
 * Get comprehensive admin dashboard analytics
 * @param c - Hono Context
 * @returns JSON response with analytics data
 */
const getAnalyticsData = async (c: Context): Promise<any> => {
    try {

        // Total users count
        const totalUsersResult = await db
            .select({ count: count() })
            .from(users);
        const totalUsers = totalUsersResult[0]?.count || 0;

        // Total borrowers (users with 'borrower' role)
        const totalBorrowersResult = await db
            .select({ count: count() })
            .from(users)
            .where(sql`'borrower' = ANY(${users.role})`);
        const totalBorrowers = totalBorrowersResult[0]?.count || 0;

        // Total lenders (users with 'lender' role)
        const totalLendersResult = await db
            .select({ count: count() })
            .from(users)
            .where(sql`'lender' = ANY(${users.role})`);
        const totalLenders = totalLendersResult[0]?.count || 0;

        // Active users (status = 'active')
        const activeUsersResult = await db
            .select({ count: count() })
            .from(users)
            .where(eq(users.status, 'active'));
        const activeUsers = activeUsersResult[0]?.count || 0;

        // Pending verification lenders
        const pendingLendersResult = await db
            .select({ count: count() })
            .from(users)
            .where(eq(users.status, 'pending_verification'));
        const pendingLenders = pendingLendersResult[0]?.count || 0;

        // Verified lenders
        const verifiedLendersResult = await db
            .select({ count: count() })
            .from(users)
            .where(eq(users.status, 'verified'));
        const verifiedLenders = verifiedLendersResult[0]?.count || 0;

        // =================================================================
        // 💰 REVENUE ANALYTICS
        // =================================================================

        // Total revenue (sum of all paid payments)
        const totalRevenueResult = await db
            .select({
                total: sql<string>`COALESCE(SUM(CAST(${rentalPaymentHistory.amount} AS NUMERIC)), 0)`
            })
            .from(rentalPaymentHistory)
            .where(eq(rentalPaymentHistory.status, 'paid'));
        const totalRevenue = parseFloat(totalRevenueResult[0]?.total || '0');

        // Monthly revenue (grouped by month and year) - platform revenue from rentals
        const monthlyRevenueResult = await db
            .select({
                year: sql<number>`EXTRACT(YEAR FROM ${rentals.created_at})`,
                month: sql<number>`EXTRACT(MONTH FROM ${rentals.created_at})`,
                revenue: sql<string>`COALESCE(SUM(CAST(${rentals.revenue_sum} AS NUMERIC)), 0)`,
                transaction_count: count()
            })
            .from(rentals)
            .groupBy(
                sql`EXTRACT(YEAR FROM ${rentals.created_at})`,
                sql`EXTRACT(MONTH FROM ${rentals.created_at})`
            )
            .orderBy(
                desc(sql`EXTRACT(YEAR FROM ${rentals.created_at})`),
                desc(sql`EXTRACT(MONTH FROM ${rentals.created_at})`)
            )
            .limit(12);

        const monthlyRevenue = monthlyRevenueResult.map((row: any) => ({
            year: row.year,
            month: row.month,
            revenue: parseFloat(row.revenue || '0'),
            transaction_count: row.transaction_count
        }));

        // Revenue by payment type
        const revenueByTypeResult = await db
            .select({
                payment_type: rentalPaymentHistory.payment_type,
                total: sql<string>`COALESCE(SUM(CAST(${rentalPaymentHistory.amount} AS NUMERIC)), 0)`,
                count: count()
            })
            .from(rentalPaymentHistory)
            .where(eq(rentalPaymentHistory.status, 'paid'))
            .groupBy(rentalPaymentHistory.payment_type);

        const revenueByType = revenueByTypeResult.map((row: any) => ({
            payment_type: row.payment_type,
            total: parseFloat(row.total || '0'),
            count: row.count
        }));

        // =================================================================
        // 📦 RENTAL ANALYTICS
        // =================================================================

        // Total rentals count
        const totalRentalsResult = await db
            .select({ count: count() })
            .from(rentals);
        const totalRentals = totalRentalsResult[0]?.count || 0;

        // Rentals by status
        const rentalsByStatusResult = await db
            .select({
                status: rentals.status,
                count: count()
            })
            .from(rentals)
            .groupBy(rentals.status);

        const rentalsByStatus = rentalsByStatusResult.reduce((acc: any, row: any) => {
            acc[row.status] = row.count;
            return acc;
        }, {});

        // Monthly rentals (grouped by month and year)
        const monthlyRentalsResult = await db
            .select({
                year: sql<number>`EXTRACT(YEAR FROM ${rentals.created_at})`,
                month: sql<number>`EXTRACT(MONTH FROM ${rentals.created_at})`,
                count: count()
            })
            .from(rentals)
            .groupBy(
                sql`EXTRACT(YEAR FROM ${rentals.created_at})`,
                sql`EXTRACT(MONTH FROM ${rentals.created_at})`
            )
            .orderBy(
                desc(sql`EXTRACT(YEAR FROM ${rentals.created_at})`),
                desc(sql`EXTRACT(MONTH FROM ${rentals.created_at})`)
            )
            .limit(12);

        const monthlyRentals = monthlyRentalsResult.map((row: any) => ({
            year: row.year,
            month: row.month,
            count: row.count
        }));

        // Active rentals (not completed, cancelled, or rejected)
        const activeRentalsResult = await db
            .select({ count: count() })
            .from(rentals)
            .where(sql`${rentals.status} NOT IN ('completed', 'cancelled', 'rejected')`);
        const activeRentals = activeRentalsResult[0]?.count || 0;

        // Completed rentals
        const completedRentalsResult = await db
            .select({ count: count() })
            .from(rentals)
            .where(eq(rentals.status, 'completed'));
        const completedRentals = completedRentalsResult[0]?.count || 0;

        // Overdue rentals
        const overdueRentalsResult = await db
            .select({ count: count() })
            .from(rentals)
            .where(eq(rentals.status, 'overdue'));
        const overdueRentals = overdueRentalsResult[0]?.count || 0;

        // Average rental duration (in days)
        const avgDurationResult = await db
            .select({
                avg_days: sql<number>`AVG(EXTRACT(DAY FROM (${rentals.end_date} - ${rentals.start_date})))`
            })
            .from(rentals)
            .where(sql`${rentals.status} IN ('completed', 'delivered', 'returned')`);
        const avgRentalDuration = Math.round(avgDurationResult[0]?.avg_days || 0);

        // =================================================================
        // 💳 PAYMENT ANALYTICS
        // =================================================================

        // Total payments count
        const totalPaymentsResult = await db
            .select({ count: count() })
            .from(rentalPaymentHistory);
        const totalPayments = totalPaymentsResult[0]?.count || 0;

        // Payments by status
        const paymentsByStatusResult = await db
            .select({
                status: rentalPaymentHistory.status,
                count: count()
            })
            .from(rentalPaymentHistory)
            .groupBy(rentalPaymentHistory.status);

        const paymentsByStatus = paymentsByStatusResult.reduce((acc: any, row: any) => {
            acc[row.status] = row.count;
            return acc;
        }, {});

        // Pending payments total amount
        const pendingPaymentsResult = await db
            .select({
                total: sql<string>`COALESCE(SUM(CAST(${rentalPaymentHistory.amount} AS NUMERIC)), 0)`,
                count: count()
            })
            .from(rentalPaymentHistory)
            .where(eq(rentalPaymentHistory.status, 'pending'));
        const pendingPaymentsAmount = parseFloat(pendingPaymentsResult[0]?.total || '0');
        const pendingPaymentsCount = pendingPaymentsResult[0]?.count || 0;

        // Failed payments
        const failedPaymentsResult = await db
            .select({ count: count() })
            .from(rentalPaymentHistory)
            .where(eq(rentalPaymentHistory.status, 'failed'));
        const failedPayments = failedPaymentsResult[0]?.count || 0;

        // =================================================================
        // 📊 AGGREGATE STATISTICS
        // =================================================================

        // Average order value (AOV)
        const averageOrderValue = totalRentals > 0 ? totalRevenue / totalRentals : 0;

        // Revenue per active user
        const revenuePerUser = activeUsers > 0 ? totalRevenue / activeUsers : 0;

        // Current month statistics
        const currentDate = new Date();
        const currentYear = currentDate.getFullYear();
        const currentMonth = currentDate.getMonth() + 1;

        const currentMonthRevenueResult = await db
            .select({
                total: sql<string>`COALESCE(SUM(CAST(${rentalPaymentHistory.amount} AS NUMERIC)), 0)`
            })
            .from(rentalPaymentHistory)
            .where(
                and(
                    eq(rentalPaymentHistory.status, 'paid'),
                    sql`EXTRACT(YEAR FROM ${rentalPaymentHistory.processed_at}) = ${currentYear}`,
                    sql`EXTRACT(MONTH FROM ${rentalPaymentHistory.processed_at}) = ${currentMonth}`
                )
            );
        const currentMonthRevenue = parseFloat(currentMonthRevenueResult[0]?.total || '0');

        const currentMonthRentalsResult = await db
            .select({ count: count() })
            .from(rentals)
            .where(
                and(
                    sql`EXTRACT(YEAR FROM ${rentals.created_at}) = ${currentYear}`,
                    sql`EXTRACT(MONTH FROM ${rentals.created_at}) = ${currentMonth}`
                )
            );
        const currentMonthRentals = currentMonthRentalsResult[0]?.count || 0;

        // =================================================================
        // 📈 GROWTH METRICS (Compare with previous month)
        // =================================================================

        const previousMonth = currentMonth === 1 ? 12 : currentMonth - 1;
        const previousYear = currentMonth === 1 ? currentYear - 1 : currentYear;

        const previousMonthRevenueResult = await db
            .select({
                total: sql<string>`COALESCE(SUM(CAST(${rentalPaymentHistory.amount} AS NUMERIC)), 0)`
            })
            .from(rentalPaymentHistory)
            .where(
                and(
                    eq(rentalPaymentHistory.status, 'paid'),
                    sql`EXTRACT(YEAR FROM ${rentalPaymentHistory.processed_at}) = ${previousYear}`,
                    sql`EXTRACT(MONTH FROM ${rentalPaymentHistory.processed_at}) = ${previousMonth}`
                )
            );
        const previousMonthRevenue = parseFloat(previousMonthRevenueResult[0]?.total || '0');

        const revenueGrowth = previousMonthRevenue > 0
            ? ((currentMonthRevenue - previousMonthRevenue) / previousMonthRevenue * 100)
            : 0;

        // =================================================================
        // 🎯 RETURN RESPONSE
        // =================================================================

        return c.json({
            success: true,
            data: {
                users: {
                    total: totalUsers,
                    borrowers: totalBorrowers,
                    lenders: totalLenders,
                    active: activeUsers,
                    pending_verification: pendingLenders,
                    verified: verifiedLenders
                },
                revenue: {
                    total: totalRevenue,
                    current_month: currentMonthRevenue,
                    previous_month: previousMonthRevenue,
                    growth_percentage: Math.round(revenueGrowth * 100) / 100,
                    average_order_value: Math.round(averageOrderValue * 100) / 100,
                    revenue_per_user: Math.round(revenuePerUser * 100) / 100,
                    monthly_breakdown: monthlyRevenue,
                    by_payment_type: revenueByType
                },
                rentals: {
                    total: totalRentals,
                    active: activeRentals,
                    completed: completedRentals,
                    overdue: overdueRentals,
                    current_month: currentMonthRentals,
                    average_duration_days: avgRentalDuration,
                    monthly_breakdown: monthlyRentals,
                    by_status: rentalsByStatus
                },
                payments: {
                    total: totalPayments,
                    pending: {
                        count: pendingPaymentsCount,
                        amount: pendingPaymentsAmount
                    },
                    failed: failedPayments,
                    by_status: paymentsByStatus
                },
                summary: {
                    current_period: {
                        month: currentMonth,
                        year: currentYear,
                        revenue: currentMonthRevenue,
                        rentals: currentMonthRentals
                    },
                    previous_period: {
                        month: previousMonth,
                        year: previousYear,
                        revenue: previousMonthRevenue
                    },
                    growth: {
                        revenue_percentage: Math.round(revenueGrowth * 100) / 100
                    }
                }
            },
            timestamp: new Date().toISOString()
        });

    } catch (error: any) {
        console.error('❌ Error fetching analytics data:', error);
        return c.json({
            success: false,
            message: 'Failed to fetch analytics data',
            error: error?.message || 'Unknown error occurred'
        }, 500);
    }
}

// =================================================================
// 📅 OPTIONAL: Get Analytics for Specific Date Range
// =================================================================
export async function getAnalyticsDataByDateRange(c: Context): Promise<any> {
    try {

        const { start_date, end_date } = c.req.query();

        if (!start_date || !end_date) {
            return c.json({
                success: false,
                message: 'start_date and end_date query parameters are required'
            }, 400);
        }

        const startDate = new Date(start_date);
        const endDate = new Date(end_date);

        // Revenue for date range
        const revenueResult = await db
            .select({
                total: sql<string>`COALESCE(SUM(CAST(${rentalPaymentHistory.amount} AS NUMERIC)), 0)`,
                count: count()
            })
            .from(rentalPaymentHistory)
            .where(
                and(
                    eq(rentalPaymentHistory.status, 'paid'),
                    gte(rentalPaymentHistory.processed_at, startDate),
                    lte(rentalPaymentHistory.processed_at, endDate)
                )
            );

        const revenue = parseFloat(revenueResult[0]?.total || '0');
        const paymentCount = revenueResult[0]?.count || 0;

        // Rentals for date range
        const rentalsResult = await db
            .select({ count: count() })
            .from(rentals)
            .where(
                and(
                    gte(rentals.created_at, startDate),
                    lte(rentals.created_at, endDate)
                )
            );

        const rentalCount = rentalsResult[0]?.count || 0;

        return c.json({
            success: true,
            data: {
                date_range: {
                    start: start_date,
                    end: end_date
                },
                revenue: {
                    total: revenue,
                    transaction_count: paymentCount
                },
                rentals: {
                    total: rentalCount
                }
            },
            timestamp: new Date().toISOString()
        });

    } catch (error: any) {
        console.error('❌ Error fetching date range analytics:', error);
        return c.json({
            success: false,
            message: 'Failed to fetch analytics data for date range',
            error: error?.message || 'Unknown error occurred'
        }, 500);
    }
}

// Configure nodemailer transporter
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER ,
        pass: process.env.EMAIL_PASSWORD || ''
    }
});

// Helper function for sending emails
async function sendEmail({ to, subject, html }: { to: string; subject: string; html: string }) {
    console.log('Sending email to:', to);

    try {
        await transporter.sendMail({
            from: `"CosConnect Support" <${process.env.EMAIL_USER }>`,
            to,
            subject,
            html,
        });
        return true;
    } catch (error) {
        console.error('Error sending email:', error);
        throw error;
    }
}

const updateUserAccountStatus = async (c: Context): Promise<Response> => {
    try {
        const body = await c.req.json();
        const adminId = c.get('userId');

        // Validate request body
        const schema = z.object({
            adminAction: z.enum(['approved', 'rejected']),
            postAuthorId: z.string().uuid('Invalid user ID'),
            postAuthorName: z.string().min(1, 'Author name is required'),
            postContent: z.string(),
            postId: z.string().uuid('Invalid post ID'),
            reason: z.string().min(1, 'Reason is required'),
            reportId: z.string().uuid('Invalid report ID'),
            reporterId: z.string().uuid('Invalid reporter ID'),
            reporterUsername: z.string(),
            timestamp: z.string(),
            metadata: z.object({
                currentStatus: z.string(),
                postCreatedAt: z.string(),
                reportCreatedAt: z.string()
            }).optional()
        });

        const validation = schema.safeParse(body);
        if (!validation.success) {
            return c.json({
                success: false,
                message: 'Invalid request body',
                errors: validation.error.flatten(),
            }, 400);
        }

        const {
            adminAction,
            postAuthorId,
            postAuthorName,
            postContent,
            postId,
            reason,
            reportId,
            reporterId,
            reporterUsername,
            timestamp,
            metadata
        } = validation.data;

        // Only process if admin approved the block action
        if (adminAction !== 'approved') {
            return c.json({
                success: false,
                message: 'No action taken - admin did not approve the block',
            }, 400);
        }

        // Get user details from database
        const [user] = await db
            .select({
                uid: users.uid,
                status: users.status,
                username: users.username,
                email: users.email
            })
            .from(users)
            .where(eq(users.uid, postAuthorId))
            .limit(1);

        if (!user) {
            return c.json({
                success: false,
                message: 'User not found',
            }, 404);
        }

        // Check if user is already suspended
        if (user.status === 'suspended') {
            return c.json({
                success: false,
                message: 'User is already suspended',
                currentStatus: user.status
            }, 400);
        }

        // Update user status to suspended
        const suspensionReason = `Account suspended due to community guideline violation. Report reason: ${reason}`;

        const [updatedUser] = await db
            .update(users)
            .set({
                status: 'suspended',
                suspended_message: suspensionReason,
                updated_at: new Date(),
                last_account_status_email_sent: null
            })
            .where(eq(users.uid, postAuthorId))
            .returning({
                uid: users.uid,
                status: users.status,
                email: users.email,
                username: users.username,
                suspended_message: users.suspended_message
            });

        // Update report status to resolved
        await db
            .update(community_post_reports)
            .set({
                status: 'resolved',
                reviewed_by: adminId,
                reviewed_at: new Date(),
                review_notes: 'User account suspended due to violation',
                updated_at: new Date()
            })
            .where(eq(community_post_reports.id, reportId));

        // Send suspension email notification
        if (updatedUser?.email) {
            const emailContent = `
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Account Suspension Notice</title>
                </head>
                <body style="margin: 0; padding: 0; background-color: #f5f5f5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
                    <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5; padding: 20px 0;">
                        <tr>
                            <td align="center">
                                <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); overflow: hidden;">
                                    <!-- Header -->
                                    <tr>
                                        <td style="background: linear-gradient(135deg, #dc3545 0%, #c82333 100%); padding: 40px 30px; text-align: center;">
                                            <div style="width: 60px; height: 60px; background-color: rgba(255,255,255,0.3); border-radius: 50%; display: inline-block; margin-bottom: 15px; line-height: 60px;">
                                                <span style="font-size: 32px;">🚫</span>
                                            </div>
                                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600;">
                                                Account Suspension Notice
                                            </h1>
                                        </td>
                                    </tr>

                                    <!-- Body -->
                                    <tr>
                                        <td style="padding: 40px 30px;">
                                            <p style="margin: 0 0 20px 0; color: #333333; font-size: 16px; line-height: 1.6;">
                                                Hello <strong>${user.username}</strong>,
                                            </p>
                                            
                                            <div style="background-color: #f8d7da; border-left: 4px solid #dc3545; padding: 15px; margin-bottom: 25px; border-radius: 0 8px 8px 0;">
                                                <p style="margin: 0 0 5px 0; color: #721c24; font-weight: 600; font-size: 16px;">Your account has been suspended</p>
                                                <p style="margin: 0; color: #721c24; font-size: 14px;">Your account has been suspended due to a violation of our community guidelines.</p>
                                            </div>

                                            <p style="margin: 0 0 20px 0; color: #555555; font-size: 15px; line-height: 1.6;">
                                                A member of our community reported one of your posts for violating our terms of service. After review, our moderation team has confirmed the violation and taken action on your account.
                                            </p>

                                            <!-- Report Details Box -->
                                            <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f8f9fa; border: 1px solid #e9ecef; border-radius: 8px; margin: 25px 0;">
                                                <tr>
                                                    <td style="padding: 20px;">
                                                        <h3 style="margin: 0 0 15px 0; color: #dc3545; font-size: 16px; font-weight: 600;">Report Details</h3>
                                                        
                                                        <table width="100%" cellpadding="8" cellspacing="0">
                                                            <tr style="border-bottom: 1px solid #e9ecef;">
                                                                <td style="color: #495057; font-weight: 600; font-size: 14px; width: 140px;">Violation Type:</td>
                                                                <td style="color: #6c757d; font-size: 14px;">${reason}</td>
                                                            </tr>
                                                            <tr style="border-bottom: 1px solid #e9ecef;">
                                                                <td style="color: #495057; font-weight: 600; font-size: 14px; padding-top: 8px;">Reported By:</td>
                                                                <td style="color: #6c757d; font-size: 14px; padding-top: 8px;">${reporterUsername}</td>
                                                            </tr>
                                                            <tr style="border-bottom: 1px solid #e9ecef;">
                                                                <td style="color: #495057; font-weight: 600; font-size: 14px; padding-top: 8px;">Report Date:</td>
                                                                <td style="color: #6c757d; font-size: 14px; padding-top: 8px;">${new Date(metadata?.reportCreatedAt || timestamp).toLocaleString('en-US', {
                dateStyle: 'long',
                timeStyle: 'short'
            })}</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="color: #495057; font-weight: 600; font-size: 14px; padding-top: 8px;">Post Date:</td>
                                                                <td style="color: #6c757d; font-size: 14px; padding-top: 8px;">${new Date(metadata?.postCreatedAt || timestamp).toLocaleString('en-US', {
                dateStyle: 'long',
                timeStyle: 'short'
            })}</td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </table>

                                            <p style="margin: 0 0 10px 0; color: #333333; font-weight: 600; font-size: 15px;">Reported Content:</p>
                                            <div style="background-color: #ffffff; border-left: 4px solid #dc3545; padding: 15px; margin: 0 0 25px 0; color: #495057; font-style: italic; white-space: pre-wrap; word-wrap: break-word; border: 1px solid #e9ecef; border-radius: 4px;">${postContent || 'Content not available'}</div>

                                            <div style="background-color: #fff3cd; border: 1px solid #ffc107; padding: 15px; border-radius: 8px; margin: 25px 0;">
                                                <p style="margin: 0 0 10px 0; color: #856404; font-weight: 600; font-size: 15px;">What this means:</p>
                                                <ul style="margin: 0; padding-left: 20px; color: #856404; font-size: 14px;">
                                                    <li style="margin-bottom: 8px;">You cannot access your account</li>
                                                    <li style="margin-bottom: 8px;">Your profile and posts are hidden from other users</li>
                                                    <li>You cannot create new posts or interact with the community</li>
                                                </ul>
                                            </div>

                                            <p style="margin: 25px 0 0 0; color: #555555; font-size: 14px; line-height: 1.6;">
                                                If you believe this suspension was made in error, please contact our support team with your report ID: <strong>${reportId}</strong>
                                            </p>
                                        </td>
                                    </tr>

                                    <!-- Footer -->
                                    <tr>
                                        <td style="background-color: #f9f9f9; padding: 20px 30px; text-align: center; border-top: 1px solid #eeeeee;">
                                            <p style="margin: 0 0 10px 0; color: #333333; font-size: 14px; font-weight: 600;">Need Help?</p>
                                            <p style="margin: 0 0 15px 0; color: #777777; font-size: 13px;">
                                                Contact us at <a href="mailto:support@cosconnect.com" style="color: #007bff; text-decoration: none;">support@cosconnect.com</a>
                                            </p>
                                            <p style="margin: 0; color: #999999; font-size: 12px; line-height: 1.5;">
                                                This is an automated message. Please do not reply to this email.<br>
                                                Report ID: ${reportId}
                                            </p>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </body>
                </html>
            `;

            try {
                await sendEmail({
                    to: user.email,
                    subject: 'Account Suspension Notice - Community Guidelines Violation',
                    html: emailContent
                });
            } catch (emailError) {
                console.error('Failed to send suspension email:', emailError);
                // Don't fail the entire operation if email fails
            }
        }

        console.log(`User ${user.username} (${postAuthorId}) suspended by admin ${adminId} due to report ${reportId}`);

        return c.json({
            success: true,
            message: 'User account suspended successfully',
            data: {
                userId: updatedUser?.uid,
                username: updatedUser?.username,
                status: updatedUser?.status,
                action: 'block_user',
                reason: suspensionReason,
                reportId: reportId,
                postId: postId,
                timestamp: new Date().toISOString()
            },
        });

    } catch (error: any) {
        console.error('Error updating user account status:', error);
        return c.json({
            success: false,
            message: 'Internal server error',
            error: error.message,
        }, 500);
    }
};

const sendWarningBlockUserAccount = async (c: Context): Promise<Response> => {
    try {
        const body = await c.req.json();
        const adminId = c.get('userId');

        // Validate request body
        const schema = z.object({
            adminAction: z.enum(['warning']),
            postAuthorId: z.string().uuid('Invalid user ID'),
            postAuthorName: z.string().min(1, 'Author name is required'),
            postContent: z.string(),
            postId: z.string().uuid('Invalid post ID'),
            reason: z.string().min(1, 'Reason is required'),
            reportId: z.string().uuid('Invalid report ID'),
            reporterId: z.string().uuid('Invalid reporter ID'),
            reporterUsername: z.string(),
            timestamp: z.string(),
            metadata: z.object({
                currentStatus: z.string(),
                postCreatedAt: z.string(),
                reportCreatedAt: z.string()
            }).optional()
        });

        const validation = schema.safeParse(body);
        if (!validation.success) {
            return c.json({
                success: false,
                message: 'Invalid request body',
                errors: validation.error.flatten(),
            }, 400);
        }

        const {
            postAuthorId,
            postAuthorName,
            postContent,
            postId,
            reason,
            reportId,
            reporterId,
            reporterUsername,
            timestamp,
            metadata
        } = validation.data;

        // Get user details
        const [user] = await db
            .select({
                uid: users.uid,
                email: users.email,
                username: users.username,
                status: users.status
            })
            .from(users)
            .where(eq(users.uid, postAuthorId))
            .limit(1);

        if (!user) {
            return c.json({
                success: false,
                message: 'User not found',
            }, 404);
        }

        // Update report status to reviewed with warning
        await db
            .update(community_post_reports)
            .set({
                status: 'reviewed',
                reviewed_by: adminId,
                reviewed_at: new Date(),
                review_notes: 'Warning sent to user',
                updated_at: new Date()
            })
            .where(eq(community_post_reports.id, reportId));

        // Send warning email using the existing sendWarningEmail from emailServices
        if (user.email) {
            const warningEmailContent = `
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Community Guidelines Warning</title>
                </head>
                <body style="margin: 0; padding: 0; background-color: #f5f5f5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
                    <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5; padding: 20px 0;">
                        <tr>
                            <td align="center">
                                <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); overflow: hidden;">
                                    <!-- Header -->
                                    <tr>
                                        <td style="background: linear-gradient(135deg, #ffc107 0%, #ff9800 100%); padding: 40px 30px; text-align: center;">
                                            <div style="width: 60px; height: 60px; background-color: rgba(255,255,255,0.3); border-radius: 50%; display: inline-block; margin-bottom: 15px; line-height: 60px;">
                                                <span style="font-size: 32px;">⚠️</span>
                                            </div>
                                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600;">
                                                Community Guidelines Warning
                                            </h1>
                                        </td>
                                    </tr>

                                    <!-- Body -->
                                    <tr>
                                        <td style="padding: 40px 30px;">
                                            <p style="margin: 0 0 20px 0; color: #333333; font-size: 16px; line-height: 1.6;">
                                                Hello <strong>${user.username}</strong>,
                                            </p>
                                            
                                            <div style="background-color: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin-bottom: 25px; border-radius: 0 8px 8px 0;">
                                                <p style="margin: 0 0 5px 0; color: #856404; font-weight: 600; font-size: 16px;">This is an official warning</p>
                                                <p style="margin: 0; color: #856404; font-size: 14px;">One of your posts has been reported for violating our community guidelines.</p>
                                            </div>

                                            <p style="margin: 0 0 20px 0; color: #555555; font-size: 15px; line-height: 1.6;">
                                                A member of our community has flagged your content. While we're not suspending your account at this time, we want to remind you of our community standards.
                                            </p>

                                            <!-- Report Details Box -->
                                            <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f8f9fa; border: 1px solid #e9ecef; border-radius: 8px; margin: 25px 0;">
                                                <tr>
                                                    <td style="padding: 20px;">
                                                        <h3 style="margin: 0 0 15px 0; color: #ff9800; font-size: 16px; font-weight: 600;">Report Details</h3>
                                                        
                                                        <table width="100%" cellpadding="8" cellspacing="0">
                                                            <tr style="border-bottom: 1px solid #e9ecef;">
                                                                <td style="color: #495057; font-weight: 600; font-size: 14px; width: 140px;">Violation Type:</td>
                                                                <td style="color: #6c757d; font-size: 14px;">${reason}</td>
                                                            </tr>
                                                            <tr style="border-bottom: 1px solid #e9ecef;">
                                                                <td style="color: #495057; font-weight: 600; font-size: 14px; padding-top: 8px;">Reported By:</td>
                                                                <td style="color: #6c757d; font-size: 14px; padding-top: 8px;">${reporterUsername}</td>
                                                            </tr>
                                                            <tr style="border-bottom: 1px solid #e9ecef;">
                                                                <td style="color: #495057; font-weight: 600; font-size: 14px; padding-top: 8px;">Report Date:</td>
                                                                <td style="color: #6c757d; font-size: 14px; padding-top: 8px;">${new Date(metadata?.reportCreatedAt || timestamp).toLocaleString('en-US', {
                dateStyle: 'long',
                timeStyle: 'short'
            })}</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="color: #495057; font-weight: 600; font-size: 14px; padding-top: 8px;">Post Date:</td>
                                                                <td style="color: #6c757d; font-size: 14px; padding-top: 8px;">${new Date(metadata?.postCreatedAt || timestamp).toLocaleString('en-US', {
                dateStyle: 'long',
                timeStyle: 'short'
            })}</td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </table>

                                            <p style="margin: 0 0 10px 0; color: #333333; font-weight: 600; font-size: 15px;">Reported Content:</p>
                                            <div style="background-color: #ffffff; border-left: 4px solid #ffc107; padding: 15px; margin: 0 0 25px 0; color: #495057; font-style: italic; white-space: pre-wrap; word-wrap: break-word; border: 1px solid #e9ecef; border-radius: 4px;">${postContent || 'Content not available'}</div>

                                            <div style="background-color: #e7f3ff; border: 1px solid #b3d9ff; padding: 15px; border-radius: 8px; margin: 25px 0;">
                                                <p style="margin: 0 0 10px 0; color: #0056b3; font-weight: 600; font-size: 15px;">Action Required</p>
                                                <p style="margin: 0; color: #495057; font-size: 14px;">Please review our community guidelines and ensure future posts comply with our standards. Repeated violations may result in account suspension.</p>
                                            </div>

                                            <p style="margin: 0 0 10px 0; color: #333333; font-weight: 600; font-size: 15px;">What you should do:</p>
                                            <ul style="margin: 0 0 25px 0; padding-left: 20px; color: #555555; font-size: 14px;">
                                                <li style="margin-bottom: 8px;">Review our community guidelines</li>
                                                <li style="margin-bottom: 8px;">Consider removing or editing the reported content</li>
                                                <li style="margin-bottom: 8px;">Ensure future posts comply with our standards</li>
                                                <li>Contact support if you have questions</li>
                                            </ul>

                                            <div style="margin: 30px 0; text-align: center;">
                                                <a href="${process.env.FRONTEND_URL || 'https://cosconnect.com'}/community-guidelines" 
                                                   style="display: inline-block; background-color: #007bff; color: #ffffff; text-decoration: none; padding: 12px 25px; border-radius: 6px; font-weight: 500; font-size: 15px;">
                                                    Review Community Guidelines
                                                </a>
                                            </div>

                                            <p style="margin: 0; color: #555555; font-size: 14px; line-height: 1.6;">
                                                If you believe this warning was issued in error, please contact our support team with your report ID: <strong>${reportId}</strong>
                                            </p>
                                        </td>
                                    </tr>

                                    <!-- Footer -->
                                    <tr>
                                        <td style="background-color: #f9f9f9; padding: 20px 30px; text-align: center; border-top: 1px solid #eeeeee;">
                                            <p style="margin: 0 0 10px 0; color: #333333; font-size: 14px; font-weight: 600;">Need Help?</p>
                                            <p style="margin: 0 0 15px 0; color: #777777; font-size: 13px;">
                                                Contact us at <a href="mailto:support@cosconnect.com" style="color: #007bff; text-decoration: none;">support@cosconnect.com</a>
                                            </p>
                                            <p style="margin: 0; color: #999999; font-size: 12px; line-height: 1.5;">
                                                This is an automated message. Please do not reply to this email.<br>
                                                Report ID: ${reportId}
                                            </p>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </body>
                </html>
            `;

            try {
                await sendEmail({
                    to: user.email,
                    subject: '⚠️ Community Guidelines Warning',
                    html: warningEmailContent
                });
            } catch (emailError: any) {
                console.error('Failed to send warning email:', emailError);
                return c.json({
                    success: false,
                    message: 'Failed to send warning email',
                    error: emailError.message || 'Unknown error',
                }, 500);
            }
        }

        console.log(`Warning sent to user ${user.username} (${postAuthorId}) by admin ${adminId} for report ${reportId}`);

        return c.json({
            success: true,
            message: `Warning email sent successfully to ${user.username}`,
            data: {
                userId: postAuthorId,
                username: user.username,
                email: user.email,
                reportId: reportId,
                postId: postId,
                warningSent: true,
                timestamp: new Date().toISOString()
            }
        });

    } catch (error: any) {
        console.error('Error in sendWarningBlockUserAccount:', error);
        return c.json({
            success: false,
            message: 'Failed to send warning',
            error: error.message,
        }, 500);
    }
};

// Zod schema for UUID validation
const idSchema = z.string().uuid()

/**
 * Fetch admin data by id with validation and error handling (controller style).
 * @param c - Hono Context
 */
const getAdminDataById = async (c: Context) => {
    const adminId = c.req.param("id")
    // Validate id
    const parseResult = idSchema.safeParse(adminId)
    if (!parseResult.success) {
        return c.json(
            {
                message: "Invalid admin id format. Must be a valid UUID.",
                status: "fail",
                statusCode: 400,
                data: null,
            },
            400,
        )
    }
    try {
        const result = await db.select().from(admin).where(eq(admin.id, adminId))
        if (!result || result.length === 0) {
            return c.json(
                {
                    message: "Admin not found",
                    status: "fail",
                    statusCode: 404,
                    data: null,
                },
                404,
            )
        }
        return c.json(
            {
                message: "Admin fetched successfully",
                status: "success",
                statusCode: 200,
                data: result[0],
            },
            200,
        )
    } catch (error) {
        console.error(`[getAdminDataById] Error fetching admin data for id ${adminId}:`, error)
        return c.json(
            {
                message: "Internal server error",
                status: "error",
                statusCode: 500,
                data: null,
            },
            500,
        )
    }
}

const getAllUsersCreated = async (c: Context) => {
    // Parse pagination params with validation
    const pageParam = c.req.query("page") || "1"
    const limitParam = c.req.query("limit") || "10"

    const page = Math.max(1, Number.parseInt(pageParam, 10)) || 1
    const limit = Math.min(100, Math.max(1, Number.parseInt(limitParam, 10))) || 10 // Cap at 100, min 1
    const offset = (page - 1) * limit

    try {
        // Get total count and paginated users in parallel for better performance
        const [totalResult, userList] = await Promise.all([
            db.select({ count: count() }).from(users),
            db.select().from(users)
                .orderBy(desc(users.created_at))
                .limit(limit)
                .offset(offset)
        ])

        const total = totalResult[0]?.count || 0
        const totalPages = Math.ceil(total / limit)

        return c.json(
            {
                message: "Users fetched successfully",
                status: "success",
                statusCode: 200,
                data: userList,
                pagination: {
                    total,
                    page,
                    limit,
                    totalPages,
                    hasNextPage: page < totalPages,
                    hasPrevPage: page > 1,
                },
            },
            200,
        )
    } catch (error) {
        console.error("[getAllUsersCreated] Error fetching users:", error)
        return c.json(
            {
                message: "Internal server error",
                status: "error",
                statusCode: 500,
                data: null,
                pagination: null,
            },
            500,
        )
    }
}

/**
 * Update user verification status with proper enum mapping and transaction safety
 * @param c - Hono Context
 */
const updateUserStatus = async (c: Context) => {
    const userId = c.req.param("userId")
    console.log(`[updateUserStatus] Starting update for user ID: ${userId}`)

    try {
        // Validate userId format
        const userIdValidation = idSchema.safeParse(userId)
        if (!userIdValidation.success) {
            console.log(`[updateUserStatus] Invalid user ID format: ${userId}`, userIdValidation.error.issues)
            return c.json(
                {
                    message: "Invalid user ID format. Must be a valid UUID.",
                    status: "fail",
                    statusCode: 400,
                    data: null,
                    errors: userIdValidation.error.issues,
                },
                400,
            )
        }

        // Parse and validate request body
        const requestBody = await c.req.json()
        const { status, rejected_message } = requestBody
        console.log(`[updateUserStatus] Request received`, { userId, status })

        // Validate required fields
        if (!status || typeof status !== "string") {
            return c.json(
                {
                    message: "Status is required and must be a string",
                    status: "fail",
                    statusCode: 400,
                    data: null,
                },
                400,
            )
        }

        // Validate status value
        if (!["approve", "reject"].includes(status)) {
            return c.json(
                {
                    message: 'Invalid status. Must be either "approve" or "reject"',
                    status: "fail",
                    statusCode: 400,
                    data: null,
                },
                400,
            )
        }

        // Check if target user exists
        const existingUser = await db
            .select({
                uid: users.uid,
                status: users.status,
                role: users.role,
                email: users.email,
                username: users.username,
            })
            .from(users)
            .where(eq(users.uid, userId))
            .limit(1)

        if (!existingUser.length) {
            return c.json(
                {
                    message: "User not found",
                    status: "fail",
                    statusCode: 404,
                    data: null,
                },
                404,
            )
        }

        const targetUser = existingUser[0]

        // Check if user is already in the target status
        const statusMapping: Record<string, UserStatus> = {
            approve: "verified",
            reject: "rejected",
        }

        const newStatus = statusMapping[status]

        if (targetUser?.status === newStatus) {
            return c.json(
                {
                    message: `User is already ${newStatus}`,
                    status: "success",
                    statusCode: 200,
                    data: targetUser,
                },
                200,
            )
        }

        const now = new Date()
        const isLender = targetUser?.role?.includes("lender") ?? false

        console.log(`[updateUserStatus] Starting transaction for user ${userId} with status: ${status}`)
        const result = await db.transaction(async (tx) => {
            // Prepare user update data
            const userUpdateData: Partial<typeof users.$inferSelect> = {
                status: newStatus,
                updated_at: now,
                email_verified: status === "approve",
                rejected_message: status === "reject" ? rejected_message || null : null,
            }

            // Update user status
            const [updatedUser] = await tx.update(users).set(userUpdateData).where(eq(users.uid, userId)).returning({
                uid: users.uid,
                username: users.username,
                email: users.email,
                status: users.status,
                email_verified: users.email_verified,
                rejected_message: users.rejected_message,
                updated_at: users.updated_at,
                role: users.role,
            })

            if (!updatedUser) {
                throw new Error("Failed to update user status")
            }

            // Update business info if user is a lender
            let businessInfo = null
            if (isLender) {
                const businessUpdateData: Partial<typeof user_business_info.$inferSelect> = {
                    updated_at: now,
                    is_verified: status === "approve",
                    verified_at: status === "approve" ? now : null,
                    verified_by: null, // Set to null since we removed adminId
                    rejection_reason: status === "reject" ? rejected_message || "Verification rejected" : null,
                }

                // Update business info
                const businessUpdateResult = await tx
                    .update(user_business_info)
                    .set(businessUpdateData)
                    .where(eq(user_business_info.user_uid, userId))
                    .returning({
                        user_uid: user_business_info.user_uid,
                        is_verified: user_business_info.is_verified,
                        verified_at: user_business_info.verified_at,
                        verified_by: user_business_info.verified_by,
                        rejection_reason: user_business_info.rejection_reason,
                    })

                // Fetch complete business info for response
                businessInfo = await tx.query.user_business_info.findFirst({
                    where: (table, { eq }) => eq(table.user_uid, userId),
                })

                console.log(`[updateUserStatus] Business verification updated:`, {
                    userId,
                    updateResult: businessUpdateResult[0],
                    finalBusinessInfo: businessInfo,
                })
            }

            return {
                user: updatedUser,
                businessInfo,
            }
        })

        console.log(`[updateUserStatus] Transaction completed successfully for user ${userId}`)

        // Audit log
        console.log(`[updateUserStatus] Status update completed:`, {
            userId,
            previousStatus: targetUser?.status,
            newStatus,
            isLender,
            timestamp: now.toISOString(),
        })

        if (isLender) {
            try {
                if (result.user?.email) {
                    await sendLenderVerificationEmail({
                        email: result.user.email,
                        name: result.user.username,
                        status: status === "approve" ? "approved" : "rejected",
                        reason: status === "reject" ? rejected_message || undefined : undefined,
                    })
                }
            } catch (err) {
                console.error(`[updateUserStatus] Failed to send lender verification email for user ${userId}:`, err)
            }

            try {
                const template =
                    status === "approve"
                        ? notificationTemplates.lenderVerificationApproved()
                        : notificationTemplates.lenderVerificationRejected(rejected_message || "Your lender verification was not approved.")

                await notificationService.create({
                    recipientId: result.user.uid,
                    recipientRole: "lender",
                    senderType: "system",
                    type: status === "approve" ? "LENDER_VERIFICATION_APPROVED" : "LENDER_VERIFICATION_REJECTED",
                    title: template.title,
                    message: template.message,
                    metadata: status === "reject" && rejected_message ? { reason: rejected_message } : {},
                })
            } catch (err) {
                console.error(`[updateUserStatus] Failed to create lender verification notification for user ${userId}:`, err)
            }
        }

        return c.json(
            {
                message: `User ${status === "approve" ? "approved" : "rejected"} successfully`,
                status: "success",
                statusCode: 200,
                data: {
                    user: result.user,
                    businessInfo: result.businessInfo,
                },
            },
            200,
        )
    } catch (error) {
        console.error(`[updateUserStatus] Error processing user ${userId || 'unknown'}:`, error)

        // Handle specific error types
        if (error instanceof SyntaxError) {
            return c.json(
                {
                    message: "Invalid JSON format in request body",
                    status: "fail",
                    statusCode: 400,
                    data: null,
                },
                400,
            )
        }

        if (error instanceof Error) {
            // Database constraint violations
            if (error.message.includes("constraint") || error.message.includes("unique")) {
                return c.json(
                    {
                        message: "Database constraint violation",
                        status: "error",
                        statusCode: 409,
                        data: null,
                    },
                    409,
                )
            }

            // Connection/timeout errors
            if (error.message.includes("timeout") || error.message.includes("connection")) {
                return c.json(
                    {
                        message: "Database connection error. Please try again.",
                        status: "error",
                        statusCode: 503,
                        data: null,
                    },
                    503,
                )
            }
        }

        console.error(`[updateUserStatus] Error details:`, {
            userId,
            error: error instanceof Error ? error.message : 'Unknown error',
            stack: error instanceof Error ? error.stack : undefined,
            timestamp: new Date().toISOString()
        })

        return c.json(
            {
                message: "Internal server error occurred while updating user status",
                status: "error",
                statusCode: 500,
                data: null,
            },
            500,
        )
    } finally {
        console.log(`[updateUserStatus] Completed processing for user ${userId || 'unknown'}`)
    }
}


const deleteUserById = async (c: Context) => {
    try {
        const userId = c.req.param("userId")
        const adminId = c.req.query("adminId")

        // Validate userId
        const idSchema = z.string().uuid()
        const idResult = idSchema.safeParse(userId)
        if (!idResult.success) {
            return c.json(
                {
                    message: "Invalid userId format. Must be a valid UUID.",
                    status: "fail",
                    statusCode: 400,
                    data: null,
                },
                400,
            )
        }

        if (!adminId) {
            return c.json(
                {
                    message: "Admin ID is required as query parameter",
                    status: "fail",
                    statusCode: 400,
                    data: null,
                },
                400,
            )
        }

        const adminIdResult = idSchema.safeParse(adminId)
        if (!adminIdResult.success) {
            return c.json(
                {
                    message: "Invalid adminId format. Must be a valid UUID.",
                    status: "fail",
                    statusCode: 400,
                    data: null,
                },
                400,
            )
        }

        const adminExists = await db
            .select({
                id: admin.id,
                username: admin.username,
                email: admin.email,
                role: admin.role,
            })
            .from(admin)
            .where(eq(admin.id, adminId))
            .limit(1)

        if (!adminExists.length) {
            return c.json(
                {
                    message: "Admin not found with the provided ID",
                    status: "fail",
                    statusCode: 404,
                    data: null,
                },
                404,
            )
        }

        // Check if user exists
        const user = await db.select().from(users).where(eq(users.uid, userId))
        if (!user || user.length === 0) {
            return c.json(
                {
                    message: "User not found.",
                    status: "fail",
                    statusCode: 404,
                    data: null,
                },
                404,
            )
        }

        // Delete user
        const deleted = await db.delete(users).where(eq(users.uid, userId)).returning()
        if (!deleted || deleted.length === 0) {
            return c.json(
                {
                    message: "Failed to delete user.",
                    status: "fail",
                    statusCode: 500,
                    data: null,
                },
                500,
            )
        }

        console.log(`[deleteUserById] User deletion completed:`, {
            userId,
            deletedUser: deleted[0],
            adminId,
            adminUsername: adminExists[0]?.username,
            timestamp: new Date().toISOString(),
        })

        return c.json(
            {
                message: "User deleted successfully.",
                status: "success",
                statusCode: 200,
                data: {
                    deletedUser: deleted[0],
                    deletedBy: adminExists[0],
                },
            },
            200,
        )
    } catch (error) {
        console.error("[deleteUserById] Error deleting user:", error)
        return c.json(
            {
                message: "Internal server error",
                status: "error",
                statusCode: 500,
                data: null,
            },
            500,
        )
    }
}

const deleteUsersByBulkIds = async (c: Context) => {
    try {
        const body = await c.req.json()
        const { userIds, adminId } = body

        // Validate input is an array of strings
        if (!Array.isArray(userIds) || userIds.length === 0) {
            return c.json(
                {
                    message: "userIds must be a non-empty array of UUID strings.",
                    status: "fail",
                    statusCode: 400,
                    data: null,
                },
                400,
            )
        }

        if (!adminId) {
            return c.json(
                {
                    message: "Admin ID is required in request body",
                    status: "fail",
                    statusCode: 400,
                    data: null,
                },
                400,
            )
        }

        // Validate all IDs including adminId
        const idSchema = z.string().uuid()
        const adminIdResult = idSchema.safeParse(adminId)
        if (!adminIdResult.success) {
            return c.json(
                {
                    message: "Invalid adminId format. Must be a valid UUID.",
                    status: "fail",
                    statusCode: 400,
                    data: null,
                },
                400,
            )
        }

        const adminExists = await db
            .select({
                id: admin.id,
                username: admin.username,
                email: admin.email,
                role: admin.role,
            })
            .from(admin)
            .where(eq(admin.id, adminId))
            .limit(1)

        if (!adminExists.length) {
            return c.json(
                {
                    message: "Admin not found with the provided ID",
                    status: "fail",
                    statusCode: 404,
                    data: null,
                },
                404,
            )
        }

        const validIds: string[] = []
        const invalidIds: string[] = []
        for (const id of userIds) {
            if (idSchema.safeParse(id).success) {
                validIds.push(id)
            } else {
                invalidIds.push(id)
            }
        }

        if (validIds.length === 0) {
            return c.json(
                {
                    message: "No valid UUIDs provided.",
                    status: "fail",
                    statusCode: 400,
                    data: { invalidIds },
                },
                400,
            )
        }

        // Check which users exist
        const foundUsers = await db.select({ uid: users.uid }).from(users).where(inArray(users.uid, validIds))
        const foundIds = foundUsers.map((u) => u.uid)
        const notFoundIds = validIds.filter((id) => !foundIds.includes(id))

        // Delete found users
        let deleted: any[] = []
        if (foundIds.length > 0) {
            deleted = await db.delete(users).where(inArray(users.uid, foundIds)).returning()
        }

        console.log(`[deleteUsersByBulkIds] Bulk deletion completed:`, {
            requestedIds: userIds,
            deletedCount: deleted.length,
            deletedIds: deleted.map((u) => u.uid),
            notFoundIds,
            invalidIds,
            adminId,
            adminUsername: adminExists[0]?.username,
            timestamp: new Date().toISOString(),
        })

        return c.json(
            {
                message: "Bulk user deletion completed.",
                status: "success",
                statusCode: 200,
                data: {
                    deletedCount: deleted.length,
                    deletedIds: deleted.map((u) => u.uid),
                    notFoundIds,
                    invalidIds,
                    deletedBy: adminExists[0],
                },
            },
            200,
        )
    } catch (error) {
        console.error("[deleteUsersByBulkIds] Error deleting users:", error)
        return c.json(
            {
                message: "Internal server error",
                status: "error",
                statusCode: 500,
                data: null,
            },
            500,
        )
    }
}

const suspendUserAccount = async (c: Context) => {
    try {
        const userId = c.req.param("userId")
        const body = await c.req.json()
        const { message, adminId } = body

        // Validate userId
        const idSchema = z.string().uuid()
        const idResult = idSchema.safeParse(userId)
        if (!idResult.success) {
            return c.json(
                {
                    message: "Invalid userId format. Must be a valid UUID.",
                    status: "fail",
                    statusCode: 400,
                    data: null,
                },
                400,
            )
        }

        // Validate message
        if (!message || typeof message !== "string" || !message.trim()) {
            return c.json(
                {
                    message: "A suspension message is required.",
                    status: "fail",
                    statusCode: 400,
                    data: null,
                },
                400,
            )
        }

        if (!adminId) {
            return c.json(
                {
                    message: "Admin ID is required in request body",
                    status: "fail",
                    statusCode: 400,
                    data: null,
                },
                400,
            )
        }

        const adminIdResult = idSchema.safeParse(adminId)
        if (!adminIdResult.success) {
            return c.json(
                {
                    message: "Invalid adminId format. Must be a valid UUID.",
                    status: "fail",
                    statusCode: 400,
                    data: null,
                },
                400,
            )
        }

        const adminExists = await db
            .select({
                id: admin.id,
                username: admin.username,
                email: admin.email,
                role: admin.role,
            })
            .from(admin)
            .where(eq(admin.id, adminId))
            .limit(1)

        if (!adminExists.length) {
            return c.json(
                {
                    message: "Admin not found with the provided ID",
                    status: "fail",
                    statusCode: 404,
                    data: null,
                },
                404,
            )
        }

        // Check if user exists
        const user = await db.select().from(users).where(eq(users.uid, userId))
        if (!user || user.length === 0) {
            return c.json(
                {
                    message: "User not found.",
                    status: "fail",
                    statusCode: 404,
                    data: null,
                },
                404,
            )
        }

        // Update user status to 'suspended' and save message
        const result = await db
            .update(users)
            .set({
                status: "suspended",
                suspended_message: message,
                updated_at: new Date(),
            })
            .where(eq(users.uid, userId))
            .returning()

        if (!result || result.length === 0) {
            return c.json(
                {
                    message: "Failed to suspend user account.",
                    status: "fail",
                    statusCode: 500,
                    data: null,
                },
                500,
            )
        }

        console.log(`[suspendUserAccount] User suspension completed:`, {
            userId,
            suspensionMessage: message,
            suspendedUser: result[0],
            adminId,
            adminUsername: adminExists[0]?.username,
            timestamp: new Date().toISOString(),
        })

        return c.json(
            {
                message: "User account suspended successfully.",
                status: "success",
                statusCode: 200,
                data: {
                    suspendedUser: result[0],
                    suspendedBy: adminExists[0],
                },
            },
            200,
        )
    } catch (error) {
        console.error("[suspendUserAccount] Error suspending user:", error)
        return c.json(
            {
                message: "Internal server error",
                status: "error",
                statusCode: 500,
                data: null,
            },
            500,
        )
    }
}




export default {
    getAdminDataById,
    getAllUsersCreated,
    updateUserStatus,
    deleteUserById,
    deleteUsersByBulkIds,
    suspendUserAccount,
    sendWarningBlockUserAccount,
    updateUserAccountStatus,
    getAnalyticsData,
    updateAdminInfo,
    verifyUserDocument
}
