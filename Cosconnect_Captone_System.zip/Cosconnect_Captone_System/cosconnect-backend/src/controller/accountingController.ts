import { rentalPaymentHistory } from '@/db-schema';
import { rentals } from '@/schema/rentals';
import { count, desc, eq, inArray, sql } from 'drizzle-orm';
import type { Context } from 'hono';
import db from '../db/supabase/db_connect';


// Updated PayoutPayload interface
interface PayoutPayload {
    accountName: string;
    amount: number;
    gcashNumber: string;
    lenderId: string;
    notes: string;
    rentalId: string;
    type: 'payout';
}

// Updated RefundPayload interface
interface RefundPayload {
    accountName: string;
    amount: number;
    gcashNumber: string;
    borrowerId: string;
    notes: string;
    rentalId: string;
    type: 'refund';
}

const sendPayoutMoneyLender = async (c: Context): Promise<Response> => {
    try {
        const body: PayoutPayload = await c.req.json();
        console.log('sendPayoutMoneyLender - Received payload:', JSON.stringify(body, null, 2));

        // Validate required fields
        const requiredFields: (keyof PayoutPayload)[] = ['rentalId', 'accountName', 'amount', 'gcashNumber', 'lenderId'];
        const missingFields = requiredFields.filter(field => !body[field]);

        if (missingFields.length > 0) {
            console.error('sendPayoutMoneyLender - Missing required fields:', missingFields);
            return c.json({
                success: false,
                error: 'Missing required fields',
                missingFields: missingFields
            }, 400);
        }

        // First, get the current rental data to check if payout was already processed
        const currentRental = await db.select()
            .from(rentals)
            .where(eq(rentals.id, body.rentalId))
            .limit(1);

        if (currentRental.length === 0) {
            console.error('sendPayoutMoneyLender - Rental not found:', body.rentalId);
            return c.json({
                success: false,
                error: 'Rental not found'
            }, 404);
        }

        const rental = currentRental[0];

        // Check if payout was already processed
        if (rental?.payout_cashout_lender?.status === 'completed' || rental?.payout_completed_at) {
            console.warn('sendPayoutMoneyLender - Payout already processed for rental:', body.rentalId);
            return c.json({
                success: false,
                error: 'Payout has already been processed for this rental'
            }, 400);
        }

        const currentTime = new Date();

        // Prepare payout data - store all the request data
        const payoutData = {
            accountName: body.accountName,
            amount: body.amount,
            gcashNumber: body.gcashNumber,
            lenderId: body.lenderId,
            notes: body.notes || '',
            processedAt: currentTime.toISOString(),
            status: 'completed' as const,
            transactionType: 'payout' as const
        };

        // Check if refund is already completed
        const refundCompleted = !!(rental?.security_deposit_refund_borrower?.status === 'completed' && rental?.refund_completed_at);

        // Both will be completed after this update (payout will be completed, check if refund is already completed)
        const bothCompleted = refundCompleted;

        // Update the rental with payout data and completion timestamps
        const updateData: any = {
            payout_cashout_lender: payoutData,
            payout_completed_at: currentTime, // Always set payout completion timestamp
            updated_at: currentTime
        };

        // If both payout and refund are completed, mark rental as fully completed
        if (bothCompleted) {
            updateData.status = 'completed';
            updateData.completed_at = currentTime;
            console.log('sendPayoutMoneyLender - Marking rental as fully completed (both payout and refund processed)');
        }

        // Use a transaction to update rental and record payout in payment history
        await db.transaction(async (tx) => {
            // Update the rental record
            await tx.update(rentals)
                .set(updateData)
                .where(eq(rentals.id, body.rentalId));

            // Record payout in rental payment history for analytics and accounting
            await tx.insert(rentalPaymentHistory).values({
                rental_id: body.rentalId,
                reference_code: `${rental?.reference_code || 'UNKNOWN'}-PAYOUT`,
                payment_type: 'payout',
                 description: `Payout to lender for ${rental?.costume_snapshot?.name || 'Unknown Costume'}`,
                payment_method: 'gcash',
                payment_reference: body.gcashNumber,
                amount: body.amount.toFixed(2),   // number -> string
                currency: 'PHP',
                status: 'paid',
                processed_at: currentTime,
            });

            console.log('sendPayoutMoneyLender - Transaction committed successfully');
        });
        // Get updated rental to return current completion status
        const updatedRental = await db.select()
            .from(rentals)
            .where(eq(rentals.id, body.rentalId))
            .limit(1);

        const finalRental = updatedRental[0];

        return c.json({
            success: true,
            message: 'Payout processed successfully',
            data: {
                rentalId: body.rentalId,
                payoutAmount: body.amount,
                lenderId: body.lenderId,
                processedAt: payoutData.processedAt,
                rentalUpdated: true,
                rentalCompleted: bothCompleted,
                payoutData: payoutData,
                completionStatus: {
                    payoutCompleted: true,
                    refundCompleted: refundCompleted,
                    bothCompleted: bothCompleted,
                    payoutCompletedAt: finalRental?.payout_completed_at?.toISOString() || null,
                    refundCompletedAt: finalRental?.refund_completed_at?.toISOString() || null,
                    fullyCompletedAt: finalRental?.completed_at?.toISOString() || null
                }
            }
        });
    } catch (error: any) {
        console.error('Error in sendPayoutMoneyLender:', {
            message: error.message,
            stack: error.stack,
            name: error.name
        });

        return c.json({
            success: false,
            error: 'Failed to process payout',
            details: error.message || 'Unknown error occurred'
        }, 500);
    }
};

const sendRefundMoneyBorrower = async (c: Context): Promise<Response> => {
    try {
        const body: RefundPayload = await c.req.json();
        console.log('sendRefundMoneyBorrower - Received payload:', JSON.stringify(body, null, 2));

        // Validate required fields
        const requiredFields: (keyof RefundPayload)[] = ['rentalId', 'accountName', 'amount', 'gcashNumber', 'borrowerId'];
        const missingFields = requiredFields.filter(field => !body[field]);

        if (missingFields.length > 0) {
            console.error('sendRefundMoneyBorrower - Missing required fields:', missingFields);
            return c.json({
                success: false,
                error: 'Missing required fields',
                missingFields: missingFields
            }, 400);
        }

        // First, get the current rental data to check if refund was already processed
        const currentRental = await db.select()
            .from(rentals)
            .where(eq(rentals.id, body.rentalId))
            .limit(1);

        if (currentRental.length === 0) {
            console.error('sendRefundMoneyBorrower - Rental not found:', body.rentalId);
            return c.json({
                success: false,
                error: 'Rental not found'
            }, 404);
        }

        const rental = currentRental[0];

        // Check if refund was already processed
        if (rental?.security_deposit_refund_borrower?.status === 'completed' || rental?.refund_completed_at) {
            console.warn('sendRefundMoneyBorrower - Refund already processed for rental:', body.rentalId);
            return c.json({
                success: false,
                error: 'Refund has already been processed for this rental'
            }, 400);
        }

        const currentTime = new Date();

        // Prepare refund data - store all the request data
        const refundData = {
            accountName: body.accountName,
            amount: body.amount,
            gcashNumber: body.gcashNumber,
            borrowerId: body.borrowerId,
            notes: body.notes || '',
            processedAt: currentTime.toISOString(),
            status: 'completed' as const,
            transactionType: 'refund' as const
        };

        // Check if payout is already completed
        const payoutCompleted = !!(rental?.payout_cashout_lender?.status === 'completed' && rental?.payout_completed_at);

        // Both will be completed after this update (refund will be completed, check if payout is already completed)
        const bothCompleted = payoutCompleted;

        // Update the rental with refund data and completion timestamps
        const updateData: any = {
            security_deposit_refund_borrower: refundData,
            refund_completed_at: currentTime, // FORCE UPDATE - Always set refund completion timestamp
            updated_at: currentTime
        };

        // If both refund and payout are completed, mark rental as fully completed
        if (bothCompleted) {
            updateData.status = 'completed';
            updateData.completed_at = currentTime;
            console.log('sendRefundMoneyBorrower - Marking rental as fully completed (both payout and refund processed)');
        }

        // FORCE THE UPDATE - Use explicit transaction to ensure consistency
        await db.transaction(async (tx) => {
            // Update the rental record
            await tx.update(rentals)
                .set(updateData)
                .where(eq(rentals.id, body.rentalId));

            // Record refund in rental payment history for analytics and accounting
            await tx.insert(rentalPaymentHistory).values({
                rental_id: body.rentalId,
                reference_code: `${rental?.reference_code || 'UNKNOWN'}-REFUND`,
                payment_type: 'refund',
                description: `Security deposit refund to borrower for ${rental?.costume_snapshot?.name || 'Unknown Costume'}`,
                payment_method: 'gcash',               // simple default
                payment_reference: body.gcashNumber,   // where refund was sent
                amount: body.amount.toFixed(2),        // number -> string
                currency: 'PHP',
                status: 'refunded',
                processed_at: currentTime,
            });

            console.log('sendRefundMoneyBorrower - Transaction committed successfully');
        });

        console.log('sendRefundMoneyBorrower - Successfully processed refund and updated rental');

        // Get updated rental to verify and return current completion status
        const updatedRental = await db.select()
            .from(rentals)
            .where(eq(rentals.id, body.rentalId))
            .limit(1);

        const finalRental = updatedRental[0];

        // Verify the update was successful
        if (!finalRental?.refund_completed_at) {
            console.error('sendRefundMoneyBorrower - CRITICAL: Refund completion timestamp not set after update');
            // Force another update if needed
            await db.update(rentals)
                .set({
                    refund_completed_at: currentTime,
                    updated_at: new Date()
                })
                .where(eq(rentals.id, body.rentalId));
        }

        return c.json({
            success: true,
            message: 'Refund processed successfully',
            data: {
                rentalId: body.rentalId,
                refundAmount: body.amount,
                borrowerId: body.borrowerId,
                processedAt: refundData.processedAt,
                rentalUpdated: true,
                rentalCompleted: bothCompleted,
                refundData: refundData,
                completionStatus: {
                    payoutCompleted: payoutCompleted,
                    refundCompleted: true, // This should now be true
                    bothCompleted: bothCompleted,
                    payoutCompletedAt: finalRental?.payout_completed_at?.toISOString() || null,
                    refundCompletedAt: finalRental?.refund_completed_at?.toISOString() || currentTime.toISOString(),
                    fullyCompletedAt: finalRental?.completed_at?.toISOString() || null
                }
            }
        });
    } catch (error: any) {
        console.error('Error in sendRefundMoneyBorrower:', {
            message: error.message,
            stack: error.stack,
            name: error.name
        });

        return c.json({
            success: false,
            error: 'Failed to process refund',
            details: error.message || 'Unknown error occurred'
        }, 500);
    }
};




const getCompletedRentalsForAccounting = async (c: Context): Promise<any> => {
    try {
        // Extract pagination params from query (with defaults)
        const { page = '1', limit = '10' } = c.req.query();
        const pageNum = Math.max(1, parseInt(page, 10));
        const limitNum = Math.max(1, Math.min(100, parseInt(limit, 10)));
        const offset = (pageNum - 1) * limitNum;

        // ✅ Updated to fetch both 'returned' and 'completed' rentals for accounting
        const rentalResults = await db
            .select({
                id: rentals.id,
                reference_code: rentals.reference_code,
                rental_amount: rentals.rental_amount,
                security_deposit: rentals.security_deposit,
                total_amount: rentals.total_amount,
                extension_fee: rentals.extension_fee,
                damage_cost: rentals.damage_cost,
                delivered_at: rentals.delivered_at,
                returned_at: rentals.returned_at,
                completed_at: rentals.completed_at,
                actual_return_date: rentals.actual_return_date,
                initial_condition_notes: rentals.initial_condition_notes,
                return_condition_notes: rentals.return_condition_notes,
                start_date: rentals.start_date,
                end_date: rentals.end_date,
                extended_days: rentals.extended_days,
                damage_reported: rentals.damage_reported,
                pickup_location: rentals.pickup_location,
                delivery_method: rentals.delivery_method,

                // ✅ NEW FIELDS - Payout and refund completion timestamps
                payout_completed_at: rentals.payout_completed_at,
                refund_completed_at: rentals.refund_completed_at,

                // ✅ NEW FIELDS - Payout and refund details
                security_deposit_refund_borrower: rentals.security_deposit_refund_borrower,
                payout_cashout_lender: rentals.payout_cashout_lender,

                // Snapshots
                costume_snapshot: rentals.costume_snapshot,
                renter_snapshot: rentals.renter_snapshot,

                // GCash info
                payment_gcash_number: rentals.payment_gcash_number,
                refund_gcash_number: rentals.refund_gcash_number,
                refund_account_name: rentals.refund_account_name,

                // Status tracking
                status: rentals.status,
                accepted_at: rentals.accepted_at,
                accepted_by: rentals.accepted_by,
                delivered_by: rentals.delivered_by,
                returned_by: rentals.returned_by,

                // Timestamps
                created_at: rentals.created_at,
                updated_at: rentals.updated_at,
            })
            .from(rentals)
            .where(
                // ✅ Updated condition to include both 'returned' and 'completed' rentals
                sql`${rentals.status} IN ('returned', 'completed')`
            )
            .orderBy(desc(rentals.returned_at))
            .limit(limitNum)
            .offset(offset);

        if (!rentalResults.length) {
            return c.json({
                data: [],
                pagination: {
                    page: pageNum,
                    limit: limitNum,
                    total: 0,
                    totalPages: 0,
                    hasNext: false,
                    hasPrev: false,
                },
            });
        }

        // Get IDs of returned/completed rentals
        const rentalIds = rentalResults.map(r => r.id);

        // Fetch all payment records associated with those rentals
        const payments = await db
            .select({
                id: rentalPaymentHistory.id,
                rental_id: rentalPaymentHistory.rental_id,
                payment_type: rentalPaymentHistory.payment_type,
                amount: rentalPaymentHistory.amount,
                status: rentalPaymentHistory.status,
                currency: rentalPaymentHistory.currency,
                payment_method: rentalPaymentHistory.payment_method,
                payment_reference: rentalPaymentHistory.payment_reference,
                processed_at: rentalPaymentHistory.processed_at,
                description: rentalPaymentHistory.description,
                receipt_url: rentalPaymentHistory.receipt_url,
                receipt_number: rentalPaymentHistory.receipt_number,
                created_at: rentalPaymentHistory.created_at,
                updated_at: rentalPaymentHistory.updated_at,
            })
            .from(rentalPaymentHistory)
            .where(inArray(rentalPaymentHistory.rental_id, rentalIds));

        // Create payment lookup map
        const paymentMap = payments.reduce((acc: Record<string, any[]>, payment) => {
            if (!acc[payment.rental_id]) acc[payment.rental_id] = [];
            acc[payment.rental_id]?.push(payment);
            return acc;
        }, {});

        // Process each rental with complete financial details
        const rentalData = rentalResults.map((rental) => {
            if (!rental) return null; // Skip invalid rentals
            const payerPayments = paymentMap[rental.id] || [];

            // Calculate borrower payment summary
            let securityDepositPaid = "0";
            let rentalFeePaid = "0";
            let extensionFeePaid = "0";
            let damageFeePaid = "0";
            let refundAmount = "0";
            let totalPaidByBorrower = 0;
            let totalRefundedToBorrower = 0;

            payerPayments.forEach(payment => {
                const amount = parseFloat(payment.amount) || 0;
                if (payment.status === 'paid' || payment.status === 'succeeded') {
                    totalPaidByBorrower += amount;
                    switch (payment.payment_type) {
                        case 'security_deposit':
                            securityDepositPaid = payment.amount;
                            break;
                        case 'rental_fee':
                            rentalFeePaid = payment.amount;
                            break;
                        case 'extension_fee':
                            extensionFeePaid = payment.amount;
                            break;
                        case 'damage_fee':
                            damageFeePaid = payment.amount;
                            break;
                    }
                } else if (payment.status === 'refunded' || payment.status === 'partial_refund') {
                    totalRefundedToBorrower += amount;
                    if (payment.payment_type === 'refund') {
                        refundAmount = payment.amount;
                    }
                }
            });

            // ✅ NEW - Process refund details from database
            const refundDetails = rental.security_deposit_refund_borrower ? {
                processed: true,
                status: rental.security_deposit_refund_borrower.status || 'unknown',
                account_name: rental.security_deposit_refund_borrower.accountName,
                amount: rental.security_deposit_refund_borrower.amount,
                gcash_number: rental.security_deposit_refund_borrower.gcashNumber,
                borrower_id: rental.security_deposit_refund_borrower.borrowerId,
                notes: rental.security_deposit_refund_borrower.notes || '',
                processed_at: rental.security_deposit_refund_borrower.processedAt || null,
                transaction_type: rental.security_deposit_refund_borrower.transactionType || 'refund',
                completed_timestamp: rental.refund_completed_at
            } : {
                processed: false,
                status: 'pending',
                account_name: null,
                amount: 0,
                gcash_number: null,
                borrower_id: null,
                notes: '',
                processed_at: null,
                transaction_type: 'refund',
                completed_timestamp: null
            };

            // Borrower payment summary with refund details
            const borrowerPaymentSummary = {
                security_deposit_paid: securityDepositPaid,
                rental_fee_paid: rentalFeePaid,
                extension_fee_paid: extensionFeePaid,
                damage_fee_paid: damageFeePaid,
                total_paid: String(totalPaidByBorrower),
                total_refunded: String(totalRefundedToBorrower),
                refund_amount: refundAmount,
                // ✅ NEW - Detailed refund processing information
                refund_details: refundDetails
            };

            // Lender earnings calculation
            const rentalAmount = parseFloat(rental.rental_amount) || 0;
            const extensionFee = parseFloat(rental.extension_fee) || 0;
            const damageCost = parseFloat(rental.damage_cost) || 0;
            const securityDeposit = parseFloat(rental.security_deposit) || 0;

            // Lender gets rental fee + extension fee + damage charges
            const grossEarnings = rentalAmount + extensionFee + damageCost;

            // Security deposit handling
            const securityDepositToLender = rental.damage_reported
                ? Math.max(0, securityDeposit - damageCost)
                : securityDeposit;

            // If damage reported, portion of security deposit is held
            const securityDepositHeld = rental.damage_reported
                ? Math.min(securityDeposit, damageCost)
                : 0;

            // Net amount to transfer to lender
            const netEarningsToLender = grossEarnings + securityDepositToLender;

            // ✅ NEW - Process payout details from database
            const payoutDetails = rental.payout_cashout_lender ? {
                processed: true,
                status: rental.payout_cashout_lender.status || 'unknown',
                account_name: rental.payout_cashout_lender.accountName,
                amount: rental.payout_cashout_lender.amount,
                gcash_number: rental.payout_cashout_lender.gcashNumber,
                lender_id: rental.payout_cashout_lender.lenderId,
                notes: rental.payout_cashout_lender.notes || '',
                processed_at: rental.payout_cashout_lender.processedAt || null,
                transaction_type: rental.payout_cashout_lender.transactionType || 'payout',
                completed_timestamp: rental.payout_completed_at
            } : {
                processed: false,
                status: 'pending',
                account_name: null,
                amount: 0,
                gcash_number: null,
                lender_id: null,
                notes: '',
                processed_at: null,
                transaction_type: 'payout',
                completed_timestamp: null
            };

            // Lender earnings summary with payout details
            const lenderEarnings = {
                rental_fee: rental.rental_amount,
                extension_fee: rental.extension_fee,
                damage_charges: rental.damage_cost,
                gross_earnings: String(grossEarnings),
                security_deposit_received: String(securityDepositToLender),
                security_deposit_held: String(securityDepositHeld),
                net_earnings: String(netEarningsToLender),
                // ✅ NEW - Detailed payout processing information
                payout_details: payoutDetails
            };

            // Damage details
            const damageDetails = rental.damage_reported ? {
                reported: true,
                cost: rental.damage_cost,
                description: rental.return_condition_notes,
                initial_condition: rental.initial_condition_notes
            } : {
                reported: false,
                cost: "0",
                description: null,
                initial_condition: null
            };

            // ✅ ENHANCED - Timeline events with payout/refund completion
            const timeline = {
                current_status: rental.status,
                created: rental.created_at,
                accepted: rental.accepted_at,
                delivered: rental.delivered_at,
                returned: rental.returned_at,
                payout_completed: rental.payout_completed_at,
                refund_completed: rental.refund_completed_at,
                fully_completed: rental.completed_at,
                updated: rental.updated_at
            };

            // ✅ NEW - Overall completion status for easy UI handling
            const completionStatus = {
                is_fully_completed: rental.status === 'completed',
                payout_completed: !!rental.payout_completed_at,
                refund_completed: !!rental.refund_completed_at,
                both_completed: !!(rental.payout_completed_at && rental.refund_completed_at),
                pending_actions: {
                    payout_pending: !rental.payout_completed_at,
                    refund_pending: !rental.refund_completed_at
                }
            };

            return {
                id: rental.id,
                reference_code: rental.reference_code,
                timeline,
                status: rental.status,
                // ✅ NEW - Completion tracking for UI
                completion_status: completionStatus,
                amounts: {
                    rental_amount: rental.rental_amount,
                    security_deposit: rental.security_deposit,
                    extension_fee: rental.extension_fee,
                    damage_cost: rental.damage_cost,
                    total_amount: rental.total_amount
                },
                borrower: {
                    uid: rental.renter_snapshot?.uid || '',
                    name: rental.renter_snapshot?.name || 'Unknown Borrower',
                    email: rental.renter_snapshot?.email || 'No email',
                    phone: rental.renter_snapshot?.phone || '',
                    address: rental.renter_snapshot?.address || '',
                    payments: borrowerPaymentSummary // This now includes refund_details
                },
                lender: {
                    uid: rental.costume_snapshot?.lender_info?.uid || '',
                    name: rental.costume_snapshot?.lender_info?.name || 'Unknown Lender',
                    email: rental.costume_snapshot?.lender_info?.email || 'No email',
                    phone_number: rental.costume_snapshot?.lender_info?.phone || '',
                    earnings: lenderEarnings // This now includes payout_details
                },
                damage: damageDetails,
                location: {
                    pickup: rental.pickup_location,
                    method: rental.delivery_method
                },
                costume: {
                    id: rental.costume_snapshot?.id || '',
                    name: rental.costume_snapshot?.name || 'Unknown Costume',
                    brand: rental.costume_snapshot?.brand || '',
                    category: rental.costume_snapshot?.category || '',
                    sizes: rental.costume_snapshot?.sizes || '',
                    images: rental.costume_snapshot?.main_images || []
                },
                payments: payerPayments,
                payment_details: {
                    gcash_number: rental.payment_gcash_number,
                    refund_gcash_number: rental.refund_gcash_number,
                    refund_account_name: rental.refund_account_name
                },
                // ✅ NEW - Separate section for easy access to transaction details
                transaction_summary: {
                    payout: payoutDetails,
                    refund: refundDetails,
                    both_processed: !!(payoutDetails.processed && refundDetails.processed)
                },
                created_at: rental.created_at,
                updated_at: rental.updated_at,
            };
        }).filter(Boolean); // Remove null values from invalid rentals

        // ✅ Updated count query to include both statuses
        const totalCountResult = await db
            .select({ count: sql<number>`COUNT(*)` })
            .from(rentals)
            .where(sql`${rentals.status} IN ('returned', 'completed')`);

        const totalCount = Number(totalCountResult[0]?.count) || 0;

        // Calculate pagination metadata
        const totalPages = Math.ceil(totalCount / limitNum);
        const pagination = {
            page: pageNum,
            limit: limitNum,
            total: totalCount,
            totalPages,
            hasNext: pageNum < totalPages,
            hasPrev: pageNum > 1,
        };

        return c.json({
            data: rentalData,
            pagination,
        });
    } catch (error: any) {
        console.error('Error fetching completed rentals with payments:', error);
        return c.json({ error: 'Internal Server Error', message: error.message }, 500);
    }
};





/**
 * Gets a paginated list of rental rejections (cancelled rentals)
 */
const getRentalRejections = async (c: Context): Promise<any> => {
    try {
        // Extract pagination parameters from query
        const page = Math.max(1, Number(c.req.query('page')) || 1);
        const limit = Math.min(100, Math.max(1, Number(c.req.query('limit')) || 10));
        const offset = (page - 1) * limit;

        console.log(page, limit, offset);

        // Get total count of rejected rentals for pagination
        const totalCountResult = await db.select({
            count: count()
        })
            .from(rentals)
            .where(eq(rentals.status, 'cancelled'));

        const total = Number(totalCountResult[0]?.count || 0);
        const totalPages = Math.ceil(total / limit);

        // If no rejected rentals exist, return early with empty array
        if (total === 0) {
            return c.json({
                success: true,
                message: 'No rental rejections found',
                data: {
                    rejections: [],
                    pagination: { total: 0, page, limit, totalPages: 0 }
                }
            });
        }

        // Get the rejected rentals with pagination
        const rejectedRentals = await db.select({
            id: rentals.id,
            reference_code: rentals.reference_code,
            costume_id: rentals.costume_id,
            renter_uid: rentals.renter_uid,
            renter_snapshot: rentals.renter_snapshot,
            costume_snapshot: rentals.costume_snapshot,
            start_date: rentals.start_date,
            end_date: rentals.end_date,
            rental_amount: rentals.rental_amount,
            created_at: rentals.created_at,
            updated_at: rentals.updated_at,
            status: rentals.status
        })
            .from(rentals)
            .where(eq(rentals.status, 'cancelled'))
            .orderBy(desc(rentals.updated_at))
            .limit(limit)
            .offset(offset);

        // Format the data for the frontend
        const formattedRejections = rejectedRentals.map(rental => ({
            id: rental.id,
            reference_code: rental.reference_code,
            costume_id: rental.costume_id,
            renter_id: rental.renter_uid,
            costume_name: rental.costume_snapshot?.name ?? 'Unknown Costume',
            renter_name: rental.renter_snapshot?.name ?? 'Unknown Renter',
            renter_email: rental.renter_snapshot?.email ?? 'No email provided',
            rental_period: {
                start: rental.start_date,
                end: rental.end_date,
            },
            rental_amount: rental.rental_amount,
            requested_at: rental.created_at,
            rejected_at: rental.updated_at,
        }));

        return c.json({
            success: true,
            message: 'Rental rejections retrieved successfully',
            data: {
                rejections: formattedRejections,
                pagination: {
                    total,
                    page,
                    limit,
                    totalPages
                }
            }
        });
    } catch (error) {
        console.error('Error retrieving rental rejections:', error);
        return c.json({
            success: false,
            message: 'Failed to retrieve rental rejections',
            error: error instanceof Error ? error.message : 'Unknown error',
            data: null
        }, 500);
    }
};


/**
 * Gets a specific rental rejection (cancelled rental) by ID
 */
/* const getRentalRejectionById = async (c: Context): Promise<any> => {
    try {
        // Extract rental ID from URL parameters
        const rentalId = c.req.param('id');

        if (!rentalId) {
            return c.json({
                success: false,
                message: 'Rental ID is required',
                data: null
            }, 400);
        }

        // Get the specific cancelled rental by ID
        const rejectedRental = await db.select({
            id: rentals.id,
            reference_code: rentals.reference_code,
            costume_id: rentals.costume_id,
            renter_uid: rentals.renter_uid,
            renter_snapshot: rentals.renter_snapshot,
            costume_snapshot: rentals.costume_snapshot,
            start_date: rentals.start_date,
            end_date: rentals.end_date,
            actual_return_date: rentals.actual_return_date,
            rental_amount: rentals.rental_amount,
            security_deposit: rentals.security_deposit,
            total_amount: rentals.total_amount,
            extended_days: rentals.extended_days,
            extension_fee: rentals.extension_fee,
            status: rentals.status,
            initial_condition_notes: rentals.initial_condition_notes,
            return_condition_notes: rentals.return_condition_notes,
            damage_reported: rentals.damage_reported,
            damage_cost: rentals.damage_cost,
            pickup_location: rentals.pickup_location,
            delivery_method: rentals.delivery_method,
            special_instructions: rentals.special_instructions,
            notes: rentals.notes,
            created_at: rentals.created_at,
            updated_at: rentals.updated_at
        })
            .from(rentals)
            .where(eq(rentals.id, rentalId))
            .limit(1);

        // Check if rental exists
        if (!rejectedRental.length) {
            return c.json({
                success: false,
                message: 'Rental not found',
                data: null
            }, 404);
        }

        const rental = rejectedRental[0];

        // Check if the rental is actually cancelled/rejected
        if (rental.status !== 'cancelled') {
            return c.json({
                success: false,
                message: 'Rental is not cancelled/rejected',
                data: null
            }, 400);
        }

        // Format the data for the frontend
        const formattedRejection = {
            id: rental.id,
            reference_code: rental.reference_code,
            costume_id: rental.costume_id,
            renter_id: rental.renter_uid,
            costume_details: {
                id: rental.costume_snapshot?.id,
                name: rental.costume_snapshot?.name || 'Unknown Costume',
                brand: rental.costume_snapshot?.brand,
                category: rental.costume_snapshot?.category,
                sizes: rental.costume_snapshot?.sizes,
                rental_price: rental.costume_snapshot?.rental_price,
                security_deposit: rental.costume_snapshot?.security_deposit,
                main_images: rental.costume_snapshot?.main_images,
                lender_info: rental.costume_snapshot?.lender_info
            },
            renter_details: {
                uid: rental.renter_snapshot?.uid,
                name: rental.renter_snapshot?.name || 'Unknown Renter',
                email: rental.renter_snapshot?.email || 'No email provided',
                phone: rental.renter_snapshot?.phone,
                address: rental.renter_snapshot?.address
            },
            rental_period: {
                start: rental.start_date,
                end: rental.end_date,
                actual_return: rental.actual_return_date
            },
            pricing: {
                rental_amount: rental.rental_amount,
                security_deposit: rental.security_deposit,
                total_amount: rental.total_amount,
                extended_days: rental.extended_days,
                extension_fee: rental.extension_fee,
                damage_cost: rental.damage_cost
            },
            condition: {
                initial_notes: rental.initial_condition_notes,
                return_notes: rental.return_condition_notes,
                damage_reported: rental.damage_reported
            },
            logistics: {
                pickup_location: rental.pickup_location,
                delivery_method: rental.delivery_method,
                special_instructions: rental.special_instructions
            },
            status: rental.status,
            notes: rental.notes,
            timestamps: {
                requested_at: rental.created_at,
                rejected_at: rental.updated_at
            }
        };

        return c.json({
            success: true,
            message: 'Rental rejection retrieved successfully',
            data: {
                rejection: formattedRejection
            }
        });

    } catch (error) {
        console.error('Error retrieving rental rejection by ID:', error);
        return c.json({
            success: false,
            message: 'Failed to retrieve rental rejection',
            error: error instanceof Error ? error.message : 'Unknown error',
            data: null
        }, 500);
    }
}; */





export default {
    getRentalRejections,
    getCompletedRentalsForAccounting,
    sendRefundMoneyBorrower,
    sendPayoutMoneyLender
};