// db/db_connect.ts
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from 'postgres';
import { config } from "dotenv";
import * as schema from '../../schema/users';
import * as schemaCostumes from '../../schema/costumes';
import * as schemaRentals from '../../schema/rentals';
import * as schemaRentalPaymentHistory from '../../schema/rentals_payment_history';

// Load environment variables
config();

const connectionString = process.env.DATABASE_URL;

if (!connectionString) {
    throw new Error("DATABASE_URL is not set in .env file");
}

console.log("🔗 Initializing database connection...");

// Create postgres client with proper configuration
const sql = postgres(connectionString, {
    max: 20,
    idle_timeout: 30,
    connect_timeout: 30,
    ssl: 'require', // Required for Supabase
    onnotice: () => { }, // Suppress notices
    connection: {
        application_name: 'era',
        statement_timeout: 30000,
    },
    prepare: false,
});

// Initialize drizzle with postgres client and schema
const db = drizzle(sql, { schema: { ...schema, ...schemaCostumes, ...schemaRentals, ...schemaRentalPaymentHistory } });

export const testConnection = async () => {
    try {
        console.log("🔍 Testing database connection...");
        const result = await sql`SELECT NOW() as current_time, version() as version`;
        console.log("✅ Database connection successful!");
        console.log("📅 Server time:", result[0]?.current_time);
        console.log("🗄️ Database version:", result[0]?.version.split(' ')[0]);
        return true;
    } catch (error) {
        console.error("❌ Database connection failed:");
        console.error("Error details:", error);
        return false;
    }
};

// Graceful shutdown
process.on('SIGINT', async () => {
    console.log('\n🔄 Shutting down gracefully...');
    await sql.end();
    process.exit(0);
});

process.on('SIGTERM', async () => {
    console.log('\n🔄 Shutting down gracefully...');
    await sql.end();
    process.exit(0);
});

export { db, sql };
export default db;