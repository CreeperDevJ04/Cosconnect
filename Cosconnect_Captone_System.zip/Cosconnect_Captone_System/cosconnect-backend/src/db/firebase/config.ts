import * as dotenv from "dotenv";
import admin from "firebase-admin";
import { initializeApp } from 'firebase/app';
import { getAuth, signInWithEmailAndPassword } from "firebase/auth";

dotenv.config();

// Convert escaped newline characters in the private key to actual newlines
const privateKey = process.env.FIREBASE_ADMIN_PRIVATE_KEY?.replace(/\\n/g, "\n");

// Check if Firebase credentials are available
const hasFirebaseCredentials = privateKey && process.env.FIREBASE_ADMIN_PROJECT_ID && process.env.FIREBASE_ADMIN_CLIENT_EMAIL;



// Initialize admin SDK conditionally
let adminApp: admin.app.App | null = null;
if (hasFirebaseCredentials && !admin.apps.length) {
    adminApp = admin.initializeApp({
        credential: admin.credential.cert({
            projectId: process.env.FIREBASE_ADMIN_PROJECT_ID!,
            clientEmail: process.env.FIREBASE_ADMIN_CLIENT_EMAIL!,
            privateKey: privateKey!,
        }),
        storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
    });
}

// Initialize Firebase client conditionally
let clientApp: any = null;
let clientAuth: any = null;
let db: admin.firestore.Firestore | null = null;
let auth: admin.auth.Auth | null = null;
let storage: admin.storage.Storage | null = null;

if (hasFirebaseCredentials) {
    // Initialize Firebase client
    const firebaseConfig = {
        apiKey: process.env.FIREBASE_API_KEY,
        authDomain: process.env.FIREBASE_AUTH_DOMAIN,
        projectId: process.env.FIREBASE_PROJECT_ID,
        storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
        messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID,
        appId: process.env.FIREBASE_APP_ID,
        measurementId: process.env.FIREBASE_MEASUREMENT_ID
    };

    clientApp = initializeApp(firebaseConfig);
    clientAuth = getAuth(clientApp);

    db = adminApp!.firestore();
    auth = adminApp!.auth();
    storage = adminApp!.storage();
} else {
    console.warn("Connected");
}

export {
    auth, clientAuth, db, signInWithEmailAndPassword, storage
};
