"use server"

import { createClient } from '@/utils/supabase/server';
import { revalidatePath } from 'next/cache';
import { headers } from 'next/headers';
import { redirect } from 'next/navigation';
import nodemailer from 'nodemailer';
interface SignUpData {
    username: string;
    email: string;
    password: string;
    phoneNumber: string;
    role: "borrower";
    birth_date: string;
}

interface SignInData {
    email: string;
    password: string;
}

interface AuthResponse {
    status: "success" | "error";
    message: string;
    user?: any;
}

interface OtpData {
    email: string;
    otp: string;
}
// ============================================================================
// EMAIL CONFIGURATION
// ============================================================================
const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: process.env.EMAIL_USER || "cosconnectme@gmail.com",
        pass: process.env.EMAIL_PASSWORD || "",
    },
});

// ============================================================================
// EMAIL TEMPLATE SENDER
// ============================================================================
export const sendOtpEmail = async (email: string, otp: string): Promise<boolean> => {
    const mailOptions = {
        from: process.env.EMAIL_USER || "cosconnectme@gmail.com",
        to: email,
        subject: "Your OTP Code",
        html: `
            <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 480px; margin: auto;">
                <div style="text-align: center; margin-bottom: 20px;">
                    <h2 style="color: #333;">Email Verification</h2>
                </div>

                <p style="color: #555; font-size: 15px;">Hi there 👋,</p>
                <p style="color: #555; font-size: 15px;">
                    To complete your verification, please use the following one-time password (OTP):
                </p>

                <div style="background: #007bff; color: white; font-size: 32px; padding: 20px; text-align: center; border-radius: 8px; letter-spacing: 8px; margin: 20px 0;">
                    ${otp}
                </div>

                <p style="color: #666; font-size: 14px;">
                    This code will expire in <strong>10 minutes</strong>. Do not share this code with anyone for your account security.
                </p>

                <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;" />

                <p style="font-size: 12px; color: #999; text-align: center;">
                    © ${new Date().getFullYear()} CosConnect. All rights reserved.
                </p>
            </div>
        `,
    };

    try {
        await transporter.sendMail(mailOptions);
        return true;
    } catch (error) {
        console.error("❌ Failed to send OTP email:", error);
        return false;
    }
};

// ============================================================================
// HELPER: GENERATE OTP
// ============================================================================
const generateOTP = () => Math.floor(100000 + Math.random() * 900000).toString();

// ============================================================================
// SEND OTP CODE FUNCTION (USED BY FRONTEND)
// ============================================================================
export async function sendOtpCode(email: string) {
    const supabase = await createClient();

    try {
        // Generate OTP
        const otpCode = generateOTP();
        const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

        // Check if user exists
        const { data: existingUser } = await supabase
            .from("users")
            .select("email")
            .eq("email", email)
            .single();

        if (!existingUser) {
            return {
                success: false,
                error: "No account found with this email",
            };
        }

        // Delete any existing OTP for this email
        await supabase.from("otp_codes").delete().eq("email", email);

        // Insert new OTP
        const { error: insertError } = await supabase.from("otp_codes").insert({
            email,
            otp_code: otpCode,
            expires_at: expiresAt.toISOString(),
            created_at: new Date().toISOString(),
        });

        if (insertError) {
            console.error("❌ Error inserting OTP:", insertError);
            return {
                success: false,
                error: "Failed to generate verification code",
            };
        }

        // ✅ Send OTP Email using Nodemailer
        const emailSent = await sendOtpEmail(email, otpCode);
        if (!emailSent) {
            return {
                success: false,
                error: "Failed to send OTP email",
            };
        }

        return {
            success: true,
            message: "Verification code sent successfully",
        };
    } catch (error) {
        console.error("❌ Error sending OTP:", error);
        return {
            success: false,
            error: "An unexpected error occurred",
        };
    }
}
// ============================================================
// OTP FUNCTIONS
// ============================================================

/**
 * Verify OTP code
 */
export async function verifyOtpCode(data: OtpData) {
    const supabase = await createClient();

    try {
        // Get OTP record
        const { data: otpRecord, error: fetchError } = await supabase
            .from('otp_codes')
            .select('*')
            .eq('email', data.email)
            .eq('otp_code', data.otp)
            .single();

        if (fetchError || !otpRecord) {
            return {
                success: false,
                error: 'Invalid verification code'
            };
        }

        // Check if OTP is expired
        const isExpired = new Date(otpRecord.expires_at) < new Date();
        if (isExpired) {
            // Delete expired OTP
            await supabase
                .from('otp_codes')
                .delete()
                .eq('email', data.email);

            return {
                success: false,
                error: 'Verification code has expired'
            };
        }

        // Delete used OTP
        await supabase
            .from('otp_codes')
            .delete()
            .eq('email', data.email);

        return {
            success: true,
            message: 'Verification successful'
        };

    } catch (error) {
        console.error('Error verifying OTP:', error);
        return {
            success: false,
            error: 'An unexpected error occurred'
        };
    }
}

/**
 * Resend email verification link
 * @param email The email address to resend verification to
 */
export async function resendVerificationEmail(email: string) {
    const supabase = await createClient();

    try {
        // First check if the email exists in the auth.users table
        const { data: userData, error: userError } = await supabase
            .from('users')
            .select('email_confirmed')
            .eq('email', email)
            .single();

        if (userError || !userData) {
            return {
                success: false,
                error: "No account found with this email"
            };
        }

        // Check if email is already confirmed
        if (userData.email_confirmed) {
            return {
                success: false,
                error: "Email is already verified"
            };
        }

        // Resend verification email using Supabase Auth
        const { error } = await supabase.auth.resend({
            type: 'signup',
            email: email,
            options: {
                emailRedirectTo: `${process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"}/auth/callback`
            }
        });

        if (error) {
            console.error('Error resending verification email:', error);
            return {
                success: false,
                error: error.message
            };
        }

        return {
            success: true,
            message: "Verification email resent successfully"
        };

    } catch (error) {
        console.error('Unexpected error in resendVerificationEmail:', error);
        return {
            success: false,
            error: "An unexpected error occurred"
        };
    }
}

/**
 * Resend OTP code (alias of sendOtpCode)
 */
export async function resendOtpCode(email: string) {
    return await sendOtpCode(email);
}



// NEW FUNCTION: Validate credentials without signing in
export async function validateCredentials(formData: SignInData) {
    const supabase = await createClient();

    try {
        // Attempt to sign in to validate credentials
        const { error, data } = await supabase.auth.signInWithPassword({
            email: formData.email,
            password: formData.password
        });

        if (error) {
            console.error('Credential validation error:', error);
            return {
                valid: false,
                status: error.message,
                error: error.message
            };
        }

        // If successful, immediately sign out (we're only validating)
        await supabase.auth.signOut();

        return {
            valid: true,
            status: "Credentials validated",
            userId: data.user.id
        };

    } catch (error) {
        console.error('Unexpected error during credential validation:', error);
        return {
            valid: false,
            status: 'An unexpected error occurred',
            error: 'An unexpected error occurred'
        };
    }
}



export async function signIn(formData: SignInData) {
    const supabase = await createClient();

    try {
        // Sign in
        const { error: authError, data: authData } = await supabase.auth.signInWithPassword({
            email: formData.email,
            password: formData.password
        });

        if (authError) return { status: authError.message, user: null };

        const uid = authData.user.id;

        // Check if user exists
        let { data: user, error: fetchError } = await supabase
            .from("users")
            .select("*")
            .eq("uid", uid)
            .single();

        if (fetchError && fetchError.code !== "PGRST116") {
            // PGRST116 = no rows found
            console.error("Error fetching user:", fetchError);
            return { status: fetchError.message, user: null };
        }

        // Create user if doesn't exist
        if (!user) {
            const username =
                authData.user.user_metadata?.username ||
                authData.user.email?.split("@")[0] ||
                `user_${Math.random().toString(36).substring(2, 10)}`;

            const newUser = {
                uid,
                id: crypto.randomUUID(),
                username,
                email: authData.user.email!,
                phone_number: authData.user.user_metadata?.phone_number || authData.user.phone || '',
                role: ['borrower'],
                current_role: 'borrower',
                status: 'active',
                is_online: true,
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString(),
                profile_image: "https://img.freepik.com/premium-vector/default-avatar-profile-icon-social-media-user-image-gray-avatar-icon-blank-profile-silhouette-vector-illustration_561158-3383.jpg?semt=ais_hybrid&w=740&q=80"
            };

            const { error: insertError } = await supabase.from("users").insert(newUser);
            if (insertError) return { status: insertError.message, user: null };
            user = newUser;
        } else {
            // Update is_online for existing user
            await supabase
                .from("users")
                .update({ is_online: true, updated_at: new Date().toISOString() })
                .eq("uid", uid);
        }

        return { status: "success", user };
    } catch (err) {
        console.error("Unexpected error:", err);
        return { status: "An unexpected error occurred", user: null };
    }
}


export async function signUp(formData: SignUpData): Promise<AuthResponse> {

    const supabase = await createClient();

    // Check if username exists
    const { data: existingUser, error: checkError } = await supabase
        .from("users")
        .select("id") // selecting id is enough
        .eq("username", formData.username.toLowerCase())
        .maybeSingle();

    if (checkError) {
        return { status: "error", message: "Error checking username availability" };
    }

    if (existingUser) {
        return { status: "error", message: "Username already taken" };
    }

    // Sign up with Supabase Auth
    const { data: authData, error } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
    });

    if (error) {
        return { status: "error", message: error.message };
    }

    if (!authData.user) {
        return { status: "error", message: "Sign-up failed, no user returned" };
    }

    if (authData.user.identities?.length === 0) {
        return { status: "error", message: "User with this email already exists" };
    }

    // Prepare userData for table
    const userData = {
        uid: authData.user.id,
        username: formData.username.toLowerCase(),
        email: formData.email,
        phone_number: formData.phoneNumber,
        profile_image: "https://img.freepik.com/premium-vector/default-avatar-profile-icon-social-media-user-image-gray-avatar-icon-blank-profile-silhouette-vector-illustration_561158-3383.jpg?semt=ais_hybrid&w=740&q=80",
        role: ["borrower"],
        birth_date: formData.birth_date,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
    };

    // Insert into users table
    const { error: insertError } = await supabase.from("users").insert(userData);

    if (insertError) {
        console.error("Insert error:", insertError);
        return { status: "error", message: "Failed to insert user record" };
    }

    revalidatePath("/", "layout");
    return { status: "success", message: "User created", user: userData };
}


export async function getUserSession() {
    const supabase = await createClient()

    const { data: { user }, error } = await supabase.auth.getUser();

    if (error || !user) {
        return null;
    }

    // Return user without modifying it, role is in user_metadata
    return {
        status: "success",
        user
    };
}



export async function signOut() {
    const supabase = await createClient();
    const { error } = await supabase.auth.signOut();
    if (error) {
        console.error('Sign out error:', error);
        redirect("/error");
    }
    revalidatePath("/", "layout");
    redirect("/signin");
}

export async function resendEmailConfirmation(email: string) {
    try {
        const supabase = await createClient();

        const { error } = await supabase.auth.resend({
            type: 'signup',
            email: email,
        });

        if (error) {
            return {
                status: 'error',
                message: error.message
            };
        }

        return {
            status: 'success',
            message: 'Confirmation email has been resent successfully'
        };
    } catch (error: any) {
        return {
            status: 'error',
            message: error.message || 'Failed to resend confirmation email'
        };
    }
}

export async function forgotPassword(email: string): Promise<AuthResponse> {
    try {
        const supabase = await createClient();
        const origin = (await headers()).get("origin");

        if (!origin) {
            return {
                status: "error",
                message: "Could not determine origin URL"
            };
        }

        const { error } = await supabase.auth.resetPasswordForEmail(email, {
            redirectTo: `${origin}/reset-password`
        });

        if (error) {
            return {
                status: "error",
                message: error.message
            };
        }

        return {
            status: "success",
            message: "Password reset instructions have been sent to your email"
        };
    } catch (error: any) {
        return {
            status: "error",
            message: error?.message || "An unexpected error occurred"
        };
    }
}

export async function resetPassword(newPassword: string, code: string): Promise<AuthResponse> {
    try {
        const supabase = await createClient();

        // First verify the code
        const { error: codeError, data } = await supabase.auth.exchangeCodeForSession(code);

        if (codeError) {
            return {
                status: "error",
                message: "Invalid or expired reset code"
            };
        }

        // Then update the password
        const { error: updateError } = await supabase.auth.updateUser({
            password: newPassword
        });

        if (updateError) {
            return {
                status: "error",
                message: updateError.message
            };
        }

        return {
            status: "success",
            message: "Password has been reset successfully",
            user: data?.user
        };
    } catch (error: any) {
        return {
            status: "error",
            message: error?.message || "An unexpected error occurred"
        };
    }
}

export async function signInWithGoogle() {
    try {
        const origin = (await headers()).get("origin");

        // Enhanced origin validation
        if (!origin) {
            console.error("No origin header found");
            throw new Error("Could not determine origin URL");
        }

        const supabase = await createClient();

        const { data, error } = await supabase.auth.signInWithOAuth({
            provider: "google",
            options: {
                redirectTo: `${origin}/auth/callback`,
                queryParams: {
                    access_type: 'offline',
                    prompt: 'select_account login',
                },
                scopes: 'openid email profile'
            }
        });


        if (error) {
            console.error("Google OAuth error:", error);
            throw new Error(`Google OAuth failed: ${error.message}`);
        }

        if (!data?.url) {
            console.error("No OAuth URL received from Supabase");
            throw new Error("No OAuth URL received from Supabase");
        }


        return {
            success: true,
            url: data.url
        };

    } catch (error) {
        console.error("Error in signInWithGoogle:", error);
        throw error;
    }
}

