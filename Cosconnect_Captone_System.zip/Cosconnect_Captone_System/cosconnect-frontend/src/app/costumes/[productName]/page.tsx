"use client"
import CostumeDetailViewer from '@/components/MarketPlace/Costume/CostumeProductInfoSection';



const ProductNamePage = () => {
    return (
        <>
            <CostumeDetailViewer />
        </>
    )
}

export default ProductNamePage