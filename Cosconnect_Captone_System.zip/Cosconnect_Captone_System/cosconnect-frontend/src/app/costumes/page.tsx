import MarketPlaceSection from '@/components/MarketPlace/MarketPlaceSection'

const CostumePage = () => {
    return <MarketPlaceSection />
}

export default CostumePage  