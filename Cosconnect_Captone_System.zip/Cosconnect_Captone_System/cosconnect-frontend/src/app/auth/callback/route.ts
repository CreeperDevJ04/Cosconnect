import { NextResponse } from 'next/server'
import { createClient } from '@/utils/supabase/server'

export async function GET(request: Request) {
    const { searchParams, origin } = new URL(request.url)
    const code = searchParams.get('code')
    const error = searchParams.get('error')
    const errorDescription = searchParams.get('error_description')

    let next = searchParams.get('next') ?? '/'
    if (!next.startsWith('/')) next = '/'

    // Handle OAuth errors
    if (error) {
        const errorParams = new URLSearchParams({
            error_type: 'oauth_provider_error',
            error_code: error,
            error_message: errorDescription || 'OAuth provider returned an error',
            timestamp: new Date().toISOString()
        })
        return NextResponse.redirect(`${origin}/error?${errorParams.toString()}`)
    }

    if (!code) {
        const errorParams = new URLSearchParams({
            error_type: 'missing_code',
            error_code: 'NO_AUTH_CODE',
            error_message: 'No authorization code received from OAuth provider',
            timestamp: new Date().toISOString()
        })
        return NextResponse.redirect(`${origin}/error?${errorParams.toString()}`)
    }

    try {
        const supabase = await createClient()
        const { data, error: sessionError } = await supabase.auth.exchangeCodeForSession(code)

        if (sessionError || !data?.user) {
            const errorParams = new URLSearchParams({
                error_type: 'session_exchange_failed',
                error_code: sessionError?.status?.toString() || 'NO_USER',
                error_message: sessionError?.message || 'Failed to exchange code or no user data',
                timestamp: new Date().toISOString()
            })
            return NextResponse.redirect(`${origin}/error?${errorParams.toString()}`)
        }

        const user = data.user

        // Check if user exists
        const { data: existingUser, error: selectError } = await supabase
            .from("users")
            .select("*")
            .eq("uid", user.id)
            .maybeSingle()

        if (selectError) {
            const errorParams = new URLSearchParams({
                error_type: 'database_select_error',
                error_code: selectError.code || 'DB_SELECT_ERROR',
                error_message: `Failed to check existing user: ${selectError.message}`,
                timestamp: new Date().toISOString()
            })
            return NextResponse.redirect(`${origin}/error?${errorParams.toString()}`)
        }

        if (!existingUser) {
            // Create new user
            const { user_metadata = {} } = user
            const email = user_metadata?.email || user.email || ''
            let username = user_metadata?.username || email.split('@')[0] || `user_${Math.random().toString(36).substring(2, 10)}`
            username = username.toLowerCase().replace(/[^a-z0-9_]/g, '_')

            const fullName = user_metadata?.full_name || user_metadata?.name || ''
            let firstName = user_metadata?.first_name || ''
            let lastName = user_metadata?.last_name || ''
            if (!firstName && fullName) {
                const nameParts = fullName.split(' ')
                firstName = nameParts[0] || ''
                lastName = nameParts.slice(1).join(' ') || ''
            }

            const userData = {
                uid: user.id,
                id: crypto.randomUUID(),
                username,
                email,
                phone_number: user_metadata?.phone_number || user.phone || '',
                full_name: fullName,
                first_name: firstName,
                last_name: lastName,
                profile_image: user_metadata?.picture || user_metadata?.avatar_url || '',
                role: ['borrower'],
                current_role: 'borrower',
                status: 'active',
                is_online: true, // <-- Set online for new user
                email_verified: !!user.email_confirmed_at,
                phone_verified: !!user.phone_confirmed_at,
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString()
            }

            const { error: insertError } = await supabase.from("users").insert(userData)
            if (insertError) {
                const errorParams = new URLSearchParams({
                    error_type: 'database_insert_error',
                    error_code: insertError.code || 'DB_INSERT_ERROR',
                    error_message: `Failed to create user record: ${insertError.message}`,
                    timestamp: new Date().toISOString()
                })
                return NextResponse.redirect(`${origin}/error?${errorParams.toString()}`)
            }

            // Update user metadata role
            await supabase.auth.updateUser({ data: { role: 'borrower' } })
        } else {
            // Existing user: set is_online = true
            await supabase
                .from("users")
                .update({ is_online: true, updated_at: new Date().toISOString() })
                .eq("uid", user.id)
        }

        // Redirect logic
        const forwardedHost = request.headers.get('x-forwarded-host')
        const isLocalEnv = process.env.NODE_ENV === 'development'
        if (isLocalEnv) return NextResponse.redirect(`${origin}${next}`)
        if (forwardedHost) return NextResponse.redirect(`https://${forwardedHost}${next}`)
        return NextResponse.redirect(`${origin}${next}`)

    } catch (error) {
        const errorParams = new URLSearchParams({
            error_type: 'unexpected_error',
            error_code: 'INTERNAL_ERROR',
            error_message: error instanceof Error ? error.message : 'An unexpected error occurred',
            timestamp: new Date().toISOString()
        })
        return NextResponse.redirect(`${origin}/error?${errorParams.toString()}`)
    }
}
