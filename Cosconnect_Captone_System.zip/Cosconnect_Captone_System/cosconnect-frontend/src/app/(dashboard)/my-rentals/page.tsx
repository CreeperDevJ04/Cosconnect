'use client'

import { MyRentalsSection } from "@/components/MyRentals/components/MyRentalSection"
import { useSupabaseAuth } from "@/lib/hooks/useSupabaseAuth"
import { Loader2 } from "lucide-react"
import { Suspense } from "react"

export default function Page() {
    // Replace with actual user ID from auth context
    const { user } = useSupabaseAuth()
    return (
        <Suspense fallback={<Loader2 className="animate-spin -ml-1 mr-3 h-5 w-5" />}>
            <MyRentalsSection userId={user?.id as string} />
        </Suspense>
    )
}
