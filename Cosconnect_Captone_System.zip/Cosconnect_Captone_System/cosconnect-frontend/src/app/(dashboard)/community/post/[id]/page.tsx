"use client";

import { useParams, useRouter } from "next/navigation";
import { useGetAllPosts } from "@/lib/api/communityApi";
import { useSupabaseAuth } from "@/lib/hooks/useSupabaseAuth";
import PostCard from "@/components/SocialFeed/components/PostCard";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Loader2 } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { AlertCircle } from "lucide-react";

const SingleCommunityPostPage = () => {
    const params = useParams<{ id: string }>();
    const router = useRouter();
    const { userData, isLoading: isAuthLoading } = useSupabaseAuth();

    const postId = useMemo(() => {
        const id = Array.isArray(params?.id) ? params.id[0] : params?.id;
        return (id || "").toString();
    }, [params?.id]);

    const { allPosts, isLoading, error, refetch, isRefetching } = useGetAllPosts({
        limit: 1,
        page: 1,
        postId,
        user_id: userData?.user_id,
        user_role: userData?.current_role,
    });

    const post = allPosts?.[0];

    // Show a professional alert when the post does not exist
    const [showNotFound, setShowNotFound] = useState(false);
    useEffect(() => {
        if (!isLoading && !error && postId && !post) {
            setShowNotFound(true);
        } else {
            setShowNotFound(false);
        }
    }, [isLoading, error, postId, post]);

    if (!postId) {
        return (
            <div className="w-full max-w-2xl mx-auto py-10 px-4">
                <div className="flex items-center gap-3 mb-6">
                    <Button variant="ghost" size="icon" onClick={() => router.back()}>
                        <ArrowLeft className="h-5 w-5" />
                    </Button>
                    <h1 className="text-xl font-semibold">Post</h1>
                </div>
                <p className="text-sm text-muted-foreground">Invalid post id.</p>
            </div>
        );
    }

    if (isAuthLoading || (isLoading && !post)) {
        return (
            <div className="w-full max-w-2xl mx-auto py-10 px-4 flex items-center justify-center h-64">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
        );
    }

    if (error) {
        return (
            <div className="w-full max-w-2xl mx-auto py-10 px-4">
                <div className="flex items-center gap-3 mb-6">
                    <Button variant="ghost" size="icon" onClick={() => router.back()}>
                        <ArrowLeft className="h-5 w-5" />
                    </Button>
                    <h1 className="text-xl font-semibold">Post</h1>
                </div>
                <div className="rounded-md border p-4">
                    <p className="text-sm text-red-600">Failed to load post. Please try again.</p>
                    <div className="mt-3">
                        <Button onClick={() => refetch()} disabled={isRefetching}>
                            {isRefetching ? (
                                <>
                                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                    Retrying...
                                </>
                            ) : (
                                "Retry"
                            )}
                        </Button>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="w-full max-w-2xl mx-auto py-6 px-4">
            <div className="flex items-center gap-3 mb-4">
                <Button variant="ghost" size="icon" onClick={() => router.back()}>
                    <ArrowLeft className="h-5 w-5" />
                </Button>
                <h1 className="text-xl font-semibold">Post</h1>
            </div>

            {!post ? (
                <>
                    <div className="rounded-md border p-6 text-sm text-muted-foreground bg-white">
                        Post not found or may have been removed.
                    </div>

                    <AlertDialog open={showNotFound} onOpenChange={setShowNotFound}>
                        <AlertDialogContent>
                            <AlertDialogHeader>
                                <AlertDialogTitle className="flex items-center gap-2">
                                    <AlertCircle className="h-5 w-5 text-amber-600" />
                                    Post unavailable
                                </AlertDialogTitle>
                                <AlertDialogDescription>
                                    We couldn’t find this post. It may have been deleted by the author or removed by a moderator. You can return to the previous page or browse the latest posts in the community feed.
                                </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                                <AlertDialogCancel onClick={() => router.back()}>Go back</AlertDialogCancel>
                                <AlertDialogAction onClick={() => router.push("/community")}>View community feed</AlertDialogAction>
                            </AlertDialogFooter>
                        </AlertDialogContent>
                    </AlertDialog>
                </>
            ) : (
                <PostCard post={post} refetch={refetch} />
            )}
        </div>
    );
};

export default SingleCommunityPostPage;