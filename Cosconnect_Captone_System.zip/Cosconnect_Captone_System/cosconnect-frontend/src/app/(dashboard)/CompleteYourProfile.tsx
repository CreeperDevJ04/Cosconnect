"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import type { UserPersonalInfo } from "@/lib/types/userType"
import { uploadImage } from "@/utils/supabase/fileUpload"
import { zodResolver } from "@hookform/resolvers/zod"
import { X, Upload, Camera } from "lucide-react"
import { useState } from "react"
import { useForm } from "react-hook-form"
import * as z from "zod"
import selfieWithId from "../../../public/images/selfiewithid.jpg"
import Image from "next/image"
import { AddressInformationSection } from "@/components/Lender/SignUpForms/AddressInformation"

const phoneRegex = /^9\d{9}$/

const profileSchema = z.object({
    first_name: z.string().min(2, "Minimum 2 characters").max(50, "Maximum 50 characters"),
    middle_name: z.string().max(50, "Maximum 50 characters").optional().nullable(),
    last_name: z.string().min(2, "Minimum 2 characters").max(50, "Maximum 50 characters"),
    birth_date: z.string().min(1, "Birth date is required"),
    phone_number: z
        .string()
        .regex(phoneRegex, "Must start with 9 and be 10 digits")
        .optional()
        .nullable()
        .or(z.literal("")),
    bio: z.string().max(500, "Maximum 500 characters").optional().nullable(),

    region: z.string().min(1, "Region is required"),
    province: z.string().optional(),
    city: z.string().optional(),
    barangay: z.string().optional(),
    street_address: z.string().max(200, "Maximum 200 characters").optional().nullable(),
    postal_code: z
        .string()
        .regex(/^\d{4}$/, "Must be 4 digits")
        .optional()
        .nullable()
        .or(z.literal("")),

    // Images
    profile_image: z.instanceof(File).optional().nullable(),
    profile_background: z.instanceof(File).optional().nullable(),

    validIdType: z.string().min(1, "ID type is required"),
    validIdNumber: z.string().min(1, "ID number is required"),
    validIdImage: z.instanceof(File).refine((file) => file !== null && file !== undefined, "Valid ID image is required"),
    selfieWithIdImage: z
        .instanceof(File)
        .refine((file) => file !== null && file !== undefined, "Selfie with ID is required"),
})

type ProfileFormData = z.infer<typeof profileSchema>

interface CompleteProfileModalProps {
    open: boolean
    personalInfo: Partial<UserPersonalInfo>
    onSubmit: (data: any) => Promise<void>
    isLoading?: boolean
    username: string
}

const formatIdByType = (type: string, value: string) => {
    const cleaned = value.replace(/\D/g, "")
    if (type === "NATIONAL_ID") {
        const parts = cleaned.match(/.{1,4}/g) || []
        return parts.join("-").substring(0, 19)
    }
    return cleaned
}

export const CompleteProfileModal = ({
    open,
    personalInfo,
    onSubmit,
    username,
    isLoading = false,
}: CompleteProfileModalProps) => {
    const [isSubmitting, setIsSubmitting] = useState(false)
    const [previewImage, setPreviewImage] = useState<string | null>(null)
    const [previewBackground, setPreviewBackground] = useState<string | null>(null)
    const [previewValidId, setPreviewValidId] = useState<string | null>(null)
    const [previewSelfieWithId, setPreviewSelfieWithId] = useState<string | null>(null)
    const [uploadProgress, setUploadProgress] = useState<string | null>(null)

    const form = useForm<ProfileFormData>({
        resolver: zodResolver(profileSchema),
        defaultValues: {
            first_name: personalInfo?.first_name === username ? "" : personalInfo?.first_name || "",
            middle_name: personalInfo?.middle_name || "",
            last_name: personalInfo?.last_name === username ? "" : personalInfo?.last_name || "",
            birth_date: personalInfo?.birth_date || "",
            phone_number: personalInfo?.phone_number || "",
            bio: personalInfo?.bio || "",

            region: "",
            province: "",
            city: "",
            barangay: "",
            street_address: "",
            postal_code: "",

            validIdType: "",
            validIdNumber: "",
            validIdImage: undefined,
            selfieWithIdImage: undefined,
        },
        mode: "onBlur",
    })

    const {
        register,
        handleSubmit,
        formState: { errors },
        reset,
        watch,
        setValue,
    } = form

    const bioValue = watch("bio")
    const phoneValue = watch("phone_number")
    const validIdType = watch("validIdType")
    const validIdNumber = watch("validIdNumber")

    // Image handlers
    const createImagePreview = (file: File, setPreview: (url: string) => void) => {
        const reader = new FileReader()
        reader.onloadend = () => setPreview(reader.result as string)
        reader.readAsDataURL(file)
    }

    const handleImageChange = (
        e: React.ChangeEvent<HTMLInputElement>,
        fieldName: keyof ProfileFormData,
        setPreview: (url: string | null) => void,
    ) => {
        const file = e.target.files?.[0]
        if (file) {
            setValue(fieldName, file as any, { shouldValidate: true })
            createImagePreview(file, setPreview)
        }
    }

    const removeImage = (fieldName: keyof ProfileFormData, setPreview: (url: string | null) => void) => {
        setValue(fieldName, undefined as any, { shouldValidate: true })
        setPreview(null)
    }

    const handlePhoneInput = (e: React.ChangeEvent<HTMLInputElement>) => {
        let value = e.target.value.replace(/\D/g, "")
        if (value.length > 0 && value[0] !== "9") {
            value = "9" + value.substring(1)
        }
        value = value.substring(0, 10)
        setValue("phone_number", value, { shouldValidate: true })
    }

    const handleIdNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const formatted = formatIdByType(validIdType, e.target.value)
        setValue("validIdNumber", formatted, { shouldValidate: true })
    }

    const prepareData = async (formData: ProfileFormData) => {
        const uploadedUrls: any = {}
        const uploadedFiles: any = {}

        const uploads = [
            { file: formData.profile_image, key: "profile_image_url", folder: "profile_images", name: "profile" },
            {
                file: formData.profile_background,
                key: "profile_background_url",
                folder: "profile_backgrounds",
                name: "background",
            },
            { file: formData.validIdImage, key: "valid_id_image_url", folder: "valid_ids", name: "valid_id" },
            {
                file: formData.selfieWithIdImage,
                key: "selfie_with_id_url",
                folder: "selfie_with_ids",
                name: "selfie_with_id",
            },
        ]

        for (const upload of uploads) {
            if (upload.file) {
                try {
                    setUploadProgress(`Uploading ${upload.name}...`)
                    const result = await uploadImage({
                        file: upload.file,
                        customFileName: `${upload.name}_${Date.now()}`,
                        folder: upload.folder,
                    })

                    if (result.error) throw new Error(result.error)
                    uploadedUrls[upload.key] = result.url
                    // Store file path for extracting file name
                    if (result.filePath) {
                        uploadedFiles[upload.key] = {
                            url: result.url,
                            filePath: result.filePath,
                            fileName: result.filePath.split('/').pop() || null,
                        }
                    }
                } catch (error) {
                    console.error(`${upload.name} upload failed:`, error)
                    throw new Error(`Failed to upload ${upload.name}`)
                }
            }
        }

        setUploadProgress(null)

        // Prepare documents array for VALID_ID and SELFIE_WITH_ID
        const documents: any[] = []

        // Add VALID_ID document
        if (uploadedFiles.valid_id_image_url && formData.validIdType && formData.validIdNumber) {
            documents.push({
                document_type: "VALID_ID",
                id_type: formData.validIdType,
                id_number: formData.validIdNumber,
                file_url: uploadedFiles.valid_id_image_url.url,
                file_name: uploadedFiles.valid_id_image_url.fileName,
            })
        }

        // Add SELFIE_WITH_ID document
        if (uploadedFiles.selfie_with_id_url && formData.validIdType && formData.validIdNumber) {
            documents.push({
                document_type: "SELFIE_WITH_ID",
                id_type: formData.validIdType,
                id_number: formData.validIdNumber,
                file_url: uploadedFiles.selfie_with_id_url.url,
                file_name: uploadedFiles.selfie_with_id_url.fileName,
            })
        }

        return {
            first_name: formData.first_name,
            middle_name: formData.middle_name || null,
            last_name: formData.last_name,
            birth_date: formData.birth_date,
            phone_number: formData.phone_number ? `+63${formData.phone_number}` : null,
            bio: formData.bio || null,

            // Address information
            region: formData.region,
            province: formData.province || null,
            municipal_city: formData.city || null,
            barangay: formData.barangay || null,
            street_address: formData.street_address || null,
            postal_code: formData.postal_code || null,

            // Profile images
            profile_image: uploadedUrls.profile_image_url || null,
            profile_background: uploadedUrls.profile_background_url || null,

            // Documents array
            documents: documents,
        }
    }

    const handleFormSubmit = async (data: ProfileFormData) => {
        setIsSubmitting(true)
        try {
            const preparedData = await prepareData(data)
            await onSubmit(preparedData)
            reset()
            setPreviewImage(null)
            setPreviewBackground(null)
            setPreviewValidId(null)
            setPreviewSelfieWithId(null)
        } catch (error) {
            console.error("Error submitting profile:", error)
            alert(error instanceof Error ? error.message : "Failed to update profile. Please try again.")
        } finally {
            setIsSubmitting(false)
        }
    }

    return (
        <Dialog open={open} onOpenChange={() => { }}>
            <DialogContent
                showCloseButton={false}
                className="w-[95vw] sm:w-[90vw] md:w-[85vw] lg:w-4xl max-h-[90vh] p-4 sm:p-6 overflow-hidden flex flex-col"
            >
                <DialogHeader className="mb-3 sm:mb-4 flex-shrink-0">
                    <DialogTitle className="text-xl sm:text-2xl font-bold">Complete Your Profile</DialogTitle>
                    <DialogDescription className="text-sm sm:text-base">
                        Fill out your personal information and verify your identity to proceed.
                    </DialogDescription>
                </DialogHeader>

                <div className="overflow-y-auto flex-1 pr-2 sm:pr-4">
                    <Form {...form}>
                        <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-6 pb-4">
                            {/* Profile Images Section */}
                            <div className="space-y-4 p-4 bg-muted/50 rounded-lg">
                                <h3 className="font-semibold text-sm">Profile Images</h3>

                                {/* Background Image */}
                                <div className="space-y-2">
                                    <Label className="text-sm">Background Picture</Label>
                                    {previewBackground ? (
                                        <div className="relative overflow-hidden rounded-lg border">
                                            <img
                                                src={previewBackground || "/placeholder.svg"}
                                                alt="Background preview"
                                                className="w-full h-32 sm:h-48 object-cover"
                                            />
                                            <Button
                                                type="button"
                                                onClick={() => removeImage("profile_background", setPreviewBackground)}
                                                className="absolute top-2 right-2"
                                                size="icon"
                                                variant="destructive"
                                            >
                                                <X className="h-4 w-4" />
                                            </Button>
                                        </div>
                                    ) : (
                                        <div className="w-full h-32 sm:h-48 border-2 border-dashed rounded-lg flex flex-col items-center justify-center gap-2 bg-background">
                                            <Upload className="h-8 w-8 text-muted-foreground" />
                                            <span className="text-sm text-muted-foreground">Upload background</span>
                                        </div>
                                    )}
                                    <Input
                                        type="file"
                                        accept="image/*"
                                        onChange={(e) => handleImageChange(e, "profile_background", setPreviewBackground)}
                                        disabled={isSubmitting || isLoading}
                                    />
                                </div>

                                {/* Profile Image */}
                                <div className="space-y-2">
                                    <Label className="text-sm">Profile Picture</Label>
                                    <div className="flex gap-4 items-center">
                                        {previewImage ? (
                                            <div className="relative">
                                                <img
                                                    src={previewImage || "/placeholder.svg"}
                                                    alt="Profile preview"
                                                    className="w-20 h-20 rounded-full object-cover border-2"
                                                />
                                                <Button
                                                    type="button"
                                                    onClick={() => removeImage("profile_image", setPreviewImage)}
                                                    className="absolute -top-2 -right-2"
                                                    size="icon"
                                                    variant="destructive"
                                                >
                                                    <X className="h-3 w-3" />
                                                </Button>
                                            </div>
                                        ) : (
                                            <div className="w-20 h-20 rounded-full border-2 border-dashed flex items-center justify-center bg-background">
                                                <Camera className="h-6 w-6 text-muted-foreground" />
                                            </div>
                                        )}
                                        <Input
                                            type="file"
                                            accept="image/*"
                                            onChange={(e) => handleImageChange(e, "profile_image", setPreviewImage)}
                                            disabled={isSubmitting || isLoading}
                                            className="flex-1"
                                        />
                                    </div>
                                </div>
                            </div>

                            {/* Personal Information */}
                            <div className="space-y-4 p-4 bg-muted/50 rounded-lg">
                                <h3 className="font-semibold text-sm">Personal Information</h3>

                                <div className="grid gap-4 sm:grid-cols-2">
                                    <div className="space-y-2">
                                        <Label htmlFor="first_name">First Name *</Label>
                                        <Input
                                            id="first_name"
                                            placeholder="First name"
                                            maxLength={50}
                                            {...register("first_name")}
                                            disabled={isSubmitting || isLoading}
                                        />
                                        {errors.first_name && <p className="text-xs text-destructive">{errors.first_name.message}</p>}
                                    </div>

                                    <div className="space-y-2">
                                        <Label htmlFor="middle_name">Middle Name</Label>
                                        <Input
                                            id="middle_name"
                                            placeholder="Middle name (optional)"
                                            maxLength={50}
                                            {...register("middle_name")}
                                            disabled={isSubmitting || isLoading}
                                        />
                                    </div>

                                    <div className="space-y-2">
                                        <Label htmlFor="last_name">Last Name *</Label>
                                        <Input
                                            id="last_name"
                                            placeholder="Last name"
                                            maxLength={50}
                                            {...register("last_name")}
                                            disabled={isSubmitting || isLoading}
                                        />
                                        {errors.last_name && <p className="text-xs text-destructive">{errors.last_name.message}</p>}
                                    </div>

                                    <div className="space-y-2">
                                        <Label htmlFor="birth_date">Birth Date *</Label>
                                        <Input
                                            id="birth_date"
                                            type="date"
                                            {...register("birth_date")}
                                            disabled={isSubmitting || isLoading}
                                        />
                                        {errors.birth_date && <p className="text-xs text-destructive">{errors.birth_date.message}</p>}
                                    </div>
                                </div>

                                <div className="space-y-2">
                                    <Label htmlFor="phone_number">Phone Number</Label>
                                    <div className="flex gap-2">
                                        <div className="bg-primary text-primary-foreground px-3 flex items-center rounded-md text-sm font-medium">
                                            +63
                                        </div>
                                        <Input
                                            id="phone_number"
                                            type="tel"
                                            placeholder="9XXXXXXXXX"
                                            maxLength={10}
                                            value={phoneValue || ""}
                                            onChange={handlePhoneInput}
                                            disabled={isSubmitting || isLoading}
                                            className="flex-1"
                                        />
                                    </div>
                                    {errors.phone_number && <p className="text-xs text-destructive">{errors.phone_number.message}</p>}
                                </div>

                                <div className="space-y-2">
                                    <div className="flex justify-between">
                                        <Label htmlFor="bio">Bio</Label>
                                        <span className="text-xs text-muted-foreground">{bioValue?.length || 0}/500</span>
                                    </div>
                                    <Textarea
                                        id="bio"
                                        placeholder="Tell us about yourself..."
                                        maxLength={500}
                                        {...register("bio")}
                                        disabled={isSubmitting || isLoading}
                                        className="min-h-20 resize-none"
                                    />
                                </div>
                            </div>

                            {/* Address information  Form Component */}
                            <div className="p-4 bg-muted/50 rounded-lg">
                                <AddressInformationSection
                                    control={form.control}
                                    isSubmitting={isSubmitting || isLoading}
                                />
                            </div>

                            {/* ID Verification */}
                            <div className="space-y-4 p-4 bg-muted/50 rounded-lg">
                                <h3 className="font-semibold text-sm">Identity Verification</h3>

                                <div className="grid gap-4 sm:grid-cols-2">
                                    <FormField
                                        control={form.control}
                                        name="validIdType"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>ID Type *</FormLabel>
                                                <Select
                                                    onValueChange={field.onChange}
                                                    value={field.value || ""}
                                                    disabled={isSubmitting || isLoading}
                                                >
                                                    <FormControl>
                                                        <SelectTrigger>
                                                            <SelectValue placeholder="Select ID type" />
                                                        </SelectTrigger>
                                                    </FormControl>
                                                    <SelectContent>
                                                        <SelectItem value="NATIONAL_ID">National ID</SelectItem>
                                                        <SelectItem value="UMID">UMID</SelectItem>
                                                        <SelectItem value="PASSPORT">Passport</SelectItem>
                                                        <SelectItem value="DRIVERS_LICENSE">Driver's License</SelectItem>
                                                        <SelectItem value="SSS_ID">SSS ID</SelectItem>
                                                        <SelectItem value="POSTAL_ID">Postal ID</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />

                                    <div className="space-y-2">
                                        <Label htmlFor="validIdNumber">ID Number *</Label>
                                        <Input
                                            id="validIdNumber"
                                            placeholder={validIdType === "NATIONAL_ID" ? "####-####-####-####" : "Enter ID number"}
                                            value={validIdNumber || ""}
                                            onChange={handleIdNumberChange}
                                            disabled={isSubmitting || isLoading}
                                        />
                                        {errors.validIdNumber && <p className="text-xs text-destructive">{errors.validIdNumber.message}</p>}
                                    </div>
                                </div>

                                {/* Valid ID Upload */}
                                <div className="space-y-2">
                                    <Label className="text-sm">Upload Valid ID *</Label>
                                    {previewValidId ? (
                                        <div className="relative overflow-hidden rounded-lg border">
                                            <img
                                                src={previewValidId || "/placeholder.svg"}
                                                alt="Valid ID preview"
                                                className="w-full h-48 object-contain bg-muted"
                                            />
                                            <Button
                                                type="button"
                                                onClick={() => removeImage("validIdImage", setPreviewValidId)}
                                                className="absolute top-2 right-2"
                                                size="icon"
                                                variant="destructive"
                                            >
                                                <X className="h-4 w-4" />
                                            </Button>
                                        </div>
                                    ) : (
                                        <div className="w-full h-48 border-2 border-dashed rounded-lg flex flex-col items-center justify-center gap-2 bg-background">
                                            <Upload className="h-8 w-8 text-muted-foreground" />
                                            <span className="text-sm text-muted-foreground">Upload your valid ID</span>
                                        </div>
                                    )}
                                    <Input
                                        type="file"
                                        accept="image/*"
                                        onChange={(e) => handleImageChange(e, "validIdImage", setPreviewValidId)}
                                        disabled={isSubmitting || isLoading}
                                    />
                                    {errors.validIdImage && <p className="text-xs text-destructive">{errors.validIdImage.message}</p>}
                                </div>

                                {/* Selfie with ID Upload */}
                                <div className="space-y-2">
                                    <Label className="text-sm">Selfie with ID *</Label>
                                    <div className="grid gap-3 sm:grid-cols-2">
                                        {previewSelfieWithId ? (
                                            <div className="relative overflow-hidden rounded-lg border">
                                                <img
                                                    src={previewSelfieWithId || "/placeholder.svg"}
                                                    alt="Selfie with ID preview"
                                                    className="w-full h-48 object-cover"
                                                />
                                                <Button
                                                    type="button"
                                                    onClick={() => removeImage("selfieWithIdImage", setPreviewSelfieWithId)}
                                                    className="absolute top-2 right-2"
                                                    size="icon"
                                                    variant="destructive"
                                                >
                                                    <X className="h-4 w-4" />
                                                </Button>
                                            </div>
                                        ) : (
                                            <div className="w-full h-48 border-2 border-dashed rounded-lg flex flex-col items-center justify-center gap-2 bg-background">
                                                <Camera className="h-8 w-8 text-muted-foreground" />
                                                <span className="text-sm text-muted-foreground text-center px-2">
                                                    Take a selfie holding your ID
                                                </span>
                                            </div>
                                        )}
                                        <div className="flex items-center justify-center">
                                            <Image
                                                width={100}
                                                height={100}
                                                src={(selfieWithId as any) || "/placeholder.svg"}
                                                alt="Example selfie with ID"
                                                className="w-full h-48 object-contain rounded-lg border"
                                            />
                                        </div>
                                    </div>
                                    <Input
                                        type="file"
                                        accept="image/*"
                                        onChange={(e) => handleImageChange(e, "selfieWithIdImage", setPreviewSelfieWithId)}
                                        disabled={isSubmitting || isLoading}
                                    />
                                    {errors.selfieWithIdImage && (
                                        <p className="text-xs text-destructive">{errors.selfieWithIdImage.message}</p>
                                    )}
                                    <p className="text-xs text-muted-foreground">
                                        Hold your ID next to your face as shown in the example image
                                    </p>
                                </div>
                            </div>

                            {uploadProgress && (
                                <div className="p-3 bg-primary/10 border border-primary/20 rounded-lg text-sm font-medium">
                                    {uploadProgress}
                                </div>
                            )}
                        </form>
                    </Form>
                </div>

                <div className="border-t pt-4 flex-shrink-0">
                    <Button
                        type="submit"
                        onClick={handleSubmit(handleFormSubmit)}
                        className="w-full"
                        disabled={isSubmitting || isLoading}
                    >
                        {isSubmitting || isLoading ? (
                            <>
                                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                                Saving Profile...
                            </>
                        ) : (
                            "Complete Profile"
                        )}
                    </Button>
                </div>
            </DialogContent>
        </Dialog>
    )
}