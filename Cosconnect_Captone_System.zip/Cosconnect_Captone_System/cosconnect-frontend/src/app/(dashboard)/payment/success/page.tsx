'use client';

import { Suspense, useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { useConfirmPayment } from '@/lib/api/rentalApi';
import { AlertTriangle, ArrowRight, CheckCircle2, Loader2 } from 'lucide-react';

// ✅ Inner component: can safely use hooks
function SuccessPaymentContent() {
    const searchParams = useSearchParams();
    const router = useRouter();
    const reference = searchParams.get('reference');
    const [isRedirecting, setIsRedirecting] = useState(false);

    const { confirmPayment, data, error: networkError, isLoading } = useConfirmPayment();

    // Confirm payment on load
    useEffect(() => {
        if (reference && !data) confirmPayment({ reference });
    }, [reference, confirmPayment, data]);

    // Handle redirect for already confirmed payments
    useEffect(() => {
        if (data?.success && data.message?.includes('already been confirmed')) {
            setIsRedirecting(true);
            const timer = setTimeout(() => router.push('/my-rentals'), 2000);
            return () => clearTimeout(timer);
        }
    }, [data, router]);

    // ❌ Missing reference
    if (!reference) {
        return (
            <div className="min-h-screen flex items-center justify-center p-4">
                <div className="max-w-md w-full space-y-8 text-center">
                    <div className="flex justify-center">
                        <AlertTriangle className="w-16 h-16 text-red-500" />
                    </div>
                    <h1 className="text-2xl font-bold">Invalid Payment Reference</h1>
                    <p className="text-muted-foreground">
                        Missing payment reference information. Please try again.
                    </p>
                    <Button asChild className="w-full mt-4">
                        <Link href="/">Return to Dashboard</Link>
                    </Button>
                </div>
            </div>
        );
    }

    // ⏳ Loading
    if (isLoading) {
        return (
            <div className="min-h-screen flex items-center justify-center p-4">
                <div className="max-w-md w-full text-center space-y-4">
                    <Loader2 className="w-16 h-16 text-primary animate-spin mx-auto" />
                    <h1 className="text-2xl font-bold">Confirming Payment...</h1>
                    <p className="text-muted-foreground">
                        Please wait while we verify your payment.
                    </p>
                </div>
            </div>
        );
    }

    // ❌ Network error
    if (networkError) {
        router.push("/my-rentals")
    }

    // ✅ Handle API response
    if (data) {
        // ❌ Payment not successful
        if (!data.success) {
            return (
                <div className="min-h-screen flex items-center justify-center p-4">
                    <div className="max-w-md w-full text-center space-y-6">
                        <div className="space-y-4">
                            <AlertTriangle className="w-16 h-16 text-red-500 mx-auto" />
                            <h1 className="text-2xl font-bold text-red-500">
                                Payment Confirmation Failed
                            </h1>
                            <p className="text-muted-foreground">
                                {data.message ||
                                    "We couldn't verify your payment. Please contact support."}
                            </p>
                        </div>
                        <div className="flex flex-col gap-3">
                            <Button asChild className="w-full">
                                <Link href="/">Return to Dashboard</Link>
                            </Button>
                            <Button variant="outline" asChild className="w-full">
                                <Link href="/support">Contact Support</Link>
                            </Button>
                        </div>
                    </div>
                </div>
            );
        }

        // 🔁 Already confirmed
        if (isRedirecting || data.message?.includes('already been confirmed')) {
            return (
                <div className="min-h-screen flex items-center justify-center p-4">
                    <div className="max-w-md w-full text-center space-y-6">
                        <CheckCircle2 className="w-16 h-16 text-blue-500 mx-auto" />
                        <Loader2 className="w-8 h-8 text-blue-500 animate-spin mx-auto" />
                        <h1 className="text-2xl font-bold">Payment Already Confirmed</h1>
                        <p className="text-muted-foreground">
                            Redirecting you to your rentals...
                        </p>
                        {data.data && (
                            <div className="bg-blue-50 p-4 rounded-lg mt-2 text-left text-sm text-blue-800">
                                <p className="font-medium">Payment Details</p>
                                <p>Reference: {data.data.reference_code || 'N/A'}</p>
                                <p>Costume: {data.data.rental?.costume_name || 'N/A'}</p>
                            </div>
                        )}
                    </div>
                </div>
            );
        }

        // ✅ New successful payment
        return (
            <div className="min-h-screen flex items-center justify-center p-4">
                <div className="max-w-md w-full text-center space-y-8">
                    <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto" />
                    <h1 className="text-2xl font-bold">Payment Successful!</h1>
                    <p className="text-muted-foreground">
                        Your costume rental payment was processed successfully.
                    </p>
                    <div className="bg-accent/10 p-4 rounded-lg text-left space-y-2">
                        <p className="text-sm font-medium">What's Next?</p>
                        <ul className="text-sm text-muted-foreground space-y-2">
                            <li className="flex items-center gap-2">
                                <CheckCircle2 className="w-4 h-4 text-green-500" />
                                <span>Check your email for confirmation</span>
                            </li>
                            <li className="flex items-center gap-2">
                                <CheckCircle2 className="w-4 h-4 text-green-500" />
                                <span>View your rental in the dashboard</span>
                            </li>
                            <li className="flex items-center gap-2">
                                <CheckCircle2 className="w-4 h-4 text-green-500" />
                                <span>Prepare for costume pickup</span>
                            </li>
                        </ul>
                    </div>
                    <div className="flex flex-col gap-3">
                        <Button asChild className="w-full">
                            <Link href="/my-rentals">
                                View My Rentals
                                <ArrowRight className="ml-2 h-4 w-4" />
                            </Link>
                        </Button>
                        <Button variant="outline" asChild className="w-full">
                            <Link href="/costumes">Browse More Costumes</Link>
                        </Button>
                    </div>
                </div>
            </div>
        );
    }

    // ⚠️ Fallback
    return (
        <div className="min-h-screen flex items-center justify-center p-4">
            <div className="max-w-md w-full text-center space-y-6">
                <AlertTriangle className="w-16 h-16 text-yellow-500 mx-auto" />
                <h1 className="text-2xl font-bold">Something Went Wrong</h1>
                <p className="text-muted-foreground">
                    Please refresh or contact support.
                </p>
                <Button asChild className="w-full">
                    <Link href="/">Return to Dashboard</Link>
                </Button>
            </div>
        </div>
    );
}

// ✅ Outer component wraps inner one in Suspense (required by Next.js 15+)
export default function SuccessPaymentPage() {
    return (
        <Suspense
            fallback={
                <div className="flex items-center justify-center min-h-screen">
                    Loading payment status...
                </div>
            }
        >
            <SuccessPaymentContent />
        </Suspense>
    );
}
