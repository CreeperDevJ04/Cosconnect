"use client";
import React, { Suspense } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";

const FailedPaymentContent = () => {
    const router = useRouter();
    const params = useSearchParams();
    const reason = params.get("reason");
    const txId = params.get("txId") || params.get("transaction_id");

    return (
        <div className="min-h-[70vh] w-full flex items-center justify-center px-4 bg-white">
            <div className="w-full max-w-md rounded-2xl border border-gray-200 bg-white shadow-sm">
                <div className="px-6 pt-8 pb-2 flex flex-col items-center text-center">
                    <div className="mb-4 inline-flex h-14 w-14 items-center justify-center rounded-full bg-gray-100 ring-8 ring-gray-100">
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            className="h-8 w-8 text-black"
                        >
                            <circle cx="12" cy="12" r="10" strokeWidth="1.5" />
                            <path
                                d="M15 9L9 15M9 9l6 6"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                            />
                        </svg>
                    </div>

                    <h1 className="text-xl font-semibold text-black">Payment failed</h1>
                    <p className="mt-2 text-sm text-gray-600">
                        We couldn't process your payment. No money was charged.
                    </p>

                    {reason && (
                        <div className="mt-4 w-full rounded-md bg-gray-50 px-4 py-2 text-left">
                            <p className="text-xs font-medium text-black">Details</p>
                            <p className="mt-1 text-sm text-gray-800 break-words">{reason}</p>
                        </div>
                    )}

                    {txId && (
                        <p className="mt-2 text-xs text-gray-500">
                            Reference: <span className="font-mono">{txId}</span>
                        </p>
                    )}
                </div>

                <div className="px-6 pt-2 pb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-center">
                    <button
                        onClick={() => router.back()}
                        className="inline-flex w-full sm:w-auto items-center justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-800 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-gray-400 focus:ring-offset-2"
                    >
                        Go back
                    </button>
                    <Link
                        href="/"
                        className="inline-flex w-full sm:w-auto items-center justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-800 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-gray-400 focus:ring-offset-2"
                    >
                        Home
                    </Link>
                </div>
            </div>
        </div>
    );
};

const FailedPaymentPage = () => {
    return (
        <Suspense fallback={
            <div className="min-h-[70vh] w-full flex items-center justify-center">
                <div className="text-gray-600">Loading...</div>
            </div>
        }>
            <FailedPaymentContent />
        </Suspense>
    );
};

export default FailedPaymentPage;