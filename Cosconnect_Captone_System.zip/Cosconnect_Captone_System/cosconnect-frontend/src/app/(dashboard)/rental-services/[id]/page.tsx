"use client"

import CostumeDetailViewer from "@/components/MarketPlace/Costume/CostumeProductInfoSection"
import { Loader2 } from "lucide-react"
import { useParams } from "next/navigation"
import { Suspense } from "react"

const Page = () => {
    const params = useParams()

    // Get the ID from the URL params
    const id = Array.isArray(params.id) ? params.id[0] : params.id

    return (
        <Suspense fallback={<Loader2 className="animate-spin -ml-1 mr-3 h-5 w-5" />}>
            <CostumeDetailViewer costumeId={id as any} />
        </Suspense>
    )
}

export default Page