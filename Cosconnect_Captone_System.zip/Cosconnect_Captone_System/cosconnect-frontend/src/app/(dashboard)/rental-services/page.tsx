import MarketPlaceSection from "@/components/MarketPlace/MarketPlaceSection"
import { Loader2 } from "lucide-react"
import { Suspense } from "react"

const CostumePage = () => {
    return (
        <Suspense fallback={<Loader2 className="animate-spin -ml-1 mr-3 h-5 w-5" />}>
            <MarketPlaceSection />
        </Suspense>
    )
}

export default CostumePage