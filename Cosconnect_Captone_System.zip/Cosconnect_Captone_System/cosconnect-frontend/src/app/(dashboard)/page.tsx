"use client"

import WelcomePage from "@/components/auth/WelcomePage"
import SocialFeedSection from "@/components/SocialFeed/SocialFeedSection"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useSupabaseAuth } from "@/lib/hooks/useSupabaseAuth"
import { UserPersonalInfo } from "@/lib/types/userType"
import { signOut } from "@/utils/supabase/auth"
import { useEffect, useState } from "react"
import { CompleteProfileModal } from "./CompleteYourProfile"
import { useUpdateInfoBorrower } from "@/lib/api/borrowerApi"

// Type definition for the document object in the documents array
interface UpdateDocument {
    document_type: string
    id_type: string | null
    id_number: string | null
    file_url: string
    file_name: string | null
}

// Type definition for the updateData object
interface BorrowerUpdateData {
    first_name: string
    middle_name: string | null
    last_name: string
    birth_date: string
    phone_number: string | null
    bio: string | null
    profile_image: string | null
    profile_background: string | null
    // Address information
    region: string
    province: string | null
    municipal_city: string | null
    barangay: string | null
    street_address: string | null
    postal_code: string | null
    // Documents array
    documents: UpdateDocument[]
    // Status for verification
    status?: string
}

const Page = () => {
    const {
        isAuthenticated,
        isLoading,
        user,
        userData,
        userDataError,
        currentRole,
        retryFetchRoles,
        retryCount,
        maxRetries
    } = useSupabaseAuth()

    const [showProfileModal, setShowProfileModal] = useState(false)
    const [isSubmittingProfile, setIsSubmittingProfile] = useState(false)
    const { mutateAsync: updateInfo, isPending } = useUpdateInfoBorrower(
        userData?.username || userData?.personal_info?.username as string
    )

    // ✅ Automatically sign out if "user not found" error occurs
    useEffect(() => {
        if (userDataError?.message?.toLowerCase().includes("user not found")) {
            console.warn("User not found — signing out automatically.")
            signOut()
        }
    }, [userDataError])

    useEffect(() => {
        if (userDataError && isAuthenticated) {
            console.error("User data error:", userDataError)
        }
    }, [userDataError, isAuthenticated])

    const personalInfo = userData?.personal_info || {}
    const { first_name, last_name, birth_date } = personalInfo as UserPersonalInfo
    const username = userData?.username || userData?.personal_info?.username

    const hasMissingFields =
        !first_name || !last_name || !birth_date ||
        first_name === "undefined" || last_name === "undefined" ||
        first_name === username || last_name === username

    useEffect(() => {
        if (isAuthenticated && !isLoading && hasMissingFields) {
            setShowProfileModal(true)
        }
    }, [isAuthenticated, isLoading, hasMissingFields])

    const handleProfileSubmit = async (data: any) => {
        if (!user?.id) {
            alert("User ID not found. Please sign in again.")
            return
        }

        setIsSubmittingProfile(true)
        try {
            console.log("📤 Raw data received from CompleteProfileModal:", data)
            console.log("📤 Documents array:", JSON.stringify(data.documents, null, 2))
            console.log("📤 Documents count:", data.documents?.length || 0)

            const updateData: BorrowerUpdateData = {
                first_name: data.first_name,
                middle_name: data.middle_name,
                last_name: data.last_name,
                birth_date: data.birth_date,
                phone_number: data.phone_number,
                bio: data.bio,
                profile_image: data.profile_image,
                profile_background: data.profile_background,
                // Address information
                region: data.region,
                province: data.province,
                municipal_city: data.municipal_city,
                barangay: data.barangay,
                street_address: data.street_address,
                postal_code: data.postal_code,
                // Documents array with VALID_ID and SELFIE_WITH_ID
                documents: data.documents || [],
                // Set status to pending_verification when documents are submitted
                ...(data.documents && data.documents.length > 0 && {
                    status: "pending_verification"
                }),
            }

            console.log("📤 Full data object being sent to updateInfo:", JSON.stringify(updateData, null, 2))
            console.log("📤 Documents array details:", JSON.stringify(updateData.documents, null, 2))
            console.log("📤 User ID:", user.id)
            console.log("📤 isPending state:", isPending)

            const result = await updateInfo({
                id: user.id,
                data: updateData,
            })

            console.log("✅ Profile updated successfully:", result)
            console.log("✅ Response data:", JSON.stringify(result, null, 2))

            setShowProfileModal(false)
            window.location.reload()
        } catch (error: any) {
            console.error("❌ Error updating profile:", error)
            console.error("❌ Error details:", JSON.stringify(error, null, 2))
            alert(error?.message || "Failed to update profile. Please try again.")
        } finally {
            setIsSubmittingProfile(false)
        }
    }

    if (isLoading) {
        return (
            <div className="flex items-center justify-center min-h-screen bg-white">
                <div className="flex flex-col items-center space-y-4">
                    <div className="animate-spin rounded-full h-8 w-8 border-2 border-gray-300 border-t-blue-600"></div>
                    <p className="text-sm text-gray-600">Loading...</p>
                </div>
            </div>
        )
    }

    if (!isAuthenticated || !user) {
        return <WelcomePage />
    }

    if (isAuthenticated && !currentRole && !userDataError) {
        return (
            <div className="flex items-center justify-center min-h-screen bg-white">
                <div className="flex flex-col items-center space-y-4">
                    <div className="animate-spin rounded-full h-8 w-8 border-2 border-gray-300 border-t-blue-600"></div>
                    <p className="text-sm text-gray-600">Loading your profile...</p>
                    {retryCount > 0 && (
                        <p className="text-xs text-gray-500">
                            Retry attempt {retryCount}/{maxRetries}
                        </p>
                    )}
                </div>
            </div>
        )
    }

    if (userDataError && !currentRole) {
        const isNetworkError =
            userDataError.message?.includes("fetch") ||
            userDataError.message?.includes("network") ||
            userDataError.message?.includes("Failed to fetch")

        const isAuthError =
            userDataError.message?.includes("JWT") ||
            userDataError.message?.includes("token") ||
            userDataError.message?.includes("unauthorized")

        const isUserNotFound =
            userDataError.message?.toLowerCase().includes("user not found")

        // ✅ Auto sign-out if user not found
        if (isUserNotFound) {
            console.warn("User not found — forcing sign out.")
            signOut()
            return null
        }

        return (
            <div className="flex items-center justify-center min-h-screen bg-gray-50">
                <div className="text-center p-8 bg-white rounded-lg shadow-sm border max-w-md">
                    <div className="w-12 h-12 mx-auto mb-4 text-red-500">
                        <svg
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                        >
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"
                            />
                        </svg>
                    </div>

                    <h2 className="text-lg font-semibold text-gray-900 mb-2">
                        {isAuthError
                            ? "Authentication Issue"
                            : "Loading Profile Failed"}
                    </h2>

                    <p className="text-sm text-gray-600 mb-4">
                        {isAuthError
                            ? "There was an issue with your authentication. Please sign in again."
                            : isNetworkError
                                ? "Network connection issue. Please check your internet and try again."
                                : "We're having trouble loading your profile data."}
                    </p>

                    <div className="space-y-2">
                        {!isAuthError && retryCount < maxRetries && (
                            <button
                                onClick={async () => {
                                    await signOut()
                                    window.location.reload()
                                }}
                                className="w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                            >
                                Try Again
                            </button>
                        )}

                        <button
                            onClick={() => window.location.reload()}
                            className="w-full px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 transition-colors"
                        >
                            Refresh Page
                        </button>

                        {isAuthError && (
                            <button
                                onClick={() => signOut()}
                                className="w-full px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors"
                            >
                                Sign Out & Try Again
                            </button>
                        )}
                    </div>

                    {process.env.NODE_ENV === "development" && (
                        <details className="mt-4 text-left">
                            <summary className="text-xs text-gray-500 cursor-pointer">
                                Error Details (Dev)
                            </summary>
                            <pre className="text-xs text-red-600 mt-2 p-2 bg-red-50 rounded overflow-auto">
                                {JSON.stringify(userDataError, null, 2)}
                            </pre>
                        </details>
                    )}
                </div>
            </div>
        )
    }

    if (hasMissingFields) {
        return (
            <>
                <div className="flex min-h-screen blur-sm pointer-events-none">
                    {currentRole === "borrower" ? <SocialFeedSection /> : <div />}
                </div>
                <CompleteProfileModal
                    open={showProfileModal}
                    personalInfo={personalInfo}
                    onSubmit={handleProfileSubmit}
                    isLoading={isSubmittingProfile || isPending}
                    username={userData?.username || ""}
                />
            </>
        )
    }

    switch (currentRole) {
        case "lender":
            return (
                <div className="flex bg-gray-50 w-full mx-auto">
                    <ScrollArea className="flex-1">
                        <SocialFeedSection />
                    </ScrollArea>
                </div>
            )

        case "borrower":
            return (
                <div className="flex min-h-screen">
                    <SocialFeedSection />
                </div>
            )

        default:
            return (
                <div className="flex items-center justify-center min-h-screen bg-gray-50">
                    <WelcomePage />
                </div>
            )
    }
}

export default Page