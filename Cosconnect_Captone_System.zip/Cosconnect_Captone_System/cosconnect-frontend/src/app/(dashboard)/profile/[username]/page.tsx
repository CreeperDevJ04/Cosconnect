"use client"

import ProfileSection from "@/components/profile/ProfileSection"

const ProfilePage = () => {
    return <div className="h-full">
        <ProfileSection />
    </div>
}

export default ProfilePage