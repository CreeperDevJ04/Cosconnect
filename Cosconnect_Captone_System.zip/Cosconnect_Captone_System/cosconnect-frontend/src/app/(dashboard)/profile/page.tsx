"use client"

import ProfileSection from "@/components/profile/ProfileSection"
import { Loader2 } from "lucide-react"
import { Suspense } from "react"

const ProfilePage = () => {
    return <div className="h-full">
        <Suspense fallback={<Loader2 className="animate-spin -ml-1 mr-3 h-5 w-5" />}>
            <ProfileSection />
        </Suspense>
    </div>
}

export default ProfilePage