"use client"

import type React from "react"
import { usePathname } from "next/navigation"

import Footer from "@/components/layout/Footer"
import Header from "@/components/layout/Header"
import SidebarLender from "@/components/Lender/SidebarLender/SideBarLender"
import { NotificationBell } from "@/components/Lender/NotificationBellLender"
import { useSupabaseAuth } from "@/lib/hooks/useSupabaseAuth"
import { SocketProvider } from "@/lib/contexts/SocketProvider"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { userData, isAuthenticated } = useSupabaseAuth()
  const pathname = usePathname()
  const currentRole = userData?.current_role || "borrower"

  const isLender = currentRole === "lender"
  const showFooter =
    currentRole !== "lender" &&
    pathname !== "/costumes/chat" &&
    pathname !== "/" &&
    !pathname.startsWith("/messages")

  return (
    <SocketProvider>
      <div className="flex min-h-screen bg-gray-50 dark:bg-gray-950">
        {/* Lender Layout */}
        {isLender ? (
          <>
            {/* Sidebar */}
            {isAuthenticated && (
              <aside className="fixed top-0 left-0 h-screen w-64 z-30 hidden md:block">
                <SidebarLender />
              </aside>
            )}

            {/* Mobile Sidebar (handled internally by SidebarLender) */}
            {isAuthenticated && (
              <div className="md:hidden">
                <SidebarLender />
              </div>
            )}

            {/* Notification Bell */}
            <div className="fixed top-4 right-4 z-40">
              <NotificationBell />
            </div>

            {/* Main Content Area */}
            <main className="flex-1 md:ml-64 min-h-screen">
              <div className="container mx-auto p-4 md:p-6 lg:p-8">
                {children}
              </div>
            </main>
          </>
        ) : (
          /* Borrower Layout */
          <div className="flex flex-col w-full min-h-screen">
            <Header />
            <main className="flex-1">
              {children}
            </main>
            {showFooter && <Footer />}
          </div>
        )}
      </div>
    </SocketProvider>
  )
}