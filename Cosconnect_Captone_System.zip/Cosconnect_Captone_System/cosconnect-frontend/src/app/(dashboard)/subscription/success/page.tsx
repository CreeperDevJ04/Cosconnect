"use client";

import React, { useEffect, useState } from "react";
import { CheckCircle2, Crown, Clock, CalendarDays } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";
import Confetti from "react-confetti";
import { useCheckPaymentStatus } from "@/lib/api/subscriptionApi";
import { useSupabaseAuth } from "@/lib/hooks/useSupabaseAuth";

const SubscriptionSuccessPage: React.FC = () => {
    const router = useRouter();
    const { userData } = useSupabaseAuth();
    const { checkPaymentStatus } = useCheckPaymentStatus();

    const [dimensions, setDimensions] = useState({ width: 0, height: 0 });
    const [loading, setLoading] = useState(true);
    const [paymentConfirmed, setPaymentConfirmed] = useState(false);
    const [isExpired, setIsExpired] = useState(false);

    const subscriptionInfo = userData?.subscription_info;
    const sessionId = subscriptionInfo?.subscription_session_id;
    console.log("sesson", sessionId)
    // Confetti resize
    useEffect(() => {
        setDimensions({ width: window.innerWidth, height: window.innerHeight });
        const handleResize = () =>
            setDimensions({ width: window.innerWidth, height: window.innerHeight });
        window.addEventListener("resize", handleResize);
        return () => window.removeEventListener("resize", handleResize);
    }, []);

    // Verify subscription / payment
    useEffect(() => {
        const verifySubscription = async () => {
            console.log("Unable to verify your subscription.", sessionId)
            if (!sessionId) {
                setLoading(false);
                return;
            }

            try {
                setLoading(true);

                // ✅ Check if already premium
                if (subscriptionInfo?.is_premium && subscriptionInfo.subscription_end_date) {
                    const endDate = new Date(subscriptionInfo.subscription_end_date);
                    const now = new Date();

                    if (now < endDate) {
                        setPaymentConfirmed(true);
                        setIsExpired(false);
                        return;
                    } else {
                        setIsExpired(true);
                        setPaymentConfirmed(false);
                        return;
                    }
                }

                // ✅ If not premium, check via PayMongo API
                const response = await checkPaymentStatus({ session_id: sessionId });

                if (response?.data?.is_paid) {
                    setPaymentConfirmed(true);
                } else {
                    setPaymentConfirmed(false);
                }
            } catch (error) {
                console.error("Error verifying subscription:", error);
                setPaymentConfirmed(false);
            } finally {
                setLoading(false);
            }
        };

        verifySubscription();
    }, [sessionId, subscriptionInfo, checkPaymentStatus]);

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-rose-50 text-gray-700">
                Checking your subscription...
            </div>
        );
    }

    // ✅ Active Premium
    if (subscriptionInfo?.is_premium && !isExpired) {
        return (
            <div className="relative min-h-screen flex items-center justify-center bg-rose-50 px-4 py-10">
                <div className="relative z-10 w-full max-w-md bg-white rounded-2xl shadow-xl p-8 sm:p-10 flex flex-col items-center gap-6">
                    <div className="flex items-center justify-center h-20 w-20 rounded-full bg-rose-100">
                        <Crown className="h-10 w-10 text-rose-600" />
                    </div>

                    <div className="text-center">
                        <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">
                            Premium Subscription Active
                        </h1>
                        <p className="text-gray-700 mt-2">
                            You are currently enjoying{" "}
                            <span className="font-semibold text-rose-600">CosConnect Premium</span>{" "}
                            features.
                        </p>
                    </div>

                    <div className="w-full bg-rose-50 border border-rose-100 rounded-lg p-4 flex flex-col gap-2 text-sm">
                        <div className="flex justify-between">
                            <span className="text-gray-600 flex items-center gap-2">
                                <CalendarDays className="w-4 h-4" /> Start Date
                            </span>
                            <span className="font-medium text-gray-800">
                                {subscriptionInfo.subscription_start_date
                                    ? new Date(subscriptionInfo.subscription_start_date).toLocaleDateString()
                                    : "N/A"}
                            </span>
                        </div>
                        <div className="flex justify-between">
                            <span className="text-gray-600 flex items-center gap-2">
                                <Clock className="w-4 h-4" /> End Date
                            </span>
                            <span className="font-medium text-gray-800">
                                {subscriptionInfo.subscription_end_date
                                    ? new Date(subscriptionInfo.subscription_end_date).toLocaleDateString()
                                    : "N/A"}
                            </span>
                        </div>
                        <div className="flex justify-between">
                            <span className="text-gray-600">Type</span>
                            <span className="font-medium capitalize text-gray-800">
                                {subscriptionInfo.subscription_type || "Monthly"}
                            </span>
                        </div>
                        <div className="flex justify-between">
                            <span className="text-gray-600">Reference</span>
                            <span className="font-medium text-gray-800">
                                {subscriptionInfo.subscription_reference || "—"}
                            </span>
                        </div>
                    </div>

                    <Button
                        className="mt-4 w-full bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-lg"
                        onClick={() => router.push("/")}
                    >
                        Go to Dashboard
                    </Button>
                </div>
            </div>
        );
    }

    // ❌ Subscription expired
    if (isExpired) {
        return (
            <div className="min-h-screen flex flex-col items-center justify-center bg-rose-50 text-center px-4">
                <Crown className="h-12 w-12 text-rose-500 mb-4" />
                <h1 className="text-2xl font-bold text-gray-800 mb-2">Subscription Expired</h1>
                <p className="text-gray-600 mb-6">
                    Your premium subscription has ended. Renew to continue enjoying premium
                    features.
                </p>
                <Button
                    className="bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-lg"
                    onClick={() => router.push("/subscription")}
                >
                    Renew Subscription
                </Button>
            </div>
        );
    }

    // 🎉 Payment just confirmed
    if (paymentConfirmed) {
        return (
            <div className="relative min-h-screen flex items-center justify-center bg-rose-50 px-4 py-10">
                <Confetti
                    width={dimensions.width}
                    height={dimensions.height}
                    numberOfPieces={250}
                    gravity={0.25}
                    colors={["#F43F5E", "#F87171", "#FB7185", "#FECACA", "#FBCFE8"]}
                />

                <div className="relative z-10 w-full max-w-md bg-white rounded-2xl shadow-xl p-8 sm:p-10 flex flex-col items-center gap-6">
                    <div className="flex items-center justify-center h-20 w-20 rounded-full bg-rose-100">
                        <CheckCircle2 className="h-10 w-10 text-rose-600" />
                    </div>

                    <div className="text-center">
                        <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">
                            Subscription Successful!
                        </h1>
                        <p className="text-gray-700 mt-2">
                            Thank you for subscribing to the Premium Plan. Enjoy priority support,
                            premium badge, and exclusive features.
                        </p>
                    </div>

                    <Button
                        className="w-full sm:w-auto px-8 py-3 bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-700 hover:to-rose-800 text-white font-semibold rounded-lg"
                        onClick={() => router.push("/")}
                    >
                        Go to Dashboard
                    </Button>
                </div>
            </div>
        );
    }

    // ⚠️ Default fallback
    return (
        <div className="min-h-screen flex items-center justify-center bg-rose-50 text-gray-700">
            Unable to verify your subscription.
        </div>
    );
};

export default SubscriptionSuccessPage;
