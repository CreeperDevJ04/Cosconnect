"use client"

import { MessengerSection } from '@/components/Messenger/message-section'
import { Loader2 } from 'lucide-react'
import { Suspense } from 'react'

const page = () => {
    return (
        <Suspense fallback={<Loader2 className="animate-spin -ml-1 mr-3 h-5 w-5" />}>
            <MessengerSection />
        </Suspense>
    )
}

export default page