"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, Plus, Edit, FileText } from "lucide-react"
import { useSupabaseAuth } from "@/lib/hooks/useSupabaseAuth"

import { TermsConditionDisplay } from "@/components/Lender/TermAndConditions/TermsConditionDisplay"
import { useGetMyTermsCondition } from "@/lib/api/lenderApi"
import TermsConditionDialog from "@/components/Lender/TermAndConditions/TermsConditionDialog"

export default function TermsConditionPage() {
    const { user } = useSupabaseAuth()
    const lenderId = user?.id || ""

    const { data: termsData, isLoading, refetch } = useGetMyTermsCondition(lenderId)

    const handleSuccess = () => {
        refetch()
    }

    return (
        <div className="container mx-auto py-8 px-4 max-w-6xl">
            <div className="space-y-6">
                {/* Header */}
                <div className="flex items-center justify-between">
                    <div>
                        <h1 className="text-3xl font-bold">Terms & Conditions</h1>
                        <p className="text-muted-foreground mt-1">Manage your terms and conditions</p>
                    </div>

                    <div className="flex gap-2">
                        {termsData ? (
                            <TermsConditionDialog lenderId={lenderId} mode="edit" onSuccess={handleSuccess}>
                                <Button>
                                    <Edit className="w-4 h-4 mr-2" />
                                    Edit Terms
                                </Button>
                            </TermsConditionDialog>
                        ) : (
                            <TermsConditionDialog lenderId={lenderId} mode="create" onSuccess={handleSuccess}>
                                <Button>
                                    <Plus className="w-4 h-4 mr-2" />
                                    Create Terms
                                </Button>
                            </TermsConditionDialog>
                        )}
                    </div>
                </div>

                {/* Content */}
                {isLoading ? (
                    <Card>
                        <CardContent className="flex items-center justify-center py-12">
                            <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
                            <span className="ml-3 text-muted-foreground">Loading terms and conditions...</span>
                        </CardContent>
                    </Card>
                ) : termsData ? (
                    <TermsConditionDisplay data={termsData} />
                ) : (
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <FileText className="w-5 h-5" />
                                No Terms & Conditions Found
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-muted-foreground mb-4">
                                You haven't created any terms and conditions yet. Click the button above to get started.
                            </p>
                            <TermsConditionDialog lenderId={lenderId} mode="create" onSuccess={handleSuccess}>
                                <Button>
                                    <Plus className="w-4 h-4 mr-2" />
                                    Create Your First Terms
                                </Button>
                            </TermsConditionDialog>
                        </CardContent>
                    </Card>
                )}
            </div>
        </div>
    )
}