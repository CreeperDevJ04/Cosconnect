"use client"
import { LenderRentalsSection } from '@/components/Lender/ManageRentals/ManageRentalsSection'
import { useSupabaseAuth } from '@/lib/hooks/useSupabaseAuth'
import { Loader2 } from 'lucide-react'
import { Suspense } from 'react'

const Page = () => {
    const { user } = useSupabaseAuth()
    return (
        <div className="container mx-auto py-6">
            <Suspense fallback={<Loader2 className="animate-spin -ml-1 mr-3 h-5 w-5" />}>
                <LenderRentalsSection userId={user?.id as string || ""} />
            </Suspense>
        </div>
    )
}

export default Page