"use client"
/* import EditProductDetailsSection from '@/components/forms/Lender/EditCostumeDetailsSection';
 */
import React from 'react';

export default function EditProductPage() {
    return (
        <div className="h-full m-8">
            {/*      <EditProductDetailsSection /> */}
        </div>
    );
}