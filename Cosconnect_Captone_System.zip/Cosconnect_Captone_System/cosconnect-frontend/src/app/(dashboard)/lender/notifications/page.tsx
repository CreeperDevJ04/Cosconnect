'use client'
import React, { Suspense } from 'react'
import NotificationsPage from '../../notifications/page'
import { Loader2 } from 'lucide-react'

const page = () => {
    return (
        <>
            <Suspense fallback={<Loader2 className="animate-spin -ml-1 mr-3 h-5 w-5" />}>
                <NotificationsPage />
            </Suspense>

        </>
    )
}

export default page