"use client";

import ContactPage from "@/components/ui/contact";
import { Loader2 } from "lucide-react";
import { Suspense } from "react";


export default function Page() {
  return (
    <Suspense fallback={<Loader2 className="animate-spin mx-auto h-5 w-5" />}>
      <ContactPage />
    </Suspense>
  );
}