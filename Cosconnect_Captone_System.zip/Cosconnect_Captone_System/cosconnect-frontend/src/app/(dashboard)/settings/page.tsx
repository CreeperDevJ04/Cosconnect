"use client"

import SettingsSection from "@/components/settings/SettingsSection"
import { Loader2 } from "lucide-react"
import { Suspense } from "react"

const SettingsPage = () => {
    return (
        <>
            <Suspense fallback={<Loader2 className="animate-spin -ml-1 mr-3 h-5 w-5" />}>
                <SettingsSection />
            </Suspense>

        </>
    )
}

export default SettingsPage