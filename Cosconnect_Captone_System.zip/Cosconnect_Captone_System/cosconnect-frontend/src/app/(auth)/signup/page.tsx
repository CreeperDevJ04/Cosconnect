import UserSignUp from '@/components/auth/UserSignUp'
import { Loader2 } from 'lucide-react'
import React, { Suspense } from 'react'

const SignUpPage = () => {
    return (
        <Suspense fallback={<Loader2 className="animate-spin -ml-1 mr-3 h-5 w-5" />}>
            <UserSignUp />
        </Suspense>
    )
}

export default SignUpPage
