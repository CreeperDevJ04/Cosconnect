import LenderSignUp from '@/components/auth/LenderSignUp'
import React from 'react'

const LenderSignUpPage = () => {
    return <LenderSignUp />
}

export default LenderSignUpPage
