import PrivacyPolicy from '@/components/layout/UiSections/PrivacyPolicy'
import React from 'react'

const PrivacyPolicyPage = () => {
    return (
        <PrivacyPolicy />
    )
}

export default PrivacyPolicyPage