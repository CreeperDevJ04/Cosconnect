import TermsAndConditions from '@/components/layout/UiSections/TermsAndConditions'
import React from 'react'

const TermsAndConditionsPage = () => {
    return (
        <TermsAndConditions />
    )
}

export default TermsAndConditionsPage