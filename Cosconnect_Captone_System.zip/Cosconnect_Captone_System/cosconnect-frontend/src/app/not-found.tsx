"use client"

import React from "react"
import Link from "next/link"
import { Home } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

const PageNotFound = () => {
    return (
        <main className="min-h-screen flex items-center justify-center bg-gradient-to-b from-slate-50 via-white to-slate-100 px-6 py-12">
            <Card className="w-full max-w-3xl bg-white border border-slate-200 shadow-md">
                <CardContent className="flex flex-col md:flex-row items-center justify-center gap-10 p-10">
                    {/* Illustration */}
                    <div className="relative w-full md:w-1/2 flex justify-center">
                        <div className="absolute -top-6 -left-4 text-[9rem] font-extrabold text-slate-200/50 select-none">
                            404
                        </div>
                        <svg
                            viewBox="0 0 200 200"
                            className="w-56 h-56 md:w-72 md:h-72"
                            xmlns="http://www.w3.org/2000/svg"
                        >
                            <path
                                fill="#94a3b8"
                                d="M44.7,-76.4C58.8,-69.2,71.8,-59.1,79.6,-45.8C87.4,-32.6,90,-16.3,88.5,-0.9C87,14.6,81.4,29.2,73.6,42.4C65.8,55.5,55.9,67.3,43.7,75.6C31.4,83.9,15.7,88.7,0.4,88.1C-14.9,87.4,-29.8,81.2,-43.3,73.4C-56.8,65.5,-68.9,55.9,-75.8,43.5C-82.8,31,-84.5,15.5,-83.2,0.8C-81.8,-14,-77.3,-28,-70.7,-41.6C-64.2,-55.3,-55.6,-68.5,-43.7,-76.7C-31.8,-85,-15.9,-88.2,-0.2,-87.8C15.4,-87.5,30.7,-83.6,44.7,-76.4Z"
                                transform="translate(100 100)"
                            />
                        </svg>
                        <div className="absolute inset-0 flex items-center justify-center">
                            <span className="text-7xl font-extrabold text-slate-800 drop-shadow-sm">
                                404
                            </span>
                        </div>
                    </div>

                    {/* Content */}
                    <div className="w-full md:w-1/2 text-center md:text-left space-y-6">
                        <h1 className="text-4xl md:text-5xl font-bold text-slate-900">
                            Page Not Found
                        </h1>
                        <p className="text-slate-600 text-lg">
                            The page you’re looking for doesn’t exist or may have been moved.
                        </p>

                        <div className="flex justify-center md:justify-start">
                            <Link href="/" className="no-underline w-full sm:w-auto">
                                <Button className="flex items-center justify-center gap-2 bg-slate-900 hover:bg-slate-800 text-white px-6 py-3 rounded-lg shadow-sm transition-all">
                                    <Home size={18} />
                                    Go Home
                                </Button>
                            </Link>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </main>
    )
}

export default PageNotFound
