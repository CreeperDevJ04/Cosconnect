"use client"

import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Textarea } from "@/components/ui/textarea"
import { useFetchAllCategories } from "@/lib/api/categoryApi"
import { useEditCostume } from "@/lib/api/costumeApi"
import { SIZE_OPTIONS } from "@/lib/types/costume"
import { uploadImage } from "@/utils/supabase/fileUpload"
import { zodResolver } from "@hookform/resolvers/zod"
import { AlertCircle, ImageIcon, Loader2, X } from "lucide-react"
import Image from "next/image"
import { memo, useCallback, useEffect, useMemo, useState } from "react"
import { useDropzone } from "react-dropzone"
import { useForm } from "react-hook-form"
import { toast } from "sonner"
import { z } from "zod"

const MAX_FILE_SIZE = 5 * 1024 * 1024 // 5MB
const ALLOWED_FILE_TYPES = ['image/jpeg', 'image/png', 'image/webp']

const CostumeSchema = z.object({
    name: z.string().min(2, "Name must be at least 2 characters"),
    description: z.string().min(10, "Description must be at least 10 characters"),
    rental_price: z.string().min(1, "Rental price is required"),
    security_deposit: z.string().min(1, "Security deposit is required"),
    extended_days_price: z.string().min(1, "Extended days price is required"),
    sizes: z.string().min(1, "Size is required"),
    category: z.string().min(1, "Category is required"),
    brand: z.string().min(1, "Brand is required"),
    gender: z.string().optional(),
})

type CostumeFormData = z.infer<typeof CostumeSchema>

export interface Costume {
    id?: string
    name?: string
    description?: string
    brand?: string
    category?: string
    gender?: string
    sizes?: string
    rental_price?: string
    sale_price?: string
    security_deposit?: string
    extended_days_price?: string
    discount_percentage?: number
    is_available?: boolean
    listing_type?: "rent" | "sale"
    status?: "active" | "inactive" | "archived"
    main_images?: {
        front?: string
        back?: string
    }
    additional_images?: {
        url?: string
        alt_text?: string
        order?: number
    }[]
    tags?: string[]
    favorite_count?: number
    view_count?: number
    lender_uid?: string
    created_at?: string
    updated_at?: string
}

interface EditCostumeDialogProps {
    open: boolean
    onClose: () => void
    costume: Costume | null
}

// Category Select Component
const CategorySelect = memo<{
    selectedCategory: string
    onCategoryChange: (value: string) => void
    errors: any
    touchedFields: any
}>(({ selectedCategory, onCategoryChange, errors, touchedFields }) => {
    const { data: categoriesData, isLoading: isCategoriesLoading } = useFetchAllCategories({
        page: 1,
        limit: 100,
    })

    const categories = useMemo(() => {
        if (!categoriesData?.data?.categories) return []
        return categoriesData.data.categories.map(category => ({
            value: category.categoryName,
            label: category.categoryName
        }))
    }, [categoriesData])

    const categoryLabel = useMemo(() => {
        if (!selectedCategory) return null
        return categories.find(c => c.value === selectedCategory)?.label
    }, [selectedCategory, categories])

    return (
        <div className="space-y-2">
            <Label htmlFor="category">
                Category <span className="text-destructive">*</span>
            </Label>
            <Select onValueChange={onCategoryChange} value={selectedCategory}>
                <SelectTrigger id="category" className="w-full">
                    <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent className="w-full">
                    {isCategoriesLoading ? (
                        <SelectItem value="loading" disabled>
                            Loading categories...
                        </SelectItem>
                    ) : categories.length === 0 ? (
                        <SelectItem value="no-categories" disabled>
                            No categories available
                        </SelectItem>
                    ) : (
                        categories.map((category) => (
                            <SelectItem
                                key={category.value}
                                value={category.value}
                                className="capitalize"
                            >
                                {category.label}
                            </SelectItem>
                        ))
                    )}
                </SelectContent>
            </Select>
            {categoryLabel && (
                <div className="text-sm mt-1 text-muted-foreground">{categoryLabel}</div>
            )}
            {touchedFields.category && errors.category?.message && (
                <p className="text-xs text-destructive">{errors.category.message}</p>
            )}
        </div>
    )
})

CategorySelect.displayName = "CategorySelect"

// Size Selector Component
const SizeSelector = memo<{
    selectedSizes: string
    onSizeChange: (size: string) => void
    errors: any
    touchedFields: any
}>(({ selectedSizes, onSizeChange, errors, touchedFields }) => {
    const handleSizeClick = useCallback((size: string) => {
        onSizeChange(selectedSizes === size ? '' : size)
    }, [selectedSizes, onSizeChange])

    return (
        <div className="space-y-2">
            <Label className="flex items-center gap-2">
                Available Size <span className="text-destructive">*</span>
                {touchedFields.sizes && errors.sizes?.message && (
                    <AlertCircle className="h-4 w-4 text-destructive" />
                )}
            </Label>
            <div className="flex flex-wrap gap-2">
                {SIZE_OPTIONS.map((size) => (
                    <button
                        key={size.id}
                        type="button"
                        onClick={() => handleSizeClick(size.value)}
                        className={`px-4 py-2 text-sm font-medium border rounded-lg transition-all ${selectedSizes === size.value
                            ? 'bg-primary text-primary-foreground border-primary shadow-sm'
                            : 'bg-background text-foreground border-input hover:bg-accent hover:border-primary/50'
                            }`}
                    >
                        {size.value}
                    </button>
                ))}
            </div>
            {selectedSizes && (
                <p className="text-xs text-muted-foreground">
                    Selected: <span className="font-medium">{selectedSizes}</span>
                </p>
            )}
            {touchedFields.sizes && errors.sizes?.message && (
                <p className="text-xs text-destructive">{errors.sizes.message}</p>
            )}
        </div>
    )
})

SizeSelector.displayName = "SizeSelector"

// Main Dialog Component
export const EditCostumeDialog = memo(({ open, onClose, costume }: EditCostumeDialogProps) => {
    const [isUploading, setIsUploading] = useState(false)
    const [previewImages, setPreviewImages] = useState<string[]>([])
    const [existingImages, setExistingImages] = useState<string[]>([])
    const [newImages, setNewImages] = useState<File[]>([])
    const { editCostume, isLoading } = useEditCostume()

    const {
        register,
        handleSubmit,
        formState: { errors, touchedFields },
        setValue,
        watch,
        reset
    } = useForm<CostumeFormData>({
        resolver: zodResolver(CostumeSchema),
        defaultValues: {
            name: "",
            description: "",
            rental_price: "",
            security_deposit: "",
            extended_days_price: "",
            sizes: "",
            category: "",
            brand: "",
            gender: "",
        }
    })

    const selectedCategory = watch("category")
    const selectedSizes = watch("sizes")

    // Load existing images when dialog opens
    useEffect(() => {
        if (open && costume) {
            const images: string[] = []

            if (costume.main_images?.front) images.push(costume.main_images.front)
            if (costume.main_images?.back) images.push(costume.main_images.back)
            if (costume.additional_images) {
                costume.additional_images.forEach((img) => {
                    if (img.url) images.push(img.url)
                })
            }

            setExistingImages(images)

            // Reset form with costume data
            reset({
                name: costume.name || "",
                description: costume.description || "",
                rental_price: costume.rental_price || "",
                security_deposit: costume.security_deposit || "",
                extended_days_price: costume.extended_days_price || "",
                sizes: costume.sizes || "",
                category: costume.category || "",
                brand: costume.brand || "",
                gender: costume.gender || "",
            })
        }
    }, [open, costume, reset])

    const onDrop = useCallback((acceptedFiles: File[]) => {
        const validFiles = acceptedFiles.filter(file =>
            ALLOWED_FILE_TYPES.includes(file.type) && file.size <= MAX_FILE_SIZE
        )

        if (validFiles.length !== acceptedFiles.length) {
            toast.error("Some files were not accepted. Only JPG, PNG, and WebP files under 5MB are allowed.")
        }

        const newPreviewUrls = validFiles.map(file => URL.createObjectURL(file))
        setPreviewImages(prev => [...prev, ...newPreviewUrls])
        setNewImages(prev => [...prev, ...validFiles])
    }, [])

    const removeNewImage = useCallback((index: number) => {
        const newPreviews = [...previewImages]
        const removedPreview = newPreviews.splice(index, 1)
        setPreviewImages(newPreviews)

        const currentFiles = [...newImages]
        currentFiles.splice(index, 1)
        setNewImages(currentFiles)

        URL.revokeObjectURL(removedPreview[0])
    }, [previewImages, newImages])

    const removeExistingImage = useCallback((index: number) => {
        const newExisting = [...existingImages]
        newExisting.splice(index, 1)
        setExistingImages(newExisting)
    }, [existingImages])

    const { getRootProps, getInputProps, isDragActive } = useDropzone({
        onDrop,
        accept: {
            'image/jpeg': ['.jpeg', '.jpg'],
            'image/png': ['.png'],
            'image/webp': ['.webp']
        },
        maxSize: MAX_FILE_SIZE,
        multiple: true
    })

    const onSubmit = async (data: CostumeFormData) => {
        try {
            setIsUploading(true)
            const toastId = toast.loading("Updating costume...")

            let newImageUrls: string[] = []

            // Upload new images if any
            if (newImages.length > 0) {
                const uploadPromises = newImages.map(file =>
                    uploadImage({
                        file,
                        folder: 'costumes',
                        customFileName: `${Date.now()}-${file.name}`
                    })
                )

                const uploadResults = await Promise.all(uploadPromises)
                newImageUrls = uploadResults
                    .filter(result => result && result.url)
                    .map(result => result.url as string)
            }

            // Combine existing and new images
            const allImages = [...existingImages, ...newImageUrls]

            // Prepare the final data
            const formData = {
                id: costume?.id,
                name: data.name,
                description: data.description,
                rental_price: data.rental_price,
                security_deposit: data.security_deposit,
                extended_days_price: data.extended_days_price,
                sizes: data.sizes,
                category: data.category,
                brand: data.brand,
                gender: data.gender,
                main_images: {
                    front: allImages[0] || "",
                    back: allImages[1] || ""
                },
                additional_images: allImages.slice(2).map((url, index) => ({
                    url,
                    alt_text: `Additional image ${index + 1} for ${data.name}`,
                    order: index + 1
                }))
            }

            // Call the editCostume mutation
            await editCostume(formData)

            toast.success("Costume updated successfully", { id: toastId })
            handleClose()
        } catch (error) {
            setIsUploading(false)
            console.error("Error updating costume:", error)
            toast.error("Failed to update costume. Please try again.")
        } finally {
            setIsUploading(false)
        }
    }

    const handleClose = () => {
        previewImages.forEach(url => URL.revokeObjectURL(url))
        setPreviewImages([])
        setExistingImages([])
        setNewImages([])
        reset()
        onClose()
    }

    if (!costume) return null

    return (
        <Dialog open={open} onOpenChange={(isOpen) => !isOpen && handleClose()}>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle className="text-2xl font-bold">Edit Costume</DialogTitle>
                    <p className="text-sm text-muted-foreground">Update costume information and images</p>
                </DialogHeader>

                <Separator className="my-4" />

                <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
                    {/* Image Upload Section */}
                    <div className="space-y-4">
                        <div>
                            <Label className="text-base font-semibold">Images</Label>
                            <p className="text-xs text-muted-foreground mt-1">
                                First image will be the front, second will be the back, rest will be additional images
                            </p>
                        </div>

                        {/* Existing Images */}
                        {existingImages.length > 0 && (
                            <div className="space-y-2">
                                <p className="text-sm font-medium text-muted-foreground">Current Images</p>
                                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                                    {existingImages.map((image, index) => (
                                        <div key={`existing-${index}`} className="relative group">
                                            <div className="aspect-square rounded-lg overflow-hidden border-2 border-border">
                                                <Image
                                                    src={image}
                                                    alt={`Existing ${index + 1}`}
                                                    width={200}
                                                    height={200}
                                                    className="w-full h-full object-cover transition-transform group-hover:scale-105"
                                                />
                                            </div>
                                            <button
                                                type="button"
                                                onClick={() => removeExistingImage(index)}
                                                className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-1.5 shadow-lg opacity-0 group-hover:opacity-100 transition-opacity hover:scale-110"
                                            >
                                                <X className="h-4 w-4" />
                                            </button>
                                            <span className="absolute bottom-2 left-2 bg-black/70 text-white text-xs font-medium px-2 py-1 rounded">
                                                {index === 0 ? "Front" : index === 1 ? "Back" : `Add ${index - 1}`}
                                            </span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* New Images Upload */}
                        <div
                            {...getRootProps()}
                            className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${isDragActive
                                ? 'border-primary bg-primary/5 scale-[0.98]'
                                : 'border-muted-foreground/25 hover:border-primary/50 hover:bg-accent/50'
                                }`}
                        >
                            <input {...getInputProps()} />
                            <div className="space-y-3">
                                <div className="mx-auto w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                                    <ImageIcon className="h-8 w-8 text-primary" />
                                </div>
                                <div>
                                    <p className="text-sm font-medium text-foreground">
                                        {isDragActive ? 'Drop the files here...' : 'Drag & drop new images here'}
                                    </p>
                                    <p className="text-xs text-muted-foreground mt-1">
                                        or click to browse files
                                    </p>
                                </div>
                                <p className="text-xs text-muted-foreground">
                                    JPG, PNG, WebP • Max 5MB per file
                                </p>
                            </div>
                        </div>

                        {/* New Image Previews */}
                        {previewImages.length > 0 && (
                            <div className="space-y-2">
                                <p className="text-sm font-medium text-primary">New Images to Upload</p>
                                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                                    {previewImages.map((preview, index) => (
                                        <div key={`new-${index}`} className="relative group">
                                            <div className="aspect-square rounded-lg overflow-hidden border-2 border-primary">
                                                <img
                                                    src={preview}
                                                    alt={`Preview ${index + 1}`}
                                                    className="w-full h-full object-cover transition-transform group-hover:scale-105"
                                                />
                                            </div>
                                            <button
                                                type="button"
                                                onClick={() => removeNewImage(index)}
                                                className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-1.5 shadow-lg opacity-0 group-hover:opacity-100 transition-opacity hover:scale-110"
                                            >
                                                <X className="h-4 w-4" />
                                            </button>
                                            <span className="absolute bottom-2 left-2 bg-primary text-primary-foreground text-xs font-medium px-2 py-1 rounded">
                                                New
                                            </span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>

                    <Separator />

                    {/* Form Fields */}
                    <div className="space-y-6">
                        <div>
                            <h3 className="text-base font-semibold mb-4">Costume Details</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {/* Name */}
                                <div className="space-y-2">
                                    <Label htmlFor="name">
                                        Costume Name <span className="text-destructive">*</span>
                                    </Label>
                                    <Input
                                        id="name"
                                        {...register("name")}
                                        maxLength={100}
                                        className={errors.name ? "border-destructive focus-visible:ring-destructive" : ""}
                                        placeholder="e.g., Shizuku Marin Costume"
                                    />
                                    {errors.name && (
                                        <p className="text-xs text-destructive flex items-center gap-1">
                                            <AlertCircle className="h-3 w-3" />
                                            {errors.name.message}
                                        </p>
                                    )}
                                </div>

                                {/* Brand */}
                                <div className="space-y-2">
                                    <Label htmlFor="brand">
                                        Brand <span className="text-destructive">*</span>
                                    </Label>
                                    <Input
                                        id="brand"
                                        {...register("brand")}
                                        className={errors.brand ? "border-destructive focus-visible:ring-destructive" : ""}
                                        placeholder="e.g., Unbranded, Custom Made"
                                    />
                                    {errors.brand && (
                                        <p className="text-xs text-destructive flex items-center gap-1">
                                            <AlertCircle className="h-3 w-3" />
                                            {errors.brand.message}
                                        </p>
                                    )}
                                </div>

                                {/* Category */}
                                <CategorySelect
                                    selectedCategory={selectedCategory}
                                    onCategoryChange={(value) => setValue("category", value, { shouldValidate: true, shouldTouch: true })}
                                    errors={errors}
                                    touchedFields={touchedFields}
                                />

                                {/* Gender */}
                                <div className="space-y-2">
                                    <Label htmlFor="gender">Gender</Label>
                                    <Select onValueChange={(value) => setValue("gender", value)} value={watch("gender")}>
                                        <SelectTrigger id="gender">
                                            <SelectValue placeholder="Select gender" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="unisex">Unisex</SelectItem>
                                            <SelectItem value="male">Male</SelectItem>
                                            <SelectItem value="female">Female</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>

                                {/* Size Selector - Full Width */}
                                <div className="md:col-span-2">
                                    <SizeSelector
                                        selectedSizes={selectedSizes}
                                        onSizeChange={(value) => setValue("sizes", value, { shouldValidate: true, shouldTouch: true })}
                                        errors={errors}
                                        touchedFields={touchedFields}
                                    />
                                </div>
                            </div>
                        </div>

                        <Separator />

                        {/* Pricing Section */}
                        <div>
                            <h3 className="text-base font-semibold mb-4">Pricing Information</h3>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                {/* Rental Price */}
                                <div className="space-y-2">
                                    <Label htmlFor="rental_price">
                                        Rental Price (₱) <span className="text-destructive">*</span>
                                    </Label>
                                    <Input
                                        id="rental_price"
                                        type="number"
                                        step="0.01"
                                        maxLength={5}
                                        {...register("rental_price")}
                                        className={errors.rental_price ? "border-destructive focus-visible:ring-destructive" : ""}
                                        placeholder="450.00"
                                    />
                                    {errors.rental_price && (
                                        <p className="text-xs text-destructive flex items-center gap-1">
                                            <AlertCircle className="h-3 w-3" />
                                            {errors.rental_price.message}
                                        </p>
                                    )}
                                </div>

                                {/* Security Deposit */}
                                <div className="space-y-2">
                                    <Label htmlFor="security_deposit">
                                        Security Deposit (₱) <span className="text-destructive">*</span>
                                    </Label>
                                    <Input
                                        id="security_deposit"
                                        type="number"
                                        step="0.01"
                                        max="10000"
                                        maxLength={5}
                                        {...register("security_deposit")}
                                        className={errors.security_deposit ? "border-destructive focus-visible:ring-destructive" : ""}
                                        placeholder="1500.00"
                                    />
                                    {errors.security_deposit && (
                                        <p className="text-xs text-destructive flex items-center gap-1">
                                            <AlertCircle className="h-3 w-3" />
                                            {errors.security_deposit.message}
                                        </p>
                                    )}
                                </div>

                                {/* Extended Days Price */}
                                <div className="space-y-2">
                                    <Label htmlFor="extended_days_price">
                                        Extended Days Price (₱) <span className="text-destructive">*</span>
                                    </Label>
                                    <Input
                                        id="extended_days_price"
                                        type="number"
                                        step="0.01"
                                        maxLength={5}
                                        {...register("extended_days_price")}
                                        className={errors.extended_days_price ? "border-destructive focus-visible:ring-destructive" : ""}
                                        placeholder="100.00"
                                    />
                                    {errors.extended_days_price && (
                                        <p className="text-xs text-destructive flex items-center gap-1">
                                            <AlertCircle className="h-3 w-3" />
                                            {errors.extended_days_price.message}
                                        </p>
                                    )}
                                </div>
                            </div>
                        </div>

                        <Separator />

                        {/* Description */}
                        <div className="space-y-2">
                            <Label htmlFor="description">
                                Description <span className="text-destructive">*</span>
                            </Label>
                            <Textarea
                                id="description"
                                {...register("description")}
                                rows={5}
                                maxLength={500}
                                className={errors.description ? "border-destructive focus-visible:ring-destructive" : ""}
                                placeholder="Provide a detailed description of the costume including material, condition, and any special features..."
                            />
                            {errors.description && (
                                <p className="text-xs text-destructive flex items-center gap-1">
                                    <AlertCircle className="h-3 w-3" />
                                    {errors.description.message}
                                </p>
                            )}
                        </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-between pt-6 border-t">
                        <p className="text-xs text-muted-foreground">
                            <span className="text-destructive">*</span> Required fields
                        </p>
                        <div className="flex gap-3">
                            <Button
                                type="button"
                                variant="outline"
                                onClick={handleClose}
                                disabled={isUploading || isLoading}
                                size="lg"
                            >
                                Cancel
                            </Button>
                            <Button type="submit" disabled={isUploading || isLoading} size="lg">
                                {isUploading || isLoading ? (
                                    <>
                                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                        Updating...
                                    </>
                                ) : (
                                    "Save Changes"
                                )}
                            </Button>
                        </div>
                    </div>
                </form>
            </DialogContent>
        </Dialog>
    )
})

EditCostumeDialog.displayName = "EditCostumeDialog"