"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { Costume } from "@/lib/api/costumeApi";
import { FilterX, PlusIcon } from "lucide-react";
import { useRouter } from "next/navigation";

interface ProductHeaderProps {
    searchQuery: string;
    onSearchChange: (query: string) => void;
    categoryFilter: string | null;
    onCategoryFilterChange: (category: string | null) => void;
    categories: string[];
    statusFilter: string | null;
    onStatusFilterChange: (status: string | null) => void;
    statuses: Costume["status"][];
    onResetFilters: () => void;
}

const ProductHeader = ({
    searchQuery,
    onSearchChange,
    categoryFilter,
    onCategoryFilterChange,
    categories,
    statusFilter,
    onStatusFilterChange,
    statuses,
    onResetFilters,
}: ProductHeaderProps) => {
    const router = useRouter();

    const handleAddNew = () => {
        router.push("/lender/products/create");
    };

    const hasActiveFilters =
        !!searchQuery ||
        (categoryFilter && categoryFilter !== "all") ||
        (statusFilter && statusFilter !== "all");

    return (
        <div className="space-y-3">
            {/* Header row */}
            <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold sm:text-2xl">Costumes</h2>
                <Button
                    onClick={handleAddNew}
                    size="sm"
                    className="h-9 px-3 sm:px-4"
                >
                    <PlusIcon className="mr-1 h-4 w-4 sm:mr-2" />
                    <span className="text-sm sm:text-base">Add New</span>
                </Button>
            </div>

            {/* Search and Filters */}
            <div className="space-y-2">
                {/* Search */}
                <Input
                    placeholder="Search costumes..."
                    value={searchQuery}
                    onChange={(e) => onSearchChange(e.target.value)}
                    className="w-full sm:max-w-xs"
                />

                {/* Filters */}
                <div className="flex flex-wrap items-center gap-2">
                    {/* Category Filter */}
                    <Select
                        value={categoryFilter || "all"}
                        onValueChange={(value) =>
                            onCategoryFilterChange(value === "all" ? null : value)
                        }
                    >
                        <SelectTrigger className="w-full sm:w-[140px]">
                            <SelectValue placeholder="Category" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Categories</SelectItem>
                            {categories.map((category) => (
                                <SelectItem key={category} value={category}>
                                    {category}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>

                    {/* Status Filter */}
                    <Select
                        value={statusFilter || "all"}
                        onValueChange={(value) =>
                            onStatusFilterChange(value === "all" ? null : value)
                        }
                    >
                        <SelectTrigger className="w-full sm:w-[140px]">
                            <SelectValue placeholder="Status" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Statuses</SelectItem>
                            {statuses.map((status) => (
                                <SelectItem key={status} value={status}>
                                    {status.charAt(0).toUpperCase() + status.slice(1)}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>

                    {/* Reset Filters */}
                    {hasActiveFilters && (
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={onResetFilters}
                            className="h-9 w-full sm:w-auto"
                        >
                            <FilterX className="mr-1 h-4 w-4" />
                            <span className="text-sm">Reset</span>
                        </Button>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ProductHeader;