"use client"
import SwitchRoleButton from "@/components/layout/UiSections/ButtonSwitch/SwitchRoleButton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { useGetUnreadNotificationCount, useGetMyNotifications } from "@/lib/api/notificationsApi";
import { cn } from '@/lib/utils';
import { ArrowLeft, Bell, HelpCircle, LogIn, LogOut, Menu, Settings, ShoppingCart, Shirt, User, ArrowRightLeft } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { usePathname, useRouter } from 'next/navigation';
import { useMemo, useState } from 'react';
import { useSupabaseAuth } from '@/lib/hooks/useSupabaseAuth';
import { Tooltip } from '@/components/ui/tooltip';
import { TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useGetUserDataByIdWithRole } from "@/lib/api/userApi";
import { MessagesButton } from "./UiSections/ButtonSwitch/MessageButton";
import MobileNotificationsDropdown from "@/components/Notifications/MobileNotificationsDropdown";

const Header = () => {
    const [isOpen, setIsOpen] = useState(false);
    const router = useRouter();
    const pathname = usePathname();

    // Use the centralized auth hook
    const { isAuthenticated, user, userData, currentRole, isLoading, signOut } = useSupabaseAuth();

    // Fetch profile data from users table (only if authenticated)
    const { data: userDataByRole } = useGetUserDataByIdWithRole(
        isAuthenticated ? (user?.id || "") : "",
        (isAuthenticated ? (currentRole || "borrower") : "borrower") as 'borrower' | 'lender'
    );

    // Memoize username extraction (prefer users table → auth hook → session metadata → email prefix)
    const username = useMemo(() => {
        const userEntity = (userDataByRole as any)?.data?.user
        const fromUsersTable = userEntity?.username
        const fromHook = userData?.username
        const fromMeta = user?.user_metadata?.username
        const fromEmail = (user?.user_metadata?.email || user?.email || "").split('@')[0]

        return (fromUsersTable || fromHook || fromMeta || fromEmail || "")
            .toString()
            .trim()
            .toLowerCase()
    }, [userDataByRole, userData?.username, user?.user_metadata?.username, user?.user_metadata?.email, user?.email]);

    // Fetch unread notification count
    const { data: unreadCountData, isLoading: isUnreadCountLoading } = useGetUnreadNotificationCount(
        isAuthenticated ? (currentRole || "borrower") : "borrower",
        isAuthenticated ? (user?.user_metadata?.email || user?.email || "") : ""
    );

    const unreadCount = unreadCountData?.data?.unreadCount || 0;
    const hasNewNotifications = unreadCount > 0;

    // Fetch a few recent notifications for dropdown (mobile)
    const {
        data: myNotifsData,
        isLoading: isMyNotifsLoading,
    } = useGetMyNotifications(
        (isAuthenticated ? (currentRole || "borrower") : "borrower") as any,
        isAuthenticated ? (user?.user_metadata?.email || user?.email || "") : "",
        1,
        5
    );

    // Compute display name
    const displayName = useMemo(() => {
        const userEntity = (userDataByRole as any)?.data?.user;
        const fullName = userEntity?.full_name;
        if (fullName && fullName.trim()) return fullName;

        if (userEntity && (userEntity.first_name || userEntity.last_name)) {
            return [
                userEntity.first_name,
                userEntity.middle_name,
                userEntity.last_name
            ].filter(Boolean).join(' ');
        }

        return user?.user_metadata?.name || username;
    }, [userDataByRole, user?.user_metadata?.name, username]);

    const navLinks = isAuthenticated
        ?
        [
            { name: 'Community', href: '/' },
            { name: 'Rental Services', href: '/rental-services' },
        ]
        : [
            { name: 'Rental Services', href: '/rental-services' }
        ];

    const supportLinks = [
        { name: 'Help Center', href: '/help', icon: HelpCircle },
        { name: 'Contact Support', href: '/support', icon: HelpCircle },
    ];

    const handleLogout = async () => {
        await signOut();
        router.push('/');
    };

    const handleRentalClick = () => {
        router.push('/my-rentals');
    };

    // Show loading state if still authenticating
    if (isLoading) {
        return (
            <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 dark:bg-primary-950/90 dark:border-primary-900">
                <div className="container flex h-16 items-center justify-between mx-auto px-4">
                    <Link href="/" className="flex items-center space-x-2">
                        <Image
                            src="/favicon.png"
                            alt="CosConnect Logo"
                            width={40}
                            height={40}
                            className="w-14 h-14"
                        />
                        <span className="hidden sm:block text-xl font-bold font-heading dark:text-white">CosConnect</span>
                    </Link>
                    <div className="flex items-center space-x-4">
                        <div className="h-8 w-8 rounded-full bg-muted animate-pulse" />
                    </div>
                </div>
            </header>
        );
    }

    return (
        <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 dark:bg-primary-950/90 dark:border-primary-900">
            <div className="container flex h-16 items-center justify-between mx-auto px-4">
                {/* Logo */}
                <div className='flex justify-start items-center gap-4 sm:gap-8'>
                    {/* Back Button */}
                    {pathname !== "/" && (
                        <button
                            onClick={() => router.back()}
                            className="mr-2 flex items-center justify-center rounded-full p-2 hover:bg-muted transition-colors"
                            aria-label="Go back"
                        >
                            <ArrowLeft className="h-5 w-5 text-foreground" />
                        </button>
                    )}
                    <Link href="/" className="flex items-center space-x-2">
                        <Image
                            src="/favicon.png"
                            alt="CosConnect Logo"
                            width={40}
                            height={40}
                            className="w-14 h-14"
                        />
                        <span className="hidden sm:block text-xl font-bold font-heading dark:text-white">CosConnect</span>
                    </Link>

                    {/* Desktop Navigation */}
                    <nav className="hidden md:flex items-center space-x-6">
                        {navLinks.map((link) => {
                            const isActive = pathname === link.href;
                            return (
                                <Link
                                    key={link.name}
                                    href={link.href}
                                    className={cn(
                                        "text-sm font-medium",
                                        "transition-colors duration-300",
                                        "hover:text-rose-600 dark:hover:text-rose-400",
                                        isActive && "text-rose-600 dark:text-rose-400 font-bold"
                                    )}
                                >
                                    {link.name}
                                </Link>
                            );
                        })}
                    </nav>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center sm:space-x-2 lg:space-x-4">
                    {/* Messages Button - Hidden on mobile, shown on md screens and up */}
                    {isAuthenticated && (
                        <Link href="/messages" className="hidden md:block">
                            <MessagesButton isAuthenticated={isAuthenticated} />
                        </Link>
                    )}

                    {/* Notifications (works on all screens) */}
                    {isAuthenticated && (
                        <MobileNotificationsDropdown />
                    )}

                    {/* My-rental Button - Desktop */}
                    {isAuthenticated && (
                        <div className="relative hidden md:block">
                            <TooltipProvider>
                                <Tooltip>
                                    <TooltipTrigger asChild>
                                        <Button
                                            variant="ghost"
                                            size="icon"
                                            className={cn(
                                                "cursor-pointer",
                                                "hover:text-rose-600 hover:bg-rose-50 dark:hover:text-rose-400 dark:hover:bg-rose-950",
                                                "transition-colors duration-300",
                                            )}
                                            onClick={handleRentalClick}
                                        >
                                            <Shirt className="h-5 w-5" />
                                        </Button>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                        My Rental Status
                                    </TooltipContent>
                                </Tooltip>
                            </TooltipProvider>
                        </div>
                    )}

                    {/* Mobile Rental Status */}
                    {isAuthenticated && (
                        <Button
                            variant="ghost"
                            size="icon"
                            className={cn(
                                "md:hidden",
                                "hover:text-rose-600 hover:bg-rose-50 dark:hover:text-rose-400 dark:hover:bg-rose-950",
                                "transition-colors duration-300"
                            )}
                            onClick={handleRentalClick}
                            aria-label="My Rental Status"
                        >
                            <Shirt className="h-5 w-5" />
                        </Button>
                    )}

                    {/* Auth Buttons / User Profile Dropdown */}
                    {!isAuthenticated ? (
                        <div className="hidden md:flex items-center gap-3">
                            <Button
                                asChild
                                variant="ghost"
                                className="text-foreground hover:bg-rose-50 hover:text-rose-600"
                            >
                                <Link href="/signin">
                                    Sign In
                                </Link>
                            </Button>
                            <Button
                                asChild
                                className="bg-rose-600 hover:bg-rose-700 text-white"
                            >
                                <Link href="/signup/choose-role">
                                    Sign Up
                                </Link>
                            </Button>
                        </div>
                    ) : (
                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <Button
                                    variant="ghost"
                                    className={cn(
                                        "hidden md:flex items-center gap-3 px-3 py-6 rounded-full group",
                                        "hover:text-rose-600 hover:bg-green-100 dark:hover:text-green-400 dark:hover:bg-rose-950",
                                        "transition-colors duration-300 cursor-pointer"
                                    )}
                                >
                                    {/* Avatar */}
                                    <Avatar className="h-8 w-8">
                                        <AvatarImage
                                            src={
                                                userData?.personal_info?.profile_image ||
                                                "https://img.freepik.com/premium-vector/default-avatar-profile-icon-social-media-user-image-gray-avatar-icon-blank-profile-silhouette-vector-illustration_561158-3383.jpg?semt=ais_hybrid&w=740&q=80"
                                            }
                                            alt={username}
                                        />
                                        <AvatarFallback>
                                            {username?.charAt(0).toUpperCase() || 'U'}
                                        </AvatarFallback>
                                    </Avatar>
                                    {/* User Info (outside dropdown) */}
                                    <div className="flex flex-col items-start max-w-[200px] leading-tight text-left">
                                        <div className="flex items-center gap-2 w-full">
                                            <span className="font-semibold text-sm text-foreground truncate max-w-[140px]">
                                                {displayName}
                                            </span>
                                            {currentRole && (
                                                <Badge
                                                    variant="secondary"
                                                    className={cn(
                                                        "h-5 px-1.5 py-0 text-[10px] capitalize rounded-sm shrink-0",
                                                        currentRole === 'lender'
                                                            ? "bg-rose-50 text-rose-700 border-rose-200"
                                                            : "bg-green-50 text-green-700 border-green-200"
                                                    )}
                                                >
                                                    {currentRole}
                                                </Badge>
                                            )}
                                        </div>
                                        <span className="text-[11px] text-muted-foreground truncate">
                                            @{username}
                                        </span>
                                    </div>
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-60">
                                <Link href={`/profile?id=${userData?.user_id}&role=${userData?.current_role}`} className='cursor-pointer'>
                                    <DropdownMenuItem className='cursor-pointer'>
                                        <User className="mr-2 h-4 w-4" />
                                        <span>Profile</span>
                                    </DropdownMenuItem>
                                </Link>
                                {currentRole === 'lender' ? (
                                    <DropdownMenuItem>
                                        <Shirt className="mr-2 h-4 w-4" />
                                        <span>Manage Orders</span>
                                    </DropdownMenuItem>
                                ) : (
                                    <Link href="/my-rentals">
                                        <DropdownMenuItem>
                                            <ShoppingCart className="mr-2 h-4 w-4" />
                                            <span>My Rentals</span>
                                        </DropdownMenuItem>
                                    </Link>
                                )}
                                <Link href="/settings">
                                    <DropdownMenuItem>
                                        <Settings className="mr-2 h-4 w-4" />
                                        <span>Settings</span>
                                    </DropdownMenuItem>
                                </Link>
                                <DropdownMenuItem onClick={handleLogout}>
                                    <LogOut className="mr-2 h-4 w-4" />
                                    <span>Logout</span>
                                </DropdownMenuItem>
                            </DropdownMenuContent>
                        </DropdownMenu>
                    )}

                    {isAuthenticated && (
                        <SwitchRoleButton
                            afterSwitch={() => {
                                if (typeof window !== "undefined") {
                                    window.location.reload();
                                }
                            }}
                            iconOnly
                        />
                    )}

                    {/* Mobile Menu */}
                    <Sheet open={isOpen} onOpenChange={setIsOpen}>
                        <SheetTrigger asChild>
                            <Button
                                variant="ghost"
                                size="icon"
                                className={cn(
                                    "md:hidden",
                                    "hover:text-rose-600 hover:bg-rose-50 dark:hover:text-rose-400 dark:hover:bg-rose-950",
                                    "transition-colors duration-300"
                                )}
                            >
                                <Menu className="h-5 w-5" />
                            </Button>
                        </SheetTrigger>
                        <SheetContent side="right" className="w-[300px] sm:w-[400px] dark:bg-primary-950 dark:border-primary-900">
                            <div className="flex flex-col h-full">
                                <SheetHeader className="border-b dark:border-primary-800">
                                    <SheetTitle className="flex items-center justify-between p-4">
                                        <Link href="/" className="flex items-center space-x-2" onClick={() => setIsOpen(false)}>
                                            <span className="text-xl font-bold font-heading dark:text-white">CosConnect</span>
                                        </Link>
                                    </SheetTitle>
                                </SheetHeader>

                                {/* Mobile Identity Block */}
                                {isAuthenticated && (
                                    <div className="px-4 py-4 border-b dark:border-primary-800 flex items-center justify-between gap-3">
                                        <Link href={`/profile?id=${userData?.user_id}&role=${userData?.current_role}`} className="flex items-center gap-3 min-w-0 hover:bg-rose-50 dark:hover:bg-rose-900 rounded-lg p-2 transition-colors duration-300 cursor-pointer w-full">
                                            <Avatar className="h-10 w-10">
                                                <AvatarImage src={userData?.personal_info?.profile_image || ""} alt={username} />
                                                <AvatarFallback>{username?.charAt(0).toUpperCase() || 'U'}</AvatarFallback>
                                            </Avatar>
                                            <div className="flex flex-col min-w-0">
                                                <span className="text-base font-semibold truncate">{displayName}</span>
                                                <div className="flex items-center gap-2 min-w-0">
                                                    <span className="text-xs text-muted-foreground truncate">@{username}</span>
                                                    {currentRole && (
                                                        <Badge
                                                            variant="secondary"
                                                            className={cn(
                                                                "text-[10px] capitalize h-5 px-1.5 py-0 rounded-sm",
                                                                currentRole === 'lender'
                                                                    ? "bg-rose-50 text-rose-700 border-rose-200"
                                                                    : "bg-green-50 text-green-700 border-green-200"
                                                            )}
                                                        >
                                                            {currentRole}
                                                        </Badge>
                                                    )}
                                                </div>
                                            </div>
                                        </Link>
                                    </div>
                                )}

                                {/* Mobile Menu Content */}
                                <div className="flex-1 overflow-y-auto">
                                    {/* Navigation Links */}
                                    <div className="space-y-2 px-4 py-4">
                                        <h3 className="text-sm font-semibold text-muted-foreground">Navigation</h3>
                                        {navLinks.map((link) => (
                                            <Link key={link.name} href={link.href}>
                                                <Button
                                                    variant="ghost"
                                                    className={cn(
                                                        "w-full justify-start",
                                                        "hover:bg-rose-50 dark:hover:bg-rose-900",
                                                        "hover:text-rose-600 dark:hover:text-rose-400",
                                                        "transition-colors duration-300",
                                                        pathname === link.href && "bg-rose-50 text-rose-600 dark:bg-rose-900 dark:text-rose-400"
                                                    )}
                                                    onClick={() => setIsOpen(false)}
                                                >
                                                    {link.name}
                                                </Button>
                                            </Link>
                                        ))}
                                    </div>

                                    {/* Account Section */}
                                    {isAuthenticated ? (
                                        <>
                                            <div className="space-y-2 px-4 py-4 border-t dark:border-primary-800">
                                                <h3 className="text-sm font-semibold text-muted-foreground">Account</h3>
                                                <Link href={`/profile?id=${userData?.user_id}&role=${userData?.current_role}`}>
                                                    <Button
                                                        variant="ghost"
                                                        className={cn(
                                                            "w-full justify-start space-x-3",
                                                            "hover:bg-rose-50 dark:hover:bg-rose-900",
                                                            "hover:text-rose-600 dark:hover:text-rose-400",
                                                            "transition-colors duration-300 cursor-pointer"
                                                        )}
                                                        onClick={() => setIsOpen(false)}
                                                    >
                                                        <User className="h-5 w-5" />
                                                        <span>Profile</span>
                                                    </Button>
                                                </Link>

                                                <MessagesButton
                                                    isAuthenticated={isAuthenticated}
                                                    setIsOpen={setIsOpen}
                                                />

                                                {currentRole === 'lender' && (
                                                    <Button
                                                        variant="ghost"
                                                        className={cn(
                                                            "w-full justify-start space-x-3",
                                                            "hover:bg-rose-50 dark:hover:bg-rose-900",
                                                            "hover:text-rose-600 dark:hover:text-rose-400",
                                                            "transition-colors duration-300"
                                                        )}
                                                        onClick={() => setIsOpen(false)}
                                                    >
                                                        <ShoppingCart className="h-5 w-5" />
                                                        <span>Manage Orders</span>
                                                    </Button>
                                                )}

                                                <Link href="/settings">
                                                    <Button
                                                        variant="ghost"
                                                        className={cn(
                                                            "w-full justify-start space-x-3",
                                                            "hover:bg-rose-50 dark:hover:bg-rose-900",
                                                            "hover:text-rose-600 dark:hover:text-rose-400",
                                                            "transition-colors duration-300"
                                                        )}
                                                        onClick={() => setIsOpen(false)}
                                                    >
                                                        <Settings className="h-5 w-5" />
                                                        <span>Settings</span>
                                                    </Button>
                                                </Link>

                                                <Button
                                                    variant="ghost"
                                                    className={cn(
                                                        "w-full justify-start space-x-3",
                                                        "hover:bg-rose-50 dark:hover:bg-rose-900",
                                                        "hover:text-rose-600 dark:hover:text-rose-400",
                                                        "transition-colors duration-300"
                                                    )}
                                                    onClick={() => {
                                                        handleLogout();
                                                        setIsOpen(false);
                                                    }}
                                                >
                                                    <LogOut className="h-5 w-5" />
                                                    <span>Logout</span>
                                                </Button>
                                            </div>
                                        </>
                                    ) : (
                                        <div className="space-y-2 px-4 py-4 border-t dark:border-primary-800">
                                            <Button
                                                variant="ghost"
                                                className={cn(
                                                    "w-full justify-start space-x-3",
                                                    "hover:bg-rose-50 dark:hover:bg-rose-900",
                                                    "hover:text-rose-600 dark:hover:text-rose-400",
                                                    "transition-colors duration-300"
                                                )}
                                                onClick={() => {
                                                    router.push('/signin');
                                                    setIsOpen(false);
                                                }}
                                            >
                                                <LogIn className="h-5 w-5" />
                                                <span>Sign In</span>
                                            </Button>
                                        </div>
                                    )}

                                    {/* Support Section */}
                                    <div className="space-y-2 px-4 py-4 border-t dark:border-primary-800">
                                        <h3 className="text-sm font-semibold text-muted-foreground">Support</h3>
                                        {supportLinks.map((link) => (
                                            <Link key={link.name} href={link.href}>
                                                <Button
                                                    variant="ghost"
                                                    className={cn(
                                                        "w-full justify-start space-x-3",
                                                        "hover:bg-rose-50 dark:hover:bg-rose-900",
                                                        "hover:text-rose-600 dark:hover:text-rose-400",
                                                        "transition-colors duration-300"
                                                    )}
                                                    onClick={() => setIsOpen(false)}
                                                >
                                                    <link.icon className="h-5 w-5" />
                                                    <span>{link.name}</span>
                                                </Button>
                                            </Link>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </SheetContent>
                    </Sheet>
                </div>
            </div>
        </header>
    );
};

export default Header;