
const SettingsSection = () => {
  return (
    <div>SettingsSection</div>
  )
}

export default SettingsSection