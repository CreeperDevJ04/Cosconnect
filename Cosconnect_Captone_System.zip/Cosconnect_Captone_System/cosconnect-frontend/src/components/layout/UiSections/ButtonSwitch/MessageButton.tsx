import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useMessageStore } from "@/lib/zustand/messageStore";
import { MessageCircle } from "lucide-react";

export function MessagesButton({
    isAuthenticated,
    setIsOpen,
}: {
    isAuthenticated: boolean
    setIsOpen?: (value: boolean) => void
}) {
    const { setMobileSidebarOpen } = useMessageStore();

    if (!isAuthenticated) return null

    const handleClick = () => {
        setMobileSidebarOpen(true);
        if (setIsOpen) setIsOpen(true);
    };

    return (
        <Button
            variant="ghost"
            className={cn(
                "w-full justify-start space-x-3",
                "hover:bg-rose-50 dark:hover:bg-rose-900",
                "hover:text-rose-600 dark:hover:text-rose-400",
                "transition-colors duration-300 cursor-pointer"
            )}
            onClick={handleClick}
        >
            <MessageCircle className="h-5 w-5" />
            <span>Messages</span>
        </Button>
    )
}
