"use client"

import { memo } from 'react';

interface Feedback {
    id: string;
    name: string;
    rating: number;
    comment: string;
    date: string;
}

interface RatingsAndFeedbackSectionProps {
    feedbacks: Feedback[];
}

const RatingsAndFeedbackSection = memo(({ feedbacks }: RatingsAndFeedbackSectionProps) => {
    if (!feedbacks || feedbacks.length === 0) {
        return null;
    }

    const getGridClasses = (length: number) => {
        if (length === 1) return 'grid-cols-1';
        if (length === 2) return 'grid-cols-1 md:grid-cols-2';
        return 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3';
    };

    return (
        <section className="py-16 bg-gray-50">
            <div className="max-w-6xl mx-auto px-4">
                <h2 className="text-3xl font-bold text-center mb-8">What Our Users Say</h2>
                <div className={`grid gap-8 ${getGridClasses(feedbacks.length)}`}>
                    {feedbacks.map((feedback) => (
                        <div key={feedback.id} className="bg-white p-6 rounded-lg shadow-md">
                            <div className="flex items-center mb-4">
                                <div className="flex">
                                    {Array.from({ length: 5 }, (_, i) => (
                                        <span 
                                            key={i} 
                                            className={`text-2xl ${i < feedback.rating ? 'text-yellow-400' : 'text-gray-300'}`}
                                        >
                                            ★
                                        </span>
                                    ))}
                                </div>
                                <span className="ml-2 text-gray-600">{feedback.rating}/5</span>
                            </div>
                            <p className="text-gray-700 mb-4">"{feedback.comment}"</p>
                            <div className="text-sm text-gray-500">
                                <p className="font-semibold">{feedback.name}</p>
                                <p>{feedback.date}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
});

RatingsAndFeedbackSection.displayName = 'RatingsAndFeedbackSection';

export default RatingsAndFeedbackSection;
