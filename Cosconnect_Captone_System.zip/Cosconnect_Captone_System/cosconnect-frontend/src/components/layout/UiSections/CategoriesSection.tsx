
const CategoriesSection = () => {
    return (
        <div>CategoriesSection</div>
    )
}

export default CategoriesSection