
const AboutSection = () => {
    return (
        <div>AboutSection</div>
    )
}

export default AboutSection