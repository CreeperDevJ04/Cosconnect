"use client";

import React from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Clock, Shield, Star } from "lucide-react";

const WhyChooseCosConnectSection = () => {
  const features = [
    {
      icon: Star,
      title: "For Borrowers",
      description:
        "Discover and rent unique cosplay costumes at affordable prices. Easy booking and flexible rental options for every event.",
    },
    {
      icon: Clock,
      title: "For Lenders",
      description:
        "Share your costumes and earn money from fellow cosplayers. Set your own rates and rental duration effortlessly.",
    },
    {
      icon: Shield,
      title: "Secure & Supportive",
      description:
        "Experience safe transactions, verified users, and a supportive cosplay community—built for creators and fans alike.",
    },
  ];

  return (
    <section
      className={cn(
        "py-16 w-full",
        "bg-background dark:bg-primary-950",
        "border-t border-border dark:border-primary-900"
      )}
    >
      <div className="max-w-6xl mx-auto px-4">
        <motion.h2
          className={cn(
            "text-3xl font-bold text-center mb-12 font-heading",
            "text-foreground dark:text-white"
          )}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
        >
          Why Choose CosConnect?
        </motion.h2>

        <motion.div
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
          variants={{
            hidden: { opacity: 0, y: 30 },
            visible: {
              opacity: 1,
              y: 0,
              transition: { staggerChildren: 0.15, duration: 0.5 },
            },
          }}
        >
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              variants={{
                hidden: { opacity: 0, y: 20 },
                visible: { opacity: 1, y: 0 },
              }}
              className={cn(
                "flex flex-col items-center text-center p-8 rounded-2xl",
                "bg-card dark:bg-primary-900",
                "border border-border dark:border-primary-800",
                "shadow-sm"
              )}
            >
              <div
                className={cn(
                  "h-14 w-14 rounded-full mb-4 flex items-center justify-center",
                  "bg-rose-100 dark:bg-rose-900"
                )}
              >
                <feature.icon className="h-7 w-7 text-rose-600" />
              </div>
              <h3
                className={cn(
                  "text-xl font-semibold mb-2 font-heading",
                  "text-foreground dark:text-white"
                )}
              >
                {feature.title}
              </h3>
              <p
                className={cn(
                  "text-sm leading-relaxed",
                  "text-muted-foreground dark:text-primary-300"
                )}
              >
                {feature.description}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default React.memo(WhyChooseCosConnectSection);
