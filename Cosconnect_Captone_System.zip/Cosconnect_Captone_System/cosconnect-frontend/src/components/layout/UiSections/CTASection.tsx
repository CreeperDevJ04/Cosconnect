
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { Store, User } from 'lucide-react'
import Link from 'next/link'
import React from 'react'


const CTASection = () => {
    return (
        <section className={cn(
            "py-16",
            "bg-background  dark:bg-background-dark",
            "border-t border-border dark:border-border-dark"
        )}>
            <div className="container mx-auto px-4 text-center">
                <h2 className={cn(
                    "text-3xl font-bold mb-6 font-heading",
                    "text-text dark:text-text-dark"
                )}>
                    Ready to Get Started?
                </h2>
                <p className={cn(
                    "text-xl mb-8 max-w-2xl mx-auto",
                    "text-text-muted dark:text-text-muted-dark"
                )}>
                    Join our community of cosplay enthusiasts and start your journey today!
                </p>

            </div>
        </section>
    )
}

export default React.memo(CTASection)
