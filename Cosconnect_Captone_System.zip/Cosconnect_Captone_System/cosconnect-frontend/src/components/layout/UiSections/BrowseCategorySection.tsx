// app/components/BrowseCategorySection.tsx
"use client";

import React from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Category } from "@/lib/types/categoryType";

interface BrowseCategorySectionProps {
  categoriesData: Category[] | undefined;
  isLoading: boolean;
  error?: any;
}

const BrowseCategorySection = ({
  categoriesData,
  isLoading,
  error,
}: BrowseCategorySectionProps) => {
  // Loading state
  if (isLoading) {
    return (
      <section className="py-16 w-full">
        <div className="w-full mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-8">Browse by Category</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div
                key={i}
                className="animate-pulse bg-muted rounded-xl h-24 sm:h-28"
              ></div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  // Error or no data
  if (error || !categoriesData) {
    return (
      <section className="py-16 w-full text-center">
        <div className="w-full mx-auto px-4">
          <h2 className="text-3xl font-bold mb-4">Browse by Category</h2>
          <p className="text-muted-foreground">
            Failed to load categories. Please try again later.
          </p>
        </div>
      </section>
    );
  }

  // Only show active categories
  const activeCategories = categoriesData.filter(
    (cat) => cat.status === "active"
  );

  return (
    <section
      className={cn(
        "py-16 w-full",
        "bg-background dark:bg-primary-950",
        "border-t border-border dark:border-primary-900"
      )}
    >
      <div className="max-w-6xl mx-auto px-4">
        <h2
          className={cn(
            "text-3xl font-bold text-center mb-10 font-heading",
            "text-foreground dark:text-white"
          )}
        >
          Browse by Category
        </h2>

        <motion.div
          className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
          variants={{
            hidden: { opacity: 0, y: 30 },
            visible: {
              opacity: 1,
              y: 0,
              transition: { staggerChildren: 0.1, duration: 0.4 },
            },
          }}
        >
          {activeCategories.map((category) => (
            <motion.div
              key={category.id || category.categoryName}
              variants={{ hidden: { opacity: 0, y: 15 }, visible: { opacity: 1, y: 0 } }}
              className={cn(
                "flex flex-col items-center justify-center text-center",
                "p-6 rounded-xl",
                "bg-card dark:bg-primary-900",
                "text-foreground dark:text-primary-100",
                "border border-border dark:border-primary-800",
                "shadow-sm hover:shadow-md transition-all duration-300"
              )}
            >
              <h3 className="font-semibold text-lg mb-1">
                {category.categoryName}
              </h3>
              <p className="text-sm text-muted-foreground dark:text-primary-300">
                {category.productListingCount} costumes available
              </p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default React.memo(BrowseCategorySection);
