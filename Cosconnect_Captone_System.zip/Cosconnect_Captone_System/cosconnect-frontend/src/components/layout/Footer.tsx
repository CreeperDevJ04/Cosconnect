// app/components/Footer.tsx
"use client";

import { cn } from "@/lib/utils";
import { Facebook, Instagram, Twitter } from "lucide-react";
import Link from "next/link";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    main: [
      { name: "About Us", href: "/footer/about"},
      /* { name: "Contact", href: "/footer/contact" }, */
      { name: "FAQs", href: "/footer/faqs" },
    ],
    legal: [
      { name: "Terms of Service", href: "/terms" },
      { name: "Privacy Policy", href: "/privacy" },
    ],
  };

  const socialLinks = [
    { name: "Facebook", icon: Facebook, href: "https://www.facebook.com/profile.php?id=61577372235506" },
   /*  { name: "Twitter", icon: Twitter, href: "https://twitter.com" }, */
    /* { name: "Instagram", icon: Instagram, href: "https://instagram.com" }, */
  ];

  return (
    <footer
      className={cn(
        "bg-background border-t w-full dark:bg-primary-950 dark:border-primary-900",
        "transition-colors duration-300"
      )}
    >
      <div className="container mx-auto px-1 py-2 flex flex-col md:flex-row justify-between items-center md:space-x-6 space-y-6 md:space-y-0">
        {/* Left - Logo + Description */}
        <div className="text-center md:text-left max-w-xs">
          <h3 className="text-lg font-bold font-heading dark:text-white">
            CosConnect
          </h3>
          <p className="text-sm text-muted-foreground dark:text-primary-200 mt-1">
            Your trusted source for cosplay costume rentals. Bring your
            favorite characters to life.
          </p>
        </div>

        {/* Middle - Quick Links */}
        <ul className="flex flex-wrap justify-center absolute-left-2 gap-2">
          {footerLinks.main.map((link) => (
            <li key={link.name}>
              <Link
                href={link.href}
                className={cn(
                  "text-sm text-muted-foreground dark:text-primary-300",
                  "hover:text-rose-600 dark:hover:text-rose-400",
                  "transition-colors duration-300"
                )}
              >
                {link.name}
              </Link>
            </li>
          ))}
        </ul>

        {/* Right - Socials */}
        <div className="flex space-x-2">
          {socialLinks.map((social) => (
            <Link
              key={social.name}
              href={social.href}
              target="_blank"
              rel="noopener noreferrer"
              className={cn(
                "text-muted-foreground dark:text-primary-300",
                "hover:text-rose-600 dark:hover:text-rose-400",
                "transition-colors duration-300"
              )}
            >
              <social.icon className="h-10 w-9 absolute-right-44" />
            </Link>
          ))}
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t mt-4 pt-4 flex flex-col md:flex-row justify-between items-center text-sm text-muted-foreground dark:text-primary-300 px-4">
        <p>© {currentYear} CosConnect. All rights reserved.</p>
        <div className="flex gap-4 mt-2 md:mt-0">
          {footerLinks.legal.map((link) => (
            <Link
              key={link.name}
              href={link.href}
              className={cn(
                "hover:text-rose-600 dark:hover:text-rose-400 transition-colors duration-300"
              )}
            >
              {link.name}
            </Link>
          ))}
        </div>
      </div>
    </footer>
  );
};

export default Footer;
