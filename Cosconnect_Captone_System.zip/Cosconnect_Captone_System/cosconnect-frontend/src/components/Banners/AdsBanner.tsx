"use client";

import { motion } from "framer-motion";
import Image from "next/image";
import { Card, CardContent } from "@/components/ui/card";
import { ExternalLink, Sparkles } from "lucide-react";

const ADS_DATA = [
  {
    id: 1,
    imageUrl: "https://hrmjoilyjstxvriyedgz.supabase.co/storage/v1/object/public/images/ads.gif",
    title: "Discover amazing deals and offers",
    description: "Click to learn more"
  },
  {
    id: 2,
    imageUrl: "https://hrmjoilyjstxvriyedgz.supabase.co/storage/v1/object/public/images/ads2.gif",
    title: "Special promotions available",
    description: "Don't miss out"
  }
];

export default function AdsBanner() {
  return (
    <div className="w-full space-y-4">
      {ADS_DATA.map((ad, index) => (
        <motion.div
          key={ad.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
          className="w-full"
        >
          <Card className="overflow-hidden border border-slate-200 bg-white shadow-sm">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-purple-500 to-pink-500">
                  <Sparkles className="h-4 w-4 text-white" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-slate-900">Sponsored</h3>
                  <p className="text-xs text-slate-500">Advertisement</p>
                </div>
              </div>
              <ExternalLink className="h-4 w-4 text-slate-400" />
            </div>

            {/* Ad Content */}
            <CardContent className="p-0">
              <motion.div
                whileHover={{ scale: 1.02 }}
                transition={{ duration: 0.2 }}
                className="relative cursor-pointer overflow-hidden"
              >
                <div className="relative aspect-square w-full">
                  <Image
                    src={ad.imageUrl}
                    alt="Advertisement"
                    fill
                    className="object-cover"
                    unoptimized // Allow GIF animation
                  />
                  
                  {/* Overlay gradient for better text readability if needed */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent" />
                  
                  {/* Optional overlay content */}
                  <div className="absolute bottom-0 left-0 right-0 p-4">
                    <div className="rounded-lg bg-white/90 backdrop-blur-sm p-3">
                      <p className="text-xs font-medium text-slate-800">
                        {ad.title}
                      </p>
                      <p className="text-xs text-slate-600 mt-1">
                        {ad.description}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Hover effect */}
                <motion.div
                  initial={{ opacity: 0 }}
                  whileHover={{ opacity: 1 }}
                  className="absolute inset-0 bg-gradient-to-t from-purple-500/10 to-transparent"
                />
              </motion.div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}
