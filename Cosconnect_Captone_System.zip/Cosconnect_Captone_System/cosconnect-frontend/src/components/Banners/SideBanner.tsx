import ActiveRentalsBanner from "./ActiveRentalsBanner";
import PremiumSubscriptionCard from "./SubscriptionBanner";
import { useSupabaseAuth } from "@/lib/hooks/useSupabaseAuth";

export default function SidebarBanners() {
    const { userData } = useSupabaseAuth();

    const isLender = userData?.roles?.includes("lender");
    return (
        <div className=" top-4 space-y-4">
            {/* Active Rentals Section */}
            <ActiveRentalsBanner user_id={userData?.user_id as string} />

            {/* Premium Subscription Section */}
            {isLender && <PremiumSubscriptionCard />}
        </div>
    );
}