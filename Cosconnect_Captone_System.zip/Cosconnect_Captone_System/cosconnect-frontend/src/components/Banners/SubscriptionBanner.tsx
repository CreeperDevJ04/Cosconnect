import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Crown,
  CheckCircle2,
  Star,
  Shield,
  ChevronDown,
  ChevronUp,
  Sparkles,
  TrendingUp,
  Zap,
  MessageCircle,
  Award,
  BarChart3
} from "lucide-react";
import PaySubscriptionDialog from "./PaySubscriptionDialog";

const PREMIUM_FEATURES = [
  {
    icon: TrendingUp,
    text: "Priority visibility in search results",
    highlight: true
  },
  {
    icon: Award,
    text: "Exclusive Premium badge on profile & posts",
    highlight: true
  },
  {
    icon: Star,
    text: "Upload up to 10 active costume listings",
    highlight: false
  },
  {
    icon: Sparkles,
    text: "Featured in Premium Lenders section",
    highlight: false
  },
  {
    icon: MessageCircle,
    text: "Priority customer support response",
    highlight: false
  },
  {
    icon: CheckCircle2,
    text: "5% discount on all platform fees",
    highlight: false
  },
  {
    icon: BarChart3,
    text: "Detailed analytics & insights dashboard",
    highlight: false
  },
  {
    icon: Sparkles,
    text: "Custom profile banner customization",
    highlight: false
  }
];

export default function PremiumSubscriptionCard() {
  const [showAllFeatures, setShowAllFeatures] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const visibleFeatures = showAllFeatures
    ? PREMIUM_FEATURES
    : PREMIUM_FEATURES.slice(0, 4);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      className="w-full"
    >
      <Card className="overflow-hidden border-2 border-rose-200 bg-white shadow-lg">
        {/* Header */}
        <CardHeader className="relative border-b border-rose-100 bg-rose-50 pb-3 pt-3">
          {/* Animated sparkles */}
          <motion.div
            animate={{
              opacity: [0.5, 1, 0.5],
              scale: [1, 1.2, 1]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
            className="absolute right-3 top-3"
          >
            <Sparkles className="h-4 w-4 text-rose-400" />
          </motion.div>

          <div className="flex items-start gap-2">
            <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg bg-rose-500 shadow-md">
              <Crown className="h-4 w-4 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <CardTitle className="text-lg font-bold text-slate-900">
                  Premium Lender
                </CardTitle>
                <span className="flex-shrink-0 rounded-full bg-rose-500 px-2 py-0.5 text-xs font-bold text-white shadow-sm">
                  PRO
                </span>
              </div>
              <p className="mt-0.5 text-xs text-slate-600 line-clamp-2">
                Boost visibility and grow your costume rental business faster
              </p>
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-4 space-y-4">
          {/* Pricing Section */}
          <motion.div
            whileHover={{ scale: 1.02 }}
            className="relative overflow-hidden rounded-lg border-2 border-blue-200 bg-blue-50 p-3"
          >
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-bold text-slate-900">₱999</span>
                  <span className="text-xs font-medium text-slate-600">/month</span>
                </div>
                <p className="mt-0.5 text-xs text-slate-500">Cancel anytime • No commitment</p>
              </div>
              <motion.div
                animate={{
                  rotate: [0, 10, -10, 0],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                <Zap className="h-6 w-6 text-blue-500" />
              </motion.div>
            </div>
          </motion.div>

          {/* Features List */}
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Star className="h-4 w-4 text-rose-500" />
              <h4 className="text-xs font-bold text-slate-900">Premium Benefits</h4>
            </div>

            <motion.ul layout className="space-y-2">
              <AnimatePresence>
                {visibleFeatures.map((feature, i) => (
                  <motion.li
                    key={i}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ delay: i * 0.05 }}
                    className="flex items-start gap-3"
                  >
                    <div className={`flex-shrink-0 rounded-lg p-1.5 ${feature.highlight ? 'bg-rose-100' : 'bg-slate-100'
                      }`}>
                      <feature.icon className={`h-4 w-4 ${feature.highlight ? 'text-rose-600' : 'text-slate-600'
                        }`} />
                    </div>
                    <span className={`text-sm leading-relaxed break-words ${feature.highlight ? 'font-semibold text-slate-900' : 'text-slate-700'
                      }`}>
                      {feature.text}
                    </span>
                  </motion.li>
                ))}
              </AnimatePresence>
            </motion.ul>

            {/* Show More/Less Button */}
            {PREMIUM_FEATURES.length > 4 && (
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setShowAllFeatures(!showAllFeatures)}
                className="flex w-full items-center justify-center gap-2 rounded-lg border border-slate-200 bg-white py-2.5 text-sm font-medium text-slate-700 transition-colors hover:bg-slate-50"
              >
                <span>{showAllFeatures ? "Show Less" : `See ${PREMIUM_FEATURES.length - 4} More Features`}</span>
                <motion.div
                  animate={{ rotate: showAllFeatures ? 180 : 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <ChevronDown className="h-4 w-4" />
                </motion.div>
              </motion.button>
            )}
          </div>

          {/* Stats Highlight */}
          <div className="rounded-lg border border-rose-200 bg-rose-50 p-3">
            <h4 className="mb-2 flex items-center gap-2 text-xs font-bold text-rose-900">
              <TrendingUp className="h-3 w-3" />
              Premium Impact
            </h4>
            <div className="grid grid-cols-3 gap-2">
              <div className="rounded-lg bg-white p-2 text-center shadow-sm">
                <div className="text-lg font-bold text-rose-600">3x</div>
                <div className="mt-0.5 text-xs font-medium text-slate-600 break-words">More Views</div>
              </div>
              <div className="rounded-lg bg-white p-2 text-center shadow-sm">
                <div className="text-lg font-bold text-rose-600">5x</div>
                <div className="mt-0.5 text-xs font-medium text-slate-600 break-words">Bookings</div>
              </div>
              <div className="rounded-lg bg-white p-2 text-center shadow-sm">
                <div className="text-lg font-bold text-rose-600">10</div>
                <div className="mt-0.5 text-xs font-medium text-slate-600 break-words">Listings</div>
              </div>
            </div>
          </div>

          {/* CTA Button */}
          <div className="space-y-2">
            <PaySubscriptionDialog>
              <motion.div
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                onHoverStart={() => setIsHovered(true)}
                onHoverEnd={() => setIsHovered(false)}
              >
                <Button
                  className="relative w-full overflow-hidden bg-rose-500 py-4 text-sm font-bold text-white shadow-lg transition-all hover:bg-rose-600 hover:shadow-xl"
                  size="lg"
                >
                  {/* Shine effect */}
                  <motion.div
                    animate={isHovered ? {
                      x: ['-100%', '100%'],
                      opacity: [0, 0.5, 0]
                    } : {}}
                    transition={{
                      duration: 0.6,
                      ease: "easeInOut"
                    }}
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent"
                  />

                  <span className="relative flex items-center justify-center gap-2">
                    <Crown className="h-5 w-5" />
                    <motion.span
                      animate={isHovered ? {
                        y: [0, -2, 0]
                      } : {}}
                      transition={{
                        duration: 0.5,
                        repeat: isHovered ? Infinity : 0
                      }}
                    >
                      Upgrade to Premium
                    </motion.span>
                  </span>
                </Button>
              </motion.div>
            </PaySubscriptionDialog>

            <div className="flex items-center justify-center gap-2 text-xs text-slate-500">
              <Shield className="h-3.5 w-3.5 flex-shrink-0" />
              <span className="text-wrap">Secure payment • Powered by PayMongo</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}