"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Image from "next/image";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Clock,
  Calendar,
  AlertTriangle,
  Package,
  ArrowRight,
  MapPin,
  User,
  Phone
} from "lucide-react";
import { useGetMyRentals } from "@/lib/api/rentalApi";

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

const CountdownTimer = ({ date }: { date: string }) => {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  useEffect(() => {
    const calculateTimeLeft = () => {
      const now = new Date();
      const target = new Date(date);
      const diff = target.getTime() - now.getTime();

      if (diff <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        return;
      }

      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      setTimeLeft({ days, hours, minutes, seconds });
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);
    return () => clearInterval(timer);
  }, [date]);

  const isUrgent = timeLeft.days === 0 && timeLeft.hours < 24;
  const isOverdue = timeLeft.days === 0 && timeLeft.hours === 0 &&
    timeLeft.minutes === 0 && timeLeft.seconds === 0;

  return (
    <motion.div
      className={`flex items-center gap-1.5 text-xs font-semibold ${isOverdue ? "text-red-600" : isUrgent ? "text-orange-600" : "text-blue-600"
        }`}
      animate={{ scale: isUrgent ? [1, 1.05, 1] : 1 }}
      transition={{ duration: 1, repeat: isUrgent ? Infinity : 0 }}
    >
      {isOverdue ? (
        <AlertTriangle className="h-3.5 w-3.5 flex-shrink-0" />
      ) : (
        <Clock className="h-3.5 w-3.5 flex-shrink-0" />
      )}
      <div className="flex items-center gap-1 whitespace-nowrap">
        {isOverdue ? (
          <span>Overdue</span>
        ) : (
          <>
            {timeLeft.days > 0 && <span>{timeLeft.days}d</span>}
            <span>{String(timeLeft.hours).padStart(2, '0')}h</span>
            <span>{String(timeLeft.minutes).padStart(2, '0')}m</span>
          </>
        )}
      </div>
    </motion.div>
  );
};

const formatReturnDate = (dateString: string) => {
  const date = new Date(dateString);
  return date.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
};

const getStatusColor = (status: string) => {
  const statusLower = status.toLowerCase();
  switch (statusLower) {
    case 'active':
    case 'rented':
    case 'confirmed':
      return 'bg-emerald-100 text-emerald-700 border-emerald-200';
    case 'overdue':
      return 'bg-red-100 text-red-700 border-red-200';
    case 'extended':
      return 'bg-amber-100 text-amber-700 border-amber-200';
    case 'pending':
      return 'bg-yellow-100 text-yellow-700 border-yellow-200';
    default:
      return 'bg-slate-100 text-slate-700 border-slate-200';
  }
};

export default function ActiveRentalsBanner({ user_id }: { user_id: string }) {

  const [hoveredId, setHoveredId] = useState<string | null>(null);

  const { data, isLoading, error } = useGetMyRentals({
    userId: user_id,
    page: 1,
    limit: 10,
    status: undefined,
  });

  const rentals = data?.data?.rentals || [];
  const activeRentals = rentals
    .filter((rental: any) =>
      ['active', 'rented', 'extended', 'confirmed'].includes(rental.status.toLowerCase())
    )
    .slice(0, 4);

  // Loading state
  if (isLoading) {
    return (
      <div className="w-full rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div className="flex items-center justify-between border-b border-slate-100 px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-100">
              <Package className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-slate-900">Active Rentals</h3>
              <p className="text-xs text-slate-500">Loading your rentals...</p>
            </div>
          </div>
        </div>
        <div className="space-y-3 p-6">
          {[1, 2].map((i) => (
            <div key={i} className="flex gap-4 rounded-xl border border-slate-200 bg-white p-4">
              <div className="h-20 w-20 animate-pulse rounded-lg bg-slate-200" />
              <div className="flex-1 space-y-2">
                <div className="h-4 w-3/4 animate-pulse rounded bg-slate-200" />
                <div className="h-3 w-1/2 animate-pulse rounded bg-slate-200" />
                <div className="h-3 w-1/3 animate-pulse rounded bg-slate-200" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // No rentals or error
  if (error || !rentals || activeRentals.length === 0) {
    return null;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full"
    >
      <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-100">
              <Package className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-slate-900">Active Rentals</h3>
              <p className="text-xs text-slate-500">Track your current costume rentals</p>
            </div>
          </div>

        </div>

        {/* Rentals List */}
        <div className="space-y-3 p-6">
          <AnimatePresence>
            {activeRentals.map((rental: any, index: number) => {
              const imageUrl = rental.costume_snapshot?.main_images?.front ||
                rental.costume_snapshot?.main_images?.back ||
                'https://images.unsplash.com/photo-1583544264732-89b5e1e6e0b9?w=400&h=400&fit=crop';

              const lenderName = rental.costume_snapshot?.lender_info?.name || 'Unknown';
              const lenderPhone = rental.costume_snapshot?.lender_info?.phone || 'N/A';
              const pickupLocation = rental.pickup_location || 'Not specified';
              const costumeName = rental.costume_snapshot?.name || 'Costume';

              return (
                <motion.div
                  key={rental.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                  onHoverStart={() => setHoveredId(rental.id)}
                  onHoverEnd={() => setHoveredId(null)}
                  className="group relative overflow-hidden rounded-xl border border-slate-200 bg-white transition-all hover:border-blue-300 hover:shadow-md"
                >
                  <div className="flex flex-col gap-4 p-4">
                    {/* Image */}
                    <div className="relative w-full h-48 overflow-hidden rounded-lg border border-slate-200">
                      {imageUrl ? (
                        <Image
                          src={imageUrl}
                          alt={costumeName}
                          fill
                          sizes="100vw"
                          className="object-cover transition-transform group-hover:scale-110"
                          priority={index === 0}
                        />
                      ) : (
                        <div className="flex h-full w-full items-center justify-center rounded-lg bg-slate-100 text-xs text-slate-500">
                          No image uploaded
                        </div>
                      )}

                      {rental.extended_days > 0 && (
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="absolute -right-2 -top-2"
                        >
                          <div className="flex h-6 w-6 items-center justify-center rounded-full bg-amber-500 text-xs font-bold text-white shadow-md">
                            +{rental.extended_days}
                          </div>
                        </motion.div>
                      )}
                    </div>

                    {/* Content */}
                    <div className="flex min-w-0 flex-1 flex-col justify-between">
                      {/* Top Section */}
                      <div className="space-y-2">
                        <div className="flex items-start justify-between gap-3">
                          <h4 className="truncate text-sm font-semibold text-slate-900 pr-2">
                            {costumeName}
                          </h4>
                          <span className={`flex-shrink-0 rounded-md border px-2 py-0.5 text-xs font-medium ${getStatusColor(rental.status)}`}>
                            {rental.status}
                          </span>
                        </div>

                        {/* Lender Info */}
                        <div className="flex items-center gap-2 text-xs text-slate-600">
                          <User className="h-3 w-3 flex-shrink-0" />
                          <span className="truncate">Lender: {lenderName}</span>
                        </div>

                        {/* Return Date */}
                        <div className="flex items-center gap-2 text-xs text-slate-600">
                          <Calendar className="h-3 w-3 flex-shrink-0" />
                          <span className="truncate">Return: {formatReturnDate(rental.end_date)}</span>
                        </div>

                        {/* Pickup Location */}
                        <div className="flex items-center gap-2 text-xs text-slate-600">
                          <MapPin className="h-3 w-3 flex-shrink-0" />
                          <span className="truncate">{pickupLocation}</span>
                        </div>

                        <p className="truncate text-xs text-slate-400">
                          Ref: {rental.reference_code}
                        </p>
                      </div>

                      {/* Bottom Section */}
                      <div className="mt-2 flex items-center justify-between gap-2">
                        <CountdownTimer date={rental.end_date} />
                      </div>
                    </div>
                  </div>

                  {/* Hover Effect */}
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: hoveredId === rental.id ? 1 : 0 }}
                    className="absolute inset-0 rounded-xl border-2 border-blue-400 pointer-events-none"
                  />
                </motion.div>
              );
            })}
          </AnimatePresence>

          {/* Action Button */}
          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="group flex w-full items-center justify-center gap-2 rounded-xl border-2 border-blue-200 bg-white py-3 text-sm font-semibold text-blue-600 transition-all hover:border-blue-300 hover:bg-blue-50"
          >
            Manage All Rentals
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
}