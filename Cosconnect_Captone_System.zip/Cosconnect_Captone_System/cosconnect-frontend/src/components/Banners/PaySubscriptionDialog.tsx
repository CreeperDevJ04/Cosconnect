"use client";

import React, { useEffect, useState } from "react";
import { useSupabaseAuth } from "@/lib/hooks/useSupabaseAuth";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  Loader2,
  Shield,
  CheckCircle2,
  Crown,
  Smartphone,
  CreditCard,
  Building2,
  Wallet,
} from "lucide-react";
import { toast } from "sonner";
import {
  PaySubscriptionResponse,
  usePaySubscription,
} from "@/lib/api/subscriptionApi";

// Zod schema for subscription form
const subscriptionSchema = z.object({
  fullName: z.string().min(2, "Full name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  phoneNumber: z
    .string()
    .min(10, "Phone number is required")
    .regex(
      /^\+63\s\d{3}\s\d{3}\s\d{4}$/,
      "Please enter a valid Philippine phone number"
    ),
});

type SubscriptionFormData = z.infer<typeof subscriptionSchema>;

interface PaySubscriptionDialogProps {
  children?: React.ReactNode;
}

const PaySubscriptionDialog: React.FC<PaySubscriptionDialogProps> = ({
  children,
}) => {
  const { userData, isLoading: isUserLoading } = useSupabaseAuth();
  const [open, setOpen] = useState(false);
  const { isLoading: isPaying, paySubscription } = usePaySubscription();

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<SubscriptionFormData>({
    resolver: zodResolver(subscriptionSchema),
    defaultValues: {
      fullName: "",
      email: "",
      phoneNumber: "+63",
    },
  });

  // Set default form values from userData
  useEffect(() => {
    if (userData?.personal_info) {
      setValue("fullName", userData.personal_info.full_name || "");
    }
    if (userData?.email) {
      setValue("email", userData.email);
    }
  }, [userData, setValue]);

  // Format phone number as user types
  const handlePhoneNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, "");

    if (value.startsWith("63")) value = value.substring(2);
    if (value.length > 0 && value[0] !== "9") value = "9" + value.slice(0, 9);
    else if (value.length > 10) value = value.substring(0, 10);

    const formatted = "+63" + value;
    const match = formatted.match(/^\+63(\d{0,3})(\d{0,3})(\d{0,4})/);
    if (!match) {
      setValue("phoneNumber", "+63");
      return;
    }

    const [, part1, part2, part3] = match;
    let display = "+63";
    if (part1) display += ` ${part1}`;
    if (part2) display += ` ${part2}`;
    if (part3) display += ` ${part3}`;
    setValue("phoneNumber", display.trim());
  };

  const onSubmit = async (data: SubscriptionFormData) => {
    try {
      const payload = { ...data, user_id: userData?.user_id };
      const response: PaySubscriptionResponse = await paySubscription(
        payload as any
      );
      window.location.href = response.data.checkout_url;
    } catch (error) {
      toast.error("Payment Failed", {
        description: "Unable to process payment. Please try again.",
      });
    }
  };

  const paymentMethods = [
    { id: "gcash", name: "GCash", icon: Smartphone },
    { id: "paymaya", name: "PayMaya", icon: Wallet },
    { id: "card", name: "Credit/Debit Card", icon: CreditCard },
    { id: "bank", name: "Online Banking", icon: Building2 },
  ];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {children || (
          <Button className="w-full bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-700 hover:to-rose-800">
            Subscribe Now
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        {isUserLoading ? (
          <div className="flex items-center justify-center py-10">
            <Loader2 className="h-6 w-6 animate-spin text-rose-600" />
            <span className="ml-2 text-gray-600">Loading user data...</span>
          </div>
        ) : (
          <>
            <DialogHeader>
              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-rose-100">
                  <Crown className="h-6 w-6 text-rose-600" />
                </div>
                <div>
                  <DialogTitle className="text-2xl">
                    Premium Subscription
                  </DialogTitle>
                  <DialogDescription>
                    Complete your payment to unlock premium features
                  </DialogDescription>
                </div>
              </div>
            </DialogHeader>

            {/* Subscription Summary */}
            <div className="rounded-lg bg-gradient-to-r from-blue-50 to-rose-50 p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-gray-900">
                    Premium Lender Plan
                  </h3>
                  <p className="text-sm text-gray-600">Billed monthly</p>
                </div>
                <div className="text-right">
                  <p className="text-3xl font-bold text-gray-900">₱999</p>
                  <p className="text-sm text-gray-600">/month</p>
                </div>
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                {[
                  "10 Costume Listings",
                  "Premium Badge",
                  "Priority Support",
                ].map((item) => (
                  <span
                    key={item}
                    className="inline-flex items-center gap-1 rounded-full bg-white px-3 py-1 text-xs font-medium text-gray-700"
                  >
                    <CheckCircle2 className="h-3 w-3 text-rose-500" />
                    {item}
                  </span>
                ))}
              </div>
            </div>

            {/* Subscription Form */}
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6 mt-4">
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-900">
                  Your Information
                </h3>

                <div className="space-y-2">
                  <Label htmlFor="fullName">Full Name</Label>
                  <Input
                    id="fullName"
                    placeholder="John Doe"
                    {...register("fullName")}
                    className={errors.fullName ? "border-red-500" : ""}
                  />
                  {errors.fullName && (
                    <p className="text-xs text-red-500">
                      {errors.fullName.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="john@example.com"
                    {...register("email")}
                    disabled
                    className={errors.email ? "border-red-500" : ""}
                  />
                  {errors.email && (
                    <p className="text-xs text-red-500">
                      {errors.email.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phoneNumber">Phone Number</Label>
                  <Input
                    id="phoneNumber"
                    type="tel"
                    placeholder="+63 912 345 6789"
                    {...register("phoneNumber")}
                    onChange={handlePhoneNumberChange}
                    className={errors.phoneNumber ? "border-red-500" : ""}
                  />
                  {errors.phoneNumber && (
                    <p className="text-xs text-red-500">
                      {errors.phoneNumber.message}
                    </p>
                  )}
                </div>
              </div>

              {/* Payment Methods */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-900">
                  Available Payment Methods
                </h3>
                <p className="text-sm text-gray-600">
                  You can pay using any of the following methods on the next
                  page
                </p>

                <div className="grid grid-cols-2 gap-3">
                  {paymentMethods.map((method) => {
                    const Icon = method.icon;
                    return (
                      <div
                        key={method.id}
                        className="flex items-center gap-3 rounded-lg border border-gray-200 bg-gray-50 p-3"
                      >
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-white">
                          <Icon className="h-5 w-5 text-gray-700" />
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium text-gray-900">
                            {method.name}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Security Notice */}
              <div className="flex items-center gap-2 rounded-lg bg-blue-50 p-3 text-sm text-blue-800">
                <Shield className="h-4 w-4 flex-shrink-0" />
                <p>
                  Secured by PayMongo. Your payment details will be handled
                  securely.
                </p>
              </div>

              {/* Submit Buttons */}
              <div className="flex gap-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setOpen(false)}
                  className="flex-1"
                  disabled={isPaying}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="flex-1 bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-700 hover:to-rose-800"
                  disabled={isPaying}
                >
                  {isPaying ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>Continue to Payment</>
                  )}
                </Button>
              </div>
            </form>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default PaySubscriptionDialog;