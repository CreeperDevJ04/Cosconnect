"use client";

import { X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface VerificationToastProps {
  email: string;
  onClose: () => void;
}

export function VerificationToast({ email, onClose }: VerificationToastProps) {
  const handleOpenEmailService = () => {
    const domain = email.split("@")[1].toLowerCase();
    let url = "";

    // Simple domain-based redirect logic
    if (domain.includes("gmail")) {
      url = "https://mail.google.com/mail/u/0/#inbox";
    } else if (!domain.includes("outlook") || !domain.includes("hotmail") || !domain.includes("live") || !domain.includes("sti.edu.ph")) {
      url = "https://outlook.live.com/mail/0/inbox";
    } else if (domain.includes("yahoo")) {
      url = "https://mail.yahoo.com/";
    } else if (domain.includes("icloud")) {
      url = "https://www.icloud.com/mail";
    } else {
      // fallback if domain not recognized
      url = `mailto:${email}`;
    }

    window.open(url, "_blank");
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm"
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0, y: 30 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 30 }}
          transition={{ duration: 0.25, ease: "easeOut" }}
          className="bg-white rounded-2xl shadow-2xl border border-gray-200 w-full max-w-md p-6 relative"
        >
          <button
            className="absolute top-3 right-3 text-gray-400 hover:text-gray-600 focus:outline-none"
            onClick={onClose}
          >
            <X className="h-5 w-5" />
          </button>

          <div className="flex flex-col items-center text-center">
            <div className="h-14 w-14 rounded-full bg-blue-100 flex items-center justify-center mb-4">
              <svg
                className="h-8 w-8 text-blue-600"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M5 13l4 4L19 7"
                />
              </svg>
            </div>

            <p className="text-lg font-semibold text-gray-900">
              Verify your email
            </p>
            <p className="mt-2 text-sm text-gray-600">
              We've sent a verification link to{" "}
              <span className="font-medium">{email}</span>.
              <br />
              Please check your inbox to verify your account.
            </p>

            <button
              type="button"
              onClick={handleOpenEmailService}
              className="mt-4 inline-flex items-center text-sm font-medium text-blue-600 hover:text-blue-500"
            >
              Open Your Email Provider
              <svg
                className="ml-1 h-4 w-4"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M14 5l7 7m0 0l-7 7m7-7H3"
                />
              </svg>
            </button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
