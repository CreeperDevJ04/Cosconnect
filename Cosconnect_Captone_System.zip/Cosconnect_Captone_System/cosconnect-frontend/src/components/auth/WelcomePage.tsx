"use client"

import { useFetchAllCategories } from '@/lib/api/categoryApi';
import { Category } from '@/lib/types/categoryType';
import { useSupabaseAuth } from '@/lib/hooks/useSupabaseAuth';
import '@/lib/styles/embla.css';

import Autoplay from 'embla-carousel-autoplay';
import useEmblaCarousel from 'embla-carousel-react';
import { Suspense, lazy, memo, useCallback, useEffect, useState } from 'react';
import Footer from '../layout/Footer';

// Lazy load components
const BrowseCategorySection = lazy(() => import('@/components/layout/UiSections/BrowseCategorySection'));
const CTASection = lazy(() => import('@/components/layout/UiSections/CTASection'));
/* const FeaturedCustomeSection = lazy(() => import('../UiSections/FeaturedCustomeSection')); */
const HeroSection = lazy(() => import('@/components/layout/UiSections/HeroSection'));
const WhyChooseCosConnectSectio = lazy(() => import('@/components/layout/UiSections/WhyChooseCosConnectSectio'));

const RatingsAndFeedbackSection = lazy(() => import('@/components/layout/UiSections/RatingsAndFeedbackSection'));

// Loading components
const LoadingSkeleton = () => (
    <div className="animate-pulse">
        <div className="h-[400px] bg-gray-200 rounded-lg mb-8"></div>
    </div>
);

const WelcomePage = memo(() => {
    // Get authentication state
    const {
        isAuthenticated,
        currentRole,

        isLoading: authLoading,
        userRolesData
    } = useSupabaseAuth();

    // Determine if user is a borrower
    const isBorrowerAuthenticated = isAuthenticated && currentRole === 'borrower';
    const borrowerUser = isBorrowerAuthenticated ? userRolesData : null;

    // Fetch categories from API
    const {
        data: categoriesData,
        isLoading: isCategoriesLoading,
        error: categoriesError
    } = useFetchAllCategories({
        page: 1,
        limit: 100,
    });

    const [emblaRef, emblaApi] = useEmblaCarousel(
        {
            loop: true,
            align: 'center',
            skipSnaps: false,
            dragFree: true,
        },
        [Autoplay({ delay: 5000, stopOnInteraction: false })]
    );

    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const timer = setTimeout(() => setIsLoading(false), 500);
        // Wait for auth to load before showing content
        if (!authLoading) {
            const timer = setTimeout(() => setIsLoading(false), 500);
            return () => clearTimeout(timer);
        }
        return () => clearTimeout(timer);
    }, [authLoading]);

    const [selectedDot, setSelectedDot] = useState(0);

    const scrollPrev = useCallback(() => {
        if (emblaApi) emblaApi.scrollPrev();
    }, [emblaApi]);

    const scrollNext = useCallback(() => {
        if (emblaApi) emblaApi.scrollNext();
    }, [emblaApi]);

    const scrollTo = useCallback((index: number) => {
        if (emblaApi) emblaApi.scrollTo(index);
    }, [emblaApi]);

    useEffect(() => {
        if (!emblaApi) return;

        const onSelect = () => {
            setSelectedDot(emblaApi.selectedScrollSnap());
        };

        emblaApi.on('select', onSelect);
        onSelect();

        return () => {
            emblaApi.off('select', onSelect);
        };
    }, [emblaApi]);

    const sampleFeedbacks = [
        { id: '1', name: 'Clarkkenzy', rating: 4, comment: 'For me, the UI and the idea of creating this site are really amazing and super useful, especially since cosplay is now known worldwide. It’s easy to use and helps you quickly find the costume you’re looking for. Hopefully, this thesis project continues to grow and maybe even adds features like event schedules or info, so it’s not just a shop but also a place for cosplay updates and notifications.', date: '2025-10-21' },
        { id: '2', name: 'koomie', rating: 4, comment: 'super legit💝🍰', date: '2025-10-25' },
        { id: '3', name: 'Zhastin', rating: 4, comment: 'The UI looks very good congratss', date: '2025-10-20' },
        { id: '4', name: 'Johuas', rating: 3, comment: 'The app prevents double bookings very good', date: '2025-10-24'},
        { id: '5', name: 'Ichinisan', rating: 4, comment: 'The chat was a good idea, I could confirm pickup times', date: '2025-10-25'},
        { id: '6', name: 'Kyojiro', rating: 2, comment: 'The idea is great, there is room for improvement, I hope it keeps improving', date: '2025-10-22'},

    ];

    // Show loading skeleton while auth is loading
    if (authLoading || isLoading) {
        return (
            <div className="flex flex-col max-w-[1920px] mx-auto w-full">
                <LoadingSkeleton />
                <LoadingSkeleton />
                <LoadingSkeleton />
            </div>
        );
    }

    return (
        <div className="flex flex-col max-w-[1920px] mx-auto w-full">
            <Suspense fallback={<LoadingSkeleton />}>
                {/* Hero Section */}
                <div className="relative overflow-hidden bg-gradient-to-br from-pink-50 via-white to-rose-200">
                    {/* Animated gradient orbs - only visible on desktop */}
                    <div className="hidden lg:block absolute inset-0 overflow-hidden">
                        <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-pink-400 to-rose-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob" />
                        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-br from-rose-400 to-pink-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000" />
                        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-gradient-to-br from-purple-300 to-pink-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-4000" />
                    </div>

                    {/* Content - no padding on mobile, padding on desktop */}
                    <div className="relative lg:px-40">
                        <HeroSection
                            borrowerUser={borrowerUser}
                            isBorrowerAuthenticated={isBorrowerAuthenticated}
                            emblaRef={emblaRef}
                            scrollPrev={scrollPrev}
                            scrollNext={scrollNext}
                            scrollTo={scrollTo}
                            emblaApi={emblaApi}
                            selectedDot={selectedDot}
                        />
                    </div>
                </div>

                {/* Featured Costumes Section */}
                {/*    <FeaturedCustomeSection
                    products={products}
                    isLoading={isLoadingProducts}
                    error={productsError}
                /> */}

                {/* Only show Features and CTA sections for non-authenticated users */}
                {!isBorrowerAuthenticated && (
                    <>
                        {/* Features Section */}
                        <WhyChooseCosConnectSectio />
                        {/* Ratings and Feedback Section */}
                        <RatingsAndFeedbackSection feedbacks={sampleFeedbacks} />
                        {/* CTA Section */}
                        <CTASection />
                        <Footer />
                    </>
                )}
            </Suspense>
        </div>
    );
});

WelcomePage.displayName = 'WelcomePage';

export default WelcomePage;