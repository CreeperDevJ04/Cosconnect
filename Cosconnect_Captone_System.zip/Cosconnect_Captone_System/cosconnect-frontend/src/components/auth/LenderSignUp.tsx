"use client";

import { useState, useCallback } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { format } from "date-fns";
import { ArrowLeft, Loader2, Store, AlertCircle, User, Mail, Lock, Eye, EyeOff, CalendarIcon, Phone } from "lucide-react";
import Link from "next/link";
import Image from "next/image";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";

import { BusinessInfoSection } from "@/components/settings/BusinessInfoSection";
import { DocumentVerificationSection } from "@/components/settings/DocumentVerificationSection";
import { signUp } from "../../../actions/auth";
import { useRegisterLenderAccount } from "@/lib/api/lenderApi";
import { handleSingleImageUpload } from "@/utils/supabase/fileUpload";
import { cn, COLORS, TYPOGRAPHY } from "@/lib/utils";
import TermsDialog from "./TermsAndConditionAndPolicy";

// Combined schema for user + lender signup
const combinedLenderSignUpSchema = z.object({
  // Basic user info (from normal signup)
  username: z.string()
    .min(3, "Username must be at least 3 characters")
    .max(20, "Username must be at most 20 characters")
    .regex(/^[a-z0-9_]{3,20}$/, "Username can only contain lowercase letters, numbers, and underscores"),
  email: z.string().email("Please enter a valid email address"),
  birth_date: z.date().max(new Date(), "Birth date must be in the past"),
  phoneNumber: z.string().regex(/^\d{9,10}$/, "Phone number must be 9-10 digits (after +63)"),
  password: z.string()
    .min(8, "Password must be at least 8 characters")
    .regex(
      /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]).{8,}$/,
      "Password must contain at least 1 uppercase, 1 lowercase, 1 number, and 1 special character"
    ),
  confirmPassword: z.string().min(8, "Confirm password must be at least 8 characters"),
  agreeToTerms: z.boolean().refine((val) => val === true, {
    message: "You must agree to the terms and conditions",
  }),
  
  // Lender-specific info
  businessName: z.string().min(2, "Business name is required").max(50, "Business name must be 50 characters or less"),
  businessType: z.string().min(1, "Please select your business type"),
  businessDescription: z.string().min(10, "Business description must be at least 10 characters").max(500),
  region: z.string().min(1, "Region is required"),
  province: z.string().min(1, "Province is required"),
  city: z.object({
    id: z.string().min(1, "City/Municipality is required"),
    name: z.string().min(1, "City/Municipality name is required")
  }),
  barangay: z.string().min(1, "Barangay is required"),
  zipCode: z.string().min(2, "Zip Code is required"),
  street: z.string().min(5, "Street address is required").max(100),
  businessPhoneNumber: z.string().min(11, "Phone Number must be at least 11 digits"),
  businessEmail: z.string().email("Invalid business email address"),
  business_telephone: z.string().optional(),
  hasValidId: z.boolean(),
  validIdType: z.any().optional(),
  validIdNumber: z.string().optional(),
  validIdFile: z.any().optional(),
  secondaryIdType1: z.any().optional(),
  secondaryIdFile1: z.any().optional(),
  secondaryIdType2: z.any().optional(),
  secondaryIdFile2: z.any().optional(),
  selfieWithId: z.any().optional(),
  upload_dti_certificate: z.any().optional(),
  upload_business_permit: z.any().optional(),
  upload_storefront_photo: z.any().optional(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
}).superRefine((data, ctx) => {
  // Validate ID requirements
  if (data.hasValidId) {
    if (!data.validIdType || !data.validIdNumber || !data.validIdFile) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Please provide all valid ID information",
        path: ["validIdFile"],
      });
    }
  } else {
    if (!data.secondaryIdType1 || !data.secondaryIdFile1 || !data.secondaryIdType2 || !data.secondaryIdFile2) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Please provide two secondary IDs",
        path: ["secondaryIdFile1"],
      });
    }
  }

  // Selfie with ID is always required
  if (!data.selfieWithId) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: "Selfie with ID is required",
      path: ["selfieWithId"],
    });
  }

  // Validate STORE business type requirements
  if (data.businessType === "STORE") {
    if (!data.upload_dti_certificate) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "DTI Certificate is required for store business",
        path: ["upload_dti_certificate"],
      });
    }
    if (!data.upload_business_permit) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Business Permit is required for store business",
        path: ["upload_business_permit"],
      });
    }
    if (!data.upload_storefront_photo) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Storefront Photo is required for store business",
        path: ["upload_storefront_photo"],
      });
    }
  }
});

type CombinedLenderSignUpData = z.infer<typeof combinedLenderSignUpSchema>;

const LenderSignUp = () => {
  const router = useRouter();
  const [currentTab, setCurrentTab] = useState<"account" | "business" | "documents">("account");
  const [isProcessing, setIsProcessing] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isTermsDialogOpen, setIsTermsDialogOpen] = useState(false);
  const { mutateAsync: registerLenderAccount } = useRegisterLenderAccount();

  const form = useForm<CombinedLenderSignUpData>({
    resolver: zodResolver(combinedLenderSignUpSchema),
    defaultValues: {
      username: "",
      email: "",
      phoneNumber: "",
      password: "",
      confirmPassword: "",
      agreeToTerms: false,
      businessName: "",
      businessType: "STORE",
      businessDescription: "",
      businessPhoneNumber: "+63 ",
      businessEmail: "",
      business_telephone: "",
      street: "",
      barangay: "",
      city: { id: "", name: "" },
      province: "",
      region: "",
      zipCode: "",
      hasValidId: true,
      validIdType: "NATIONAL_ID",
      validIdNumber: "",
      validIdFile: null,
      secondaryIdType1: "BARANGAY_ID",
      secondaryIdFile1: null,
      secondaryIdType2: "POLICE_CLEARANCE",
      secondaryIdFile2: null,
      selfieWithId: null,
      upload_dti_certificate: null,
      upload_business_permit: null,
      upload_storefront_photo: null,
    },
    mode: "onChange",
  });

  const uploadFile = useCallback(async (file: File, errorMessage: string): Promise<string> => {
    try {
      const uploadResult = await handleSingleImageUpload(file);
      if (uploadResult.error) {
        throw new Error(`${errorMessage}: ${uploadResult.error}`);
      }
      return uploadResult.url as string;
    } catch (error) {
      console.error("File upload error:", error);
      throw error;
    }
  }, []);

  const handleAcceptTerms = useCallback(() => {
    form.setValue('agreeToTerms', true, { shouldValidate: true });
    setIsTermsDialogOpen(false);
  }, [form]);

  const onSubmit = useCallback(async (values: CombinedLenderSignUpData) => {
    setIsProcessing(true);
    
    try {
      // Step 1: Create user account
      const userFormData = {
        username: values.username.toLowerCase(),
        email: values.email,
        phoneNumber: values.phoneNumber,
        birth_date: format(values.birth_date, "yyyy-MM-dd"),
        password: values.password,
        role: "borrower" as const,
      };

      const userResult = await signUp(userFormData);

      if (userResult.status !== "success") {
        toast.error(userResult.message || "Failed to create account");
        setIsProcessing(false);
        return;
      }

      // Extract userId from the response
      const userId = userResult.user?.uid;
      if (!userId) {
        toast.error("Failed to get user ID from account creation");
        setIsProcessing(false);
        return;
      }

      toast.success("Account created! Now registering as lender...");

      // Step 2: Prepare personal info (use username as placeholder - user will update in CompleteProfile)
      const personalInfo = {
        first_name: values.username,
        last_name: values.username,
        full_name: values.username,
        username: values.username,
        email: values.email,
        phone_number: values.phoneNumber,
      };

      // Step 3: Upload files
      toast.info("Uploading documents...");
      
      let validIdFileUrl = "";
      let selfieWithIdUrl = "";
      let dtiCertificateUrl = "";
      let businessPermitUrl = "";
      let storefrontPhotoUrl = "";

      // Upload required files
      if (values.hasValidId && values.validIdFile instanceof File) {
        validIdFileUrl = await uploadFile(values.validIdFile, "Failed to upload valid ID");
      } else if (values.hasValidId) {
        toast.error("Valid ID file is required");
        setIsProcessing(false);
        return;
      }

      if (values.selfieWithId instanceof File) {
        selfieWithIdUrl = await uploadFile(values.selfieWithId, "Failed to upload selfie with ID");
      } else {
        toast.error("Selfie with ID is required");
        setIsProcessing(false);
        return;
      }

      // Upload store-specific files if business type is STORE
      if (values.businessType === "STORE") {
        if (values.upload_dti_certificate instanceof File) {
          dtiCertificateUrl = await uploadFile(values.upload_dti_certificate, "Failed to upload DTI Certificate");
        } else {
          toast.error("DTI Certificate is required for store business");
          setIsProcessing(false);
          return;
        }
        
        if (values.upload_business_permit instanceof File) {
          businessPermitUrl = await uploadFile(values.upload_business_permit, "Failed to upload Business Permit");
        } else {
          toast.error("Business Permit is required for store business");
          setIsProcessing(false);
          return;
        }
        
        if (values.upload_storefront_photo instanceof File) {
          storefrontPhotoUrl = await uploadFile(values.upload_storefront_photo, "Failed to upload Storefront Photo");
        } else {
          toast.error("Storefront Photo is required for store business");
          setIsProcessing(false);
          return;
        }
      }

      // Validate all required URLs are present
      if (!validIdFileUrl || !selfieWithIdUrl) {
        toast.error("Failed to upload required documents");
        setIsProcessing(false);
        return;
      }

      if (values.businessType === "STORE" && (!dtiCertificateUrl || !businessPermitUrl || !storefrontPhotoUrl)) {
        toast.error("Failed to upload required store documents");
        setIsProcessing(false);
        return;
      }

      // Step 4: Prepare lender data in backend expected format
      const lenderData = {
        personal_info: personalInfo,
        identification: {
          has_valid_id: values.hasValidId,
          valid_id_type: values.validIdType || "NATIONAL_ID",
          valid_id_number: values.validIdNumber || "",
          valid_id_file: validIdFileUrl,
          selfie_with_id: selfieWithIdUrl,
        },
        business_info: {
          business_name: values.businessName,
          business_type: values.businessType as "STORE" | "INDIVIDUAL",
          business_description: values.businessDescription,
          business_email: values.businessEmail,
          business_phone_number: values.businessPhoneNumber,
          business_telephone: values.business_telephone || "",
          business_address: `${values.street}, ${values.barangay}`,
          street: values.street,
          barangay: values.barangay,
          city: values.city,
          province: values.province,
          region: values.region,
          zip_code: values.zipCode,
          ...(values.businessType === "STORE" && {
            upload_dti_certificate: dtiCertificateUrl,
            upload_business_permit: businessPermitUrl,
            upload_storefront_photo: storefrontPhotoUrl,
          }),
        },
        terms_and_conditions: "Accepted" as const,
      };

      // Step 5: Register as lender
      toast.info("Submitting lender application...");
      await registerLenderAccount({ userId, lenderData });

      toast.success("Account created successfully! Please check your email to verify your account.");
      form.reset();
      router.push(`/signin?verification=email-sent&email=${encodeURIComponent(values.email)}`);

    } catch (error: any) {
      const errorMessage = error.response?.data?.message || error.message || "An error occurred during registration";
      toast.error(errorMessage);
    } finally {
      setIsProcessing(false);
    }
  }, [form, router, registerLenderAccount, uploadFile]);

  return (
    <div className="min-h-screen grid grid-cols-1 lg:grid-cols-2 bg-background">
      {/* Left Side - Form */}
      <div className="flex items-center justify-center px-6 py-12 overflow-y-auto relative">
        {/* Back Button */}
        <Link
          href="/signup/choose-role"
          className="absolute top-6 left-6 w-10 h-10 rounded-full border-2 border-gray-300 hover:border-rose-600 hover:bg-rose-50 flex items-center justify-center transition-all duration-200 group z-10"
        >
          <ArrowLeft className="w-5 h-5 text-gray-600 group-hover:text-rose-600" />
        </Link>

        <div className="w-full max-w-2xl">
          <Card className="shadow-xl border-0 transition-all duration-300 hover:shadow-2xl">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Store className="w-5 h-5" />
                Register as a Lender
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Alert className="mb-6">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Complete all steps to create your account and register as a lender in one go!
                </AlertDescription>
              </Alert>

              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <Tabs value={currentTab} onValueChange={(v: string) => setCurrentTab(v as "account" | "business" | "documents")}>
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="account">Account</TabsTrigger>
                      <TabsTrigger value="business">Business</TabsTrigger>
                      <TabsTrigger value="documents">Documents</TabsTrigger>
                    </TabsList>

                    <TabsContent value="account" className="space-y-5 mt-6">
                      {/* Username */}
                      <FormField
                        control={form.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel
                              className={cn(
                                TYPOGRAPHY.sizes.sm,
                                TYPOGRAPHY.weights.medium
                              )}
                              style={{ color: COLORS.light.text }}
                            >
                              Username
                            </FormLabel>
                            <FormControl>
                              <div className="relative">
                                <User
                                  className="absolute left-3 top-3 h-5 w-5"
                                  style={{ color: COLORS.light.textMuted }}
                                />
                                <Input
                                  placeholder="Enter your username"
                                  maxLength={35}
                                  className={cn(
                                    "pl-10 h-12 transition-all duration-200",
                                    "focus:ring-2 focus:ring-opacity-50",
                                    "disabled:opacity-50 disabled:cursor-not-allowed"
                                  )}
                                  style={{
                                    borderColor: COLORS.light.border,
                                    backgroundColor: COLORS.light.bg,
                                    color: COLORS.light.text,
                                  }}
                                  disabled={isProcessing}
                                  autoComplete="username"
                                  {...field}
                                  value={field.value.toLowerCase()}
                                  onChange={(e) => field.onChange(e.target.value.toLowerCase())}
                                />
                              </div>
                            </FormControl>
                            <FormMessage className={cn(TYPOGRAPHY.sizes.xs, "text-gray-500")} />
                          </FormItem>
                        )}
                      />

                      {/* Email */}
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel
                              className={cn(
                                TYPOGRAPHY.sizes.sm,
                                TYPOGRAPHY.weights.medium
                              )}
                              style={{ color: COLORS.light.text }}
                            >
                              Email
                            </FormLabel>
                            <FormControl>
                              <div className="relative">
                                <Mail
                                  className="absolute left-3 top-3 h-5 w-5"
                                  style={{ color: COLORS.light.textMuted }}
                                />
                                <Input
                                  type="email"
                                  placeholder="Enter your email"
                                  maxLength={40}
                                  className={cn(
                                    "pl-10 h-12 transition-all duration-200",
                                    "focus:ring-2 focus:ring-opacity-50",
                                    "disabled:opacity-50 disabled:cursor-not-allowed"
                                  )}
                                  style={{
                                    borderColor: COLORS.light.border,
                                    backgroundColor: COLORS.light.bg,
                                    color: COLORS.light.text,
                                  }}
                                  disabled={isProcessing}
                                  autoComplete="email"
                                  {...field}
                                />
                              </div>
                            </FormControl>
                            <FormMessage className={cn(TYPOGRAPHY.sizes.xs, "text-gray-500")} />
                          </FormItem>
                        )}
                      />

                      {/* Birth Date */}
                      <FormField
                        control={form.control}
                        name="birth_date"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel
                              className={cn(
                                TYPOGRAPHY.sizes.sm,
                                TYPOGRAPHY.weights.medium
                              )}
                              style={{ color: COLORS.light.text }}
                            >
                              Birth Date
                            </FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button
                                    variant="outline"
                                    className={cn(
                                      "w-full pl-3 text-left font-normal h-12",
                                      !field.value && "text-muted-foreground"
                                    )}
                                  >
                                    {field.value ? (
                                      format(field.value as any, "yyyy-MM-dd")
                                    ) : (
                                      <span>Select your birth date</span>
                                    )}
                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <Calendar
                                  mode="single"
                                  selected={field.value as any}
                                  onSelect={(date) => field.onChange(date)}
                                  disabled={(date) => date > new Date()}
                                  captionLayout="dropdown"
                                  initialFocus
                                />
                              </PopoverContent>
                            </Popover>
                            <FormMessage className={cn(TYPOGRAPHY.sizes.xs, "text-gray-500")} />
                          </FormItem>
                        )}
                      />

                      {/* Phone Number */}
                      <FormField
                        control={form.control}
                        name="phoneNumber"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel
                              className={cn(
                                TYPOGRAPHY.sizes.sm,
                                TYPOGRAPHY.weights.medium
                              )}
                              style={{ color: COLORS.light.text }}
                            >
                              Phone Number
                            </FormLabel>
                            <FormControl>
                              <div className="relative flex items-center">
                                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-gray-500 select-none">
                                  +63
                                </span>
                                <Input
                                  type="tel"
                                  placeholder="9123456789"
                                  className={cn(
                                    "pl-14 h-12 transition-all duration-200",
                                    "focus:ring-2 focus:ring-opacity-50",
                                    "disabled:opacity-50 disabled:cursor-not-allowed"
                                  )}
                                  style={{
                                    borderColor: COLORS.light.border,
                                    backgroundColor: COLORS.light.bg,
                                    color: COLORS.light.text,
                                  }}
                                  disabled={isProcessing}
                                  autoComplete="tel"
                                  maxLength={10}
                                  {...field}
                                  value={field.value || ""}
                                />
                              </div>
                            </FormControl>
                            <FormMessage
                              className="text-xs"
                              style={{ color: COLORS.error }}
                            />
                          </FormItem>
                        )}
                      />

                      {/* Password */}
                      <FormField
                        control={form.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel
                              className={cn(
                                TYPOGRAPHY.sizes.sm,
                                TYPOGRAPHY.weights.medium
                              )}
                              style={{ color: COLORS.light.text }}
                            >
                              Password
                            </FormLabel>
                            <FormControl>
                              <div className="relative">
                                <Lock
                                  className="absolute left-3 top-3 h-5 w-5"
                                  style={{ color: COLORS.light.textMuted }}
                                />
                                <Input
                                  type={showPassword ? "text" : "password"}
                                  placeholder="Enter your password"
                                  maxLength={45}
                                  className={cn(
                                    "pl-10 pr-10 h-12 transition-all duration-200",
                                    "focus:ring-2 focus:ring-opacity-50",
                                    "disabled:opacity-50 disabled:cursor-not-allowed"
                                  )}
                                  style={{
                                    borderColor: COLORS.light.border,
                                    backgroundColor: COLORS.light.bg,
                                    color: COLORS.light.text,
                                  }}
                                  disabled={isProcessing}
                                  autoComplete="new-password"
                                  {...field}
                                />
                                <button
                                  type="button"
                                  className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 hover:opacity-70 transition-opacity"
                                  onClick={() => setShowPassword(!showPassword)}
                                  disabled={isProcessing}
                                  tabIndex={-1}
                                >
                                  {showPassword ? (
                                    <EyeOff
                                      className="h-5 w-5"
                                      style={{ color: COLORS.light.textMuted }}
                                    />
                                  ) : (
                                    <Eye
                                      className="h-5 w-5"
                                      style={{ color: COLORS.light.textMuted }}
                                    />
                                  )}
                                </button>
                              </div>
                            </FormControl>
                            <FormMessage
                              className="text-xs"
                              style={{ color: COLORS.error }}
                            />
                          </FormItem>
                        )}
                      />

                      {/* Confirm Password */}
                      <FormField
                        control={form.control}
                        name="confirmPassword"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel
                              className={cn(
                                TYPOGRAPHY.sizes.sm,
                                TYPOGRAPHY.weights.medium
                              )}
                              style={{ color: COLORS.light.text }}
                            >
                              Confirm Password
                            </FormLabel>
                            <FormControl>
                              <div className="relative">
                                <Lock
                                  className="absolute left-3 top-3 h-5 w-5"
                                  style={{ color: COLORS.light.textMuted }}
                                />
                                <Input
                                  type={showConfirmPassword ? "text" : "password"}
                                  placeholder="Confirm your password"
                                  maxLength={45}
                                  className={cn(
                                    "pl-10 pr-10 h-12 transition-all duration-200",
                                    "focus:ring-2 focus:ring-opacity-50",
                                    "disabled:opacity-50 disabled:cursor-not-allowed"
                                  )}
                                  style={{
                                    borderColor: COLORS.light.border,
                                    backgroundColor: COLORS.light.bg,
                                    color: COLORS.light.text,
                                  }}
                                  disabled={isProcessing}
                                  autoComplete="new-password"
                                  {...field}
                                />
                                <button
                                  type="button"
                                  className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 hover:opacity-70 transition-opacity"
                                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                                  disabled={isProcessing}
                                  tabIndex={-1}
                                >
                                  {showConfirmPassword ? (
                                    <EyeOff
                                      className="h-5 w-5"
                                      style={{ color: COLORS.light.textMuted }}
                                    />
                                  ) : (
                                    <Eye
                                      className="h-5 w-5"
                                      style={{ color: COLORS.light.textMuted }}
                                    />
                                  )}
                                </button>
                              </div>
                            </FormControl>
                            <FormMessage
                              className="text-xs"
                              style={{ color: COLORS.error }}
                            />
                          </FormItem>
                        )}
                      />

                    </TabsContent>

                    <TabsContent value="business" className="space-y-4 mt-6">
                      <BusinessInfoSection control={form.control as any} />
                    </TabsContent>

                    <TabsContent value="documents" className="space-y-4 mt-6">
                      <DocumentVerificationSection control={form.control as any} />
                      
                      {/* Terms Checkbox - Only in Documents tab */}
                      <div className="pt-6 pb-4">
                        <FormField
                          control={form.control}
                          name="agreeToTerms"
                          render={({ field }) => (
                            <FormItem className="space-y-0">
                              <div className="flex items-start space-x-3">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value}
                                    onCheckedChange={(checked) => {
                                      if (checked) {
                                        setIsTermsDialogOpen(true);
                                      } else {
                                        field.onChange(false);
                                      }
                                    }}
                                    disabled={isProcessing}
                                    className={cn(
                                      "mt-1 h-5 w-5 rounded border-2",
                                      "data-[state=checked]:bg-rose-600 data-[state=checked]:border-rose-600"
                                    )}
                                  />
                                </FormControl>
                                <div className="flex-1">
                                  <FormLabel
                                    className={cn(
                                      TYPOGRAPHY.sizes.sm,
                                      "cursor-pointer"
                                    )}
                                    style={{ color: COLORS.light.text }}
                                  >
                                    I agree to the{" "}
                                    <span className="text-rose-600 hover:underline">Terms of Service</span>
                                    {" "}and{" "}
                                    <span className="text-rose-600 hover:underline">Privacy Policy</span>
                                  </FormLabel>
                                  <FormMessage className="text-xs" style={{ color: COLORS.error }} />
                                </div>
                              </div>
                            </FormItem>
                          )}
                        />
                      </div>
                    </TabsContent>
                  </Tabs>

                  <div className="flex justify-between pt-4">
                    {currentTab !== "account" && (
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => {
                          if (currentTab === "documents") setCurrentTab("business");
                          else if (currentTab === "business") setCurrentTab("account");
                        }}
                        disabled={isProcessing}
                      >
                        Previous
                      </Button>
                    )}
                    
                    {currentTab !== "documents" ? (
                      <Button
                        type="button"
                        onClick={() => {
                          if (currentTab === "account") setCurrentTab("business");
                          else if (currentTab === "business") setCurrentTab("documents");
                        }}
                        disabled={isProcessing}
                        className="ml-auto"
                      >
                        Next
                      </Button>
                    ) : (
                      <Button
                        type="submit"
                        disabled={isProcessing}
                        className="ml-auto"
                      >
                        {isProcessing ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Creating Account...
                          </>
                        ) : (
                          "Create Lender Account"
                        )}
                      </Button>
                    )}
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Right Side - Image */}
      <div className="hidden lg:block relative">
        <Image
          src="https://rlfkmbjptciiluhsbvxx.supabase.co/storage/v1/object/public/images/navia%20complte.jpg"
          alt="Lender Registration"
          fill
          className="object-cover"
          priority
        />
      </div>

      {/* Terms Dialog */}
      <TermsDialog
        open={isTermsDialogOpen}
        onOpenChange={setIsTermsDialogOpen}
        onAccept={handleAcceptTerms}
      />
    </div>
  );
};

export default LenderSignUp;
