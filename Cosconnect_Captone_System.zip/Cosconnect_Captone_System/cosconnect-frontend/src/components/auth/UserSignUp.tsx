"use client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import {
    Form,
    FormControl,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { cn, COLORS, TYPOGRAPHY } from "@/lib/utils";
import { zodResolver } from "@hookform/resolvers/zod";

import {
    Loader2,
    Lock,
    Mail,
    User,
    Eye,
    EyeOff,
    CalendarIcon,
    ArrowLeft,
    Store,
} from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { z } from "zod";
import PrivacyPolicy from "../layout/UiSections/PrivacyPolicy";
import TermsAndConditions from "../layout/UiSections/TermsAndConditions";
import { Popover, PopoverContent, PopoverTrigger } from "../ui/popover";
import { format } from "date-fns";
import { Calendar } from "../ui/calendar";
import { signUp } from "../../../actions/auth";
import TermsDialog from "./TermsAndConditionAndPolicy";

const usernameRegex = /^[a-z0-9_]{3,20}$/; // Only allow lowercase alphanumeric and underscore, 3-20 chars

const passwordRegex =
    /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]).{8,}$/;

const signUpSchema = z
    .object({
        username: z
            .string()
            .min(3, "Username must be at least 3 characters")
            .max(20, "Username must be at most 20 characters")
            .regex(
                usernameRegex,
                "Username can only contain lowercase letters, numbers, and underscores (3-20 chars). No spaces or special characters."
            )
            .transform((val) => val.toLowerCase()), // Ensure lowercase
        email: z.string().email("Please enter a valid email address"),
        birth_date: z.date().max(new Date(), "Birth date must be in the past"),
        phoneNumber: z
            .string()
            .regex(/^\d{9,10}$/, "Phone number must be 9-10 digits (after +63)."),
        password: z
            .string()
            .min(8, "Password must be at least 8 characters")
            .regex(
                passwordRegex,
                "Password must contain at least 1 uppercase, 1 lowercase, 1 number, and 1 special character."
            ),
        confirmPassword: z
            .string()
            .min(8, "Confirm password must be at least 8 characters"),
        agreeToTerms: z.boolean().refine((val) => val === true, {
            message: "You must agree to the terms and conditions",
        }),
    })
    .refine((data) => data.password === data.confirmPassword, {
        message: "Passwords don't match",
        path: ["confirmPassword"],
    });

type UserSignUpData = z.infer<typeof signUpSchema>;

const UserSignUp = () => {
    const [isLoading, setIsLoading] = useState(false);
    const [isMounted, setIsMounted] = useState(false);
    const [showPassword, setShowPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);
    const [fieldErrors, setFieldErrors] = useState<{
        username?: string;
        email?: string;
    }>({});

    const [isTermsAccepted, setIsTermsAccepted] = useState(false)

    const [isTermsDialogOpen, setIsTermsDialogOpen] = useState(false);
    const router = useRouter();
    const searchParams = useSearchParams();
    const lenderIntent = searchParams?.get('intent') === 'lender';
    const form = useForm<UserSignUpData>({
        resolver: zodResolver(signUpSchema),
        defaultValues: {
            username: "",
            email: "",
            phoneNumber: "",
            password: "",
            confirmPassword: "",
            agreeToTerms: false,
        },
    });

    useEffect(() => {
        setIsMounted(true);
    }, []);

    const handlePhoneNumberChange = (
        e: React.ChangeEvent<HTMLInputElement>,
        onChange: (value: string) => void
    ) => {
        let value = e.target.value.replace(/\D/g, ""); // Remove all non-digits

        // Ensure the number starts with 9 and is exactly 10 digits (no +63)
        if (value.startsWith("63")) {
            value = value.substring(2);
        }
        if (value.length > 0 && value[0] !== "9") {
            value = "9" + value.slice(0, 9);
        } else if (value.length > 10) {
            value = value.substring(0, 10);
        }

        onChange(value); // Send just the digits, NOT +63
    };

    const onSubmit = useCallback(
        async (values: UserSignUpData) => {
            setIsLoading(true);
            setFieldErrors({}); // Clear previous errors

            try {
                const formData = {
                    ...values,
                    username: values.username.toLowerCase(),
                    role: "borrower" as const,
                    birth_date: format(values.birth_date, "yyyy-MM-dd"),
                };
                // Remove confirmPassword from formData before sending to API
                const { confirmPassword, ...apiData } = formData;
                const result = await signUp(apiData);

                if (result.status === "success") {
                    if (lenderIntent) {
                        toast.success("Account created! Please verify your email, then sign in to complete lender registration.");
                    } else {
                        toast.success("Account created successfully! Please check your email to verify your account.");
                    }
                    form.reset();
                    const redirectUrl = lenderIntent 
                        ? `/signin?verification=email-sent&email=${encodeURIComponent(values.email)}&redirect=/settings`
                        : `/signin?verification=email-sent&email=${encodeURIComponent(values.email)}`;
                    router.push(redirectUrl);
                } else {
                    console.log(result);
                    // Handle specific error messages
                    if (result.status === "error") {
                        setFieldErrors((prev) => ({
                            ...prev,
                            email: "This email is already registered",
                        }));
                        form.setError("email", {
                            type: "manual",
                            message: "This email is already registered",
                        });
                    } else if (result.status === "User with this email already exists") {
                        setFieldErrors((prev) => ({
                            ...prev,
                            email: "This email is already registered",
                        }));
                        form.setError("email", {
                            type: "manual",
                            message: "This email is already registered",
                        });
                    } else {
                        toast.error(result.status || "An error occurred during sign-up");
                    }
                }
            } catch (error) {
                console.error("Sign-up error:", error);
                toast.error("An error occurred during sign-up");
            } finally {
                setIsLoading(false);
            }
        },
        [form, router]
    );

    const handleTermsChange = (checked: boolean) => {
        if (checked) {
            setIsTermsDialogOpen(true);
        } else {
            setIsTermsAccepted(false);
            form.setValue('agreeToTerms', false, { shouldValidate: true });
        }
    };

    const handleAcceptTerms = () => {
        setIsTermsAccepted(true);
        form.setValue('agreeToTerms', true, { shouldValidate: true });
        setIsTermsDialogOpen(false);

    };


    if (!isMounted) {
        return null;
    }

    return (
        <div
            className="min-h-screen grid grid-cols-1 lg:grid-cols-2"
            style={{ backgroundColor: COLORS.light.bg }}
        >
            {/* Left Side - Form */}
            <div className="flex items-center justify-center px-6 py-12 relative">
                {/* Back Button */}
                <Link 
                    href="/signup/choose-role"
                    className="absolute top-6 left-6 w-10 h-10 rounded-full border-2 border-gray-300 hover:border-rose-600 hover:bg-rose-50 flex items-center justify-center transition-all duration-200 group"
                >
                    <ArrowLeft className="w-5 h-5 text-gray-600 group-hover:text-rose-600" />
                </Link>
                <div className="w-full max-w-md">
                    <Card
                        className={cn(
                            "w-full shadow-xl border-0",
                            "transition-all duration-300 hover:shadow-2xl"
                        )}
                        style={{
                            backgroundColor: COLORS.light.bgSecondary,
                            borderColor: COLORS.light.border,
                        }}
                    >
                        <CardContent className="p-8 space-y-8">
                            {/* Lender Intent Banner */}
                            {lenderIntent && (
                                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                                    <div className="flex items-start gap-3">
                                        <Store className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
                                        <div className="text-sm">
                                            <p className="font-semibold text-amber-900 mb-1">Lender Registration</p>
                                            <p className="text-amber-700">
                                                First, create your account. After verification, you'll be able to register as a lender from your settings.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            )}

                            {/* Header Section */}
                            <div className="space-y-3 text-center">
                                <h2
                                    className={cn(TYPOGRAPHY.sizes.h3, TYPOGRAPHY.weights.bold)}
                                    style={{
                                        color: COLORS.light.text,
                                        fontFamily: TYPOGRAPHY.fonts.heading,
                                    }}
                                >
                                    Create Your Account
                                </h2>
                                <p
                                    className={cn(TYPOGRAPHY.sizes.base)}
                                    style={{ color: COLORS.light.textSecondary }}
                                >
                                    Join CosConnect to start renting costumes
                                </p>
                            </div>

                            {/* Form Section */}
                            <Form {...form}>
                                <form
                                    onSubmit={form.handleSubmit(onSubmit)}
                                    className="space-y-6"
                                >
                                    <div className="space-y-5">
                                        {/* Username Field */}
                                        <FormField
                                            control={form.control}
                                            name="username"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel
                                                        className={cn(
                                                            TYPOGRAPHY.sizes.sm,
                                                            TYPOGRAPHY.weights.medium
                                                        )}
                                                        style={{ color: COLORS.light.text }}
                                                    >
                                                        Username
                                                    </FormLabel>
                                                    <FormControl>
                                                        <div className="relative">
                                                            <User
                                                                className="absolute left-3 top-3 h-5 w-5"
                                                                style={{ color: COLORS.light.textMuted }}
                                                            />
                                                            <Input
                                                                placeholder="Enter your username"
                                                                maxLength={35}
                                                                className={cn(
                                                                    "pl-10 h-12 transition-all duration-200",
                                                                    "focus:ring-2 focus:ring-opacity-50",
                                                                    "disabled:opacity-50 disabled:cursor-not-allowed",
                                                                    fieldErrors.username &&
                                                                    "border-gray-500 focus:ring-gray-500/20"
                                                                )}
                                                                style={{
                                                                    borderColor: fieldErrors.username
                                                                        ? COLORS.error
                                                                        : COLORS.light.border,
                                                                    backgroundColor: COLORS.light.bg,
                                                                    color: COLORS.light.text,
                                                                }}
                                                                disabled={isLoading}
                                                                autoComplete="username"
                                                                {...field}
                                                                value={field.value.toLowerCase()}
                                                                onChange={(e) => {
                                                                    const value = e.target.value.toLowerCase();
                                                                    field.onChange(value);
                                                                    if (fieldErrors.username) {
                                                                        const newErrors = { ...fieldErrors };
                                                                        delete newErrors.username;
                                                                        setFieldErrors(newErrors);
                                                                        form.clearErrors("username");
                                                                    }
                                                                }}
                                                            />
                                                        </div>
                                                    </FormControl>
                                                    <FormMessage
                                                        className={cn(TYPOGRAPHY.sizes.xs, "text-gray-500")}
                                                    />
                                                </FormItem>
                                            )}
                                        />

                                        {/* Email Field */}
                                        <FormField
                                            control={form.control}
                                            name="email"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel
                                                        className={cn(
                                                            TYPOGRAPHY.sizes.sm,
                                                            TYPOGRAPHY.weights.medium
                                                        )}
                                                        style={{ color: COLORS.light.text }}
                                                    >
                                                        Email
                                                    </FormLabel>
                                                    <FormControl>
                                                        <div className="relative">
                                                            <Mail
                                                                className="absolute left-3 top-3 h-5 w-5"
                                                                style={{ color: COLORS.light.textMuted }}
                                                            />
                                                            <Input
                                                                type="email"
                                                                placeholder="Enter your email"
                                                                maxLength={40}
                                                                className={cn(
                                                                    "pl-10 h-12 transition-all duration-200",
                                                                    "focus:ring-2 focus:ring-opacity-50",
                                                                    "disabled:opacity-50 disabled:cursor-not-allowed",
                                                                    fieldErrors.email &&
                                                                    "border-gray-500 focus:ring-gray-500/20"
                                                                )}
                                                                style={{
                                                                    borderColor: fieldErrors.email
                                                                        ? COLORS.error
                                                                        : COLORS.light.border,
                                                                    backgroundColor: COLORS.light.bg,
                                                                    color: COLORS.light.text,
                                                                }}
                                                                disabled={isLoading}
                                                                autoComplete="email"
                                                                {...field}
                                                                onChange={(e) => {
                                                                    field.onChange(e);
                                                                    if (fieldErrors.email) {
                                                                        const newErrors = { ...fieldErrors };
                                                                        delete newErrors.email;
                                                                        setFieldErrors(newErrors);
                                                                        form.clearErrors("email");
                                                                    }
                                                                }}
                                                            />
                                                        </div>
                                                    </FormControl>
                                                    <FormMessage
                                                        className={cn(TYPOGRAPHY.sizes.xs, "text-gray-500")}
                                                    />
                                                </FormItem>
                                            )}
                                        />

                                        <FormField
                                            control={form.control}
                                            name="birth_date"
                                            render={({ field }) => (
                                                <FormItem className="flex flex-col">
                                                    <FormLabel>Birth Date</FormLabel>
                                                    <Popover>
                                                        <PopoverTrigger asChild>
                                                            <FormControl>
                                                                <Button
                                                                    variant="outline"
                                                                    className={cn(
                                                                        "w-full pl-3 text-left font-normal",
                                                                        !field.value && "text-muted-foreground"
                                                                    )}
                                                                >
                                                                    {field.value ? (
                                                                        format(field.value as any, "yyyy-MM-dd")
                                                                    ) : (
                                                                        <span>Select your birth date</span>
                                                                    )}
                                                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                                                </Button>
                                                            </FormControl>
                                                        </PopoverTrigger>
                                                        <PopoverContent
                                                            className="w-auto p-0"
                                                            align="start"
                                                        >
                                                            <Calendar
                                                                mode="single"
                                                                selected={field.value as any}
                                                                // ✅ Ensure we store Date object
                                                                onSelect={(date) => field.onChange(date)}
                                                                // ✅ Optional: prevent future dates
                                                                disabled={(date) => date > new Date()}
                                                                captionLayout="dropdown"
                                                                initialFocus
                                                            />
                                                        </PopoverContent>
                                                    </Popover>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />

                                        {/* Phone Number Field */}
                                        <FormField
                                            control={form.control}
                                            name="phoneNumber"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel
                                                        className={cn(
                                                            TYPOGRAPHY.sizes.sm,
                                                            TYPOGRAPHY.weights.medium
                                                        )}
                                                        style={{ color: COLORS.light.text }}
                                                    >
                                                        Phone Number
                                                    </FormLabel>
                                                    <FormControl>
                                                        <div className="relative flex items-center">
                                                            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-gray-500 select-none">
                                                                +63
                                                            </span>
                                                            <Input
                                                                type="tel"
                                                                placeholder="9123456789"
                                                                className={cn(
                                                                    "pl-14 h-12 transition-all duration-200",
                                                                    "focus:ring-2 focus:ring-opacity-50",
                                                                    "disabled:opacity-50 disabled:cursor-not-allowed"
                                                                )}
                                                                style={{
                                                                    borderColor: COLORS.light.border,
                                                                    backgroundColor: COLORS.light.bg,
                                                                    color: COLORS.light.text,
                                                                }}
                                                                disabled={isLoading}
                                                                autoComplete="tel"
                                                                maxLength={10}
                                                                {...field}
                                                                value={field.value || ""} // Just show the digits
                                                                onChange={(e) =>
                                                                    handlePhoneNumberChange(e, field.onChange)
                                                                }
                                                            />
                                                        </div>
                                                    </FormControl>
                                                    <FormMessage
                                                        className="text-xs"
                                                        style={{ color: COLORS.error }}
                                                    />
                                                </FormItem>
                                            )}
                                        />

                                        {/* Password Field */}
                                        <FormField
                                            control={form.control}
                                            name="password"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel
                                                        className={cn(
                                                            TYPOGRAPHY.sizes.sm,
                                                            TYPOGRAPHY.weights.medium
                                                        )}
                                                        style={{ color: COLORS.light.text }}
                                                    >
                                                        Password
                                                    </FormLabel>
                                                    <FormControl>
                                                        <div className="relative">
                                                            <Lock
                                                                className="absolute left-3 top-3 h-5 w-5"
                                                                style={{ color: COLORS.light.textMuted }}
                                                            />
                                                            <Input
                                                                type={showPassword ? "text" : "password"}
                                                                placeholder="Enter your password"
                                                                maxLength={45}
                                                                className={cn(
                                                                    "pl-10 pr-10 h-12 transition-all duration-200",
                                                                    "focus:ring-2 focus:ring-opacity-50",
                                                                    "disabled:opacity-50 disabled:cursor-not-allowed"
                                                                )}
                                                                style={{
                                                                    borderColor: COLORS.light.border,
                                                                    backgroundColor: COLORS.light.bg,
                                                                    color: COLORS.light.text,
                                                                }}
                                                                disabled={isLoading}
                                                                autoComplete="new-password"
                                                                {...field}
                                                            />
                                                            <button
                                                                type="button"
                                                                className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 hover:opacity-70 transition-opacity"
                                                                onClick={() => setShowPassword(!showPassword)}
                                                                disabled={isLoading}
                                                                tabIndex={-1}
                                                            >
                                                                {showPassword ? (
                                                                    <EyeOff
                                                                        className="h-5 w-5"
                                                                        style={{ color: COLORS.light.textMuted }}
                                                                    />
                                                                ) : (
                                                                    <Eye
                                                                        className="h-5 w-5"
                                                                        style={{ color: COLORS.light.textMuted }}
                                                                    />
                                                                )}
                                                            </button>
                                                        </div>
                                                    </FormControl>
                                                    <FormMessage
                                                        className="text-xs"
                                                        style={{ color: COLORS.error }}
                                                    />
                                                </FormItem>
                                            )}
                                        />

                                        {/* Confirm Password Field */}
                                        <FormField
                                            control={form.control}
                                            name="confirmPassword"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel
                                                        className={cn(
                                                            TYPOGRAPHY.sizes.sm,
                                                            TYPOGRAPHY.weights.medium
                                                        )}
                                                        style={{ color: COLORS.light.text }}
                                                    >
                                                        Confirm Password
                                                    </FormLabel>
                                                    <FormControl>
                                                        <div className="relative">
                                                            <Lock
                                                                className="absolute left-3 top-3 h-5 w-5"
                                                                style={{ color: COLORS.light.textMuted }}
                                                            />
                                                            <Input
                                                                type={showConfirmPassword ? "text" : "password"}
                                                                placeholder="Confirm your password"
                                                                maxLength={45}
                                                                className={cn(
                                                                    "pl-10 pr-10 h-12 transition-all duration-200",
                                                                    "focus:ring-2 focus:ring-opacity-50",
                                                                    "disabled:opacity-50 disabled:cursor-not-allowed"
                                                                )}
                                                                style={{
                                                                    borderColor: COLORS.light.border,
                                                                    backgroundColor: COLORS.light.bg,
                                                                    color: COLORS.light.text,
                                                                }}
                                                                disabled={isLoading}
                                                                autoComplete="new-password"
                                                                {...field}
                                                            />
                                                            <button
                                                                type="button"
                                                                className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 hover:opacity-70 transition-opacity"
                                                                onClick={() =>
                                                                    setShowConfirmPassword(!showConfirmPassword)
                                                                }
                                                                disabled={isLoading}
                                                                tabIndex={-1}
                                                            >
                                                                {showConfirmPassword ? (
                                                                    <EyeOff
                                                                        className="h-5 w-5"
                                                                        style={{ color: COLORS.light.textMuted }}
                                                                    />
                                                                ) : (
                                                                    <Eye
                                                                        className="h-5 w-5"
                                                                        style={{ color: COLORS.light.textMuted }}
                                                                    />
                                                                )}
                                                            </button>
                                                        </div>
                                                    </FormControl>
                                                    <FormMessage
                                                        className="text-xs"
                                                        style={{ color: COLORS.error }}
                                                    />
                                                </FormItem>
                                            )}
                                        />

                                        {/* Terms and Conditions Checkbox */}
                                        <FormField
                                            control={form.control}
                                            name="agreeToTerms"
                                            render={({ field }) => (
                                                <FormItem className="space-y-0">
                                                    <div className="flex items-start space-x-3">
                                                        <FormControl>
                                                            <Checkbox
                                                                checked={field.value}
                                                                onCheckedChange={(checked) => handleTermsChange(checked === true)}
                                                                className={cn(
                                                                    "mt-1 h-4 w-4 rounded border-slate-300 text-gray-500",
                                                                    "focus:ring-gray-500/20",
                                                                    "data-[state=checked]:bg-gray-500 data-[state=checked]:border-gray-500"
                                                                )}
                                                            />
                                                        </FormControl>
                                                        <div className="space-y-1">
                                                            <FormLabel className={cn(
                                                                "text-sm font-normal text-slate-700 leading-5",
                                                                "flex flex-wrap items-center gap-1"
                                                            )}>
                                                                I agree to the
                                                                <Button
                                                                    type="button"
                                                                    variant="link"
                                                                    className="h-auto p-0 text-gray-500 hover:underline"
                                                                >
                                                                    Terms of Service
                                                                </Button>
                                                                and
                                                                <Button
                                                                    type="button"
                                                                    variant="link"
                                                                    className="h-auto p-0 text-gray-500 hover:underline"
                                                                >
                                                                    Privacy Policy
                                                                </Button>
                                                            </FormLabel>
                                                            <FormMessage className="text-xs text-gray-500" />
                                                        </div>
                                                    </div>
                                                </FormItem>
                                            )}
                                        />
                                        {/* Verification Note Alert */}
                                        <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                                            <div className="flex items-start">
                                                <svg
                                                    className="h-5 w-5 text-blue-500 mt-0.5 mr-2 flex-shrink-0"
                                                    fill="none"
                                                    viewBox="0 0 24 24"
                                                    stroke="currentColor"
                                                >
                                                    <path
                                                        strokeLinecap="round"
                                                        strokeLinejoin="round"
                                                        strokeWidth={2}
                                                        d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                                                    />
                                                </svg>
                                                <div>
                                                    <h4 className="text-sm font-medium text-blue-800">Verify Your Email</h4>
                                                    <p className="text-sm text-blue-700 mt-1">
                                                        After signing up, please check your email (including spam/junk folder)
                                                        for a verification link to activate your account.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Submit Button */}
                                    <div className="space-y-6">
                                        <Button
                                            type="submit"
                                            className={cn(
                                                "w-full h-12 transition-all duration-200",
                                                TYPOGRAPHY.sizes.base,
                                                TYPOGRAPHY.weights.medium,
                                                "focus:ring-4 focus:ring-opacity-20",
                                                "disabled:opacity-50 disabled:cursor-not-allowed",
                                                "hover:shadow-lg transform hover:-translate-y-0.5"
                                            )}

                                            disabled={isLoading}

                                        >
                                            {isLoading ? (
                                                <div className="flex items-center justify-center">
                                                    <Loader2 className="animate-spin -ml-1 mr-3 h-5 w-5" />
                                                    Creating Account...
                                                </div>
                                            ) : (
                                                "Create Account"
                                            )}
                                        </Button>

                                        {/* Separator and Sign In Link */}
                                        <div className="space-y-4">
                                            <Separator
                                                style={{ backgroundColor: COLORS.light.border }}
                                            />
                                            <div
                                                className={cn("text-center", TYPOGRAPHY.sizes.sm)}
                                                style={{ color: COLORS.light.textMuted }}
                                            >
                                                Already have an account?{" "}
                                                <Link
                                                    href="/signin"
                                                    className={cn(
                                                        TYPOGRAPHY.weights.medium,
                                                        "hover:underline transition-colors duration-200",
                                                        "focus:outline-none focus:ring-2 focus:ring-opacity-50 rounded-sm px-1"
                                                    )}
                                                    style={{

                                                        fontFamily: TYPOGRAPHY.fonts.body,
                                                    }}
                                                    tabIndex={isLoading ? -1 : 0}
                                                >
                                                    Sign in here
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </Form>
                        </CardContent>
                    </Card>
                </div>
            </div>

            {/* Right Side - Image */}
            <div className="hidden lg:block relative bg-muted w-full h-full">
                <div className="relative w-full h-full">
                    <Image
                        src={
                            "https://static.vecteezy.com/system/resources/previews/048/213/706/non_2x/colorful-background-a-stack-of-colorful-fabric-full-frame-shot-of-multi-colored-fabric-background-photo.JPG"
                        }
                        alt="Sign In Illustration"
                        fill
                        sizes="(max-width: 768px) 100vw, 50vw"
                        className="object-cover transition-opacity duration-300"
                        priority
                        quality={90}
                        loading="eager"
                        onLoadingComplete={(img) => {
                            img.classList.remove("opacity-0");
                            img.classList.add("opacity-100");
                        }}
                    />
                </div>
            </div>

            <TermsDialog
                open={isTermsDialogOpen}
                onOpenChange={setIsTermsDialogOpen}
                onAccept={handleAcceptTerms}
            />
        </div>
    );
};

export default UserSignUp;
