"use client";

import { Button } from "@/components/ui/button";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { Loader2, RefreshCw, Shield, Mail, Clock } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";

interface OTPDialogProps {
    isOpen: boolean;
    onClose: () => void;
    onVerify: (otp: string) => Promise<{ success: boolean; message?: string }>;
    email: string;
    onResendOTP?: () => Promise<{ success: boolean; message?: string }>;
    isLoading?: boolean;
}

const OTPDialog = ({
    isOpen,
    onClose,
    onVerify,
    email,
    onResendOTP,
    isLoading = false
}: OTPDialogProps) => {
    const [otp, setOtp] = useState(['', '', '', '', '', '']);
    const [isVerifying, setIsVerifying] = useState(false);
    const [isResending, setIsResending] = useState(false);
    const [countdown, setCountdown] = useState(0);
    const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

    // Start countdown when dialog opens
    useEffect(() => {
        if (isOpen) {
            setCountdown(60); // 60 seconds countdown
            setOtp(['', '', '', '', '', '']);
        }
    }, [isOpen]);

    // Countdown timer
    useEffect(() => {
        if (countdown > 0) {
            const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
            return () => clearTimeout(timer);
        }
        if (countdown === 0) {
            setIsResending(false);
        }
        return () => setIsResending(false);
    }, [countdown]);

    // Focus first input when dialog opens
    useEffect(() => {
        if (isOpen && inputRefs.current[0]) {
            inputRefs.current[0]?.focus();
        }
    }, [isOpen]);

    const handleInputChange = (index: number, value: string) => {
        // Only allow numbers
        if (!/^\d*$/.test(value)) return;

        const newOtp = [...otp];

        if (value.length <= 1) {
            newOtp[index] = value;
            setOtp(newOtp);

            // Auto-focus next input
            if (value && index < 5) {
                inputRefs.current[index + 1]?.focus();
            }
        }
    };

    const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
        if (e.key === 'Backspace' && !otp[index] && index > 0) {
            // Move to previous input on backspace if current is empty
            inputRefs.current[index - 1]?.focus();
        } else if (e.key === 'ArrowLeft' && index > 0) {
            inputRefs.current[index - 1]?.focus();
        } else if (e.key === 'ArrowRight' && index < 5) {
            inputRefs.current[index + 1]?.focus();
        } else if (e.key === 'Enter') {
            handleVerifyOTP();
        }
    };

    const handlePaste = (e: React.ClipboardEvent) => {
        e.preventDefault();
        const pastedData = e.clipboardData.getData('text').replace(/\D/g, '');

        if (pastedData.length === 6) {
            const newOtp = pastedData.split('').slice(0, 6);
            setOtp(newOtp);
            // Focus the last input
            inputRefs.current[5]?.focus();
        }
    };

    const handleVerifyOTP = useCallback(async () => {
        const otpString = otp.join('');

        if (otpString.length !== 6) {
            toast.error('Please enter all 6 digits');
            return;
        }

        setIsVerifying(true);
        try {
            const result = await onVerify(otpString);
            if (result.success) {
                // Don't show success toast here - let the parent handle it
                // The dialog will be closed by the parent component after successful verification
            } else {
                toast.error(result.message || 'Invalid OTP. Please try again.');
                // Clear OTP on failure
                setOtp(['', '', '', '', '', '']);
                inputRefs.current[0]?.focus();
            }
        } catch (error) {
            toast.error('Failed to verify OTP. Please try again.');
            setOtp(['', '', '', '', '', '']);
            inputRefs.current[0]?.focus();
        } finally {
            setIsVerifying(false);
        }
    }, [otp, onVerify]);

    const handleResendOTP = useCallback(async () => {
        if (!onResendOTP || countdown > 0) return;

        setIsResending(true);
        try {
            const result = await onResendOTP();
            if (result.success) {
                toast.success('New verification code sent to your email!');
                setCountdown(60);
                setOtp(['', '', '', '', '', '']);
                inputRefs.current[0]?.focus();
            } else {
                toast.error(result.message || 'Failed to resend OTP. Please try again.');
            }
        } catch (error) {
            toast.error('Failed to resend OTP. Please try again.');
        } finally {
            setIsResending(false);
        }
    }, [onResendOTP, countdown]);

    const handleDialogClose = useCallback(() => {
        // Reset all states when closing
        setOtp(['', '', '', '', '', '']);
        setIsVerifying(false);
        setIsResending(false);
        setCountdown(0);
        onClose();
    }, [onClose]);

    const isOTPComplete = otp.every(digit => digit !== '');
    const isAnyLoading = isVerifying || isResending || isLoading;

    return (
        <Dialog open={isOpen} onOpenChange={handleDialogClose}>
            <DialogContent className="sm:max-w-lg border-0 shadow-2xl bg-gradient-to-br from-white via-gray-50 to-white">
                <DialogHeader className="text-center pb-6">
                    {/* Enhanced Icon with gradient background */}
                    <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-primary via-primary/90 to-primary/80 shadow-lg shadow-primary/25">
                        <Shield className="h-10 w-10 text-white" />
                    </div>

                    {/* Enhanced Title */}
                    <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 bg-clip-text text-transparent">
                        Email Verification
                    </DialogTitle>

                    {/* Enhanced Description with better styling */}
                    <DialogDescription className="text-base text-gray-600 mt-3 max-w-sm mx-auto leading-relaxed">
                        We've sent a 6-digit verification code to
                    </DialogDescription>

                    {/* Email display with professional styling */}
                    <div className="mt-3 inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-full border border-blue-200">
                        <Mail className="h-4 w-4 text-blue-600" />
                        <span className="font-semibold text-blue-900">{email}</span>
                    </div>
                </DialogHeader>

                <div className="space-y-8 px-2">
                    {/* Enhanced OTP Input Container */}
                    <div className="space-y-4">
                        <div className="text-center">
                            <h3 className="text-sm font-medium text-gray-700 mb-4">Enter verification code</h3>
                        </div>

                        <div className="flex justify-center space-x-3">
                            {otp.map((digit, index) => (
                                <Input
                                    key={index}
                                    ref={(el: any) => (inputRefs.current[index] = el)}
                                    type="text"
                                    inputMode="numeric"
                                    maxLength={1}
                                    value={digit}
                                    onChange={(e) => handleInputChange(index, e.target.value)}
                                    onKeyDown={(e) => handleKeyDown(index, e)}
                                    onPaste={index === 0 ? handlePaste : undefined}
                                    className={cn(
                                        "h-14 w-14 text-center text-xl font-bold",
                                        "border-2 transition-all duration-200 rounded-xl",
                                        "focus:scale-105 focus:shadow-lg",
                                        digit
                                            ? "border-primary bg-gradient-to-br from-primary/10 to-primary/5 shadow-md shadow-primary/20"
                                            : "border-gray-200 hover:border-gray-300 focus:border-primary focus:shadow-lg focus:shadow-primary/10"
                                    )}
                                    disabled={isAnyLoading}
                                />
                            ))}
                        </div>

                        {/* Progress indicator */}
                        <div className="flex justify-center space-x-1 mt-4">
                            {otp.map((digit, index) => (
                                <div
                                    key={index}
                                    className={cn(
                                        "h-1 w-8 rounded-full transition-all duration-300",
                                        digit
                                            ? "bg-gradient-to-r from-primary to-primary/80"
                                            : "bg-gray-200"
                                    )}
                                />
                            ))}
                        </div>
                    </div>

                    {/* Enhanced Timer and Resend Section */}
                    <div className="text-center space-y-3">
                        {countdown > 0 ? (
                            <div className="inline-flex items-center gap-2 px-4 py-2 bg-orange-50 rounded-full border border-orange-200">
                                <Clock className="h-4 w-4 text-orange-600" />
                                <p className="text-sm text-orange-800">
                                    Resend available in{" "}
                                    <span className="font-bold text-orange-900">{countdown}s</span>
                                </p>
                            </div>
                        ) : (
                            <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                onClick={handleResendOTP}
                                disabled={isAnyLoading}
                                className="text-primary hover:text-primary/80 hover:bg-primary/5 px-4 py-2 rounded-full border border-primary/20 hover:border-primary/40 transition-all duration-200"
                            >
                                {isResending ? (
                                    <>
                                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                        Sending...
                                    </>
                                ) : (
                                    <>
                                        <RefreshCw className="mr-2 h-4 w-4" />
                                        Resend Code
                                    </>
                                )}
                            </Button>
                        )}
                    </div>

                    {/* Enhanced Action Buttons */}
                    <div className="space-y-3 pt-2">
                        {/* Verify Button */}
                        <Button
                            onClick={handleVerifyOTP}
                            disabled={!isOTPComplete || isAnyLoading}
                            className={cn(
                                "w-full h-12 text-base font-semibold rounded-xl transition-all duration-200",
                                "bg-gradient-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary/80",
                                "shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed",
                                "transform hover:scale-[1.02] active:scale-[0.98]"
                            )}
                        >
                            {isVerifying ? (
                                <>
                                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                                    Verifying...
                                </>
                            ) : (
                                "Verify & Continue"
                            )}
                        </Button>

                        {/* Cancel Button */}
                        <Button
                            type="button"
                            variant="outline"
                            onClick={handleDialogClose}
                            disabled={isAnyLoading}
                            className="w-full h-11 text-base rounded-xl border-2 hover:bg-gray-50 transition-all duration-200"
                        >
                            Cancel
                        </Button>
                    </div>

                    {/* Enhanced Help Section */}
                    <div className="text-center pt-4 border-t border-gray-100">
                        <div className="inline-flex items-center gap-2 px-4 py-2 bg-gray-50 rounded-full">
                            <div className="h-2 w-2 bg-gray-400 rounded-full"></div>
                            <p className="text-xs text-gray-600">
                                Having trouble? Check your spam folder or contact support
                            </p>
                        </div>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
};

export default OTPDialog;