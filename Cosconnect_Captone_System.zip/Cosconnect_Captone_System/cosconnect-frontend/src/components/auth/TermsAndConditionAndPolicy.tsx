import React, { useState } from 'react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Shield, FileText, CheckCircle2 } from 'lucide-react';

interface TermsDialogProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    onAccept: () => void;
}

export default function TermsDialog({ open, onOpenChange, onAccept }: TermsDialogProps) {
    const [activeTab, setActiveTab] = useState('terms');

    const handleAccept = () => {
        onAccept();
        onOpenChange(false);
    };

    const handleOpenChange = (newOpen: boolean) => {
        if (!newOpen) {
            setActiveTab('terms');
        }
        onOpenChange(newOpen);
    };

    return (
        <Dialog open={open} onOpenChange={handleOpenChange}>
            <DialogContent className="max-w-4xl h-[90vh] max-h-[800px] flex flex-col p-0 gap-0">
                {/* Header - Fixed height */}
                <DialogHeader className="px-4 sm:px-6 py-4 border-b bg-gradient-to-r from-blue-50 to-indigo-50 flex-shrink-0">
                    <DialogTitle className="text-xl sm:text-2xl font-bold flex items-center gap-2">
                        <div className="p-2 bg-blue-100 rounded-lg flex-shrink-0">
                            <FileText className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600" />
                        </div>
                        <span className="leading-tight">Terms & Privacy Policy</span>
                    </DialogTitle>
                    <DialogDescription className="text-sm sm:text-base mt-2">
                        Please read carefully before accepting.
                    </DialogDescription>
                </DialogHeader>

                {/* Content - Flexible height with scroll */}
                <div className="flex-1 overflow-hidden flex flex-col min-h-0">
                    <Tabs value={activeTab} onValueChange={setActiveTab} className="flex flex-col h-full">
                        <TabsList className="mx-4 sm:mx-6 mt-4 grid grid-cols-2 flex-shrink-0">
                            <TabsTrigger value="terms" className="flex items-center gap-2 text-xs sm:text-sm">
                                <FileText className="w-3 h-3 sm:w-4 sm:h-4" />
                                <span className="hidden sm:inline">Terms & Conditions</span>
                                <span className="sm:hidden">Terms</span>
                            </TabsTrigger>
                            <TabsTrigger value="privacy" className="flex items-center gap-2 text-xs sm:text-sm">
                                <Shield className="w-3 h-3 sm:w-4 sm:h-4" />
                                <span className="hidden sm:inline">Privacy Policy</span>
                                <span className="sm:hidden">Privacy</span>
                            </TabsTrigger>
                        </TabsList>

                        <TabsContent value="terms" className="flex-1 mt-4 overflow-hidden">
                            <ScrollArea className="h-full px-4 sm:px-6">
                                <div className="space-y-6 pb-4 text-sm text-gray-700">
                                    <div className="bg-blue-50 border-l-4 border-blue-500 p-3 sm:p-4 rounded-r-lg">
                                        <p className="text-sm leading-relaxed text-gray-800">
                                            <strong>Welcome to CosConnect</strong>, a web-based social marketspace and rental services for cosplay essentials.
                                        </p>
                                        <p className="text-xs text-gray-600 mt-2">Last Updated: October 2025</p>
                                    </div>

                                    <section>
                                        <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                                            <span className="flex items-center justify-center w-7 h-7 bg-blue-100 text-blue-600 rounded-full text-sm font-bold flex-shrink-0">1</span>
                                            Acceptance of Terms
                                        </h3>
                                        <p className="ml-9 leading-relaxed">By using CosConnect, you confirm that you have read, understood, and agreed to these Terms and Conditions and our Privacy Policy.</p>
                                    </section>

                                    <section>
                                        <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                                            <span className="flex items-center justify-center w-7 h-7 bg-blue-100 text-blue-600 rounded-full text-sm font-bold flex-shrink-0">2</span>
                                            Definitions
                                        </h3>
                                        <div className="space-y-2 ml-9">
                                            <div className="bg-gray-50 p-3 rounded-lg border-l-4 border-gray-300">
                                                <p><strong className="text-blue-600">Borrower:</strong> A registered user who rents or borrows a costume from a Lender.</p>
                                            </div>
                                            <div className="bg-gray-50 p-3 rounded-lg border-l-4 border-gray-300">
                                                <p><strong className="text-blue-600">Lender:</strong> A registered user who lists a costume for rent.</p>
                                            </div>
                                            <div className="bg-gray-50 p-3 rounded-lg border-l-4 border-gray-300">
                                                <p><strong className="text-blue-600">Marketspace:</strong> The section where users may post cosplay-related items for community awareness.</p>
                                            </div>
                                            <div className="bg-gray-50 p-3 rounded-lg border-l-4 border-gray-300">
                                                <p><strong className="text-blue-600">Rental Services:</strong> CosConnect's system that facilitates costume lending between users.</p>
                                            </div>
                                        </div>
                                    </section>

                                    <section>
                                        <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                                            <span className="flex items-center justify-center w-7 h-7 bg-blue-100 text-blue-600 rounded-full text-sm font-bold flex-shrink-0">3</span>
                                            Rental Services
                                        </h3>
                                        <div className="ml-9 space-y-3">
                                            <p className="leading-relaxed">CosConnect provides a service that facilitates costume rentals between owners and borrowers.</p>
                                            <p className="font-semibold text-gray-900">Users agree to:</p>
                                            <ul className="space-y-2">
                                                <li className="flex gap-2"><span className="text-blue-600 flex-shrink-0">•</span><span>Provide accurate descriptions and rental details.</span></li>
                                                <li className="flex gap-2"><span className="text-blue-600 flex-shrink-0">•</span><span>Return items in good condition within the agreed timeframe.</span></li>
                                                <li className="flex gap-2"><span className="text-blue-600 flex-shrink-0">•</span><span>Follow all rental policies outlined by CosConnect.</span></li>
                                            </ul>
                                        </div>
                                    </section>

                                    <section>
                                        <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                                            <span className="flex items-center justify-center w-7 h-7 bg-blue-100 text-blue-600 rounded-full text-sm font-bold flex-shrink-0">4</span>
                                            Marketspace
                                        </h3>
                                        <div className="ml-9 space-y-3">
                                            <p className="leading-relaxed">CosConnect's Marketspace allows users to sell cosplay-related items. Please note:</p>
                                            <ul className="space-y-2">
                                                <li className="flex gap-2"><span className="text-blue-600 flex-shrink-0">•</span><span>CosConnect does not directly handle payments for Marketspace transactions.</span></li>
                                                <li className="flex gap-2"><span className="text-blue-600 flex-shrink-0">•</span><span>CosConnect is not responsible for product quality, authenticity, or user disputes.</span></li>
                                                <li className="flex gap-2"><span className="text-blue-600 flex-shrink-0">•</span><span>Users must ensure compliance with all applicable laws.</span></li>
                                            </ul>
                                        </div>
                                    </section>

                                    <section>
                                        <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                                            <span className="flex items-center justify-center w-7 h-7 bg-blue-100 text-blue-600 rounded-full text-sm font-bold flex-shrink-0">5</span>
                                            Third-Party Services
                                        </h3>
                                        <div className="ml-9 space-y-3">
                                            <p className="leading-relaxed">CosConnect partners with trusted third-party delivery providers. We are not responsible for delays, damages, or losses during delivery.</p>
                                        </div>
                                    </section>

                                    <section>
                                        <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                                            <span className="flex items-center justify-center w-7 h-7 bg-blue-100 text-blue-600 rounded-full text-sm font-bold flex-shrink-0">6</span>
                                            Age Restrictions
                                        </h3>
                                        <div className="ml-9 space-y-3">
                                            <div className="bg-amber-50 border-l-4 border-amber-500 p-3 rounded-r-lg">
                                                <p className="font-semibold text-amber-900">Rental services are strictly for users aged 18 and above.</p>
                                            </div>
                                            <ul className="space-y-2">
                                                <li className="flex gap-2"><span className="text-blue-600 flex-shrink-0">•</span><span>Users under 18 may access social features only with guardian consent.</span></li>
                                                <li className="flex gap-2"><span className="text-blue-600 flex-shrink-0">•</span><span>CosConnect may request verification to confirm age or identity.</span></li>
                                                <li className="flex gap-2"><span className="text-blue-600 flex-shrink-0">•</span><span>Accounts misrepresenting identity may be terminated immediately.</span></li>
                                            </ul>
                                        </div>
                                    </section>

                                    <section>
                                        <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                                            <span className="flex items-center justify-center w-7 h-7 bg-blue-100 text-blue-600 rounded-full text-sm font-bold flex-shrink-0">7</span>
                                            User Conduct
                                        </h3>
                                        <div className="ml-9 space-y-3">
                                            <p className="leading-relaxed">Users agree not to post offensive content, engage in fraud, or infringe on others' rights. Violations may result in account suspension.</p>
                                        </div>
                                    </section>

                                    <section>
                                        <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                                            <span className="flex items-center justify-center w-7 h-7 bg-blue-100 text-blue-600 rounded-full text-sm font-bold flex-shrink-0">8</span>
                                            Liability and Disclaimers
                                        </h3>
                                        <div className="ml-9">
                                            <p className="leading-relaxed">CosConnect provides services "as is" without warranties. We are not responsible for losses from user transactions, service interruptions, or third-party failures.</p>
                                        </div>
                                    </section>

                                    <section>
                                        <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                                            <span className="flex items-center justify-center w-7 h-7 bg-blue-100 text-blue-600 rounded-full text-sm font-bold flex-shrink-0">9</span>
                                            Termination
                                        </h3>
                                        <div className="ml-9">
                                            <p className="leading-relaxed">CosConnect reserves the right to suspend or terminate accounts that violate these Terms or engage in fraudulent activity.</p>
                                        </div>

                                    </section>

                                    <section>
                                        <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                                            <span className="flex items-center justify-center w-7 h-7 bg-blue-100 text-blue-600 rounded-full text-sm font-bold flex-shrink-0">10</span>
                                            Governing Law
                                        </h3>
                                        <div className="ml-9">
                                            <p className="leading-relaxed">These Terms are governed by the laws of the Republic of the Philippines and comply with the Data Privacy Act of 2012 (R.A. 10173).</p>
                                        </div>
                                        <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                                            <span className="flex items-center justify-center w-7 h-7 bg-blue-100 text-blue-600 rounded-full text-sm font-bold flex-shrink-0">11</span>
                                            Commission Fees
                                        </h3>

                                        <div className="ml-9 space-y-4">

                                            <div>
                                                <p className="font-semibold text-gray-900">Borrower Commission – 3%</p>
                                                <p className="leading-relaxed">
                                                    This fee is added to the rental amount paid by the Borrower.
                                                </p>
                                                <p className="leading-relaxed">
                                                    <strong>Example:</strong> If the rental fee is ₱1,000, the Borrower pays ₱1,030 (₱1,000 + 3% fee).
                                                </p>
                                                <p className="leading-relaxed">
                                                    <strong>Purpose:</strong> Keeps rentals affordable and encourages more users to participate in the platform.
                                                </p>
                                            </div>

                                            <div>
                                                <p className="font-semibold text-gray-900">Lender Commission – 5%</p>
                                                <p className="leading-relaxed">
                                                    This fee is deducted from the rental amount earned by the Lender.
                                                </p>
                                                <p className="leading-relaxed">
                                                    <strong>Example:</strong> If the rental fee is ₱1,000, the Lender receives ₱950
                                                    (₱1,000 - 5% fee).
                                                </p>
                                                <p className="leading-relaxed">
                                                    <strong>Purpose:</strong> Lenders earn income while benefiting from CosConnect’s
                                                    platform services such as visibility, scheduling, and communication.
                                                </p>
                                            </div>

                                        </div>
                                        <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                                            <span className="flex items-center justify-center w-7 h-7 bg-blue-100 text-blue-600 rounded-full text-sm font-bold flex-shrink-0">12</span>
                                            Courier Responsibility
                                        </h3>

                                        <div className="ml-9">
                                            <p className="leading-relaxed">
                                                CosConnect is not directly responsible for courier losses. However, we assist both parties
                                                in resolving the issue and in documenting claims to the courier service.
                                            </p>
                                        </div>

                                    </section>

                                    <section>
                                        <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                                            <span className="flex items-center justify-center w-7 h-7 bg-blue-100 text-blue-600 rounded-full text-sm font-bold flex-shrink-0">13</span>
                                            Contact Us
                                        </h3>
                                        <div className="ml-9">
                                            <p className="leading-relaxed mb-2">For legal, privacy, or general concerns:</p>
                                            <a href="mailto:cosconnecthelp@gmail.com" className="text-blue-600 hover:text-blue-700 font-medium">
                                                📧 cosconnecthelp@gmail.com
                                            </a>
                                        </div>
                                    </section>
                                </div>
                            </ScrollArea>
                        </TabsContent>

                        <TabsContent value="privacy" className="flex-1 mt-4 overflow-hidden">
                            <ScrollArea className="h-full px-4 sm:px-6">
                                <div className="space-y-6 pb-4 text-sm text-gray-700">
                                    <div className="bg-green-50 border-l-4 border-green-500 p-3 sm:p-4 rounded-r-lg">
                                        <p className="text-sm leading-relaxed text-gray-800">
                                            CosConnect is committed to protecting your personal data and upholding the <strong>Data Privacy Act of 2012</strong>.
                                        </p>
                                    </div>

                                    <section>
                                        <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                                            <span className="flex items-center justify-center w-7 h-7 bg-green-100 text-green-600 rounded-full text-sm font-bold flex-shrink-0">1</span>
                                            Introduction
                                        </h3>
                                        <div className="ml-9">
                                            <p className="leading-relaxed">We ensure that all personal information is processed lawfully, transparently, and securely in compliance with the Data Privacy Act of 2012.</p>
                                        </div>
                                    </section>

                                    <section>
                                        <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                                            <span className="flex items-center justify-center w-7 h-7 bg-green-100 text-green-600 rounded-full text-sm font-bold flex-shrink-0">2</span>
                                            Information We Collect
                                        </h3>
                                        <div className="ml-9 space-y-3">
                                            <p className="leading-relaxed">We collect information to improve our services:</p>
                                            <ul className="space-y-2">
                                                <li className="flex gap-2"><span className="text-green-600 flex-shrink-0">•</span><span>Account information (name, email, username, password)</span></li>
                                                <li className="flex gap-2"><span className="text-green-600 flex-shrink-0">•</span><span>Profile data (cosplay interests, photo, location)</span></li>
                                                <li className="flex gap-2"><span className="text-green-600 flex-shrink-0">•</span><span>Rental and communication history</span></li>
                                                <li className="flex gap-2"><span className="text-green-600 flex-shrink-0">•</span><span>Usage data (browser, device, IP)</span></li>
                                                <li className="flex gap-2"><span className="text-green-600 flex-shrink-0">•</span><span>Data from third-party delivery partners</span></li>
                                            </ul>
                                        </div>
                                    </section>

                                    <section>
                                        <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                                            <span className="flex items-center justify-center w-7 h-7 bg-green-100 text-green-600 rounded-full text-sm font-bold flex-shrink-0">3</span>
                                            How We Use Your Information
                                        </h3>
                                        <div className="ml-9 space-y-3">
                                            <ul className="space-y-2">
                                                <li className="flex gap-2"><span className="text-green-600 flex-shrink-0">•</span><span>Operate and improve CosConnect's services</span></li>
                                                <li className="flex gap-2"><span className="text-green-600 flex-shrink-0">•</span><span>Facilitate rentals and user communication</span></li>
                                                <li className="flex gap-2"><span className="text-green-600 flex-shrink-0">•</span><span>Ensure community safety and prevent fraud</span></li>
                                                <li className="flex gap-2"><span className="text-green-600 flex-shrink-0">•</span><span>Comply with applicable laws</span></li>
                                            </ul>
                                        </div>
                                    </section>

                                    <section>
                                        <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                                            <span className="flex items-center justify-center w-7 h-7 bg-green-100 text-green-600 rounded-full text-sm font-bold flex-shrink-0">4</span>
                                            Data Sharing
                                        </h3>
                                        <div className="ml-9 space-y-3">
                                            <p className="leading-relaxed">We share limited data with delivery partners and service providers.</p>
                                            <div className="bg-green-50 border border-green-200 p-3 rounded-lg">
                                                <p className="text-green-900">We <strong>never sell user data</strong>. All partners must follow strict privacy rules.</p>
                                            </div>
                                        </div>
                                    </section>

                                    <section>
                                        <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                                            <span className="flex items-center justify-center w-7 h-7 bg-green-100 text-green-600 rounded-full text-sm font-bold flex-shrink-0">5</span>
                                            Data Retention
                                        </h3>
                                        <div className="ml-9">
                                            <p className="leading-relaxed">User data is kept only as long as necessary for providing services, legal compliance, and dispute resolution. Afterward, it is securely deleted or anonymized.</p>
                                        </div>
                                    </section>

                                    <section>
                                        <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                                            <span className="flex items-center justify-center w-7 h-7 bg-green-100 text-green-600 rounded-full text-sm font-bold flex-shrink-0">6</span>
                                            Security
                                        </h3>
                                        <div className="ml-9">
                                            <p className="leading-relaxed">We use reasonable safeguards to protect data from unauthorized access. However, no system is completely secure.</p>
                                        </div>
                                    </section>

                                    <section>
                                        <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                                            <span className="flex items-center justify-center w-7 h-7 bg-green-100 text-green-600 rounded-full text-sm font-bold flex-shrink-0">7</span>
                                            User Rights
                                        </h3>
                                        <div className="ml-9 space-y-3">
                                            <p className="leading-relaxed">Under the Data Privacy Act, users have the right to:</p>
                                            <ul className="space-y-2">
                                                <li className="flex gap-2"><span className="text-green-600 flex-shrink-0">•</span><span>Access and obtain copies of their data</span></li>
                                                <li className="flex gap-2"><span className="text-green-600 flex-shrink-0">•</span><span>Correct or update inaccurate information</span></li>
                                                <li className="flex gap-2"><span className="text-green-600 flex-shrink-0">•</span><span>Withdraw consent to processing</span></li>
                                                <li className="flex gap-2"><span className="text-green-600 flex-shrink-0">•</span><span>Request deletion of their data</span></li>
                                            </ul>
                                            <p className="mt-2">Contact: <a href="mailto:cosconnecthelp@gmail.com" className="text-blue-600 hover:underline font-medium">cosconnecthelp@gmail.com</a></p>
                                        </div>
                                    </section>

                                    <section>
                                        <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                                            <span className="flex items-center justify-center w-7 h-7 bg-green-100 text-green-600 rounded-full text-sm font-bold flex-shrink-0">8</span>
                                            Children's Privacy
                                        </h3>
                                        <div className="ml-9 space-y-3">
                                            <div className="bg-amber-50 border-l-4 border-amber-500 p-3 rounded-r-lg">
                                                <p className="text-amber-900">CosConnect is open to users aged 13+, but rental services are restricted to users 18+.</p>
                                            </div>
                                            <p className="leading-relaxed">We do not knowingly collect data from children under 13.</p>
                                        </div>
                                    </section>

                                    <section>
                                        <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                                            <span className="flex items-center justify-center w-7 h-7 bg-green-100 text-green-600 rounded-full text-sm font-bold flex-shrink-0">9</span>
                                            Cookies and Tracking
                                        </h3>
                                        <div className="ml-9">
                                            <p className="leading-relaxed">We use cookies to improve performance, personalize experiences, and track analytics. You can disable cookies through your browser.</p>
                                        </div>
                                    </section>

                                    <section>
                                        <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                                            <span className="flex items-center justify-center w-7 h-7 bg-green-100 text-green-600 rounded-full text-sm font-bold flex-shrink-0">10</span>
                                            Policy Updates
                                        </h3>
                                        <div className="ml-9">
                                            <p className="leading-relaxed">We may update this Privacy Policy occasionally. Continued use after changes means acceptance of the updated policy.</p>
                                        </div>
                                    </section>
                                </div>
                            </ScrollArea>
                        </TabsContent>
                    </Tabs>
                </div>

                {/* Footer - Fixed height */}
                <div className="px-4 sm:px-6 py-3 sm:py-4 border-t bg-gray-50 flex-shrink-0">
                    <button
                        onClick={handleAccept}
                        className="w-full py-2.5 sm:py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2"
                    >
                        <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5" />
                        <span>I Have Read and Understood</span>
                    </button>
                </div>
            </DialogContent>
        </Dialog>
    );
}