"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { User, Store, ArrowRight, Info } from "lucide-react";
import Link from "next/link";
import {
    Tooltip,
    TooltipContent,
    TooltipProvider,
    TooltipTrigger,
} from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";

const ChooseRolePage = () => {
    return (
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-rose-50 via-white to-pink-50 p-4">
            <div className="w-full max-w-5xl">
                {/* Header */}
                <div className="text-center mb-12">
                    <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
                        Choose Your Role
                    </h1>
                    <p className="text-lg text-gray-600">
                        Select how you'd like to use CosConnect
                    </p>
                </div>

                {/* Role Cards */}
                <div className="grid md:grid-cols-2 gap-8">
                    {/* Borrower Card */}
                    <TooltipProvider>
                        <Tooltip delayDuration={200}>
                            <TooltipTrigger asChild>
                                <Card className="relative overflow-hidden border-2 hover:border-rose-400 hover:shadow-xl transition-all duration-300 cursor-pointer group">
                                    <CardHeader className="space-y-4">
                                        <div className="w-16 h-16 rounded-full bg-rose-100 flex items-center justify-center group-hover:bg-rose-200 transition-colors">
                                            <User className="w-8 h-8 text-rose-600" />
                                        </div>
                                        <div>
                                            <CardTitle className="text-2xl mb-2">
                                                Sign Up as Borrower
                                            </CardTitle>
                                            <CardDescription className="text-base">
                                                Rent amazing costumes for your events
                                            </CardDescription>
                                        </div>
                                    </CardHeader>
                                    <CardContent className="space-y-4">
                                        <ul className="space-y-3 text-sm text-gray-600">
                                            <li className="flex items-start gap-2">
                                                <span className="text-rose-600 mt-0.5">✓</span>
                                                <span>Browse and rent costumes instantly</span>
                                            </li>
                                            <li className="flex items-start gap-2">
                                                <span className="text-rose-600 mt-0.5">✓</span>
                                                <span>Quick and easy signup process</span>
                                            </li>
                                            <li className="flex items-start gap-2">
                                                <span className="text-rose-600 mt-0.5">✓</span>
                                                <span>Track your rental history</span>
                                            </li>
                                            <li className="flex items-start gap-2">
                                                <span className="text-rose-600 mt-0.5">✓</span>
                                                <span>Rate and review costumes</span>
                                            </li>
                                        </ul>

                                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                                            <Info className="w-3 h-3 mr-1" />
                                            You can become a lender later!
                                        </Badge>

                                        <Link href="/signup" className="block">
                                            <Button className="w-full bg-rose-600 hover:bg-rose-700 text-white group-hover:scale-105 transition-transform">
                                                Continue as Borrower
                                                <ArrowRight className="ml-2 w-4 h-4" />
                                            </Button>
                                        </Link>
                                    </CardContent>
                                </Card>
                            </TooltipTrigger>
                            <TooltipContent side="top" className="max-w-xs">
                                <p className="font-semibold mb-1">Borrower Account</p>
                                <p className="text-sm">
                                    Perfect for individuals looking to rent costumes. You can upgrade to a lender account anytime from your settings.
                                </p>
                            </TooltipContent>
                        </Tooltip>
                    </TooltipProvider>

                    {/* Lender Card */}
                    <TooltipProvider>
                        <Tooltip delayDuration={200}>
                            <TooltipTrigger asChild>
                                <Card className="relative overflow-hidden border-2 hover:border-rose-400 hover:shadow-xl transition-all duration-300 cursor-pointer group">
                                    <CardHeader className="space-y-4">
                                        <div className="w-16 h-16 rounded-full bg-rose-100 flex items-center justify-center group-hover:bg-rose-200 transition-colors">
                                            <Store className="w-8 h-8 text-rose-600" />
                                        </div>
                                        <div>
                                            <CardTitle className="text-2xl mb-2">
                                                Sign Up as Lender
                                            </CardTitle>
                                            <CardDescription className="text-base">
                                                List your costumes and earn money
                                            </CardDescription>
                                        </div>
                                    </CardHeader>
                                    <CardContent className="space-y-4">
                                        <ul className="space-y-3 text-sm text-gray-600">
                                            <li className="flex items-start gap-2">
                                                <span className="text-rose-600 mt-0.5">✓</span>
                                                <span>Create your costume store</span>
                                            </li>
                                            <li className="flex items-start gap-2">
                                                <span className="text-rose-600 mt-0.5">✓</span>
                                                <span>Set your own rental prices</span>
                                            </li>
                                            <li className="flex items-start gap-2">
                                                <span className="text-rose-600 mt-0.5">✓</span>
                                                <span>Manage orders and inventory</span>
                                            </li>
                                            <li className="flex items-start gap-2">
                                                <span className="text-rose-600 mt-0.5">✓</span>
                                                <span>Build your business profile</span>
                                            </li>
                                        </ul>

                                        <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                                            <Info className="w-3 h-3 mr-1" />
                                            Requires business verification
                                        </Badge>

                                        <Link href="/signup/lender" className="block">
                                            <Button className="w-full bg-rose-600 hover:bg-rose-700 text-white group-hover:scale-105 transition-transform">
                                                Continue as Lender
                                                <ArrowRight className="ml-2 w-4 h-4" />
                                            </Button>
                                        </Link>
                                    </CardContent>
                                </Card>
                            </TooltipTrigger>
                            <TooltipContent side="top" className="max-w-xs">
                                <p className="font-semibold mb-1">Lender Account</p>
                                <p className="text-sm">
                                    For businesses or individuals who want to rent out their costume collection. Requires business information and document verification.
                                </p>
                            </TooltipContent>
                        </Tooltip>
                    </TooltipProvider>
                </div>

                {/* Footer */}
                <div className="text-center mt-8">
                    <p className="text-gray-600">
                        Already have an account?{" "}
                        <Link href="/signin" className="text-rose-600 hover:text-rose-700 font-semibold">
                            Sign In
                        </Link>
                    </p>
                </div>
            </div>
        </div>
    );
};

export default ChooseRolePage;
