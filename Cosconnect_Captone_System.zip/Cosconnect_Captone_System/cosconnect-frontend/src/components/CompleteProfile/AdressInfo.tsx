"use client"

import { FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { useGetAllDataBarangays } from "@/lib/api/barangaysApi"
import { Button } from "@/components/ui/button"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { cn } from "@/lib/utils"
import { Loader2, MapPin, AlertCircle, ChevronsUpDown, RefreshCw, Check } from "lucide-react"
import { type Control, type FieldErrors, useWatch, useFormContext } from "react-hook-form"
import { useMemo, useState } from "react"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"

// Import your local datasets
import { regions } from "@/utils/philippine_datasets/region"
import { provinces } from "@/utils/philippine_datasets/province"
import { municipalities } from "@/utils/philippine_datasets/municipality"


interface AddressFormProps {
    control: Control<any>
    errors: FieldErrors<any>
    isSubmitting?: boolean
    fieldPrefix?: string
}

export default function AddressForm({ control, errors, isSubmitting = false, fieldPrefix = "" }: AddressFormProps) {
    const { setValue } = useFormContext()

    // Watch selected values for dependent dropdowns
    const selectedRegion = useWatch({ control, name: `${fieldPrefix}region` })
    const selectedProvince = useWatch({ control, name: `${fieldPrefix}province` })
    const selectedCity = useWatch({ control, name: `${fieldPrefix}city` })
    console.log("selectedCity", selectedCity)
    const [searchQuery, setSearchQuery] = useState("")
    const [isRetrying, setIsRetrying] = useState(false)
    const [isBarangayOpen, setIsBarangayOpen] = useState(false)

    const {
        barangays: barangaysData,
        isLoading: isLoadingBarangays,
        isError: isBarangayError,
        isFetching: isFetchingBarangays,
        error: barangayError,
        refetch: refetchBarangays,
    }: any = useGetAllDataBarangays(
        selectedCity?.id ? { id: selectedCity.id, name: selectedCity.name } : undefined
    );
    console.log("barangaysData", barangaysData)

    const barangays = useMemo(() => {
        if (!barangaysData?.data) return []
        return Array.isArray(barangaysData.data) ? barangaysData.data : []
    }, [barangaysData?.data])

    // Memoize filtered provinces based on selected region
    const filteredProvinces = useMemo(() => {
        if (!selectedRegion) return []
        const regionId = regions.find((r) => r.region_name === selectedRegion)?.region_id
        return provinces.filter((p) => p.region_id === regionId)
    }, [selectedRegion])

    // Memoize filtered cities based on selected province
    const filteredCities = useMemo(() => {
        if (!selectedProvince) return []
        const provinceId = provinces.find((p) => p.province_name === selectedProvince)?.province_id
        if (!provinceId) return []
        return municipalities.filter((m) => m.province_id === provinceId)
    }, [selectedProvince])

    // Memoize filtered barangays based on selected city and search query
    const filteredBarangays = useMemo(() => {
        if (!selectedCity?.id || !barangays) return [];

        if (!searchQuery.trim()) return barangays;

        return barangays.filter((barangay: any) =>
            barangay.barangay_name.toLowerCase().includes(searchQuery.toLowerCase())
        );
    }, [selectedCity, barangays, searchQuery]);

    // Handle retry with loading state
    const handleRetryBarangays = async (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
        setIsRetrying(true);

        try {
            await refetchBarangays();
        } catch (error) {
            console.error("Failed to refetch barangays:", error);
        } finally {
            setTimeout(() => setIsRetrying(false), 500);
        }
    };

    console.log("filteredBarangays", filteredBarangays)
    const handleCityChange = (value: string) => {
        const selectedCity = filteredCities.find((city: any) => city.municipality_id === value)
        setValue(
            `${fieldPrefix}city`,
            {
                id: value,
                name: selectedCity?.municipality_name || "",
            },
            { shouldValidate: true },
        )

        // Reset barangay fields completely
        setValue(`${fieldPrefix}barangay`, "", { shouldValidate: true })
        setValue(`${fieldPrefix}barangay_name`, "", { shouldValidate: true })
        setSearchQuery("")
    }

    // Check if barangay field should be disabled
    const isBarangayDisabled = !selectedCity?.id || isLoadingBarangays || isFetchingBarangays || isRetrying

    // Get appropriate loading/error message
    const getBarangayButtonContent = (fieldValue: string) => {
        if (isLoadingBarangays || isFetchingBarangays || isRetrying) {
            return (
                <div className="flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>{isRetrying ? "Retrying..." : "Loading barangays..."}</span>
                </div>
            )
        }

        if (isBarangayError) {
            return (
                <span className="text-destructive truncate flex items-center gap-2">
                    <AlertCircle className="h-4 w-4" />
                    Error loading barangays
                </span>
            )
        }

        if (fieldValue) {
            const selectedBarangay = barangays?.find(
                (barangay: any) => barangay.barangay_id?.toString() === fieldValue || barangay.barangay_name === fieldValue,
            )
            return <span className="truncate">{selectedBarangay?.barangay_name || fieldValue}</span>
        }

        return "Select barangay"
    }

    return (
        <div className="space-y-6">
            <div className="flex items-center gap-3 pb-2 border-b">
                <div className="flex items-center justify-center w-8 h-8 rounded-lg">
                    <MapPin className="h-5 w-5 text-primary" />
                </div>
                <div>
                    <h4 className="text-md font-semibold">Address Information</h4>
                    <p className="text-sm text-muted-foreground">Enter your address details</p>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                {/* Region Select */}
                <FormField
                    control={control}
                    name={`${fieldPrefix}region`}
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Region *</FormLabel>
                            <Select
                                onValueChange={(value) => {
                                    field.onChange(value)
                                    setValue(`${fieldPrefix}province`, "", { shouldValidate: true })
                                    setValue(`${fieldPrefix}city`, { id: "", name: "" }, { shouldValidate: true })
                                    setValue(`${fieldPrefix}barangay`, "", { shouldValidate: true })
                                    setValue(`${fieldPrefix}barangay_name`, "", { shouldValidate: true })
                                    setSearchQuery("")
                                }}
                                value={field.value || ""}
                                disabled={isSubmitting}
                            >
                                <FormControl>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select a region" />
                                    </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                    {regions.map((region) => (
                                        <SelectItem key={region.region_id} value={region.region_name}>
                                            {region.region_name}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                            <FormMessage />
                        </FormItem>
                    )}
                />

                {/* Province Select */}
                <FormField
                    control={control}
                    name={`${fieldPrefix}province`}
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Province *</FormLabel>
                            <Select
                                onValueChange={(value) => {
                                    field.onChange(value)
                                    setValue(`${fieldPrefix}city`, { id: "", name: "" }, { shouldValidate: true })
                                    setValue(`${fieldPrefix}barangay`, "", { shouldValidate: true })
                                    setValue(`${fieldPrefix}barangay_name`, "", { shouldValidate: true })
                                    setSearchQuery("")
                                }}
                                value={field.value || ""}
                                disabled={!selectedRegion || isSubmitting}
                            >
                                <FormControl>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select a province" />
                                    </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                    {filteredProvinces.map((province) => (
                                        <SelectItem key={province.province_id} value={province.province_name}>
                                            {province.province_name}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                            <FormMessage />
                        </FormItem>
                    )}
                />

                {/* City/Municipality Select */}
                <FormField
                    control={control}
                    name={`${fieldPrefix}city`}
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>City/Municipality *</FormLabel>
                            <Select
                                onValueChange={(value) => {
                                    const selectedCity = filteredCities.find(city => city.municipality_id.toString() === value);
                                    if (selectedCity) {
                                        field.onChange({
                                            id: selectedCity.municipality_id,
                                            name: selectedCity.municipality_name
                                        });
                                    }
                                }}
                                value={field.value?.id?.toString() || ""}
                                disabled={!selectedProvince || isSubmitting}
                            >
                                <FormControl>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select a city/municipality">
                                            {field.value?.name || "Select a city/municipality"}
                                        </SelectValue>
                                    </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                    {filteredCities.map((city) => (
                                        <SelectItem
                                            key={city.municipality_id}
                                            value={city.municipality_id.toString()}
                                        >
                                            {city.municipality_name}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                            <FormMessage />
                        </FormItem>
                    )}
                />

                {/* Barangay Select */}
                <FormField
                    control={control}
                    name="barangay"
                    render={({ field }) => (
                        <FormItem className="flex flex-col">
                            <FormLabel>Barangay</FormLabel>
                            <Popover>
                                <PopoverTrigger asChild>
                                    <FormControl>
                                        <Button
                                            variant="outline"
                                            role="combobox"
                                            className={cn(
                                                "w-full justify-between",
                                                !field.value && "text-muted-foreground"
                                            )}
                                            disabled={isBarangayDisabled}
                                        >
                                            {getBarangayButtonContent(field.value)}
                                            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                        </Button>
                                    </FormControl>
                                </PopoverTrigger>
                                <PopoverContent className="w-[--radix-popover-trigger-width] p-0" align="start">
                                    <Command shouldFilter={false}>
                                        <CommandInput
                                            placeholder="Search barangay..."
                                            value={searchQuery}
                                            onValueChange={setSearchQuery}
                                        />
                                        <CommandList>
                                            {isLoadingBarangays || isFetchingBarangays || isRetrying ? (
                                                <div className="py-8 text-center">
                                                    <Loader2 className="h-6 w-6 animate-spin mx-auto mb-2 text-primary" />
                                                    <p className="text-sm text-muted-foreground">
                                                        {isRetrying ? "Retrying..." : "Loading barangays..."}
                                                    </p>
                                                    <p className="text-xs text-muted-foreground mt-1">
                                                        Please wait...
                                                    </p>
                                                </div>
                                            ) : isBarangayError ? (
                                                <div className="py-8 text-center px-4">
                                                    <AlertCircle className="h-8 w-8 mx-auto mb-3 text-destructive" />
                                                    <p className="text-sm font-medium text-destructive mb-2">
                                                        Failed to Load Barangays
                                                    </p>
                                                    <p className="text-xs text-muted-foreground mb-4">
                                                        {barangayError?.message || "An error occurred while fetching barangays"}
                                                    </p>
                                                    <div className="flex flex-col gap-2">
                                                        <Button
                                                            variant="default"
                                                            size="sm"
                                                            onClick={handleRetryBarangays}
                                                            disabled={isRetrying}
                                                            className="flex items-center gap-2"
                                                        >
                                                            {isRetrying ? (
                                                                <>
                                                                    <Loader2 className="h-4 w-4 animate-spin" />
                                                                    Retrying...
                                                                </>
                                                            ) : (
                                                                <>
                                                                    <RefreshCw className="h-4 w-4" />
                                                                    Retry
                                                                </>
                                                            )}
                                                        </Button>
                                                        <p className="text-xs text-muted-foreground">
                                                            Check your internet connection
                                                        </p>
                                                    </div>
                                                </div>
                                            ) : filteredBarangays.length === 0 ? (
                                                <CommandEmpty>
                                                    <div className="py-6 text-center">
                                                        <p className="text-sm text-muted-foreground mb-2">
                                                            {searchQuery ? "No barangays match your search" : "No barangays found"}
                                                        </p>
                                                        {selectedCity?.id && !searchQuery && (
                                                            <>
                                                                <p className="text-xs text-muted-foreground mb-3">
                                                                    Try refreshing the list
                                                                </p>
                                                                <Button
                                                                    variant="outline"
                                                                    size="sm"
                                                                    onClick={handleRetryBarangays}
                                                                    disabled={isRetrying}
                                                                    className="flex items-center gap-2"
                                                                >
                                                                    {isRetrying ? (
                                                                        <>
                                                                            <Loader2 className="h-3 w-3 animate-spin" />
                                                                            Refreshing...
                                                                        </>
                                                                    ) : (
                                                                        <>
                                                                            <RefreshCw className="h-3 w-3" />
                                                                            Refresh
                                                                        </>
                                                                    )}
                                                                </Button>
                                                            </>
                                                        )}
                                                    </div>
                                                </CommandEmpty>
                                            ) : (
                                                <CommandGroup className="max-h-[300px] overflow-auto">
                                                    {filteredBarangays.map((barangay: any) => (
                                                        <CommandItem
                                                            value={barangay.barangay_name}
                                                            key={barangay.barangay_id}
                                                            onSelect={() => {
                                                                field.onChange(barangay.barangay_name);
                                                                setSearchQuery("");
                                                            }}
                                                            className="cursor-pointer"
                                                        >
                                                            <Check
                                                                className={cn(
                                                                    "mr-2 h-4 w-4",
                                                                    field.value === barangay.barangay_name
                                                                        ? "opacity-100"
                                                                        : "opacity-0"
                                                                )}
                                                            />
                                                            {barangay.barangay_name}
                                                        </CommandItem>
                                                    ))}
                                                </CommandGroup>
                                            )}
                                        </CommandList>
                                    </Command>
                                </PopoverContent>
                            </Popover>
                            {isBarangayError && (
                                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                    <AlertCircle className="h-3 w-3 text-destructive" />
                                    <span>Unable to load barangays. Click the button to retry.</span>
                                </div>
                            )}
                            {!isBarangayError && !selectedCity?.id && (
                                <p className="text-xs text-muted-foreground">
                                    Please select a city/municipality first
                                </p>
                            )}
                            {!isBarangayError && selectedCity?.id && barangays && barangays.length > 0 && (
                                <p className="text-xs text-muted-foreground">
                                    {barangays.length} barangay{barangays.length !== 1 ? 's' : ''} available
                                </p>
                            )}
                            <FormMessage />
                        </FormItem>
                    )}
                />
                {/* Street Address */}
                <FormField
                    control={control}
                    name={`${fieldPrefix}street_address`}
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Street Address</FormLabel>
                            <FormControl>
                                <Input placeholder="Enter street address" {...field} disabled={isSubmitting} />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />

                {/* Postal Code */}
                <FormField
                    control={control}
                    name={`${fieldPrefix}postal_code`}
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Postal Code</FormLabel>
                            <FormControl>
                                <Input
                                    placeholder="XXXX"
                                    maxLength={4}
                                    {...field}
                                    disabled={isSubmitting}
                                    onChange={(e) => {
                                        const value = e.target.value.replace(/\D/g, "").slice(0, 4)
                                        field.onChange(value)
                                    }}
                                />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />
            </div>
        </div>
    )
}