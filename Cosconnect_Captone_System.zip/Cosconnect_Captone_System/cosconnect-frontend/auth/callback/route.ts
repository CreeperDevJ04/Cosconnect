import { NextResponse } from 'next/server';
import { createClient } from '@/utils/supabase/server';

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get('code');
  const error = searchParams.get('error');
  const errorDescription = searchParams.get('error_description');

  let next = searchParams.get('next') ?? '/';
  if (!next.startsWith('/')) next = '/';

  console.log("OAuth/Email Callback - Code:", code ? "Present" : "Missing");
  console.log("OAuth/Email Callback - Next URL:", next);
  console.log("OAuth/Email Callback - Origin:", origin);
  console.log("OAuth/Email Callback - Error:", error);
  console.log("OAuth/Email Callback - Error Description:", errorDescription);

  // Handle provider-level error
  if (error) {
    const errorParams = new URLSearchParams({
      error_type: 'oauth_provider_error',
      error_code: error,
      error_message: errorDescription || 'OAuth provider returned an error',
      timestamp: new Date().toISOString(),
    });
    return NextResponse.redirect(`${origin}/error?${errorParams.toString()}`);
  }

  // Handle missing auth code
  if (!code) {
    const errorParams = new URLSearchParams({
      error_type: 'missing_code',
      error_code: 'NO_AUTH_CODE',
      error_message: 'No authorization code received from OAuth provider',
      timestamp: new Date().toISOString(),
    });
    return NextResponse.redirect(`${origin}/error?${errorParams.toString()}`);
  }

  try {
    const supabase = await createClient();
    const { data, error: sessionError } = await supabase.auth.exchangeCodeForSession(code);

    console.log("Session Exchange - Error:", sessionError);
    console.log("Session Exchange - User Data:", data?.user ? {
      id: data.user.id,
      email: data.user.email,
      user_metadata: data.user.user_metadata,
    } : "No user data");

    if (sessionError) {
      const errorParams = new URLSearchParams({
        error_type: 'session_exchange_failed',
        error_code: sessionError.status?.toString() || 'UNKNOWN',
        error_message: sessionError.message || 'Failed to exchange authorization code for session',
        timestamp: new Date().toISOString(),
      });
      return NextResponse.redirect(`${origin}/error?${errorParams.toString()}`);
    }

    if (!data?.user) {
      const errorParams = new URLSearchParams({
        error_type: 'no_user_data',
        error_code: 'NO_USER',
        error_message: 'No user data received after session exchange',
        timestamp: new Date().toISOString(),
      });
      return NextResponse.redirect(`${origin}/error?${errorParams.toString()}`);
    }

    const user = data.user;

    // Detect if this callback came from email confirmation (no next/provider param)
    const isEmailVerification = !searchParams.get('next') && !searchParams.get('provider');
    console.log("Detected email verification:", isEmailVerification);

    // Check if user exists in DB
    const { data: existingUser, error: selectError } = await supabase
      .from("users")
      .select("uid, username, email, phone_number, role")
      .eq("uid", user.id)
      .maybeSingle();

    if (selectError) {
      const errorParams = new URLSearchParams({
        error_type: 'database_select_error',
        error_code: selectError.code || 'DB_SELECT_ERROR',
        error_message: `Failed to check existing user: ${selectError.message}`,
        timestamp: new Date().toISOString(),
      });
      return NextResponse.redirect(`${origin}/error?${errorParams.toString()}`);
    }

    // Create user record if not exists
    if (!existingUser) {
      console.log('Creating new user record...');
      const { user_metadata } = user;
      const email = user_metadata?.email || user.email;
      let username = user_metadata?.username || email?.split('@')[0] || `user-${Date.now()}`;
      username = username.toLowerCase();
      const profileImage = user_metadata?.picture || user_metadata?.avatar_url || "";

      const userData = {
        uid: user.id,
        username,
        email: email!,
        phone_number: user_metadata?.phone_number || user.phone || '',
        profile_image: profileImage,
        role: ['borrower'],
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      const { error: insertError } = await supabase.from("users").insert(userData);
      if (insertError) {
        const errorParams = new URLSearchParams({
          error_type: 'database_insert_error',
          error_code: insertError.code || 'DB_INSERT_ERROR',
          error_message: `Failed to create user record: ${insertError.message}`,
          timestamp: new Date().toISOString(),
        });
        return NextResponse.redirect(`${origin}/error?${errorParams.toString()}`);
      }

      await supabase.auth.updateUser({ data: { role: 'borrower' } });
      console.log('User created successfully in DB.');
    } else {
      console.log('User already exists:', existingUser);
    }

    // 🔁 Handle redirect logic
    const forwardedHost = request.headers.get('x-forwarded-host');
    const isLocalEnv = process.env.NODE_ENV === 'development';

    // If user just verified their email, redirect them to /signin
    if (isEmailVerification) {
      console.log("Email verified successfully, redirecting to sign-in...");
      return NextResponse.redirect(`${origin}/signin?verified=success`);
    }

    console.log("OAuth Success - Redirecting to:", next);
    if (isLocalEnv) {
      return NextResponse.redirect(`${origin}${next}`);
    } else if (forwardedHost) {
      return NextResponse.redirect(`https://${forwardedHost}${next}`);
    } else {
      return NextResponse.redirect(`${origin}${next}`);
    }

  } catch (error) {
    console.error("Unexpected error in OAuth/Email callback:", error);
    const errorParams = new URLSearchParams({
      error_type: 'unexpected_error',
      error_code: 'INTERNAL_ERROR',
      error_message: error instanceof Error ? error.message : 'Unexpected error occurred',
      timestamp: new Date().toISOString(),
    });
    return NextResponse.redirect(`${origin}/error?${errorParams.toString()}`);
  }
}
