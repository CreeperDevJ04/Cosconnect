// BorrowerDialogView.tsx
import React from 'react';
import { format } from 'date-fns';
import { X, ExternalLink } from 'lucide-react';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BorrowerProfile } from '@/types/borrowerType';

interface BorrowerViewDialogProps {
    open: boolean;
    borrower: BorrowerProfile;
    onClose: () => void;
}

export const BorrowerViewDialog: React.FC<BorrowerViewDialogProps> = ({
    open,
    borrower,
    onClose,
}) => {
    const getStatusBadge = (status: string) => {
        switch (status) {
            case 'approved':
                return <Badge className="bg-green-100 text-green-800">Approved</Badge>;
            case 'rejected':
                return <Badge className="bg-red-100 text-red-800">Rejected</Badge>;
            case 'pending':
                return <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>;
            default:
                return <Badge variant="outline">{status}</Badge>;
        }
    };

    return (
        <Dialog open={open} onOpenChange={onClose}>
            <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle className="flex items-center justify-between">
                        <span>Borrower Details</span>
                        <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8">
                            <X className="h-4 w-4" />
                        </Button>
                    </DialogTitle>
                    <DialogDescription>
                        Complete information about the borrower
                    </DialogDescription>
                </DialogHeader>

                <div className="space-y-6 py-4">
                    {/* Personal Information */}
                    <div className="space-y-2">
                        <h3 className="text-lg font-medium">Personal Information</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border rounded-md p-4">
                            <div>
                                <p className="text-sm text-muted-foreground">Full Name</p>
                                <p className="font-medium">{borrower.fullName}</p>
                            </div>
                            <div>
                                <p className="text-sm text-muted-foreground">Email</p>
                                <p className="font-medium">{borrower.email}</p>
                            </div>
                            <div>
                                <p className="text-sm text-muted-foreground">Username</p>
                                <p className="font-medium">{borrower.username}</p>
                            </div>
                            <div>
                                <p className="text-sm text-muted-foreground">Status</p>
                                <div className="font-medium">{getStatusBadge(borrower.status || 'pending')}</div>
                            </div>
                            <div>
                                <p className="text-sm text-muted-foreground">Phone Number</p>
                                <p className="font-medium">{borrower.phoneNumber}</p>
                            </div>
                            <div>
                                <p className="text-sm text-muted-foreground">Address</p>
                                <p className="font-medium">{borrower.address}</p>
                            </div>
                            <div>
                                <p className="text-sm text-muted-foreground">Registered On</p>
                                <p className="font-medium">{format(new Date(borrower.createdAt), 'MMMM dd, yyyy')}</p>
                            </div>
                            <div>
                                <p className="text-sm text-muted-foreground">Last Updated</p>
                                <p className="font-medium">{format(new Date(borrower.updatedAt), 'MMMM dd, yyyy')}</p>
                            </div>
                            <div>
                                <p className="text-sm text-muted-foreground">Verification Status</p>
                                <p className="font-medium">{borrower.isVerified ? 'Verified' : 'Not Verified'}</p>
                            </div>
                        </div>
                    </div>

                    {/* ID Verification */}
                    <div className="space-y-2">
                        <h3 className="text-lg font-medium">ID Verification</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border rounded-md p-4">
                            {borrower.hasValidId ? (
                                <>
                                    <div>
                                        <p className="text-sm text-muted-foreground">ID Type</p>
                                        <p className="font-medium">{borrower.validIdType}</p>
                                    </div>
                                    <div>
                                        <p className="text-sm text-muted-foreground">ID Number</p>
                                        <p className="font-medium">{borrower.validIdNumber}</p>
                                    </div>
                                    <div>
                                        <p className="text-sm text-muted-foreground">ID Document</p>
                                        {borrower.validIdFile ? (
                                            <a
                                                href={borrower.validIdFile}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="flex items-center text-blue-600 hover:underline"
                                            >
                                                View Document <ExternalLink className="ml-1 h-3 w-3" />
                                            </a>
                                        ) : (
                                            <p>Not provided</p>
                                        )}
                                    </div>
                                </>
                            ) : (
                                <>
                                    <div>
                                        <p className="text-sm text-muted-foreground">First ID Type</p>
                                        <p className="font-medium">{borrower.secondaryIdType1}</p>
                                    </div>
                                    <div>
                                        <p className="text-sm text-muted-foreground">First ID Document</p>
                                        {borrower.secondaryIdFile1 ? (
                                            <a
                                                href={borrower.secondaryIdFile1}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="flex items-center text-blue-600 hover:underline"
                                            >
                                                View Document <ExternalLink className="ml-1 h-3 w-3" />
                                            </a>
                                        ) : (
                                            <p>Not provided</p>
                                        )}
                                    </div>
                                    {borrower.secondaryIdType2 && (
                                        <>
                                            <div>
                                                <p className="text-sm text-muted-foreground">Second ID Type</p>
                                                <p className="font-medium">{borrower.secondaryIdType2}</p>
                                            </div>
                                            <div>
                                                <p className="text-sm text-muted-foreground">Second ID Document</p>
                                                {borrower.secondaryIdFile2 ? (
                                                    <a
                                                        href={borrower.secondaryIdFile2}
                                                        target="_blank"
                                                        rel="noopener noreferrer"
                                                        className="flex items-center text-blue-600 hover:underline"
                                                    >
                                                        View Document <ExternalLink className="ml-1 h-3 w-3" />
                                                    </a>
                                                ) : (
                                                    <p>Not provided</p>
                                                )}
                                            </div>
                                        </>
                                    )}
                                </>
                            )}
                        </div>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
}; 