// BorrowerDeleteDialog.tsx
import React from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Loader2 } from 'lucide-react';

const deleteSchema = z.object({
    reason: z.string().min(10, "Reason must be at least 10 characters long"),
});

type DeleteFormValues = z.infer<typeof deleteSchema>;

interface BorrowerDeleteDialogProps {
    open: boolean;
    borrowerId: string | null;
    onClose: () => void;
    onDelete: (reason: string) => void;
    isLoading?: boolean;
}

export const BorrowerDeleteDialog: React.FC<BorrowerDeleteDialogProps> = ({
    open,
    borrowerId,
    onClose,
    onDelete,
    isLoading = false,
}) => {
    const form = useForm<DeleteFormValues>({
        resolver: zodResolver(deleteSchema),
        defaultValues: {
            reason: '',
        },
    });

    const onSubmit = (data: DeleteFormValues) => {
        onDelete(data.reason);
        form.reset();
    };

    return (
        <AlertDialog open={open} onOpenChange={onClose}>
            <AlertDialogContent>
                <AlertDialogHeader>
                    <AlertDialogTitle>Delete Borrower</AlertDialogTitle>
                    <AlertDialogDescription>
                        Are you sure you want to delete this borrower? This action cannot be undone.
                    </AlertDialogDescription>
                </AlertDialogHeader>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                        <FormField
                            control={form.control}
                            name="reason"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Reason for deletion</FormLabel>
                                    <FormControl>
                                        <Textarea
                                            placeholder="Please provide a reason for deleting this borrower's account..."
                                            className="resize-none"
                                            {...field}
                                        />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <AlertDialogFooter>
                            <AlertDialogCancel onClick={() => {
                                form.reset();
                                onClose();
                            }}>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                                type="submit"
                                className="bg-red-600 hover:bg-red-700"
                                disabled={isLoading}
                            >
                                {isLoading ? (
                                    <>
                                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                        Deleting...
                                    </>
                                ) : (
                                    'Delete'
                                )}
                            </AlertDialogAction>
                        </AlertDialogFooter>
                    </form>
                </Form>
            </AlertDialogContent>
        </AlertDialog>
    );
}; 