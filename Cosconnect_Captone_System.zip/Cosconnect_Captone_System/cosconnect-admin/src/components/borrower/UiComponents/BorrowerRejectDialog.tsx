// BorrowerRejectDialog.tsx
import React from 'react';
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface BorrowerRejectDialogProps {
    open: boolean;
    borrowerData: any;
    onClose: () => void;
    onSuccess: () => void;
}

export const BorrowerRejectDialog: React.FC<BorrowerRejectDialogProps> = ({
    open,
    borrowerData,
    onClose,
    onSuccess,
}) => {


    const handleReject = async () => {
        try {

            onSuccess();
        } catch (error) {
            // Error is handled by the API function

            console.log("Error rejecting borrower", error)
            onClose();
        }
    };

    return (
        <AlertDialog open={open} onOpenChange={onClose}>
            <AlertDialogContent>
                <AlertDialogHeader>
                    <AlertDialogTitle>Reject Borrower</AlertDialogTitle>
                    <AlertDialogDescription>
                        Are you sure you want to reject this borrower? They will not be able to access borrowing features.
                    </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction
                        onClick={handleReject}
                        className="bg-red-600 hover:bg-red-700"
                    >
                        Reject
                    </AlertDialogAction>
                </AlertDialogFooter>
            </AlertDialogContent>
        </AlertDialog>
    );
}; 