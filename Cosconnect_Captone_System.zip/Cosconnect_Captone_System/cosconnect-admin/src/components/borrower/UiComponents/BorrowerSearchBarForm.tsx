// BorrowerSearchBarForm.tsx
import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
    Form,
    FormControl,
    FormField,
    FormItem,
    FormLabel,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { z } from 'zod';
import { debounce } from 'lodash';

const searchSchema = z.object({
    searchTerm: z.string().optional(),
});

type SearchFormValues = z.infer<typeof searchSchema>;

interface BorrowerSearchFormProps {
    onSearch: (searchTerm: string) => void;
}

export const BorrowerSearchForm: React.FC<BorrowerSearchFormProps> = ({ onSearch }) => {
    const form = useForm<SearchFormValues>({
        resolver: zodResolver(searchSchema),
        defaultValues: {
            searchTerm: '',
        },
    });

    // Debounce search to prevent excessive API calls
    const debouncedSearch = React.useCallback(
        debounce((value: string) => {
            onSearch(value);
        }, 500),
        [onSearch]
    );

    // Clean up debounce on unmount
    React.useEffect(() => {
        return () => {
            debouncedSearch.cancel();
        };
    }, [debouncedSearch]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        form.setValue('searchTerm', e.target.value);
        debouncedSearch(e.target.value);
    };

    const onSubmit = (data: SearchFormValues) => {
        // Cancel debounce and execute search immediately on form submit
        debouncedSearch.cancel();
        onSearch(data.searchTerm || '');
    };

    return (
        <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="flex w-full max-w-sm items-center space-x-2">
                <FormField
                    control={form.control}
                    name="searchTerm"
                    render={({ field }) => (
                        <FormItem className="w-full">
                            <FormControl>
                                <div className="relative w-full">
                                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                                    <Input
                                        {...field}
                                        placeholder="Search by name, email, or phone..."
                                        className="w-full pl-8"
                                        onChange={handleInputChange}
                                    />
                                </div>
                            </FormControl>
                        </FormItem>
                    )}
                />
                <Button type="submit">Search</Button>
            </form>
        </Form>
    );
};

export default React.memo(BorrowerSearchForm); 