// BorrowerApproveDialog.tsx
import React from 'react';
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface BorrowerApproveDialogProps {
    open: boolean;
    borrowerData: any;
    onClose: () => void;
    onSuccess: () => void;
}

export const BorrowerApproveDialog: React.FC<BorrowerApproveDialogProps> = ({
    open,
    borrowerData,
    onClose,
    onSuccess,
}) => {

    const handleApprove = async () => {
        try {


            onSuccess();
        } catch (error) {
            console.error('Error approving borrower:', error);
            onClose();
        }
    };

    return (
        <AlertDialog open={open} onOpenChange={onClose}>
            <AlertDialogContent>
                <AlertDialogHeader>
                    <AlertDialogTitle>Approve Borrower</AlertDialogTitle>
                    <AlertDialogDescription>
                        Are you sure you want to approve this borrower? They will gain access to borrowing features.
                    </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction
                        onClick={handleApprove}
                        className="bg-green-600 hover:bg-green-700"
                    >

                    </AlertDialogAction>
                </AlertDialogFooter>
            </AlertDialogContent>
        </AlertDialog>
    );
}; 