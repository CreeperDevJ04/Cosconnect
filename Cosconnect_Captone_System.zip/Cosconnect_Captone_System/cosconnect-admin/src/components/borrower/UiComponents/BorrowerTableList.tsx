import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";

import { format } from 'date-fns';
import { CheckCircle, Eye, MoreHorizontal, Trash2, XCircle } from "lucide-react";
import React from 'react';
import { BorrowerDeleteDialog } from './BorrowerDeleteDialog';
import { BorrowerApproveDialog } from './BorrowerApproveDialog';
import { BorrowerRejectDialog } from './BorrowerRejectDialog';
import { BorrowerViewDialog } from './BorrowerDialogView';
import { BorrowerProfile } from '@/types/borrowerType';


interface BorrowerTableProps {
    borrowers: BorrowerProfile[];
    refetch: () => void;
}

export const BorrowerTable: React.FC<BorrowerTableProps> = ({ borrowers, refetch }) => {
    const [borrowerToDelete, setBorrowerToDelete] = React.useState<string | null>(null);
    const [borrowerToApprove, setBorrowerToApprove] = React.useState<BorrowerProfile | null>(null);
    const [borrowerToReject, setBorrowerToReject] = React.useState<BorrowerProfile | null>(null);
    const [borrowerToView, setBorrowerToView] = React.useState<BorrowerProfile | null>(null);

    const getStatusBadge = (status: string) => {
        switch (status?.toLowerCase()) {
            case 'approved':
                return <Badge className="bg-green-100 text-green-800 hover:bg-green-200">Approved</Badge>;
            case 'rejected':
                return <Badge className="bg-red-100 text-red-800 hover:bg-red-200">Rejected</Badge>;
            case 'pending':
                return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200">Pending</Badge>;
            default:
                return <Badge variant="outline">{status || 'Pending'}</Badge>;
        }
    };

    const handleDelete = async (reason: string) => {
        if (!borrowerToDelete) return;

        try {
            console.log('borrowerToDelete', borrowerToDelete)

            refetch();
            setBorrowerToDelete(null);
        } catch (error) {
            // Error is handled by the API function
        }
    };

    return (
        <>
            <div className="rounded-md border">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Full Name</TableHead>
                            <TableHead>Email</TableHead>
                            <TableHead>Phone Number</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Created At</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {borrowers.length === 0 ? (
                            <TableRow>
                                <TableCell colSpan={6} className="h-24 text-center">
                                    No borrowers found.
                                </TableCell>
                            </TableRow>
                        ) : (
                            borrowers.map((borrower) => (
                                <TableRow key={borrower.id}>
                                    <TableCell>{borrower.fullName}</TableCell>
                                    <TableCell>{borrower.email}</TableCell>
                                    <TableCell>{borrower.phoneNumber}</TableCell>
                                    <TableCell>{getStatusBadge(borrower.status || 'pending')}</TableCell>
                                    <TableCell>{format(new Date(borrower.createdAt), 'MMM dd, yyyy')}</TableCell>
                                    <TableCell className="text-right">
                                        <DropdownMenu>
                                            <DropdownMenuTrigger asChild>
                                                <Button
                                                    variant="ghost"
                                                    size="icon"
                                                    className="h-8 w-8"
                                                >
                                                    <MoreHorizontal className="h-4 w-4" />
                                                    <span className="sr-only">Open menu</span>
                                                </Button>
                                            </DropdownMenuTrigger>
                                            <DropdownMenuContent align="end">
                                                <DropdownMenuItem onClick={() => setBorrowerToView(borrower)}>
                                                    <Eye className="mr-2 h-4 w-4" />
                                                    View Details
                                                </DropdownMenuItem>
                                                {borrower.status === 'pending' && (
                                                    <>
                                                        <DropdownMenuItem onClick={() => setBorrowerToApprove(borrower)}>
                                                            <CheckCircle className="mr-2 h-4 w-4" />
                                                            Approve
                                                        </DropdownMenuItem>
                                                        <DropdownMenuItem onClick={() => setBorrowerToReject(borrower)}>
                                                            <XCircle className="mr-2 h-4 w-4" />
                                                            Reject
                                                        </DropdownMenuItem>
                                                    </>
                                                )}
                                                <DropdownMenuItem
                                                    onClick={() => setBorrowerToDelete(borrower.id)}
                                                    className="text-red-600 focus:text-red-600"
                                                >
                                                    <Trash2 className="mr-2 h-4 w-4" />
                                                    Delete
                                                </DropdownMenuItem>
                                            </DropdownMenuContent>
                                        </DropdownMenu>

                                    </TableCell>
                                </TableRow>
                            ))
                        )}
                    </TableBody>
                </Table>
            </div>

            <BorrowerDeleteDialog
                open={!!borrowerToDelete}
                borrowerId={borrowerToDelete}
                onClose={() => setBorrowerToDelete(null)}
                onDelete={handleDelete}
            />

            <BorrowerApproveDialog
                open={!!borrowerToApprove}
                borrowerData={borrowerToApprove}
                onClose={() => setBorrowerToApprove(null)}
                onSuccess={() => {
                    refetch();
                    setBorrowerToApprove(null);
                }}
            />

            <BorrowerRejectDialog
                open={!!borrowerToReject}
                borrowerData={borrowerToReject}
                onClose={() => setBorrowerToReject(null)}
                onSuccess={() => {
                    refetch();
                    setBorrowerToReject(null);
                }}
            />

            {borrowerToView && (
                <BorrowerViewDialog
                    open={!!borrowerToView}
                    borrower={borrowerToView}
                    onClose={() => setBorrowerToView(null)}
                />
            )}
        </>
    );
};

export default React.memo(BorrowerTable); 