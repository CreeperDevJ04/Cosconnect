import React from 'react';
import { Button } from '@/components/ui/button';
import {
    ChevronLeft,
    ChevronRight,
    ChevronsLeft,
    ChevronsRight,
} from 'lucide-react';

interface BorrowerTablePaginationProps {
    pageCount: number;
    currentPage: number;
    onPageChange: (page: number) => void;
}

export const BorrowerTablePagination: React.FC<BorrowerTablePaginationProps> = React.memo(({
    pageCount,
    currentPage,
    onPageChange,
}) => {
    const pages = React.useMemo(() => {
        const pages = [];
        const maxVisiblePages = 5;
        let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
        let endPage = Math.min(pageCount, startPage + maxVisiblePages - 1);

        if (endPage - startPage + 1 < maxVisiblePages) {
            startPage = Math.max(1, endPage - maxVisiblePages + 1);
        }

        for (let i = startPage; i <= endPage; i++) {
            pages.push(i);
        }

        return pages;
    }, [currentPage, pageCount]);

    const handlePageChange = React.useCallback((page: number) => {
        if (page >= 1 && page <= pageCount) {
            onPageChange(page);
        }
    }, [onPageChange, pageCount]);

    if (pageCount <= 1) return null;

    return (
        <div className="flex items-center justify-end space-x-2">
            <Button
                variant="outline"
                size="icon"
                onClick={() => handlePageChange(1)}
                disabled={currentPage === 1}
                className="h-8 w-8"
            >
                <ChevronsLeft className="h-4 w-4" />
                <span className="sr-only">First page</span>
            </Button>
            <Button
                variant="outline"
                size="icon"
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
                className="h-8 w-8"
            >
                <ChevronLeft className="h-4 w-4" />
                <span className="sr-only">Previous page</span>
            </Button>
            {pages.map((page) => (
                <Button
                    key={page}
                    variant={currentPage === page ? "default" : "outline"}
                    size="icon"
                    onClick={() => handlePageChange(page)}
                    className="h-8 w-8"
                >
                    {page}
                </Button>
            ))}
            <Button
                variant="outline"
                size="icon"
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === pageCount}
                className="h-8 w-8"
            >
                <ChevronRight className="h-4 w-4" />
                <span className="sr-only">Next page</span>
            </Button>
            <Button
                variant="outline"
                size="icon"
                onClick={() => handlePageChange(pageCount)}
                disabled={currentPage === pageCount}
                className="h-8 w-8"
            >
                <ChevronsRight className="h-4 w-4" />
                <span className="sr-only">Last page</span>
            </Button>
        </div>
    );
});

BorrowerTablePagination.displayName = 'BorrowerTablePagination';

export default React.memo(BorrowerTablePagination); 