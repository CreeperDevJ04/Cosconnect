    // LenderListsSection.tsx
    'use client';

    import React from 'react';
    import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

    import { LenderSearchForm } from './UiComponents/LenderSearchBarForm';
    import { LenderStatusFilter } from './UiComponents/LenderStatusFilter';
    import { LenderTableSkeleton } from './UiComponents/LenderTableSkeleton';
    import { LenderTable } from './UiComponents/LenderTableList';
    import { PaginationTable } from './UiComponents/LenderTablePagination';
    import { LenderProfile } from '@/types/lenderType';

    const LenderListsSection = () => {
        const [page, setPage] = React.useState(1);
        const [limit, setLimit] = React.useState(10);
        const [search, setSearch] = React.useState('');
        const [status, setStatus] = React.useState<'pending' | 'approved' | 'rejected' | undefined>(undefined);
        const [cachedLenders, setCachedLenders] = React.useState<LenderProfile[]>([]);
        const [filteredLenders, setFilteredLenders] = React.useState<LenderProfile[]>([]);




        // Filter the data whenever search, status, or cached data changes
        React.useEffect(() => {
            let filtered = [...cachedLenders];

            // Apply search filter
            if (search) {
                const searchLower = search.toLowerCase();
                filtered = filtered.filter(lender =>
                    lender.fullName.toLowerCase().includes(searchLower) ||
                    lender.email.toLowerCase().includes(searchLower) ||
                    lender.businessInfo.businessName.toLowerCase().includes(searchLower)
                );
            }

            // Apply status filter
            if (status) {
                filtered = filtered.filter(lender => lender.status === status);
            }

            setFilteredLenders(filtered);
            setPage(1); // Reset to first page when filters change
        }, [search, status, cachedLenders]);

        // Calculate pagination
        const totalPages = Math.ceil(filteredLenders.length / limit);
        const startIndex = (page - 1) * limit;
        const endIndex = startIndex + limit;
        const paginatedLenders = filteredLenders.slice(startIndex, endIndex);

        const handlePageChange = (newPage: number) => {
            setPage(newPage);
        };

        const handleLimitChange = (newLimit: number) => {
            setLimit(newLimit);
            setPage(1);
        };

        const handleSearch = (searchTerm: string) => {
            setSearch(searchTerm);
        };

        const handleStatusFilter = (newStatus: 'pending' | 'approved' | 'rejected' | undefined) => {
            setStatus(newStatus);
        };

        const handleRefresh = () => {

        };

        return (
            <Card className="shadow-sm">
                <CardHeader>
                    <CardTitle className="text-xl font-semibold">Lender Management</CardTitle>
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mt-4">
                        <LenderSearchForm onSearch={handleSearch} />
                        <LenderStatusFilter status={status} onStatusChange={handleStatusFilter} />
                    </div>
                </CardHeader>
                <CardContent>

                </CardContent>
            </Card>
        );
    };

    export default LenderListsSection;