import React from 'react';
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface LenderRejectDialogProps {
    open: boolean;
    lenderData: any;
    onClose: () => void;
    onSuccess: () => void;
}

export const LenderRejectDialog: React.FC<LenderRejectDialogProps> = ({
    open,
    lenderData,
    onClose,
    onSuccess,
}) => {
    const handleReject = async () => {
        try {
            // TODO: Implement reject lender API call
            onSuccess();
        } catch (error) {
            // Error is handled by the API function
            onClose();
        }
    };

    return (
        <AlertDialog open={open} onOpenChange={onClose}>
            <AlertDialogContent>
                <AlertDialogHeader>
                    <AlertDialogTitle>Reject Lender</AlertDialogTitle>
                    <AlertDialogDescription>
                        Are you sure you want to reject this lender? They will not be able to access lending features.
                    </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction
                        onClick={handleReject}

                        className="bg-red-600 hover:bg-red-700"
                    >
                        Reject
                    </AlertDialogAction>
                </AlertDialogFooter>
            </AlertDialogContent>
        </AlertDialog>
    );
}; 