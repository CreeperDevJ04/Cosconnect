import React from 'react';
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface LenderApproveDialogProps {
    open: boolean;
    lenderData: any;
    onClose: () => void;
    onSuccess: () => void;
}

export const LenderApproveDialog: React.FC<LenderApproveDialogProps> = ({
    open,
    lenderData,
    onClose,
    onSuccess,
}) => {

    const handleApprove = async () => {
        try {
            // TODO: Implement approve lender API call
            onSuccess();
        } catch (error) {
            // Error is handled by the API function
            console.log("Error approving lender", error)
            onClose();
        }
    };

    return (
        <AlertDialog open={open} onOpenChange={onClose}>
            <AlertDialogContent>
                <AlertDialogHeader>
                    <AlertDialogTitle>Approve Lender</AlertDialogTitle>
                    <AlertDialogDescription>
                        Are you sure you want to approve this lender? They will gain access to lending features.
                    </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction
                        onClick={handleApprove}
                        className="bg-green-600 hover:bg-green-700"
                    >
                        Approve
                    </AlertDialogAction>
                </AlertDialogFooter>
            </AlertDialogContent>
        </AlertDialog>
    );
};