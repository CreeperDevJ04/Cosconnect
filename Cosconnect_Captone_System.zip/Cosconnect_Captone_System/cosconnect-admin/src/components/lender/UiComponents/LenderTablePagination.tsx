// Pagination.tsx
import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface PaginationProps {
    pageCount: number;
    currentPage: number;
    onPageChange: (page: number) => void;
    siblingCount?: number;
    className?: string;
}

export const PaginationTable: React.FC<PaginationProps> = ({
    pageCount,
    currentPage,
    onPageChange,
    siblingCount = 1,
    className,
}) => {
    const DOTS = '...';

    const range = (start: number, end: number) => {
        const length = end - start + 1;
        return Array.from({ length }, (_, idx) => idx + start);
    };

    const paginationRange = React.useMemo(() => {
        const totalPageNumbers = siblingCount * 2 + 3;
        const totalBlocks = totalPageNumbers + 2;

        if (pageCount <= totalPageNumbers) {
            return range(1, pageCount);
        }

        const leftSiblingIndex = Math.max(currentPage - siblingCount, 1);
        const rightSiblingIndex = Math.min(currentPage + siblingCount, pageCount);

        const shouldShowLeftDots = leftSiblingIndex > 2;
        const shouldShowRightDots = rightSiblingIndex < pageCount - 1;

        if (!shouldShowLeftDots && shouldShowRightDots) {
            const leftRange = range(1, totalPageNumbers);
            return [...leftRange, DOTS, pageCount];
        }

        if (shouldShowLeftDots && !shouldShowRightDots) {
            const rightRange = range(pageCount - totalPageNumbers + 1, pageCount);
            return [1, DOTS, ...rightRange];
        }

        if (shouldShowLeftDots && shouldShowRightDots) {
            const middleRange = range(leftSiblingIndex, rightSiblingIndex);
            return [1, DOTS, ...middleRange, DOTS, pageCount];
        }

        return [];
    }, [pageCount, currentPage, siblingCount]);

    if (pageCount <= 1) return null;

    return (
        <nav
            aria-label="Pagination"
            className={cn("flex items-center space-x-1", className)}
        >
            <Button
                variant="outline"
                size="icon"
                onClick={() => onPageChange(Math.max(1, currentPage - 1))}
                disabled={currentPage === 1}
                className="h-8 w-8"
                aria-label="Previous page"
            >
                <ChevronLeft className="h-4 w-4" />
            </Button>

            {paginationRange.map((pageNumber, index) => {
                if (pageNumber === DOTS) {
                    return (
                        <span
                            key={`dots-${index}`}
                            className="px-2 py-1 text-muted-foreground"
                        >
                            {DOTS}
                        </span>
                    );
                }

                return (
                    <Button
                        key={`page-${pageNumber}`}
                        variant={currentPage === pageNumber ? "default" : "outline"}
                        onClick={() => onPageChange(Number(pageNumber))}
                        className="h-8 w-8"
                        aria-current={currentPage === pageNumber ? "page" : undefined}
                        aria-label={`Page ${pageNumber}`}
                    >
                        {pageNumber}
                    </Button>
                );
            })}

            <Button
                variant="outline"
                size="icon"
                onClick={() => onPageChange(Math.min(pageCount, currentPage + 1))}
                disabled={currentPage === pageCount}
                className="h-8 w-8"
                aria-label="Next page"
            >
                <ChevronRight className="h-4 w-4" />
            </Button>
        </nav>
    );
};