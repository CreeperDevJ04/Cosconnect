// LenderTable.tsx
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import { LenderProfile } from '@/types/lenderType';
import { format } from 'date-fns';
import { CheckCircle, Eye, MoreHorizontal, Trash2, XCircle } from "lucide-react";
import React from 'react';

import { LenderDeleteDialog } from './LenderDeleteDialog';
import { LenderApproveDialog } from './LenderApproveDialog';
import { LenderViewDialog } from './LenderDialogView';
import { LenderRejectDialog } from './LenderRejectDialog';

interface LenderTableProps {
    lenders: LenderProfile[];
    refetch: () => void;
}

export const LenderTable: React.FC<LenderTableProps> = ({ lenders, refetch }) => {
    const [lenderToDelete, setLenderToDelete] = React.useState<string | null>(null);
    const [lenderToApprove, setLenderToApprove] = React.useState<LenderProfile | null>(null);
    const [lenderToReject, setLenderToReject] = React.useState<LenderProfile | null>(null);
    const [lenderToView, setLenderToView] = React.useState<LenderProfile | null>(null);

    const getStatusBadge = (status: string) => {
        switch (status) {
            case 'approved':
                return <Badge className="bg-green-100 text-green-800 hover:bg-green-200">Approved</Badge>;
            case 'rejected':
                return <Badge className="bg-red-100 text-red-800 hover:bg-red-200">Rejected</Badge>;
            case 'pending':
                return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200">Pending</Badge>;
            default:
                return <Badge variant="outline">{status}</Badge>;
        }
    };

    const handleDelete = async (reason: string) => {
        if (!lenderToDelete) return;

        try {

            setLenderToDelete(null);
        } catch (error) {
            // Error is handled by the API function
        }
    };

    return (
        <>
            <div className="rounded-md border">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Full Name</TableHead>
                            <TableHead>Business Name</TableHead>
                            <TableHead>Email</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Created At</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {lenders.length === 0 ? (
                            <TableRow>
                                <TableCell colSpan={6} className="h-24 text-center">
                                    No lenders found.
                                </TableCell>
                            </TableRow>
                        ) : (
                            lenders.map((lender) => (
                                <TableRow key={lender.id}>
                                    <TableCell>{lender.fullName}</TableCell>
                                    <TableCell>{lender.businessInfo.businessName}</TableCell>
                                    <TableCell>{lender.email}</TableCell>
                                    <TableCell>{getStatusBadge(lender.status)}</TableCell>
                                    <TableCell>{format(new Date(lender.createdAt), 'MMM dd, yyyy')}</TableCell>
                                    <TableCell className="text-right">
                                        <DropdownMenu>
                                            <DropdownMenuTrigger asChild>
                                                <Button
                                                    variant="ghost"
                                                    size="icon"
                                                    className="h-8 w-8"
                                                >
                                                    <MoreHorizontal className="h-4 w-4" />
                                                    <span className="sr-only">Open menu</span>
                                                </Button>
                                            </DropdownMenuTrigger>
                                            <DropdownMenuContent align="end">
                                                <DropdownMenuItem onClick={() => setLenderToView(lender)}>
                                                    <Eye className="mr-2 h-4 w-4" />
                                                    View Details
                                                </DropdownMenuItem>
                                                {lender.status === 'pending' && (
                                                    <>
                                                        <DropdownMenuItem onClick={() => setLenderToApprove(lender)}>
                                                            <CheckCircle className="mr-2 h-4 w-4" />
                                                            Approve
                                                        </DropdownMenuItem>
                                                        <DropdownMenuItem onClick={() => setLenderToReject(lender)}>
                                                            <XCircle className="mr-2 h-4 w-4" />
                                                            Reject
                                                        </DropdownMenuItem>
                                                    </>
                                                )}
                                                <DropdownMenuItem
                                                    onClick={() => setLenderToDelete(lender.id)}
                                                    className="text-red-600 focus:text-red-600"
                                                >
                                                    <Trash2 className="mr-2 h-4 w-4" />
                                                    Delete
                                                </DropdownMenuItem>
                                            </DropdownMenuContent>
                                        </DropdownMenu>
                                    </TableCell>
                                </TableRow>
                            ))
                        )}
                    </TableBody>
                </Table>
            </div>

            <LenderDeleteDialog
                open={!!lenderToDelete}
                lenderId={lenderToDelete}
                onClose={() => setLenderToDelete(null)}
                onDelete={handleDelete}
            />

            <LenderApproveDialog
                open={!!lenderToApprove}
                lenderData={lenderToApprove}
                onClose={() => setLenderToApprove(null)}
                onSuccess={() => {
                    refetch();
                    setLenderToApprove(null);
                }}
            />

            <LenderRejectDialog
                open={!!lenderToReject}
                lenderData={lenderToReject}
                onClose={() => setLenderToReject(null)}
                onSuccess={() => {
                    refetch();
                    setLenderToReject(null);
                }}
            />

            {lenderToView && (
                <LenderViewDialog
                    open={!!lenderToView}
                    lender={lenderToView}
                    onClose={() => setLenderToView(null)}
                />
            )}
        </>
    );
};