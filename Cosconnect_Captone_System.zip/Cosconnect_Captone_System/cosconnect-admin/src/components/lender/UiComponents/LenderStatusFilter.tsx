// LenderStatusFilter.tsx
import React from 'react';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";

interface LenderStatusFilterProps {
    status: 'pending' | 'approved' | 'rejected' | undefined;
    onStatusChange: (status: 'pending' | 'approved' | 'rejected' | undefined) => void;
}

export const LenderStatusFilter: React.FC<LenderStatusFilterProps> = ({
    status,
    onStatusChange
}) => {
    const handleChange = (value: string) => {
        if (value === 'all') {
            onStatusChange(undefined);
        } else {
            onStatusChange(value as 'pending' | 'approved' | 'rejected');
        }
    };

    return (
        <div className="flex items-center space-x-2">
            <span className="text-sm font-medium">Status:</span>
            <Select value={status || 'all'} onValueChange={handleChange}>
                <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                </SelectContent>
            </Select>
        </div>
    );
};