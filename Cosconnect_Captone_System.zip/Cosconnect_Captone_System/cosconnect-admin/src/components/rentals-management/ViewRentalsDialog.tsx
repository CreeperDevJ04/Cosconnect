"use client"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
    DollarSign,
    Calendar,
    MapPin,
    User,
    ShoppingCart,
    Shield,
    Send,
    Loader2,
    CheckCircle,
    XCircle,
    Clock,
    CreditCard,
    Banknote,
    AlertTriangle,
} from "lucide-react"
import type React from "react"
import { useState, useEffect } from "react"
import type { RentalDetails } from "@/types/rentals/getRentalsFinished"
import { z } from "zod"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { toast } from "sonner"
import { useTransferMoneyBorrower, useTransferMoneyLender } from "@/lib/apis/rentalsApi"
import DataRow from "../common/DataRow"
import SectionWrapper from "../common/SectionWrapper"
import { useQueryClient } from "@tanstack/react-query"

// Zod schemas
const refundFormSchema = z.object({
    amount: z
        .string()
        .min(1, "Amount is required")
        .refine((val) => !isNaN(Number(val)) && Number(val) > 0, "Amount must be a positive number"),
    gcashNumber: z
        .string()
        .min(10, "GCash number must be 10 digits")
        .max(10, "GCash number must be 10 digits")
        .regex(/^9\d{9}$/, "GCash number must start with 9 and be 10 digits"),
    accountName: z.string().min(2, "Account name must be at least 2 characters"),
    notes: z.string().optional(),
})

const payoutFormSchema = z.object({
    amount: z
        .string()
        .min(1, "Amount is required")
        .refine((val) => !isNaN(Number(val)) && Number(val) > 0, "Amount must be a positive number"),
    gcashNumber: z
        .string()
        .min(10, "GCash number must be 10 digits")
        .max(10, "GCash number must be 10 digits")
        .regex(/^9\d{9}$/, "GCash number must start with 9 and be 10 digits"),
    accountName: z.string().min(2, "Account name must be at least 2 characters"),
    notes: z.string().optional(),
})

type RefundFormValues = z.infer<typeof refundFormSchema>
type PayoutFormValues = z.infer<typeof payoutFormSchema>

interface RentalDetailsDialogProps {
    open: boolean
    onOpenChange: (open: boolean) => void
    rental: RentalDetails | null
}

const SuccessOverlay: React.FC<{ message: string }> = ({ message }) => (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 rounded-lg">
        <div className="bg-white rounded-lg p-8 flex flex-col items-center gap-4 shadow-lg">
            <div className="relative w-16 h-16">
                <div className="absolute inset-0 bg-green-100 rounded-full animate-pulse" />
                <CheckCircle className="w-16 h-16 text-green-600 relative z-10" />
            </div>
            <div className="text-center">
                <p className="text-lg font-semibold text-gray-800">{message}</p>
                <p className="text-sm text-gray-500 mt-2">Please wait...</p>
            </div>
            <div className="flex gap-1">
                <div className="w-2 h-2 bg-green-600 rounded-full animate-bounce" style={{ animationDelay: "0s" }} />
                <div className="w-2 h-2 bg-green-600 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }} />
                <div className="w-2 h-2 bg-green-600 rounded-full animate-bounce" style={{ animationDelay: "0.4s" }} />
            </div>
        </div>
    </div>
)

export const RentalDetailsDialog: React.FC<RentalDetailsDialogProps> = ({ open, onOpenChange, rental }) => {
    const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
        timeline: false,
        borrowerPayments: false,
        lenderEarnings: false,
        damageReport: false,
        paymentsHistory: false,
    })
    const [successOverlay, setSuccessOverlay] = useState<{ show: boolean; message: string }>({
        show: false,
        message: "",
    })

    const queryClient = useQueryClient()
    const { mutate: transferMoneyBorrower, isPending: isRefundPending } = useTransferMoneyBorrower()
    const { mutate: transferMoneyLender, isPending: isPayoutPending } = useTransferMoneyLender()

    const refundForm = useForm<RefundFormValues>({
        resolver: zodResolver(refundFormSchema),
        defaultValues: {
            amount: "",
            gcashNumber: "",
            accountName: "",
            notes: "",
        },
    })

    const payoutForm = useForm<PayoutFormValues>({
        resolver: zodResolver(payoutFormSchema),
        defaultValues: {
            amount: "",
            gcashNumber: "",
            accountName: "",
            notes: "",
        },
    })

    useEffect(() => {
        if (rental) {
            const breakdown = calculateTransactionBreakdown()

            // Set borrower refund form values
            refundForm.setValue("amount", breakdown.borrowerRefund)
            refundForm.setValue("accountName", rental.payment_details?.refund_account_name || rental.borrower?.name || "")
            const refundGcash = rental.payment_details?.refund_gcash_number?.replace("+63", "") || ""
            if (refundGcash) {
                refundForm.setValue("gcashNumber", refundGcash)
            }

            // Set lender payout form values
            payoutForm.setValue("amount", breakdown.netLenderPayout)
            payoutForm.setValue("accountName", rental.lender?.name || "")
            const payoutGcash = rental.payment_details?.gcash_number?.replace("+63", "") || ""
            if (payoutGcash) {
                payoutForm.setValue("gcashNumber", payoutGcash)
            }
        }
    }, [rental, refundForm, payoutForm])

    useEffect(() => {
        if (successOverlay.show) {
            const timer = setTimeout(() => {
                console.log("[v0] Success overlay timeout - hiding overlay")
                setSuccessOverlay({ show: false, message: "" })
            }, 3000)
            return () => clearTimeout(timer)
        }
    }, [successOverlay.show])

    const toggleSection = (section: string) => {
        setExpandedSections((prev) => ({
            ...prev,
            [section]: !prev[section],
        }))
    }

    if (!rental) return null

    const formatCurrency = (value: string | number | undefined | null): string => {
        if (value === null || value === undefined) return "0.00"
        const numValue = typeof value === "string" ? Number.parseFloat(value) : value
        return isNaN(numValue) ? "0.00" : numValue.toFixed(2)
    }

    const formatDate = (date: string | null | undefined): string => {
        if (!date) return "N/A"
        try {
            return new Date(date).toLocaleString()
        } catch {
            return "Invalid Date"
        }
    }

    const calculateBorrowerRefund = (): string => {
        const securityDeposit = Number.parseFloat(rental?.amounts?.security_deposit || "0")
        const damageCost = Number.parseFloat(rental?.damage?.cost || "0")
        return Math.max(0, securityDeposit - damageCost).toFixed(2)
    }

    const calculateLenderEarnings = (): string => {
        const rentalFee = Number.parseFloat(rental?.lender?.earnings?.rental_fee || "0")
        const extensionFee = Number.parseFloat(rental?.lender?.earnings?.extension_fee || "0")
        const damageCharges = Number.parseFloat(rental?.lender?.earnings?.damage_charges || "0")
        return (rentalFee + extensionFee + damageCharges).toFixed(2)
    }

    const calculateTransactionBreakdown = () => {
        const totalAmount = Number.parseFloat(rental?.amounts?.rental_amount || "0")
        const grossLenderEarnings = Number.parseFloat(rental?.lender?.earnings?.gross_earnings || "0")
        const securityDeposit = Number.parseFloat(rental?.amounts?.security_deposit || "0")
        const damageCost = Number.parseFloat(rental?.damage?.cost || "0")

        // Processing fee: 3% of Gross Lender Earnings (deducted from borrower)
        const processingFeeRate = 0.03 // 3% processing fee
        const processingFee = Number.parseFloat((grossLenderEarnings * processingFeeRate).toFixed(2))

        // Borrower total paid: Gross Lender Earnings + Processing Fee
        const borrowerTotalPaid = grossLenderEarnings + processingFee

        // Commission fee: 5% of Total Transaction Amount (from total)
        const commissionRate = 0.05 // 5% commission
        const commissionFee = Number.parseFloat((grossLenderEarnings * commissionRate).toFixed(2))

        // Net lender payout after commission deduction
        const netLenderPayout = grossLenderEarnings - commissionFee

        // Borrower refund calculation (security deposit - damage cost)
        const borrowerRefund = Math.max(0, securityDeposit - damageCost)

        return {
            totalAmount: totalAmount.toFixed(2),
            borrowerTotalPaid: borrowerTotalPaid.toFixed(2),
            processingFee: processingFee.toFixed(2),
            commissionFee: commissionFee.toFixed(2),
            grossLenderEarnings: grossLenderEarnings.toFixed(2),
            netLenderPayout: Math.max(0, netLenderPayout).toFixed(2),
            borrowerRefund: borrowerRefund.toFixed(2),
            totalPlatformFees: (processingFee + commissionFee).toFixed(2),
        }
    }

    const getStatusColor = (status: string | undefined): string => {
        if (!status) return "bg-gray-100 text-gray-800"
        switch (status.toLowerCase()) {
            case "completed":
            case "success":
            case "processed":
                return "bg-green-100 text-green-800"
            case "pending":
                return "bg-yellow-100 text-yellow-800"
            case "failed":
            case "error":
                return "bg-red-100 text-red-800"
            default:
                return "bg-blue-100 text-blue-800"
        }
    }

    const getTransactionIcon = (processed: boolean | undefined): React.ReactNode => {
        if (processed === undefined) return <Clock className="w-4 h-4" />
        return processed ? <CheckCircle className="w-4 h-4" /> : <XCircle className="w-4 h-4" />
    }

    const onRefundSubmit = async (data: RefundFormValues) => {
        if (!rental) return

        // Ensure we have a borrower ID before calling the API
        if (!rental.borrower?.uid) {
            toast.error("Missing borrower ID for this rental. Cannot process refund.");
            return;
        }

        try {
            const preparedData = {
                rentalId: rental.id,
                borrowerId: rental.borrower.uid,  // no fallback ""
                amount: Number.parseFloat(data.amount),
                gcashNumber: `+63${data.gcashNumber}`,
                accountName: data.accountName.trim(),
                notes: data.notes?.trim() || "",
                type: "refund" as const,
            }

            await transferMoneyBorrower(preparedData as any, {
                onSuccess: (response) => {
                    refundForm.reset()
                    setSuccessOverlay({ show: true, message: "Sending refund..." })

                    // Invalidate and refetch rental data
                    queryClient.invalidateQueries({ queryKey: ["rental", rental.id] })
                    queryClient.invalidateQueries({ queryKey: ["all-rentals-if-finished"] })
                },
                onError: () => {
                    toast.error("Failed to process refund.")
                },
            })
        } catch {
            toast.error("Unexpected error while processing refund.")

        }
    }

    const onPayoutSubmit = async (data: PayoutFormValues) => {
        if (!rental) return

        // Ensure we have a lender ID before calling the API
        if (!rental.lender?.uid) {
            toast.error("Missing lender ID for this rental. Cannot process payout.")
            return
        }

        try {
            const preparedData = {
                rentalId: rental.id,
                lenderId: rental.lender.uid,
                amount: Number.parseFloat(data.amount),
                gcashNumber: `+63${data.gcashNumber}`,
                accountName: data.accountName.trim(),
                notes: data.notes?.trim() || "",
                type: "payout" as const,
            }

            await transferMoneyLender(preparedData as any, {
                onSuccess: (response) => {
                    payoutForm.reset()
                    setSuccessOverlay({ show: true, message: "Sending payout..." })

                    // Invalidate and refetch rental data
                    queryClient.invalidateQueries({ queryKey: ["rental", rental.id] })
                    queryClient.invalidateQueries({ queryKey: ["all-rentals-if-finished"] })
                },
                onError: () => {
                    toast.error("Failed to process payout.")
                },
            })
        } catch {
            toast.error("Unexpected error while processing payout.")
        }
    }

    const breakdown = calculateTransactionBreakdown()

    return (
        <>
            {successOverlay.show && <SuccessOverlay message={successOverlay.message} />}

            <Dialog open={open} onOpenChange={onOpenChange}>
                <DialogContent className="max-h-[90vh] overflow-y-auto w-full sm:max-w-[95vw] max-w-[1200px] p-6">
                    <DialogHeader className="border-b pb-4">
                        <div className="flex items-center justify-between">
                            <DialogTitle className="text-2xl font-bold flex items-center gap-3">
                                <ShoppingCart className="w-6 h-6" />
                                Rental #{rental.reference_code || "N/A"}
                            </DialogTitle>
                            <div className="flex items-center gap-2">
                                <Badge className={getStatusColor(rental.status)}>{rental.status || "Unknown"}</Badge>
                                <Badge variant="outline">ID: {rental.id?.slice(-8) || "N/A"}</Badge>
                            </div>
                        </div>
                    </DialogHeader>

                    <Tabs defaultValue="overview" className="w-full">
                        <TabsList className="grid w-full grid-cols-4">
                            <TabsTrigger value="overview">Overview</TabsTrigger>
                            <TabsTrigger value="transactions">Transactions</TabsTrigger>
                            <TabsTrigger value="payments">Payment Forms</TabsTrigger>
                            <TabsTrigger value="details">Full Details</TabsTrigger>
                        </TabsList>

                        <TabsContent value="overview" className="space-y-6">
                            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                                {/* Quick Status Cards */}
                                <Card>
                                    <CardHeader className="pb-3">
                                        <CardTitle className="text-sm font-medium text-muted-foreground">Completion Status</CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-2">
                                        <div className="flex items-center justify-between">
                                            <span className="text-sm">Fully Completed</span>
                                            <Badge
                                                className={
                                                    rental.completion_status?.is_fully_completed
                                                        ? "bg-green-100 text-green-800"
                                                        : "bg-red-100 text-red-800"
                                                }
                                            >
                                                {rental.completion_status?.is_fully_completed ? "Yes" : "No"}
                                            </Badge>
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <span className="text-sm">Payout Done</span>
                                            <Badge
                                                className={
                                                    rental.completion_status?.payout_completed
                                                        ? "bg-green-100 text-green-800"
                                                        : "bg-orange-100 text-orange-800"
                                                }
                                            >
                                                {rental.completion_status?.payout_completed ? "Yes" : "Pending"}
                                            </Badge>
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <span className="text-sm">Refund Done</span>
                                            <Badge className={getStatusColor(rental.borrower?.payments?.refund_details?.status)}>
                                                {rental.borrower?.payments?.refund_details?.status ? "Yes" : "Pending"}
                                            </Badge>
                                        </div>
                                    </CardContent>
                                </Card>

                                {/* Financial Summary */}
                                <Card>
                                    <CardHeader className="pb-3">
                                        <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                                            <DollarSign className="w-4 h-4" />
                                            Financial Summary
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-2">
                                        <div className="flex items-center justify-between">
                                            <span className="text-sm">Total Rental</span>
                                            <span className="font-semibold">₱{formatCurrency(rental.amounts?.total_amount)}</span>
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <span className="text-sm">Security Deposit</span>
                                            <span className="font-semibold">₱{formatCurrency(rental.amounts?.security_deposit)}</span>
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <span className="text-sm">Damage Cost</span>
                                            <span className="font-semibold text-red-600">₱{formatCurrency(rental.damage?.cost)}</span>
                                        </div>
                                        <div className="border-t pt-2">
                                            <div className="flex items-center justify-between">
                                                <span className="text-sm font-medium">Net Refund Due</span>
                                                <span className="font-bold text-green-600">₱{calculateBorrowerRefund()}</span>
                                            </div>
                                            <div className="flex items-center justify-between">
                                                <span className="text-sm font-medium">Lender Payout Due</span>
                                                <span className="font-bold text-blue-600">₱{calculateLenderEarnings()}</span>
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>

                                {/* Timeline */}
                                <Card>
                                    <CardHeader className="pb-3">
                                        <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                                            <Calendar className="w-4 h-4" />
                                            Timeline
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-2">
                                        <div className="flex items-center justify-between">
                                            <span className="text-sm">Created</span>
                                            <span className="text-xs">{formatDate(rental.timeline?.created)}</span>
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <span className="text-sm">Accepted</span>
                                            <span className="text-xs">{formatDate(rental.timeline?.accepted)}</span>
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <span className="text-sm">Delivered</span>
                                            <span className="text-xs">{formatDate(rental.timeline?.delivered)}</span>
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <span className="text-sm">Returned</span>
                                            <span className="text-xs">{formatDate(rental.timeline?.returned)}</span>
                                        </div>
                                    </CardContent>
                                </Card>
                            </div>

                            {/* Participants */}
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                {/* Borrower Info */}
                                <Card>
                                    <CardHeader>
                                        <CardTitle className="flex items-center gap-2">
                                            <User className="w-5 h-5" />
                                            Borrower Details
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-3">
                                        <DataRow label="Name">{rental.borrower?.name || "N/A"}</DataRow>
                                        <DataRow label="Email">{rental.borrower?.email || "N/A"}</DataRow>
                                        <DataRow label="Phone">{rental.borrower?.phone || "N/A"}</DataRow>
                                        <DataRow label="Address">{rental.borrower?.address || "N/A"}</DataRow>
                                    </CardContent>
                                </Card>

                                {/* Lender Info */}
                                <Card>
                                    <CardHeader>
                                        <CardTitle className="flex items-center gap-2">
                                            <ShoppingCart className="w-5 h-5" />
                                            Lender Details
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-3">
                                        <DataRow label="Name">{rental.lender?.name || "N/A"}</DataRow>
                                        <DataRow label="Email">{rental.lender?.email || "N/A"}</DataRow>
                                        <DataRow label="Business Phone Number">{rental.lender?.phone_number || "N/A"}</DataRow>
                                    </CardContent>
                                </Card>
                            </div>

                            {/* Costume Details */}
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <ShoppingCart className="w-5 h-5" />
                                        Costume Information
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                        <div className="space-y-3">
                                            <DataRow label="Name">{rental.costume?.name || "N/A"}</DataRow>
                                            <DataRow label="Brand">{rental.costume?.brand || "N/A"}</DataRow>
                                            <DataRow label="Category">{rental.costume?.category || "N/A"}</DataRow>
                                            <DataRow label="Sizes">{rental.costume?.sizes || "N/A"}</DataRow>
                                        </div>
                                        <div className="space-y-3">
                                            <div>
                                                <span className="text-sm text-muted-foreground">Images:</span>
                                                <div className="flex gap-2 mt-2">
                                                    {rental.costume?.images?.front && (
                                                        <img
                                                            src={rental.costume.images.front || "/placeholder.svg"}
                                                            alt="Front"
                                                            className="w-20 h-20 object-cover border rounded"
                                                        />
                                                    )}
                                                    {rental.costume?.images?.back && (
                                                        <img
                                                            src={rental.costume.images.back || "/placeholder.svg"}
                                                            alt="Back"
                                                            className="w-20 h-20 object-cover border rounded"
                                                        />
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        </TabsContent>

                        <TabsContent value="transactions" className="space-y-6">
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                {/* Refund Status */}
                                <Card>
                                    <CardHeader>
                                        <CardTitle className="flex items-center gap-2">
                                            <Banknote className="w-5 h-5 text-blue-600" />
                                            Borrower Refund Status
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-4">
                                        <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                                            <div className="flex items-center gap-3">
                                                {getTransactionIcon(rental.borrower?.payments?.refund_details?.processed)}
                                                <div>
                                                    <p className="font-semibold">Refund Transaction</p>
                                                    <p className="text-sm text-muted-foreground">
                                                        Amount: ₱{formatCurrency(rental.borrower?.payments?.refund_details?.amount)}
                                                    </p>
                                                </div>
                                            </div>
                                            <Badge className={getStatusColor(rental.borrower?.payments?.refund_details?.status)}>
                                                {rental.borrower?.payments?.refund_details?.status || "Unknown"}
                                            </Badge>
                                        </div>

                                        {rental.borrower?.payments?.refund_details && (
                                            <div className="space-y-2 text-sm">
                                                <DataRow label="Processed">
                                                    {rental.borrower.payments.refund_details.processed ? "Yes" : "No"}
                                                </DataRow>
                                                <DataRow label="Account Name">
                                                    {rental.borrower.payments.refund_details.account_name || "N/A"}
                                                </DataRow>
                                                <DataRow label="GCash Number">
                                                    {rental.borrower.payments.refund_details.gcash_number || "N/A"}
                                                </DataRow>
                                                <DataRow label="Transaction Type">
                                                    {rental.borrower.payments.refund_details.transaction_type || "N/A"}
                                                </DataRow>
                                                <DataRow label="Processed At">
                                                    {formatDate(rental.borrower.payments.refund_details.processed_at)}
                                                </DataRow>
                                                <DataRow label="Completed At">
                                                    {formatDate(rental.borrower.payments.refund_details.completed_timestamp)}
                                                </DataRow>
                                                {rental.borrower.payments.refund_details.notes && (
                                                    <DataRow label="Notes">{rental.borrower.payments.refund_details.notes}</DataRow>
                                                )}
                                            </div>
                                        )}
                                    </CardContent>
                                </Card>

                                {/* Payout Status */}
                                <Card>
                                    <CardHeader>
                                        <CardTitle className="flex items-center gap-2">
                                            <CreditCard className="w-5 h-5 text-green-600" />
                                            Lender Payout Status
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-4">
                                        <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                                            <div className="flex items-center gap-3">
                                                {getTransactionIcon(rental.lender?.earnings?.payout_details?.processed)}
                                                <div>
                                                    <p className="font-semibold">Payout Transaction</p>
                                                    <p className="text-sm text-muted-foreground">
                                                        Amount: ₱{formatCurrency(rental.lender?.earnings?.payout_details?.amount)}
                                                    </p>
                                                </div>
                                            </div>
                                            <Badge className={getStatusColor(rental.lender?.earnings?.payout_details?.status)}>
                                                {rental.lender?.earnings?.payout_details?.status || "Unknown"}
                                            </Badge>
                                        </div>

                                        {rental.lender?.earnings?.payout_details && (
                                            <div className="space-y-2 text-sm">
                                                <DataRow label="Processed">
                                                    {rental.lender.earnings.payout_details.processed ? "Yes" : "No"}
                                                </DataRow>
                                                <DataRow label="Account Name">
                                                    {rental.lender.earnings.payout_details.account_name || "N/A"}
                                                </DataRow>
                                                <DataRow label="GCash Number">
                                                    {rental.lender.earnings.payout_details.gcash_number || "N/A"}
                                                </DataRow>
                                                <DataRow label="Transaction Type">
                                                    {rental.lender.earnings.payout_details.transaction_type || "N/A"}
                                                </DataRow>
                                                <DataRow label="Processed At">
                                                    {formatDate(rental.lender.earnings.payout_details.processed_at)}
                                                </DataRow>
                                                <DataRow label="Completed At">
                                                    {formatDate(rental.lender.earnings.payout_details.completed_timestamp)}
                                                </DataRow>
                                                {rental.lender.earnings.payout_details.notes && (
                                                    <DataRow label="Notes">{rental.lender.earnings.payout_details.notes}</DataRow>
                                                )}
                                            </div>
                                        )}
                                    </CardContent>
                                </Card>
                            </div>

                            {/* Transaction Breakdown Summary */}
                            <Card className="border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-white">
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2 text-lg">
                                        <DollarSign className="w-5 h-5 text-blue-600" />
                                        Transaction Breakdown Summary
                                    </CardTitle>
                                    <p className="text-sm text-muted-foreground mt-1">
                                        Complete financial breakdown showing amounts to be processed for borrower and lender
                                    </p>
                                </CardHeader>
                                <CardContent>
                                    {(() => {
                                        const breakdown = calculateTransactionBreakdown()
                                        return (
                                            <div className="space-y-6">
                                                {/* Transaction Overview */}
                                                <div className="bg-green-50 p-5 rounded-lg border border-green-200">
                                                    <h4 className="font-semibold mb-4 text-green-800 flex items-center gap-2">
                                                        <DollarSign className="w-5 h-5" />
                                                        Transaction Overview
                                                    </h4>
                                                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                                        <div className="flex items-center justify-between">
                                                            <span className="font-medium text-sm">Total Transaction:</span>
                                                            <span className="font-bold text-lg text-green-700">₱{breakdown.totalAmount}</span>
                                                        </div>
                                                        <div className="flex items-center justify-between">
                                                            <span className="font-medium text-sm">Borrower Total Paid:</span>
                                                            <span className="font-bold text-lg text-purple-700">₱{breakdown.borrowerTotalPaid}</span>
                                                        </div>
                                                        <div className="flex items-center justify-between">
                                                            <span className="font-medium text-sm">Lender Gross Earnings:</span>
                                                            <span className="font-bold text-lg text-blue-700">₱{breakdown.grossLenderEarnings}</span>
                                                        </div>
                                                    </div>
                                                </div>

                                                {/* Platform Fees Section */}
                                                <div className="bg-amber-50 p-5 rounded-lg border border-amber-200">
                                                    <h4 className="font-semibold mb-4 text-amber-800 flex items-center gap-2">
                                                        <AlertTriangle className="w-5 h-5" />
                                                        Platform Fees Breakdown
                                                    </h4>
                                                    <div className="space-y-3">
                                                        <div className="flex items-center justify-between py-2 border-b border-amber-300">
                                                            <div>
                                                                <span className="font-medium">Processing Fee (3%):</span>
                                                                <span className="text-xs text-muted-foreground ml-2">3% of Total Paid (₱{breakdown.borrowerTotalPaid})</span>
                                                            </div>
                                                            <span className="font-bold text-amber-700">₱{breakdown.processingFee}</span>
                                                        </div>
                                                        <div className="flex items-center justify-between py-2 border-b border-amber-300">
                                                            <div>
                                                                <span className="font-medium">Commission Fee (5%):</span>
                                                                <span className="text-xs text-muted-foreground ml-2">5% of Total Transaction (₱{breakdown.totalAmount})</span>
                                                            </div>
                                                            <span className="font-bold text-orange-600">₱{breakdown.commissionFee}</span>
                                                        </div>
                                                        <div className="flex items-center justify-between pt-2 mt-2 border-t-2 border-amber-400">
                                                            <span className="font-bold text-lg">Total Platform Fees:</span>
                                                            <span className="font-bold text-lg text-red-600">₱{breakdown.totalPlatformFees}</span>
                                                        </div>
                                                    </div>
                                                </div>

                                                {/* Payout Breakdown Section */}
                                                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                                    {/* Lender Payout */}
                                                    <Card className="bg-blue-50 border-blue-200">
                                                        <CardHeader className="pb-3">
                                                            <CardTitle className="text-base font-semibold text-blue-800 flex items-center gap-2">
                                                                <CreditCard className="w-5 h-5" />
                                                                Lender Payout Breakdown
                                                            </CardTitle>
                                                        </CardHeader>
                                                        <CardContent>
                                                            <div className="space-y-3">
                                                                <div className="flex items-center justify-between py-2">
                                                                    <span className="text-sm font-medium">Gross Earnings:</span>
                                                                    <span className="font-semibold">₱{breakdown.grossLenderEarnings}</span>
                                                                </div>
                                                                <div className="flex items-center justify-between py-1 text-xs text-muted-foreground">
                                                                    <span className="ml-4">- Commission Fee (5% of Total Transaction):</span>
                                                                    <span className="text-red-500">-₱{breakdown.commissionFee}</span>
                                                                </div>
                                                                <div className="border-t-2 border-blue-300 pt-3 mt-3">
                                                                    <div className="flex items-center justify-between">
                                                                        <span className="font-bold text-blue-800">Net Payout to Lender:</span>
                                                                        <span className="font-bold text-xl text-blue-700">₱{breakdown.netLenderPayout}</span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </CardContent>
                                                    </Card>

                                                    {/* Borrower Refund */}
                                                    <Card className="bg-purple-50 border-purple-200">
                                                        <CardHeader className="pb-3">
                                                            <CardTitle className="text-base font-semibold text-purple-800 flex items-center gap-2">
                                                                <Banknote className="w-5 h-5" />
                                                                Borrower Payment Breakdown
                                                            </CardTitle>
                                                        </CardHeader>
                                                        <CardContent>
                                                            <div className="space-y-3">
                                                                <div className="flex items-center justify-between py-2">
                                                                    <span className="text-sm font-medium">Total Paid:</span>
                                                                    <span className="font-semibold">₱{breakdown.borrowerTotalPaid}</span>
                                                                </div>
                                                                <div className="flex items-center justify-between py-1 text-xs text-muted-foreground">
                                                                    <span className="ml-4">- Processing Fee (3% of Total Paid):</span>
                                                                    <span className="text-red-500">-₱{breakdown.processingFee}</span>
                                                                </div>
                                                                <div className="border-t-2 border-purple-300 pt-3 mt-3 mb-4">
                                                                    <div className="flex items-center justify-between">
                                                                        <span className="font-bold text-purple-800">Net Amount Paid:</span>
                                                                        <span className="font-bold text-xl text-purple-700">₱{(Number.parseFloat(breakdown.borrowerTotalPaid) - Number.parseFloat(breakdown.processingFee)).toFixed(2)}</span>
                                                                    </div>
                                                                </div>
                                                                <div className="border-t border-purple-200 pt-2 mt-2">
                                                                    <div className="flex items-center justify-between py-2">
                                                                        <span className="text-sm font-medium">Security Deposit:</span>
                                                                        <span className="font-semibold">
                                                                            ₱{formatCurrency(rental.amounts?.security_deposit)}
                                                                        </span>
                                                                    </div>
                                                                    <div className="flex items-center justify-between py-1 text-xs text-muted-foreground">
                                                                        <span className="ml-4">- Damage Cost:</span>
                                                                        <span className="text-red-500">
                                                                            -₱{formatCurrency(rental.damage?.cost)}
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                                <div className="border-t-2 border-purple-300 pt-3 mt-3">
                                                                    <div className="flex items-center justify-between">
                                                                        <span className="font-bold text-purple-800">Net Refund to Borrower:</span>
                                                                        <span className="font-bold text-xl text-purple-700">₱{breakdown.borrowerRefund}</span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </CardContent>
                                                    </Card>
                                                </div>
                                                {/* Final Summary */}
                                                <Card className="bg-gray-50 border-2 border-gray-400">
                                                    <CardHeader className="pb-3">
                                                        <CardTitle className="text-base font-semibold text-gray-800 flex items-center gap-2">
                                                            <CheckCircle className="w-5 h-5" />
                                                            Payment Summary
                                                        </CardTitle>
                                                    </CardHeader>
                                                    <CardContent>
                                                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                                            <div className="text-center p-3 bg-white rounded border border-gray-200">
                                                                <div className="text-xs text-muted-foreground mb-1">To Lender</div>
                                                                <div className="font-bold text-lg text-blue-600">₱{breakdown.netLenderPayout}</div>
                                                            </div>
                                                            <div className="text-center p-3 bg-white rounded border border-gray-200">
                                                                <div className="text-xs text-muted-foreground mb-1">To Borrower</div>
                                                                <div className="font-bold text-lg text-purple-600">₱{breakdown.borrowerRefund}</div>
                                                            </div>
                                                            <div className="text-center p-3 bg-white rounded border border-gray-200">
                                                                <div className="text-xs text-muted-foreground mb-1">Platform Earnings</div>
                                                                <div className="font-bold text-lg text-green-600">₱{breakdown.totalPlatformFees}</div>
                                                                <div className="text-xs text-muted-foreground mt-1">
                                                                    (3% Processing from Total Paid + 5% Commission from Total)
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="mt-4 pt-4 border-t-2 border-gray-300">
                                                            <div className="flex items-center justify-between">
                                                                <span className="font-bold text-gray-800">Total Amount to Process:</span>
                                                                <span className="font-bold text-xl text-blue-700">
                                                                    ₱{(
                                                                        Number.parseFloat(breakdown.netLenderPayout) +
                                                                        Number.parseFloat(breakdown.borrowerRefund)
                                                                    ).toFixed(2)}
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </CardContent>
                                                </Card>
                                            </div>
                                        )
                                    })()}
                                </CardContent>
                            </Card>

                            {/* Transaction Status Summary */}
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <Shield className="w-5 h-5" />
                                        Transaction Status Summary
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                        <div>
                                            <h4 className="font-semibold mb-3 flex items-center gap-2">
                                                <Banknote className="w-4 h-4 text-blue-600" />
                                                Payout Summary
                                            </h4>
                                            {rental.transaction_summary?.payout ? (
                                                <div className="space-y-2 text-sm">
                                                    <DataRow label="Status">{rental.transaction_summary.payout.status || "N/A"}</DataRow>
                                                    <DataRow label="Amount">₱{formatCurrency(rental.transaction_summary.payout.amount)}</DataRow>
                                                    <DataRow label="Account">{rental.transaction_summary.payout.account_name || "N/A"}</DataRow>
                                                    <DataRow label="GCash">{rental.transaction_summary.payout.gcash_number || "N/A"}</DataRow>
                                                    <DataRow label="Processed">
                                                        {rental.transaction_summary.payout.processed ? "Yes" : "No"}
                                                    </DataRow>
                                                </div>
                                            ) : (
                                                <p className="text-muted-foreground">No payout data available</p>
                                            )}
                                        </div>
                                        <div>
                                            <h4 className="font-semibold mb-3 flex items-center gap-2">
                                                <CreditCard className="w-4 h-4 text-green-600" />
                                                Refund Summary
                                            </h4>
                                            {rental.transaction_summary?.refund ? (
                                                <div className="space-y-2 text-sm">
                                                    <DataRow label="Status">{rental.transaction_summary.refund.status || "N/A"}</DataRow>
                                                    <DataRow label="Amount">₱{formatCurrency(rental.transaction_summary.refund.amount)}</DataRow>
                                                    <DataRow label="Account">{rental.transaction_summary.refund.account_name || "N/A"}</DataRow>
                                                    <DataRow label="GCash">{rental.transaction_summary.refund.gcash_number || "N/A"}</DataRow>
                                                    <DataRow label="Processed">
                                                        {rental.transaction_summary.refund.processed ? "Yes" : "No"}
                                                    </DataRow>
                                                </div>
                                            ) : (
                                                <p className="text-muted-foreground">No refund data available</p>
                                            )}
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        </TabsContent>

                        <TabsContent value="payments" className="space-y-6">
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                {/* Borrower Refund Section */}
                                {rental.borrower?.payments?.refund_details?.status === "completed" ? (
                                    <Card>
                                        <CardHeader>
                                            <CardTitle className="flex items-center gap-2 text-blue-600">
                                                <Send className="w-5 h-5" />
                                                Borrower Refund
                                            </CardTitle>
                                        </CardHeader>
                                        <CardContent className="space-y-2">
                                            <Badge className="bg-green-100 text-green-800">Refund Completed</Badge>
                                            <p className="text-sm text-muted-foreground">
                                                ₱{formatCurrency(rental.borrower?.payments?.refund_details?.amount)} has been refunded to{" "}
                                                {rental.borrower?.payments?.refund_details?.account_name} (
                                                {rental.borrower?.payments?.refund_details?.gcash_number})
                                            </p>
                                        </CardContent>
                                    </Card>
                                ) : (
                                    <Card>
                                        <CardHeader>
                                            <CardTitle className="flex items-center gap-2 text-blue-600">
                                                <Send className="w-5 h-5" />
                                                Process Borrower Refund
                                            </CardTitle>
                                        </CardHeader>
                                        <CardContent>
                                            {(() => {
                                                const breakdown = calculateTransactionBreakdown()
                                                return (
                                                    <div className="mb-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
                                                        <h4 className="font-semibold text-sm text-blue-800 mb-2 flex items-center gap-2">
                                                            <Banknote className="w-4 h-4" />
                                                            Refund Calculation Summary
                                                        </h4>
                                                        <div className="space-y-1.5 text-xs">
                                                            <div className="flex items-center justify-between">
                                                                <span className="text-muted-foreground">Security Deposit:</span>
                                                                <span className="font-medium">₱{formatCurrency(rental.amounts?.security_deposit)}</span>
                                                            </div>
                                                            <div className="flex items-center justify-between">
                                                                <span className="text-muted-foreground">- Damage Cost:</span>
                                                                <span className="font-medium text-red-600">-₱{formatCurrency(rental.damage?.cost)}</span>
                                                            </div>
                                                            <div className="border-t border-blue-200 pt-1.5 mt-1.5">
                                                                <div className="flex items-center justify-between">
                                                                    <span className="font-semibold text-blue-800">Net Refund Amount:</span>
                                                                    <span className="font-bold text-lg text-blue-700">₱{breakdown.borrowerRefund}</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                )
                                            })()}
                                            <form onSubmit={refundForm.handleSubmit(onRefundSubmit)} className="space-y-4">
                                                <div className="space-y-2">
                                                    <Label htmlFor="refund-amount">Refund Amount (₱)</Label>
                                                    <Input
                                                        id="refund-amount"
                                                        type="number"
                                                        step="0.01"
                                                        placeholder="0.00"
                                                        {...refundForm.register("amount")}
                                                        className={refundForm.formState.errors.amount ? "border-red-500" : ""}
                                                    />
                                                    {refundForm.formState.errors.amount && (
                                                        <p className="text-sm text-red-500">{refundForm.formState.errors.amount.message}</p>
                                                    )}
                                                </div>

                                                <div className="space-y-2">
                                                    <Label htmlFor="refund-gcash">GCash Number</Label>
                                                    <div className="flex">
                                                        <span className="flex items-center px-3 bg-gray-50 border border-r-0 rounded-l-md text-sm text-gray-600">
                                                            +63
                                                        </span>
                                                        <Input
                                                            id="refund-gcash"
                                                            type="text"
                                                            placeholder="9123456789"
                                                            className={`rounded-l-none ${refundForm.formState.errors.gcashNumber ? "border-red-500" : ""}`}
                                                            {...refundForm.register("gcashNumber")}
                                                        />
                                                    </div>
                                                    {refundForm.formState.errors.gcashNumber && (
                                                        <p className="text-sm text-red-500">{refundForm.formState.errors.gcashNumber.message}</p>
                                                    )}
                                                </div>

                                                <div className="space-y-2">
                                                    <Label htmlFor="refund-account">Account Name</Label>
                                                    <Input
                                                        id="refund-account"
                                                        type="text"
                                                        placeholder="Full Name"
                                                        {...refundForm.register("accountName")}
                                                        className={refundForm.formState.errors.accountName ? "border-red-500" : ""}
                                                    />
                                                    {refundForm.formState.errors.accountName && (
                                                        <p className="text-sm text-red-500">{refundForm.formState.errors.accountName.message}</p>
                                                    )}
                                                </div>

                                                <div className="space-y-2">
                                                    <Label htmlFor="refund-notes">Notes (Optional)</Label>
                                                    <Textarea
                                                        id="refund-notes"
                                                        placeholder="Additional notes or reference..."
                                                        className="resize-none"
                                                        rows={3}
                                                        {...refundForm.register("notes")}
                                                    />
                                                </div>

                                                <Button
                                                    type="submit"
                                                    className="w-full bg-blue-600 hover:bg-blue-700"
                                                    disabled={isRefundPending}
                                                >
                                                    {isRefundPending ? (
                                                        <>
                                                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                                            Processing Refund...
                                                        </>
                                                    ) : (
                                                        <>
                                                            <Send className="w-4 h-4 mr-2" />
                                                            Process Refund
                                                        </>
                                                    )}
                                                </Button>
                                            </form>
                                        </CardContent>
                                    </Card>
                                )}

                                {/* Lender Payout Section */}
                                {rental.completion_status?.payout_completed ? (
                                    <Card>
                                        <CardHeader>
                                            <CardTitle className="flex items-center gap-2 text-green-600">
                                                <CreditCard className="w-5 h-5" />
                                                Lender Payout
                                            </CardTitle>
                                        </CardHeader>
                                        <CardContent className="space-y-2">
                                            <Badge className="bg-green-100 text-green-800">Payout Completed</Badge>
                                            <p className="text-sm text-muted-foreground">
                                                ₱{formatCurrency(rental.lender?.earnings?.payout_details?.amount)} has been paid to{" "}
                                                {rental.lender?.earnings?.payout_details?.account_name} (
                                                {rental.lender?.earnings?.payout_details?.gcash_number})
                                            </p>
                                        </CardContent>
                                    </Card>
                                ) : (
                                    <Card>
                                        <CardHeader>
                                            <CardTitle className="flex items-center gap-2 text-green-600">
                                                <CreditCard className="w-5 h-5" />
                                                Process Lender Payout
                                            </CardTitle>
                                        </CardHeader>
                                        <CardContent>
                                            {(() => {

                                                return (
                                                    <div className="mb-4 p-4 bg-green-50 rounded-lg border border-green-200">
                                                        <h4 className="font-semibold text-sm text-green-800 mb-2 flex items-center gap-2">
                                                            <CreditCard className="w-4 h-4" />
                                                            Payout Calculation Summary
                                                        </h4>
                                                        <div className="space-y-1.5 text-xs">
                                                            <div className="flex items-center justify-between">
                                                                <span className="text-muted-foreground">Gross Earnings:</span>
                                                                <span className="font-medium">₱{breakdown.grossLenderEarnings}</span>
                                                            </div>
                                                            <div className="flex items-center justify-between">
                                                                <span className="text-muted-foreground">- Commission Fee (5% of Total):</span>
                                                                <span className="font-medium text-red-600">-₱{breakdown.commissionFee}</span>
                                                            </div>
                                                            <div className="border-t border-green-200 pt-1.5 mt-1.5">
                                                                <div className="flex items-center justify-between">
                                                                    <span className="font-semibold text-green-800">Net Payout Amount:</span>
                                                                    <span className="font-bold text-lg text-green-700">₱{breakdown.netLenderPayout}</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                )
                                            })()}
                                            <form onSubmit={payoutForm.handleSubmit(onPayoutSubmit)} className="space-y-4">
                                                <div className="space-y-2">
                                                    <Label htmlFor="payout-amount">Payout Amount (₱)</Label>
                                                    <Input
                                                        id="payout-amount"
                                                        type="number"
                                                        step="0.01"
                                                        placeholder="0.00"
                                                        value={breakdown.netLenderPayout}
                                                        {...payoutForm.register("amount")}
                                                        className={payoutForm.formState.errors.amount ? "border-red-500" : ""}
                                                    />
                                                    {payoutForm.formState.errors.amount && (
                                                        <p className="text-sm text-red-500">{payoutForm.formState.errors.amount.message}</p>
                                                    )}
                                                </div>

                                                <div className="space-y-2">
                                                    <Label htmlFor="payout-gcash">GCash Number</Label>
                                                    <div className="flex">
                                                        <span className="flex items-center px-3 bg-gray-50 border border-r-0 rounded-l-md text-sm text-gray-600">
                                                            +63
                                                        </span>
                                                        <Input
                                                            id="payout-gcash"
                                                            type="text"
                                                            placeholder="9123456789"
                                                            className={`rounded-l-none ${payoutForm.formState.errors.gcashNumber ? "border-red-500" : ""}`}
                                                            {...payoutForm.register("gcashNumber")}
                                                        />
                                                    </div>
                                                    {payoutForm.formState.errors.gcashNumber && (
                                                        <p className="text-sm text-red-500">{payoutForm.formState.errors.gcashNumber.message}</p>
                                                    )}
                                                </div>

                                                <div className="space-y-2">
                                                    <Label htmlFor="payout-account">Account Name</Label>
                                                    <Input
                                                        id="payout-account"
                                                        type="text"
                                                        placeholder="Full Name"
                                                        {...payoutForm.register("accountName")}
                                                        className={payoutForm.formState.errors.accountName ? "border-red-500" : ""}
                                                    />
                                                    {payoutForm.formState.errors.accountName && (
                                                        <p className="text-sm text-red-500">{payoutForm.formState.errors.accountName.message}</p>
                                                    )}
                                                </div>

                                                <div className="space-y-2">
                                                    <Label htmlFor="payout-notes">Notes (Optional)</Label>
                                                    <Textarea
                                                        id="payout-notes"
                                                        placeholder="Additional notes or reference..."
                                                        className="resize-none"
                                                        rows={3}
                                                        {...payoutForm.register("notes")}
                                                    />
                                                </div>

                                                <Button
                                                    type="submit"
                                                    className="w-full bg-green-600 hover:bg-green-700"
                                                    disabled={isPayoutPending}
                                                >
                                                    {isPayoutPending ? (
                                                        <>
                                                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                                            Processing Payout...
                                                        </>
                                                    ) : (
                                                        <>
                                                            <CreditCard className="w-4 h-4 mr-2" />
                                                            Process Payout
                                                        </>
                                                    )}
                                                </Button>
                                            </form>
                                        </CardContent>
                                    </Card>
                                )}
                            </div>

                            {/* Processing Instructions (only if not fully completed) */}
                            {!rental.completion_status?.payout_completed ||
                                rental.borrower?.payments?.refund_details?.status !== "completed" ? (
                                <Card className="border-amber-200 bg-amber-50">
                                    <CardHeader>
                                        <CardTitle className="flex items-center gap-2 text-amber-800">
                                            <AlertTriangle className="w-5 h-5" />
                                            Processing Instructions
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent className="text-sm text-amber-800">
                                        <ul className="space-y-2">
                                            <li>• Verify all amounts and account details before processing</li>
                                            <li>• Ensure GCash numbers are valid and belong to the correct recipients</li>
                                            <li>• Add notes for record-keeping and future reference</li>
                                            <li>• Both transactions can be processed independently</li>
                                            <li>• Processing may take a few minutes to complete</li>
                                        </ul>
                                    </CardContent>
                                </Card>
                            ) : null}
                        </TabsContent>

                        <TabsContent value="details" className="space-y-6">
                            {/* Detailed Financial Breakdown */}
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                {/* Borrower Payments Detail */}
                                <SectionWrapper
                                    title="Borrower Payment Breakdown"
                                    icon={<User className="w-4 h-4" />}
                                    expanded={expandedSections["borrowerPayments"]}
                                    toggle={() => toggleSection("borrowerPayments")}
                                >
                                    <div className="space-y-2">
                                        <DataRow label="Security Deposit Paid">
                                            {formatCurrency(rental.borrower?.payments?.security_deposit_paid)}
                                        </DataRow>
                                        <DataRow label="Rental Fee Paid">
                                            {formatCurrency(rental.borrower?.payments?.rental_fee_paid)}
                                        </DataRow>
                                        <DataRow label="Extension Fee Paid">
                                            {formatCurrency(rental.borrower?.payments?.extension_fee_paid)}
                                        </DataRow>
                                        <DataRow label="Damage Fee Paid">
                                            {formatCurrency(rental.borrower?.payments?.damage_fee_paid)}
                                        </DataRow>
                                        <div className="border-t pt-2 mt-2">
                                            <DataRow label="Total Paid" className="font-semibold">
                                                {formatCurrency(rental.borrower?.payments?.total_paid)}
                                            </DataRow>
                                            <DataRow label="Total Refunded" className="text-green-600">
                                                {formatCurrency(rental.borrower?.payments?.total_refunded)}
                                            </DataRow>
                                            <DataRow label="Refund Amount Due" className="font-bold text-blue-600">
                                                {formatCurrency(rental.borrower?.payments?.refund_amount)}
                                            </DataRow>
                                        </div>
                                    </div>
                                </SectionWrapper>

                                {/* Lender Earnings Detail */}
                                <SectionWrapper
                                    title="Lender Earnings Breakdown"
                                    icon={<DollarSign className="w-4 h-4" />}
                                    expanded={expandedSections["lenderEarnings"]}
                                    toggle={() => toggleSection("lenderEarnings")}
                                >
                                    <div className="space-y-2">
                                        <DataRow label="Rental Fee">{formatCurrency(rental.lender?.earnings?.rental_fee)}</DataRow>
                                        <DataRow label="Extension Fee">{formatCurrency(rental.lender?.earnings?.extension_fee)}</DataRow>
                                        <DataRow label="Damage Charges">{formatCurrency(rental.lender?.earnings?.damage_charges)}</DataRow>
                                        <div className="border-t pt-2 mt-2">
                                            <DataRow label="Gross Earnings">
                                                {formatCurrency(rental.lender?.earnings?.gross_earnings)}
                                            </DataRow>
                                            <DataRow label="Security Deposit Received">
                                                {formatCurrency(rental.lender?.earnings?.security_deposit_received)}
                                            </DataRow>
                                            <DataRow label="Security Deposit Held" className="text-red-500">
                                                {formatCurrency(rental.lender?.earnings?.security_deposit_held)}
                                            </DataRow>
                                            <DataRow label="Net Earnings" className="font-bold text-green-600">
                                                {formatCurrency(rental.lender?.earnings?.net_earnings)}
                                            </DataRow>
                                        </div>
                                    </div>
                                </SectionWrapper>
                            </div>

                            {/* Damage Report */}
                            <SectionWrapper
                                title="Damage Report"
                                icon={<Shield className="w-4 h-4" />}
                                expanded={expandedSections["damageReport"]}
                                toggle={() => toggleSection("damageReport")}
                            >
                                <div className="space-y-2">
                                    <DataRow label="Damage Reported">{rental.damage?.reported ? "Yes" : "No"}</DataRow>
                                    <DataRow label="Damage Cost">₱{formatCurrency(rental.damage?.cost)}</DataRow>
                                    <DataRow label="Description">{rental.damage?.description || "No description provided"}</DataRow>
                                    <DataRow label="Initial Condition">{rental.damage?.initial_condition || "Not specified"}</DataRow>
                                </div>
                            </SectionWrapper>

                            {/* Location & Pickup */}
                            <SectionWrapper title="Location & Pickup" icon={<MapPin className="w-4 h-4" />}>
                                <div className="space-y-2">
                                    <DataRow label="Pickup Location">{rental.location?.pickup || "N/A"}</DataRow>
                                    <DataRow label="Delivery Method">{rental.location?.method || "N/A"}</DataRow>
                                </div>
                            </SectionWrapper>

                            {/* Payment History */}
                            <SectionWrapper
                                title="Payment History"
                                icon={<CreditCard className="w-4 h-4" />}
                                expanded={expandedSections["paymentsHistory"]}
                                toggle={() => toggleSection("paymentsHistory")}
                            >
                                <div className="space-y-4">
                                    {rental.payments && rental.payments.length > 0 ? (
                                        rental.payments.map((payment) => (
                                            <Card key={payment.id} className="border-l-4 border-l-blue-500">
                                                <CardContent className="pt-4">
                                                    <div className="grid grid-cols-2 gap-4 text-sm">
                                                        <DataRow label="Payment Type">{payment.payment_type || "N/A"}</DataRow>
                                                        <DataRow label="Amount">₱{formatCurrency(payment.amount)}</DataRow>
                                                        <DataRow label="Status">
                                                            <Badge className={getStatusColor(payment.status)}>{payment.status || "Unknown"}</Badge>
                                                        </DataRow>
                                                        <DataRow label="Method">{payment.payment_method || "N/A"}</DataRow>
                                                        <DataRow label="Reference">{payment.payment_reference || "N/A"}</DataRow>
                                                        <DataRow label="Processed">{formatDate(payment.processed_at)}</DataRow>
                                                        <DataRow label="Description" className="col-span-2">
                                                            {payment.description || "No description"}
                                                        </DataRow>
                                                    </div>
                                                </CardContent>
                                            </Card>
                                        ))
                                    ) : (
                                        <p className="text-muted-foreground">No payment history available</p>
                                    )}
                                </div>
                            </SectionWrapper>

                            {/* Full Timeline */}
                            <SectionWrapper
                                title="Complete Timeline"
                                icon={<Calendar className="w-4 h-4" />}
                                expanded={expandedSections["timeline"]}
                                toggle={() => toggleSection("timeline")}
                            >
                                <div className="space-y-2">
                                    <DataRow label="Current Status">{rental.timeline?.current_status || "N/A"}</DataRow>
                                    <DataRow label="Created">{formatDate(rental.timeline?.created)}</DataRow>
                                    <DataRow label="Accepted">{formatDate(rental.timeline?.accepted)}</DataRow>
                                    <DataRow label="Delivered">{formatDate(rental.timeline?.delivered)}</DataRow>
                                    <DataRow label="Returned">{formatDate(rental.timeline?.returned)}</DataRow>
                                    <DataRow label="Payout Completed">{formatDate(rental.timeline?.payout_completed)}</DataRow>
                                    <DataRow label="Refund Completed">{formatDate(rental.timeline?.refund_completed)}</DataRow>
                                    <DataRow label="Fully Completed">{formatDate(rental.timeline?.fully_completed)}</DataRow>
                                    <DataRow label="Last Updated">{formatDate(rental.timeline?.updated)}</DataRow>
                                    <DataRow label="Record Created">{formatDate(rental.created_at)}</DataRow>
                                    <DataRow label="Record Updated">{formatDate(rental.updated_at)}</DataRow>
                                </div>
                            </SectionWrapper>
                        </TabsContent>
                    </Tabs>
                </DialogContent>
            </Dialog>
        </>
    )
}
