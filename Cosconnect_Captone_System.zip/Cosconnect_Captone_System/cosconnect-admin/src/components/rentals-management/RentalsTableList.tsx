"use client"

import type React from "react"
import { memo } from "react"
import { format } from "date-fns"
import { Eye, MoreHorizontal, User, Building, Calendar, Package, AlertTriangle } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Card } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Skeleton } from "@/components/ui/skeleton"
import type { Rental } from "@/types/rentals/getRentalsFinished"

interface RentalsTableProps {
    rentals: Rental[]
    isLoading: boolean
    onViewDetails: (rental: Rental) => void
}

const getStatusVariant = (status: string) => {
    switch (status.toLowerCase()) {
        case "pending":
            return "outline"
        case "accepted":
            return "default"
        case "delivered":
            return "default"
        case "returned":
            return "default"
        default:
            return "secondary"
    }
}

const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
        case "pending":
            return "text-yellow-600 bg-yellow-50 border-yellow-200"
        case "accepted":
            return "text-blue-600 bg-blue-50 border-blue-200"
        case "delivered":
            return "text-green-600 bg-green-50 border-green-200"
        case "returned":
            return "text-purple-600 bg-purple-50 border-purple-200"
        default:
            return "text-gray-600 bg-gray-50 border-gray-200"
    }
}

const formatCurrency = (amount: string) => {
    return new Intl.NumberFormat("en-PH", {
        style: "currency",
        currency: "PHP",
    }).format(Number.parseFloat(amount))
}

const TableSkeleton = memo(() => (
    <>
        {Array.from({ length: 5 }).map((_, index) => (
            <TableRow key={index}>
                <TableCell>
                    <Skeleton className="h-4 w-32" />
                </TableCell>
                <TableCell>
                    <Skeleton className="h-4 w-24" />
                </TableCell>
                <TableCell>
                    <Skeleton className="h-8 w-20" />
                </TableCell>
                <TableCell>
                    <Skeleton className="h-4 w-28" />
                </TableCell>
                <TableCell>
                    <Skeleton className="h-4 w-24" />
                </TableCell>
                <TableCell>
                    <Skeleton className="h-4 w-20" />
                </TableCell>
                <TableCell>
                    <Skeleton className="h-4 w-20" />
                </TableCell>
                <TableCell>
                    <Skeleton className="h-8 w-8" />
                </TableCell>
            </TableRow>
        ))}
    </>
))

TableSkeleton.displayName = "TableSkeleton"

const RentalsTable: React.FC<RentalsTableProps> = memo(({ rentals, isLoading, onViewDetails }) => {
    if (isLoading) {
        return (
            <Card>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Reference</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Costume</TableHead>
                            <TableHead>Borrower</TableHead>
                            <TableHead>Lender</TableHead>
                            <TableHead>Amount</TableHead>
                            <TableHead>Date</TableHead>
                            <TableHead className="w-[50px]">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        <TableSkeleton />
                    </TableBody>
                </Table>
            </Card>
        )
    }

    if (rentals.length === 0) {
        return (
            <Card className="p-12 text-center">
                <Package className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No rentals found</h3>
                <p className="text-muted-foreground">No rental transactions match your current filters.</p>
            </Card>
        )
    }

    return (
        <Card>
            <div className="overflow-x-auto">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead className="min-w-[180px]">Reference</TableHead>
                            <TableHead className="min-w-[120px]">Status</TableHead>
                            <TableHead className="min-w-[200px]">Costume</TableHead>
                            <TableHead className="min-w-[180px]">Borrower</TableHead>
                            <TableHead className="min-w-[180px]">Lender</TableHead>
                            <TableHead className="min-w-[120px]">Amount</TableHead>
                            <TableHead className="min-w-[120px]">Date</TableHead>
                            <TableHead className="w-[50px]">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {rentals.map((rental) => (
                            <TableRow key={rental.id} className="hover:bg-muted/50">
                                <TableCell className="font-medium">
                                    <div className="space-y-1">
                                        <div className="font-mono text-sm">{rental.reference_code}</div>
                                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                            <Calendar className="h-3 w-3" />
                                            {format(new Date(rental.created_at), "MMM dd, yyyy")}
                                        </div>
                                    </div>
                                </TableCell>

                                <TableCell>
                                    <Badge
                                        variant={getStatusVariant(rental.status)}
                                        className={`${getStatusColor(rental.status)} capitalize`}
                                    >
                                        {rental.status}
                                    </Badge>
                                    {rental.damage.reported && (
                                        <div className="flex items-center gap-1 mt-1">
                                            <AlertTriangle className="h-3 w-3 text-orange-500" />
                                            <span className="text-xs text-orange-600">Damage</span>
                                        </div>
                                    )}
                                </TableCell>

                                <TableCell>
                                    <div className="flex items-center gap-3">
                                        <Avatar className="h-10 w-10">
                                            <AvatarImage src={rental.costume.images.front || "/placeholder.svg"} alt={rental.costume.name} />
                                            <AvatarFallback>{rental.costume.name.charAt(0).toUpperCase()}</AvatarFallback>
                                        </Avatar>
                                        <div className="space-y-1">
                                            <div className="font-medium text-sm line-clamp-1">{rental.costume.name}</div>
                                            <div className="text-xs text-muted-foreground">
                                                {rental.costume.brand} • {rental.costume.category}
                                            </div>
                                            <Badge variant="outline" className="text-xs">
                                                Size {rental.costume.sizes}
                                            </Badge>
                                        </div>
                                    </div>
                                </TableCell>

                                <TableCell>
                                    <div className="space-y-1">
                                        <div className="flex items-center gap-2">
                                            <User className="h-3 w-3 text-muted-foreground" />
                                            <span className="font-medium text-sm">{rental.borrower.name}</span>
                                        </div>
                                        <div className="text-xs text-muted-foreground">{rental.borrower.email}</div>
                                        <div className="text-xs text-muted-foreground">{rental.borrower.phone}</div>
                                    </div>
                                </TableCell>

                                <TableCell>
                                    <div className="space-y-1">
                                        <div className="flex items-center gap-2">
                                            <Building className="h-3 w-3 text-muted-foreground" />
                                            <span className="font-medium text-sm">{rental.lender.name}</span>
                                        </div>
                                        <div className="text-xs text-muted-foreground">{rental.lender.email}</div>
                                        <div className="flex items-center gap-1 text-xs text-green-600">
                                            Earned: {formatCurrency(rental.lender.earnings.net_earnings)}
                                        </div>
                                    </div>
                                </TableCell>

                                <TableCell>
                                    <div className="space-y-1">
                                        <div className="font-semibold text-sm">{formatCurrency(rental.amounts.total_amount)}</div>
                                        <div className="text-xs text-muted-foreground">
                                            Rental: {formatCurrency(rental.amounts.rental_amount)}
                                        </div>
                                        <div className="text-xs text-muted-foreground">
                                            Deposit: {formatCurrency(rental.amounts.security_deposit)}
                                        </div>
                                    </div>
                                </TableCell>

                                <TableCell>
                                    <div className="text-xs text-muted-foreground space-y-1">
                                        <div>Created: {format(new Date(rental.created_at), "MM/dd")}</div>
                                        <div>Updated: {format(new Date(rental.updated_at), "MM/dd")}</div>
                                    </div>
                                </TableCell>

                                <TableCell>
                                    <DropdownMenu>
                                        <DropdownMenuTrigger asChild>
                                            <Button variant="ghost" size="icon" className="h-8 w-8">
                                                <MoreHorizontal className="h-4 w-4" />
                                                <span className="sr-only">Open menu</span>
                                            </Button>
                                        </DropdownMenuTrigger>
                                        <DropdownMenuContent align="end">
                                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                            <DropdownMenuSeparator />
                                            <DropdownMenuItem onClick={() => onViewDetails(rental)}>
                                                <Eye className="mr-2 h-4 w-4" />
                                                View Details
                                            </DropdownMenuItem>
                                        </DropdownMenuContent>
                                    </DropdownMenu>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </div>
        </Card>
    )
})

RentalsTable.displayName = "RentalsTable"

export default RentalsTable
