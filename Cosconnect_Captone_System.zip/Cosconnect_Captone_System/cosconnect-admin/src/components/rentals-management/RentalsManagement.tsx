"use client"

import { useAdminGetAllRentalsIfFinished } from "@/lib/apis/rentalsApi"
import type { Rental, RentalDetails, RentalsFilters } from "@/types/rentals/getRentalsFinished"
import type React from "react"
import { useState, useMemo, useCallback, useEffect } from "react"
import { toast } from "sonner"
import { StatusTabs } from "./status-tabs"
import RentalsFilterComponent from "./RentalsFilters"
import RentalsTable from "./RentalsTableList"
import Pagination from "./RentalsPagination"
import { RentalDetailsDialog } from "./ViewRentalsDialog"
import MainTabs from "./main-tabs"
import StatusFilterSidebar from "./status-filter-sidebar"


const RentalsManagement: React.FC = () => {
    const [mainTab, setMainTab] = useState<"active" | "completed">("active")
    const [currentPage, setCurrentPage] = useState(1)
    const [itemsPerPage, setItemsPerPage] = useState(20)

    const [filters, setFilters] = useState<RentalsFilters>({
        search: "",
        status: "all",
        dateRange: { from: null, to: null },
        sortBy: "created_at",
        sortOrder: "desc",
    })

    const [rentalDetails, setRentalDetails] = useState<RentalDetails | null>(null)
    const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)

    const { isFetching, rentalsFinished, isError } = useAdminGetAllRentalsIfFinished({
        page: currentPage,
        limit: itemsPerPage,
    })

    const filteredRentals = useMemo(() => {
        if (!rentalsFinished?.data) return []

        let filtered = [...rentalsFinished.data]

        // Filter by main tab (active vs completed)
        filtered = filtered.filter((rental) => {
            const isCompleted = rental.status.toLowerCase() === "completed"
            return mainTab === "completed" ? isCompleted : !isCompleted
        })

        // Apply search filter
        if (filters.search) {
            const searchTerm = filters.search.toLowerCase()
            filtered = filtered.filter((rental) =>
                [
                    rental.reference_code,
                    rental.borrower.name,
                    rental.borrower.email,
                    rental.lender.name,
                    rental.lender.email,
                    rental.costume.name,
                ]
                    .join(" ")
                    .toLowerCase()
                    .includes(searchTerm),
            )
        }

        // Apply status filter (only for active tab)
        if (mainTab === "active" && filters.status !== "all") {
            filtered = filtered.filter((rental) => rental.status.toLowerCase() === filters.status.toLowerCase())
        }

        // Apply sorting
        filtered.sort((a, b) => {
            const sortMap: Record<string, (r: Rental) => any> = {
                created_at: (r) => new Date(r.created_at),
                updated_at: (r) => new Date(r.updated_at),
                total_amount: (r) => Number.parseFloat(r.amounts.total_amount),
                reference_code: (r) => r.reference_code,
            }

            const getValue = sortMap[filters.sortBy] || sortMap.created_at
            const aValue = getValue(a)
            const bValue = getValue(b)

            return aValue < bValue
                ? filters.sortOrder === "asc"
                    ? -1
                    : 1
                : aValue > bValue
                    ? filters.sortOrder === "asc"
                        ? 1
                        : -1
                    : 0
        })

        return filtered
    }, [rentalsFinished?.data, filters, mainTab])

    const statusCounts = useMemo<Record<string, number>>(() => {
        if (!rentalsFinished?.data) {
            return {
                all: 0,
                "for-return": 0,
                pending: 0,
                cancelled: 0,
                rejected: 0,
                completed: 0,
            }
        }

        return {
            all: rentalsFinished.data.length,
            "for-return": rentalsFinished.data.filter((r) =>
                ["pending", "cancelled", "rejected"].includes(r.status.toLowerCase())
            ).length,
            pending: rentalsFinished.data.filter((r) => r.status.toLowerCase() === "pending").length,
            cancelled: rentalsFinished.data.filter((r) => r.status.toLowerCase() === "cancelled").length,
            rejected: rentalsFinished.data.filter((r) => r.status.toLowerCase() === "rejected").length,
            completed: rentalsFinished.data.filter((r) => r.status.toLowerCase() === "completed").length,
        }
    }, [rentalsFinished?.data])

    const handleFiltersChange = useCallback((newFilters: Partial<RentalsFilters>) => {
        setFilters((prev) => ({ ...prev, ...newFilters }))
        const isSortOnly = Object.keys(newFilters).every((key) => ["sortBy", "sortOrder"].includes(key))
        if (!isSortOnly) setCurrentPage(1)
    }, [])

    const handleMainTabChange = useCallback((tab: "active" | "completed") => {
        setMainTab(tab)
        setCurrentPage(1)
        setFilters((prev) => ({ ...prev, status: "all" }))
    }, [])

    const handleStatusChange = useCallback(
        (status: string) => {
            handleFiltersChange({ status })
        },
        [handleFiltersChange],
    )

    const handlePageChange = useCallback((page: number) => {
        setCurrentPage(page)
    }, [])

    const handleLimitChange = useCallback((limit: number) => {
        setItemsPerPage(limit)
        setCurrentPage(1)
    }, [])

    const handleViewDetails = useCallback((rental: Rental) => {
        setRentalDetails(rental as any)
        setIsViewDialogOpen(true)
    }, [])

    // Update rentalDetails when data changes to reflect cache updates
    useEffect(() => {
        if (isViewDialogOpen && rentalDetails && rentalsFinished?.data) {
            const updatedRental = rentalsFinished.data.find(r => r.id === rentalDetails.id)
            if (updatedRental) {
                setRentalDetails(updatedRental as any)
            }
        }
    }, [rentalsFinished?.data, isViewDialogOpen, rentalDetails])

    if (isError) {
        toast.error("Failed to load rentals data")
    }

    const totalCount = filteredRentals.length
    const paginationInfo = rentalsFinished?.pagination || {
        page: currentPage,
        limit: itemsPerPage,
        total: 0,
        totalPages: 0,
        hasNext: false,
        hasPrev: false,
    }

    return (
        <div className="space-y-0">
            {/* Main Tabs */}
            <MainTabs
                activeTab={mainTab}
                onTabChange={handleMainTabChange}
                activeCounts={{
                    active: statusCounts.active || 0,
                    completed: statusCounts.completed || 0,
                }}
            />

            <div className="p-6 space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                    {/* Left Sidebar - Status Filter (only show in active tab) */}
                    {mainTab === "active" && (
                        <div className="lg:col-span-1">
                            <StatusFilterSidebar
                                activeStatus={filters.status}
                                onStatusChange={handleStatusChange}
                                statusCounts={statusCounts}
                            />
                        </div>
                    )}

                    {/* Main Content */}
                    <div className={mainTab === "active" ? "lg:col-span-3" : "lg:col-span-4"}>
                        {/* Filters Section */}
                        <RentalsFilterComponent filters={filters} onFiltersChange={handleFiltersChange} totalCount={totalCount} />

                        {/* Table Section */}
                        <RentalsTable rentals={filteredRentals} isLoading={isFetching} onViewDetails={handleViewDetails} />

                        {/* Pagination Section */}
                        {totalCount > 0 && (
                            <Pagination
                                pagination={paginationInfo}
                                onPageChange={handlePageChange}
                                onLimitChange={handleLimitChange}
                            />
                        )}
                    </div>
                </div>
            </div>

            {/* View Details Dialog */}
            <RentalDetailsDialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen} rental={rentalDetails} />
        </div>
    )
}

export default RentalsManagement
