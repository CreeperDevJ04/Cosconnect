"use client"

import type React from "react"
import { memo } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface StatusFilterSidebarProps {
    activeStatus: string
    onStatusChange: (status: string) => void
    statusCounts: Record<string, number>
}

const statusOptions = [
    { value: "all", label: "All Rentals" },
    { value: "pending", label: "Pending" },
    { value: "cancelled", label: "Cancelled" },
    { value: "rejected", label: "Rejected" },
]

const StatusFilterSidebar: React.FC<StatusFilterSidebarProps> = memo(
    ({ activeStatus, onStatusChange, statusCounts }) => {
        return (
            <Card className="p-4 space-y-2 h-fit">
                <h3 className="font-semibold text-sm mb-4">Filter by Status</h3>
                <div className="space-y-2">
                    {statusOptions.map((option) => (
                        <Button
                            key={option.value}
                            variant={activeStatus === option.value ? "default" : "ghost"}
                            onClick={() => onStatusChange(option.value)}
                            className="w-full justify-between"
                        >
                            <span>{option.label}</span>
                            <Badge variant="secondary" className="text-xs">
                                {statusCounts[option.value] || 0}
                            </Badge>
                        </Button>
                    ))}
                </div>
            </Card>
        )
    },
)

StatusFilterSidebar.displayName = "StatusFilterSidebar"

export default StatusFilterSidebar
