"use client"

import type React from "react"
import { memo } from "react"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"

export const STATUS_TABS = [
    { value: "all", label: "All Rentals", count: 0 },
    { value: "for-return", label: "For Return", count: 0 },
    { value: "pending", label: "Pending", count: 0 },
    { value: "cancelled", label: "Cancelled", count: 0 },
    { value: "rejected", label: "Rejected", count: 0 },
    { value: "completed", label: "Completed", count: 0 },
] as const

interface StatusTabsProps {
    activeTab: string
    onTabChange: (tab: string) => void
    counts?: Record<string, number>
}

export const StatusTabs: React.FC<StatusTabsProps> = memo(({ activeTab, onTabChange, counts = {} }) => {
    return (
        <Tabs value={activeTab} onValueChange={onTabChange} className="w-full">
            <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6 gap-1 bg-transparent border-b rounded-none p-0 h-auto">
                {STATUS_TABS.map((tab) => (
                    <TabsTrigger
                        key={tab.value}
                        value={tab.value}
                        className="rounded-none border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent px-3 py-2 text-sm font-medium"
                    >
                        <div className="flex items-center gap-2">
                            <span>{tab.label}</span>
                            {counts[tab.value] ? (
                                <Badge variant="secondary" className="text-xs">
                                    {counts[tab.value]}
                                </Badge>
                            ) : null}
                        </div>
                    </TabsTrigger>
                ))}
            </TabsList>
        </Tabs>
    )
})

StatusTabs.displayName = "StatusTabs"
