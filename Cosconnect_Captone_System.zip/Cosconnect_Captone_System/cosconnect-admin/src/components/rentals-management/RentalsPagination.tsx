"use client"

import React, { memo } from "react"
import { ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, MoreHorizontal } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card } from "@/components/ui/card"
import type { PaginationInfo } from "@/types/rentals/getRentalsFinished"

interface PaginationProps {
    pagination: PaginationInfo
    onPageChange: (page: number) => void
    onLimitChange: (limit: number) => void
}

const limitOptions = [
    { value: 10, label: "10 per page" },
    { value: 20, label: "20 per page" },
    { value: 50, label: "50 per page" },
    { value: 100, label: "100 per page" },
]

const Pagination: React.FC<PaginationProps> = memo(({ pagination, onPageChange, onLimitChange }) => {
    const { page, limit, total, totalPages, hasNext, hasPrev } = pagination

    const startItem = (page - 1) * limit + 1
    const endItem = Math.min(page * limit, total)

    // Generate page numbers to display
    const getPageNumbers = () => {
        const pages: (number | string)[] = []
        const maxVisiblePages = 7

        if (totalPages <= maxVisiblePages) {
            // Show all pages if total is small
            for (let i = 1; i <= totalPages; i++) {
                pages.push(i)
            }
        } else {
            // Always show first page
            pages.push(1)

            if (page > 3) {
                pages.push("...")
            }

            // Show pages around current page
            const start = Math.max(2, page - 1)
            const end = Math.min(totalPages - 1, page + 1)

            for (let i = start; i <= end; i++) {
                pages.push(i)
            }

            if (page < totalPages - 2) {
                pages.push("...")
            }

            // Always show last page
            if (totalPages > 1) {
                pages.push(totalPages)
            }
        }

        return pages
    }

    const pageNumbers = getPageNumbers()

    if (total === 0) {
        return null
    }

    return (
        <Card className="p-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                {/* Results info */}
                <div className="text-sm text-muted-foreground">
                    Showing {startItem} to {endItem} of {total} results
                </div>

                {/* Pagination controls */}
                <div className="flex items-center gap-2">
                    {/* First page */}
                    <Button variant="outline" size="icon" onClick={() => onPageChange(1)} disabled={!hasPrev} className="h-8 w-8">
                        <ChevronsLeft className="h-4 w-4" />
                        <span className="sr-only">First page</span>
                    </Button>

                    {/* Previous page */}
                    <Button
                        variant="outline"
                        size="icon"
                        onClick={() => onPageChange(page - 1)}
                        disabled={!hasPrev}
                        className="h-8 w-8"
                    >
                        <ChevronLeft className="h-4 w-4" />
                        <span className="sr-only">Previous page</span>
                    </Button>

                    {/* Page numbers */}
                    <div className="flex items-center gap-1">
                        {pageNumbers.map((pageNum, index) => (
                            <React.Fragment key={index}>
                                {pageNum === "..." ? (
                                    <div className="flex items-center justify-center h-8 w-8">
                                        <MoreHorizontal className="h-4 w-4 text-muted-foreground" />
                                    </div>
                                ) : (
                                    <Button
                                        variant={pageNum === page ? "default" : "outline"}
                                        size="icon"
                                        onClick={() => onPageChange(pageNum as number)}
                                        className="h-8 w-8"
                                    >
                                        {pageNum}
                                    </Button>
                                )}
                            </React.Fragment>
                        ))}
                    </div>

                    {/* Next page */}
                    <Button
                        variant="outline"
                        size="icon"
                        onClick={() => onPageChange(page + 1)}
                        disabled={!hasNext}
                        className="h-8 w-8"
                    >
                        <ChevronRight className="h-4 w-4" />
                        <span className="sr-only">Next page</span>
                    </Button>

                    {/* Last page */}
                    <Button
                        variant="outline"
                        size="icon"
                        onClick={() => onPageChange(totalPages)}
                        disabled={!hasNext}
                        className="h-8 w-8"
                    >
                        <ChevronsRight className="h-4 w-4" />
                        <span className="sr-only">Last page</span>
                    </Button>
                </div>

                {/* Items per page selector */}
                <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground whitespace-nowrap">Items per page:</span>
                    <Select value={limit.toString()} onValueChange={(value) => onLimitChange(Number.parseInt(value))}>
                        <SelectTrigger className="w-[130px] h-8">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            {limitOptions.map((option) => (
                                <SelectItem key={option.value} value={option.value.toString()}>
                                    {option.label}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
            </div>
        </Card>
    )
})

Pagination.displayName = "Pagination"

export default Pagination
