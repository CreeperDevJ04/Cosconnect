import { memo } from "react"
import { Badge } from "../ui/badge"
import { Button } from "../ui/button"
import { Card } from "../ui/card"

interface MainTabsProps {
    activeTab: "active" | "completed"
    onTabChange: (tab: "active" | "completed") => void
    activeCounts: {
        active: number
        completed: number
    }
}

const MainTabs: React.FC<MainTabsProps> = memo(({ activeTab, onTabChange, activeCounts }: any) => {
    return (
        <Card className="p-4 border-b rounded-none">
            <div className="flex gap-2">
                {/* Active Rentals Tab */}
                <Button
                    variant={activeTab === "active" ? "default" : "ghost"}
                    onClick={() => onTabChange("active")}
                    className="relative"
                >
                    Active Rentals
                    <Badge variant="secondary" className="ml-2 text-xs">
                        {activeCounts.active}
                    </Badge>
                </Button>

                {/* Completed & Refunded Tab */}
                <Button
                    variant={activeTab === "completed" ? "default" : "ghost"}
                    onClick={() => onTabChange("completed")}
                    className="relative"
                >
                    Completed & Refunded
                    <Badge variant="secondary" className="ml-2 text-xs">
                        {activeCounts.completed}
                    </Badge>
                </Button>
            </div>
        </Card>
    )
})

MainTabs.displayName = "MainTabs"

export default MainTabs