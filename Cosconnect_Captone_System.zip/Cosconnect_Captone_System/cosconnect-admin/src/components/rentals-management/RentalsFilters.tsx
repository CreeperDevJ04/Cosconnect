"use client"

import type React from "react"
import { memo } from "react"
import { Search, Filter, Calendar, SortAsc, SortDesc } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Card } from "@/components/ui/card"
import type { RentalsFilters } from "@/types/rentals/getRentalsFinished"

interface RentalsFiltersProps {
    filters: RentalsFilters
    onFiltersChange: (filters: Partial<RentalsFilters>) => void
    totalCount: number
}

const statusOptions = [
    { value: "all", label: "All Status", variant: "secondary" as const },
    { value: "pending", label: "Pending", variant: "outline" as const },
    { value: "accepted", label: "Accepted", variant: "default" as const },
    { value: "delivered", label: "Delivered", variant: "default" as const },
    { value: "returned", label: "Returned", variant: "default" as const },
]

const sortOptions = [
    { value: "created_at", label: "Date Created" },
    { value: "updated_at", label: "Last Updated" },
    { value: "total_amount", label: "Total Amount" },
    { value: "reference_code", label: "Reference Code" },
]

const RentalsFilterComponent: React.FC<RentalsFiltersProps> = memo(({ filters, onFiltersChange, totalCount }) => {
    const handleSearchChange = (value: string) => {
        onFiltersChange({ search: value })
    }

    const handleStatusChange = (status: string) => {
        onFiltersChange({ status })
    }

    const handleSortChange = (sortBy: string) => {
        onFiltersChange({ sortBy })
    }

    const toggleSortOrder = () => {
        onFiltersChange({
            sortOrder: filters.sortOrder === "asc" ? "desc" : "asc",
        })
    }

    const clearFilters = () => {
        onFiltersChange({
            search: "",
            status: "all",
            sortBy: "created_at",
            sortOrder: "desc",
        })
    }

    const activeFiltersCount = [filters.search, filters.status !== "all" ? filters.status : null].filter(Boolean).length

    return (
        <Card className="p-6 space-y-4">
            <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
                <div className="flex items-center gap-2">
                    <h2 className="text-lg font-semibold">Rentals Management</h2>
                    <Badge variant="secondary" className="text-xs">
                        {totalCount} total
                    </Badge>
                </div>

                <div className="flex items-center gap-2">
                    {activeFiltersCount > 0 && (
                        <Badge variant="outline" className="text-xs">
                            {activeFiltersCount} filter{activeFiltersCount > 1 ? "s" : ""} active
                        </Badge>
                    )}
                    <Button variant="outline" size="sm" onClick={clearFilters} className="text-xs bg-transparent">
                        Clear All
                    </Button>
                </div>
            </div>

            <div className="flex flex-col lg:flex-row gap-4">
                {/* Search Input */}
                <div className="relative flex-1 min-w-0">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                        placeholder="Search by reference code, borrower, or lender..."
                        value={filters.search}
                        onChange={(e) => handleSearchChange(e.target.value)}
                        className="pl-10"
                    />
                </div>

                {/* Status Filter */}
                <Select value={filters.status} onValueChange={handleStatusChange}>
                    <SelectTrigger className="w-full lg:w-[180px]">
                        <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent>
                        {statusOptions.map((option) => (
                            <SelectItem key={option.value} value={option.value}>
                                <div className="flex items-center gap-2">
                                    <Badge variant={option.variant} className="text-xs">
                                        {option.label}
                                    </Badge>
                                </div>
                            </SelectItem>
                        ))}
                    </SelectContent>
                </Select>

                {/* Sort Controls */}
                <div className="flex gap-2">
                    <Select value={filters.sortBy} onValueChange={handleSortChange}>
                        <SelectTrigger className="w-full lg:w-[160px]">
                            <SelectValue placeholder="Sort by" />
                        </SelectTrigger>
                        <SelectContent>
                            {sortOptions.map((option) => (
                                <SelectItem key={option.value} value={option.value}>
                                    {option.label}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>

                    <Button variant="outline" size="icon" onClick={toggleSortOrder} className="shrink-0 bg-transparent">
                        {filters.sortOrder === "asc" ? <SortAsc className="h-4 w-4" /> : <SortDesc className="h-4 w-4" />}
                    </Button>
                </div>

                {/* Advanced Filters */}
                <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="outline" size="icon" className="shrink-0 bg-transparent">
                            <Filter className="h-4 w-4" />
                        </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-56">
                        <DropdownMenuLabel>Advanced Filters</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem>
                            <Calendar className="mr-2 h-4 w-4" />
                            Date Range
                        </DropdownMenuItem>
                        <DropdownMenuItem>Amount Range</DropdownMenuItem>
                        <DropdownMenuItem>Payment Method</DropdownMenuItem>
                    </DropdownMenuContent>
                </DropdownMenu>
            </div>
        </Card>
    )
})

RentalsFilterComponent.displayName = "RentalsFilterComponent"

export default RentalsFilterComponent
