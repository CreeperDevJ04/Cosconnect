"use client"

import { CheckCircle, Clock, XCircle, AlertCircle, RefreshCw } from "lucide-react"
import type { Transaction } from "@/types/transactions"
import { cn } from "@/lib/utils"

interface TransactionRowProps {
  transaction: Transaction
}

// Payment Status Configuration
const PAYMENT_STATUS_CONFIG = {
  paid: { icon: CheckCircle, color: "text-green-600", bg: "bg-green-50", label: "Paid" },
  pending: { icon: Clock, color: "text-yellow-600", bg: "bg-yellow-50", label: "Pending" },
  failed: { icon: XCircle, color: "text-red-600", bg: "bg-red-50", label: "Failed" },
  refunded: { icon: RefreshCw, color: "text-blue-600", bg: "bg-blue-50", label: "Refunded" },
  cancelled: { icon: XCircle, color: "text-gray-600", bg: "bg-gray-50", label: "Cancelled" },
}

// Rental Status Configuration
const RENTAL_STATUS_CONFIG = {
  pending: { icon: Clock, color: "text-yellow-600", bg: "bg-yellow-50", label: "Pending" },
  confirmed: { icon: CheckCircle, color: "text-green-600", bg: "bg-green-50", label: "Confirmed" },
  completed: { icon: CheckCircle, color: "text-green-600", bg: "bg-green-50", label: "Completed" },
  cancelled: { icon: XCircle, color: "text-gray-600", bg: "bg-gray-50", label: "Cancelled" },
  rejected: { icon: AlertCircle, color: "text-red-600", bg: "bg-red-50", label: "Rejected" },
  returned: { icon: CheckCircle, color: "text-blue-600", bg: "bg-blue-50", label: "Returned" },
}

export function TransactionRow({ transaction }: TransactionRowProps) {
  const paymentStatusConfig = PAYMENT_STATUS_CONFIG[transaction.status as keyof typeof PAYMENT_STATUS_CONFIG] || PAYMENT_STATUS_CONFIG.pending
  const rentalStatusConfig = RENTAL_STATUS_CONFIG[transaction.rental?.status as keyof typeof RENTAL_STATUS_CONFIG] || RENTAL_STATUS_CONFIG.pending

  const PaymentStatusIcon = paymentStatusConfig.icon
  const RentalStatusIcon = rentalStatusConfig.icon

  const formattedDate = new Date(transaction.createdAt).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  })

  const formatPaymentType = (type: string) => {
    return type.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')
  }

  const formatPaymentMethod = (method: string) => {
    if (method === 'paymaya') return 'PayMaya'
    if (method === 'gcash') return 'GCash'
    return method.charAt(0).toUpperCase() + method.slice(1)
  }

  return (
    <tr className="border-b border-border hover:bg-muted/50 transition-colors">
      <td className="px-4 py-3 text-sm font-mono font-medium">{transaction.referenceCode}</td>
      <td className="px-4 py-3 text-sm">{transaction.rental?.renterName || "—"}</td>
      <td className="px-4 py-3 text-sm">{transaction.rental?.costumeName || "—"}</td>
      <td className="px-4 py-3 text-sm">{formatPaymentType(transaction.paymentType)}</td>
      <td className="px-4 py-3 text-sm">{formatPaymentMethod(transaction.paymentMethod)}</td>
      <td className="px-4 py-3">
        <div
          className={cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium", paymentStatusConfig.bg)}
        >
          <PaymentStatusIcon className={cn("h-3 w-3", paymentStatusConfig.color)} />
          <span className={paymentStatusConfig.color}>{paymentStatusConfig.label}</span>
        </div>
      </td>
      <td className="px-4 py-3">
        <div
          className={cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium", rentalStatusConfig.bg)}
        >
          <RentalStatusIcon className={cn("h-3 w-3", rentalStatusConfig.color)} />
          <span className={rentalStatusConfig.color}>{rentalStatusConfig.label}</span>
        </div>
      </td>
      <td className="px-4 py-3 text-sm font-medium">
        ₱{Number.parseFloat(transaction.amount).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
      </td>
      <td className="px-4 py-3 text-sm text-muted-foreground">{formattedDate}</td>
    </tr>
  )
}