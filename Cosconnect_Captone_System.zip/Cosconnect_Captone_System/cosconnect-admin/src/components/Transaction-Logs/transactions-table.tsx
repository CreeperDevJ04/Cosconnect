
// ============================================
// FILE: transactions-table.tsx
// ============================================
"use client"

import { useState, useMemo } from "react"
import { TransactionFilters } from "./transaction-filters"
import { TransactionRow } from "./transaction-row"
import { Pagination } from "./pagination"
import { Skeleton } from "@/components/ui/skeleton"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useGetTransactionsRentals } from "@/lib/apis/rentalsApi"
import { Package, Download } from "lucide-react"
import { toast } from "sonner"
import jsPDF from 'jspdf'
import autoTable from 'jspdf-autotable'

const ITEMS_PER_PAGE = 10

export function TransactionsTable() {
    const [currentPage, setCurrentPage] = useState(1)

    const [filters, setFilters] = useState({
        search: "",
        status: null as string | null,
        paymentType: null as string | null,
        paymentMethod: null as string | null,
    })

    const [dateRange, setDateRange] = useState({
        startDate: null as string | null,
        endDate: null as string | null,
    })

    const [datePreset, setDatePreset] = useState<"10" | "30" | "60" | "custom">("custom")

    const [pdfPassword, setPdfPassword] = useState("")
    const [showPasswordDialog, setShowPasswordDialog] = useState(false)

    const { transactions, isLoading, isError } = useGetTransactionsRentals()

    const applyDatePreset = (preset: "10" | "30" | "60" | "custom") => {
        if (preset === "custom") {
            setDateRange({ startDate: null, endDate: null })
            return
        }

        const days = Number(preset)
        const today = new Date()
        const start = new Date()
        start.setDate(today.getDate() - days)

        const formatDate = (date: Date) => date.toISOString().slice(0, 10)

        setDateRange({
            startDate: formatDate(start),
            endDate: formatDate(today),
        })
    }

    // Filter transactions based on search, filters, and date range
    const filteredTransactions = useMemo(() => {
        return transactions.filter((transaction) => {
            const searchLower = filters.search.toLowerCase()
            const matchesSearch =
                !filters.search ||
                transaction.referenceCode.toLowerCase().includes(searchLower) ||
                transaction.rental?.renterName?.toLowerCase().includes(searchLower) ||
                transaction.rental?.costumeName?.toLowerCase().includes(searchLower)

            const matchesStatus = !filters.status || transaction.status === filters.status
            const matchesPaymentType = !filters.paymentType || transaction.paymentType === filters.paymentType
            const matchesPaymentMethod = !filters.paymentMethod || transaction.paymentMethod === filters.paymentMethod

            const createdAt = new Date(transaction.createdAt)
            const matchesStartDate = !dateRange.startDate || createdAt >= new Date(dateRange.startDate)
            const matchesEndDate =
                !dateRange.endDate ||
                createdAt <= new Date(new Date(dateRange.endDate).setHours(23, 59, 59, 999))

            return (
                matchesSearch &&
                matchesStatus &&
                matchesPaymentType &&
                matchesPaymentMethod &&
                matchesStartDate &&
                matchesEndDate
            )
        })
    }, [transactions, filters, dateRange])

    // Paginate filtered data
    const paginatedData = useMemo(() => {
        const startIndex = (currentPage - 1) * ITEMS_PER_PAGE
        const endIndex = startIndex + ITEMS_PER_PAGE
        return filteredTransactions.slice(startIndex, endIndex)
    }, [filteredTransactions, currentPage])

    const totalPages = Math.ceil(filteredTransactions.length / ITEMS_PER_PAGE)

    // Reset to page 1 when filters change
    const handleFilterChange = (key: string, value: any) => {
        setCurrentPage(1)
        setFilters((prev) => ({ ...prev, [key]: value }))
    }

    const handleDatePresetChange = (value: string) => {
        const preset: "10" | "30" | "60" | "custom" =
            value === "10" || value === "30" || value === "60" ? value : "custom"

        setCurrentPage(1)
        setDatePreset(preset)
        applyDatePreset(preset)
    }

    const resetFilters = () => {
        setCurrentPage(1)
        setFilters({
            search: "",
            status: null,
            paymentType: null,
            paymentMethod: null,
        })
        setDateRange({
            startDate: null,
            endDate: null,
        })
        setDatePreset("custom")
    }


    const generatePDF = async () => {
        if (filteredTransactions.length === 0) return

        const doc = new jsPDF('landscape')
        const pageWidth = doc.internal.pageSize.getWidth()
        const pageHeight = doc.internal.pageSize.getHeight()

        // Header with background
        doc.setFillColor(41, 128, 185)
        doc.rect(0, 0, pageWidth, 40, 'F')

        // Company/Title
        doc.setTextColor(255, 255, 255)
        doc.setFontSize(24)
        doc.setFont('helvetica', 'bold')
        doc.text('CosConnect Transactions Report', 20, 25)

        // Subtitle
        doc.setFontSize(12)
        doc.setFont('helvetica', 'normal')
        doc.text('Detailed Transaction Records', 20, 35)

        // Reset text color
        doc.setTextColor(0, 0, 0)

        // Report Details Box
        doc.setFillColor(248, 249, 250)
        doc.rect(15, 50, pageWidth - 30, 25, 'F')
        doc.setDrawColor(200, 200, 200)
        doc.rect(15, 50, pageWidth - 30, 25)

        doc.setFontSize(11)
        doc.setFont('helvetica', 'bold')
        doc.text('Report Details:', 20, 60)
        doc.setFont('helvetica', 'normal')
        const dateRangeText = dateRange.startDate && dateRange.endDate
            ? `${dateRange.startDate} to ${dateRange.endDate}`
            : datePreset === "custom" ? "Custom Range" : `Last ${datePreset} days`
        doc.text(`Date Range: ${dateRangeText}`, 20, 68)
        doc.text(`Generated: ${new Date().toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        })}`, pageWidth - 20, 68, { align: 'right' })

        let yPosition = 85

        // Transactions Table
        autoTable(doc, {
            startY: yPosition,
            head: [['Reference', 'Renter', 'Costume', 'Payment Type', 'Payment Method', 'Payment Status', 'Rental Status', 'Amount', 'Date']],
            body: filteredTransactions.map((transaction) => [
                transaction.referenceCode,
                transaction.rental?.renterName || 'N/A',
                transaction.rental?.costumeName || 'N/A',
                transaction.paymentType,
                transaction.paymentMethod,
                transaction.status,
                transaction.rental?.status || 'N/A',
                `PHP ${Math.abs(Number(transaction.amount)).toLocaleString('en-PH')}`,
                new Date(transaction.createdAt).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                })
            ]),
            theme: 'grid',
            styles: {
                fontSize: 7,
                cellPadding: 3,
                lineColor: [200, 200, 200],
                lineWidth: 0.1
            },
            headStyles: {
                fillColor: [41, 128, 185],
                textColor: 255,
                fontStyle: 'bold',
                fontSize: 9
            },
            alternateRowStyles: { fillColor: [248, 249, 250] },
            margin: { left: 15, right: 15 }
        })

        // Footer
        const footerY = pageHeight - 20
        doc.setFillColor(248, 249, 250)
        doc.rect(0, footerY - 5, pageWidth, 15, 'F')
        doc.setDrawColor(200, 200, 200)
        doc.rect(0, footerY - 5, pageWidth, 15)

        doc.setFontSize(8)
        doc.setTextColor(100, 100, 100)
        doc.text('CosConnect Transactions Report - Confidential', 20, footerY + 2)
        doc.text(`Total Records: ${filteredTransactions.length}`, pageWidth - 20, footerY + 2, { align: 'right' })

        // Save the PDF
        const dateLabel = dateRange.startDate && dateRange.endDate
            ? `${dateRange.startDate}_to_${dateRange.endDate}`
            : datePreset === "custom" ? 'custom' : `${datePreset}days`
        const passwordSuffix = pdfPassword ? '_protected' : ''
        doc.save(`transactions-report-${dateLabel}-${new Date().toISOString().split('T')[0]}${passwordSuffix}.pdf`)

        // Reset password
        setPdfPassword("")
    }

    if (isError) {
        return (
            <div className="rounded-lg border border-destructive bg-destructive/10 p-4 text-sm text-destructive">
                Failed to load transactions. Please try again.
            </div>
        )
    }

    return (
        <div className="space-y-6">
            <div className="flex items-start justify-between w-full">
                <div>
                    <h1 className="text-3xl font-bold">Transactions</h1>
                    <p className="text-muted-foreground">
                        Manage and view all rental transactions
                    </p>
                </div>

                <Dialog open={showPasswordDialog} onOpenChange={setShowPasswordDialog}>
                    <DialogTrigger asChild>
                        <Button
                            variant="outline"
                            className="self-start"
                            disabled={isLoading || filteredTransactions.length === 0}
                        >
                            <Download className="h-4 w-4 mr-2" />
                            Export PDF
                        </Button>
                    </DialogTrigger>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>Export PDF Report</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                            <div>
                                <Label htmlFor="pdf-password">Password (optional)</Label>
                                <Input
                                    id="pdf-password"
                                    type="password"
                                    value={pdfPassword}
                                    onChange={(e) => setPdfPassword(e.target.value)}
                                    placeholder="Enter password to protect PDF"
                                />
                                <p className="text-sm text-muted-foreground mt-1">
                                    Leave empty for no password protection
                                </p>
                            </div>
                        </div>
                        <DialogFooter>
                            <Button variant="outline" onClick={() => setShowPasswordDialog(false)}>
                                Cancel
                            </Button>
                            <Button onClick={() => {
                                generatePDF()
                                setShowPasswordDialog(false)
                            }}>
                                Export
                            </Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>
            </div>
            {/* Filters */}
            <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                <div className="flex-1">
                    <TransactionFilters
                        search={filters.search}
                        status={filters.status}
                        paymentType={filters.paymentType}
                        paymentMethod={filters.paymentMethod}
                        startDate={dateRange.startDate}
                        endDate={dateRange.endDate}
                        datePreset={datePreset}
                        onSearchChange={(value) => handleFilterChange("search", value)}
                        onStatusChange={(value) => handleFilterChange("status", value)}
                        onPaymentTypeChange={(value) => handleFilterChange("paymentType", value)}
                        onPaymentMethodChange={(value) => handleFilterChange("paymentMethod", value)}
                        onStartDateChange={(value) =>
                            setDateRange((prev) => ({
                                ...prev,
                                startDate: value,
                            }))
                        }
                        onEndDateChange={(value) =>
                            setDateRange((prev) => ({
                                ...prev,
                                endDate: value,
                            }))
                        }
                        onDatePresetChange={handleDatePresetChange}
                        onReset={resetFilters}
                    />
                </div>
            </div>

            {/* Results Count */}
            {!isLoading && (
                <div className="text-sm text-muted-foreground">
                    Showing {paginatedData.length > 0 ? (currentPage - 1) * ITEMS_PER_PAGE + 1 : 0} to{" "}
                    {Math.min(currentPage * ITEMS_PER_PAGE, filteredTransactions.length)} of {filteredTransactions.length}{" "}
                    transactions
                </div>
            )}

            {/* Table */}
            <div className="overflow-x-auto rounded-lg border border-border">
                <table className="w-full">
                    <thead className="border-b border-border bg-muted/50">
                        <tr>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider">Reference</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider">Renter</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider">Costume</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider">Payment Type</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider">Payment Method</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider">Payment Status</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider">Rental Status</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider">Amount</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider">Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        {isLoading ? (
                            Array.from({ length: ITEMS_PER_PAGE }).map((_, i) => (
                                <tr key={i} className="border-b border-border">
                                    {Array.from({ length: 9 }).map((_, j) => (
                                        <td key={j} className="px-4 py-3">
                                            <Skeleton className="h-4 w-full" />
                                        </td>
                                    ))}
                                </tr>
                            ))
                        ) : paginatedData.length > 0 ? (
                            paginatedData.map((transaction) => <TransactionRow key={transaction.id} transaction={transaction} />)
                        ) : (
                            <tr>
                                <td colSpan={9} className="px-4 py-12">
                                    <div className="flex flex-col items-center justify-center text-center">
                                        <Package className="h-12 w-12 text-muted-foreground/50 mb-3" />
                                        <h3 className="text-sm font-medium text-foreground mb-1">No transactions found</h3>
                                        <p className="text-sm text-muted-foreground">
                                            {filters.search || filters.status || filters.paymentType || filters.paymentMethod
                                                ? "Try adjusting your filters to find what you're looking for."
                                                : "Transactions will appear here once they are created."}
                                        </p>
                                    </div>
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>

            {/* Pagination */}
            {!isLoading && totalPages > 1 && (
                <Pagination
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={setCurrentPage}
                    isLoading={isLoading}
                />
            )}
        </div>
    )
}