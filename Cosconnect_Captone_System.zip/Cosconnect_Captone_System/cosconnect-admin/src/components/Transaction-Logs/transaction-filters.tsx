"use client"

import { Search, X } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface TransactionFiltersProps {
  search: string
  status: string | null
  paymentType: string | null
  paymentMethod: string | null
  startDate: string | null
  endDate: string | null
  datePreset: string
  onSearchChange: (value: string) => void
  onStatusChange: (value: string | null) => void
  onPaymentTypeChange: (value: string | null) => void
  onPaymentMethodChange: (value: string | null) => void
  onStartDateChange: (value: string | null) => void
  onEndDateChange: (value: string | null) => void
  onDatePresetChange: (value: string) => void
  onReset: () => void
}

// Payment Status Options (from API)
const STATUS_OPTIONS = [
  { value: "paid", label: "Paid" },
  { value: "pending", label: "Pending" },
  { value: "failed", label: "Failed" },
  { value: "refunded", label: "Refunded" },
  { value: "cancelled", label: "Cancelled" },
]

// Payment Type Options (from API)
const PAYMENT_TYPE_OPTIONS = [
  { value: "rental_fee", label: "Rental Fee" },
  { value: "security_deposit", label: "Security Deposit" },
  { value: "extension_fee", label: "Extension Fee" },
  { value: "damage_cost", label: "Damage Cost" },
]

// Payment Method Options (from API)
const PAYMENT_METHOD_OPTIONS = [
  { value: "paymaya", label: "PayMaya" },
  { value: "gcash", label: "GCash" },
]

export function TransactionFilters({
  search,
  status,
  paymentType,
  paymentMethod,
  startDate,
  endDate,
  datePreset,
  onSearchChange,
  onStatusChange,
  onPaymentTypeChange,
  onPaymentMethodChange,
  onStartDateChange,
  onEndDateChange,
  onDatePresetChange,
  onReset,
}: TransactionFiltersProps) {
  const hasActiveFilters = search || status || paymentType || paymentMethod || startDate || endDate

  return (
    <div className="space-y-4 rounded-lg border border-border bg-card p-4">
      {/* Search Input */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Search by reference, renter name, costume..."
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Filter Selects */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <Select value={datePreset} onValueChange={onDatePresetChange}>
          <SelectTrigger>
            <SelectValue placeholder="Date range" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="10">Last 10 days</SelectItem>
            <SelectItem value="30">Last 30 days</SelectItem>
            <SelectItem value="60">Last 60 days</SelectItem>
            <SelectItem value="custom">Custom range</SelectItem>
          </SelectContent>
        </Select>
        <Input
          type="date"
          value={startDate || ""}
          onChange={(e) => onStartDateChange(e.target.value || null)}
          disabled={datePreset !== "custom"}
        />
        <Input
          type="date"
          value={endDate || ""}
          onChange={(e) => onEndDateChange(e.target.value || null)}
          disabled={datePreset !== "custom"}
        />

        {/* Payment Status Filter */}
        <Select value={status || "all"} onValueChange={(v) => onStatusChange(v === "all" ? null : v)}>
          <SelectTrigger>
            <SelectValue placeholder="All Payment Statuses" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Payment Statuses</SelectItem>
            {STATUS_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Payment Type Filter */}
        <Select value={paymentType || "all"} onValueChange={(v) => onPaymentTypeChange(v === "all" ? null : v)}>
          <SelectTrigger>
            <SelectValue placeholder="All Payment Types" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Payment Types</SelectItem>
            {PAYMENT_TYPE_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Payment Method Filter */}
        <Select value={paymentMethod || "all"} onValueChange={(v) => onPaymentMethodChange(v === "all" ? null : v)}>
          <SelectTrigger>
            <SelectValue placeholder="All Payment Methods" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Payment Methods</SelectItem>
            {PAYMENT_METHOD_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Reset Button */}
        {hasActiveFilters && (
          <Button variant="outline" onClick={onReset} className="gap-2 bg-transparent">
            <X className="h-4 w-4" />
            Reset Filters
          </Button>
        )}
      </div>
    </div>
  )
}