import type React from "react"

interface DataRowProps {
    label: string
    children: React.ReactNode
    className?: string
}

const DataRow: React.FC<DataRowProps> = ({ label, children, className = "" }) => (
    <div className={`flex items-center justify-between ${className}`}>
        <span className="text-sm text-muted-foreground">{label}:</span>
        <span className="text-sm font-medium">{children}</span>
    </div>
)

export default DataRow
