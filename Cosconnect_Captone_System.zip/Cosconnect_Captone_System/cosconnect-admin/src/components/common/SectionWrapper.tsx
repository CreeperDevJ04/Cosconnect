"use client"

import type React from "react"
import { ChevronDown, ChevronUp } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

interface SectionWrapperProps {
    title: string
    icon?: React.ReactNode
    children: React.ReactNode
    expanded?: boolean
    toggle?: () => void
}

const SectionWrapper: React.FC<SectionWrapperProps> = ({ title, icon, children, expanded = true, toggle }) => (
    <Card>
        <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2 text-base">
                    {icon}
                    {title}
                </CardTitle>
                {toggle && (
                    <Button variant="ghost" size="icon" onClick={toggle} className="h-8 w-8">
                        {expanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                )}
            </div>
        </CardHeader>
        {expanded && <CardContent>{children}</CardContent>}
    </Card>
)

export default SectionWrapper
