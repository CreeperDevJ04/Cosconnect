"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useSupabaseAuth } from "@/lib/hooks/useSupabaseAuth"
import useSelectedPostStore from "@/lib/zustand/selectedPostStore"
import { Loader2, Search, X } from "lucide-react"
import { Suspense, useCallback, useEffect, useMemo, useRef, useState } from "react"
import { Skeleton } from "@/components/ui/skeleton"

import { usePathname, useRouter, useSearchParams } from "next/navigation"
import { useGetAllPosts } from "@/lib/apis/communityApi"
import { ErrorStatePosts } from "./components/ErrorStatsPosts"
import CreatePostForm from "./components/CreatePostForm"
import PostCard from "./components/PostCard"
import PostPagination from "./components/PostsPagination"

// Types
export type LenderInfo = {
    business_name: string
    business_type: string
    business_profile_image: string | null
}

export type BorrowerInfo = {
    fullname: string
    profile_image: string
    current_role: string
}

export type PostItem = {
    id: string
    author_id: string
    author_name: string
    author_role: string
    author_avatar: string
    content: string
    images: string[]
    is_for_sale: boolean
    heart_count: number
    likes: number
    is_liked: boolean
    created_at: string
    updated_at: string
    comment_count: number
    lender_info?: LenderInfo
    borrower_info?: BorrowerInfo
}

export type PaginationMeta = {
    current_page: number
    per_page: number
    total: number
    total_pages: number
    has_next_page: boolean
    has_previous_page: boolean
}

export type Filters = {
    search: string | null
    onlyForSale: boolean
}

export type AllPostsResponse = {
    success: boolean
    data: PostItem[]
    pagination: PaginationMeta
    filters: Filters
}

// Transform for PostCard
const transformPostForCard = (post: any) => ({
    id: post.id,
    content: post.content,
    images: post.images,
    created_at: post.created_at,
    updated_at: post.updated_at,
    heart_count: post.heart_count,
    is_liked: post.is_liked,
    comment_count: post.comment_count,
    author_id: post.author_id,
    author_name: post.author_name,
    author_avatar: post.author_avatar,
    author_role: post.author_role,
    is_for_sale: post.is_for_sale,
    lender_info: post.lender_info,
    borrower_info: post.borrower_info,
})

const DEFAULT_POSTS_PER_PAGE = 10

const SocialFeedSection = () => {
    const searchParams = useSearchParams()
    const router = useRouter()
    const pathname = usePathname()
    const { isLoading: isAuthLoading, adminData, isAuthenticated } = useSupabaseAuth()
    const setSelectedPost = useSelectedPostStore((state) => state.setSelectedPost)

    const urlParams = useMemo(
        () => ({
            query: searchParams.get("q") || "",
            sale: searchParams.get("sale") === "true",
            page: Number.parseInt(searchParams.get("page") || "1", 10),
            postId: searchParams.get("postId") || undefined,
        }),
        [searchParams],
    )

    const [searchInput, setSearchInput] = useState(urlParams.query)
    const [appliedSearch, setAppliedSearch] = useState(urlParams.query)
    const [appliedForSale, setAppliedForSale] = useState(urlParams.sale)
    const [forSaleCheckbox, setForSaleCheckbox] = useState(urlParams.sale)
    const [currentPage, setCurrentPage] = useState(urlParams.page)
    const [postsPerPage, setPostsPerPage] = useState(DEFAULT_POSTS_PER_PAGE)

    const sentinelRef = useRef<HTMLDivElement | null>(null)
    const isInitializedRef = useRef(false)

    useEffect(() => {
        if (urlParams.query !== appliedSearch || urlParams.sale !== appliedForSale || urlParams.page !== currentPage) {
            setSearchInput(urlParams.query)
            setAppliedSearch(urlParams.query)
            setForSaleCheckbox(urlParams.sale)
            setAppliedForSale(urlParams.sale)
            setCurrentPage(urlParams.page)
            isInitializedRef.current = true
        }
    }, [urlParams.query, urlParams.sale, urlParams.page, appliedSearch, appliedForSale, currentPage])

    const {
        allPosts: posts,
        pagination,
        isLoading,
        error,
        refetch,
        isRefetching,
    } = useGetAllPosts({
        limit: postsPerPage,
        page: currentPage,
        search: appliedSearch,
        onlyForSale: appliedForSale,
        postId: urlParams.postId,
        user_id: adminData?.user_id,
        user_role: adminData?.current_role,
    })

    // Previously: useEffect(() => { if (posts) { setDisplayPosts(posts); } }, [posts]);
    // Now: Use posts directly instead of displayPosts state

    const updateURL = useCallback(
        (params: { query?: string; sale?: boolean; page?: number }) => {
            const currentParams = new URLSearchParams(window.location.search)

            if (params.query !== undefined) {
                params.query ? currentParams.set("q", params.query) : currentParams.delete("q")
            }

            if (params.sale !== undefined) {
                params.sale ? currentParams.set("sale", "true") : currentParams.delete("sale")
            }

            if (params.page !== undefined) {
                params.page > 1 ? currentParams.set("page", params.page.toString()) : currentParams.delete("page")
            }

            const newUrl = `${pathname}?${currentParams.toString()}`
            router.push(newUrl, { scroll: false })
        },
        [pathname, router],
    )

    const handleSearch = useCallback(
        (e: React.FormEvent) => {
            e.preventDefault()

            setAppliedSearch(searchInput)
            setAppliedForSale(forSaleCheckbox)
            setCurrentPage(1)

            updateURL({
                query: searchInput,
                sale: forSaleCheckbox,
                page: 1,
            })
        },
        [searchInput, forSaleCheckbox, updateURL],
    )

    const handleClearFilters = useCallback(() => {
        setSearchInput("")
        setAppliedSearch("")
        setForSaleCheckbox(false)
        setAppliedForSale(false)
        setCurrentPage(1)
        updateURL({ query: "", sale: false, page: 1 })
    }, [updateURL])

    const handleSelectPost = useCallback(
        (post: PostItem) => {
            setSelectedPost(transformPostForCard(post))
        },
        [setSelectedPost],
    )

    const handleRefresh = useCallback(() => {
        refetch()
    }, [refetch])

    const handlePageChange = useCallback(
        (page: number) => {
            setCurrentPage(page)
            updateURL({ page })
            window.scrollTo({ top: 0, behavior: "smooth" })
        },
        [updateURL],
    )

    const handleItemsPerPageChange = useCallback(
        (newItemsPerPage: number) => {
            setPostsPerPage(newItemsPerPage)
            setCurrentPage(1)
            updateURL({ page: 1 })
        },
        [updateURL],
    )

    const handlePostCreated = useCallback(
        (newPost: PostItem) => {
            // Refetch to sync with server instead of managing local state
            const timeoutId = setTimeout(() => {
                refetch()
            }, 500)

            return () => clearTimeout(timeoutId)
        },
        [refetch],
    )

    const hasActiveFilters = useMemo(() => Boolean(appliedSearch || appliedForSale), [appliedSearch, appliedForSale])

    // Loading state
    if (isAuthLoading || (isLoading && currentPage === 1 && (!posts || posts.length === 0))) {
        return (
            <div className="flex justify-center items-center h-64 w-full">
                <Loader2 className="h-8 w-8 animate-spin text-gray-500" />
            </div>
        )
    }

    // Error state
    if (error) {
        return <ErrorStatePosts handleRefersh={handleRefresh} isRefetching={isRefetching} />
    }

    return (
        <Suspense fallback={<Loader2 className="animate-spin h-5 w-5" />}>
            <div className="w-full max-w-2xl mx-auto py-6 px-2 sm:px-4 md:px-6 bg-gray-50 min-h-screen">
                {/* Search / Filter Form */}
                <form onSubmit={handleSearch} className="mb-6 bg-white rounded-lg shadow-sm border border-gray-200 p-4">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
                        <div className="flex-1 w-full">
                            <Input
                                type="text"
                                placeholder="Search posts..."
                                value={searchInput}
                                onChange={(e) => setSearchInput(e.target.value)}
                                className="w-full"
                            />
                        </div>
                        <label className="flex items-center gap-2 text-sm text-gray-700 whitespace-nowrap">
                            <input
                                type="checkbox"
                                checked={forSaleCheckbox}
                                onChange={(e) => setForSaleCheckbox(e.target.checked)}
                                className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500 h-4 w-4"
                            />
                            <span>For Sale Only</span>
                        </label>
                        <div className="flex items-center gap-2">
                            <Button type="submit" size="sm" className="flex items-center gap-1">
                                <Search className="h-4 w-4" />
                                Search
                            </Button>
                            {hasActiveFilters && (
                                <Button
                                    type="button"
                                    variant="ghost"
                                    size="sm"
                                    onClick={handleClearFilters}
                                    className="flex items-center gap-1"
                                >
                                    <X className="h-4 w-4" />
                                    Clear
                                </Button>
                            )}
                        </div>
                    </div>

                    {/* Active filters indicator */}
                    {hasActiveFilters && (
                        <div className="mt-3 flex flex-wrap gap-2">
                            {appliedSearch && (
                                <span className="inline-flex items-center gap-1 px-2 py-1 bg-indigo-50 text-indigo-700 text-xs rounded-md">
                                    Search: "{appliedSearch}"
                                </span>
                            )}
                            {appliedForSale && (
                                <span className="inline-flex items-center gap-1 px-2 py-1 bg-indigo-50 text-indigo-700 text-xs rounded-md">
                                    For Sale Only
                                </span>
                            )}
                        </div>
                    )}
                </form>

                {/* Create Post Form */}
                <div className="mb-8 bg-white rounded-lg shadow-sm border border-gray-200 p-4">
                    <CreatePostForm adminData={adminData} isAuthenticated={isAuthenticated} onPostCreated={handlePostCreated} />
                </div>

                {/* Page loading indicator */}
                {isLoading && currentPage > 1 && (
                    <div className="flex justify-center py-8 mb-4">
                        <div className="flex items-center space-x-2 text-gray-500">
                            <Loader2 className="h-5 w-5 animate-spin" />
                            <span className="text-sm">Loading page {currentPage}...</span>
                        </div>
                    </div>
                )}

                {/* Posts */}
                <div className="space-y-4 mb-8">
                    {posts && posts.length > 0 ? (
                        <>
                            {posts.map((post: any) => (
                                <div
                                    key={post.id}
                                    onClick={() => handleSelectPost(post)}
                                    className="cursor-pointer transition-transform hover:scale-[1.01] duration-200"
                                >
                                    <PostCard post={post as any} refetch={handleRefresh} />
                                </div>
                            ))}
                            {isRefetching && (
                                <div className="flex justify-center py-4">
                                    <div className="flex items-center space-x-2 text-gray-500">
                                        <Loader2 className="h-5 w-5 animate-spin" />
                                        <span className="text-sm">Refreshing posts...</span>
                                    </div>
                                </div>
                            )}
                            {/* Infinite scroll sentinel */}
                            <div ref={sentinelRef} className="h-6" />
                        </>
                    ) : (
                        !isLoading && (
                            <div className="text-center py-16 text-gray-500 bg-white rounded-lg shadow-sm border border-gray-200">
                                <div className="space-y-3">
                                    <p className="text-xl font-medium">No posts found</p>
                                    <p className="text-sm text-gray-400">
                                        {hasActiveFilters ? "Try adjusting your search or filters." : "Be the first to create a post!"}
                                    </p>
                                    {hasActiveFilters && (
                                        <Button variant="outline" size="sm" onClick={handleClearFilters} className="mt-4 bg-transparent">
                                            <X className="h-4 w-4 mr-2" />
                                            Clear Filters
                                        </Button>
                                    )}
                                </div>
                            </div>
                        )
                    )}
                </div>

                {/* Pagination */}
                {pagination && pagination.total_pages > 1 && (
                    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
                        <PostPagination
                            currentPage={pagination.current_page}
                            totalPages={pagination.total_pages}
                            totalItems={pagination.total}
                            itemsPerPage={pagination.per_page}
                            onPageChange={handlePageChange}
                            onItemsPerPageChange={handleItemsPerPageChange}
                            isLoading={isLoading || isRefetching}
                            className="w-full"
                        />
                    </div>
                )}

                {/* Pagination Info */}
                {pagination && pagination.total_pages > 1 && (
                    <div className="mt-4 text-center text-sm text-gray-500 sm:hidden">
                        Page {pagination.current_page} of {pagination.total_pages}
                    </div>
                )}

                {pagination && (
                    <div className="mt-4 text-center text-xs text-gray-400">
                        Showing {(pagination.current_page - 1) * pagination.per_page + 1} to{" "}
                        {Math.min(pagination.current_page * pagination.per_page, pagination.total)} of {pagination.total} posts
                    </div>
                )}
            </div>
        </Suspense>
    )
}

export default SocialFeedSection
