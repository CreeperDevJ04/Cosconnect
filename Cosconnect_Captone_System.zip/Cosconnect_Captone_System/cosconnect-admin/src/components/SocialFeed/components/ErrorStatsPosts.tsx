import { Button } from "@/components/ui/button"
import { Loader2, RefreshCw } from "lucide-react"


export const ErrorStatePosts = ({ handleRefresh, isRefetching, }: any) => {

    return (
        <>
            <div className="flex flex-col justify-center items-center h-64 space-y-4">
                <div className="text-center">
                    <p className="text-red-500 text-lg font-medium mb-2">
                        Error loading posts
                    </p>
                    <p className="text-gray-600 text-sm">
                        Something went wrong while fetching the posts. Please try again.
                    </p>
                </div>
                <Button
                    onClick={handleRefresh}
                    disabled={isRefetching}
                    className="px-6 py-2"
                >
                    {isRefetching ? (
                        <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Retrying...
                        </>
                    ) : (
                        <>
                            <RefreshCw className="h-4 w-4 mr-2" />
                            Retry
                        </>
                    )}
                </Button>
            </div>

        </>
    )
}