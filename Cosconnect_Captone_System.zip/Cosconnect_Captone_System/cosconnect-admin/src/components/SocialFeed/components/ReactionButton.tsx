// ==================== ADD THESE IMPORTS AT THE TOP ====================
import { memo, useCallback, useMemo, useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from 'framer-motion';
import {
    Heart,
    ThumbsUp,
    Laugh,
    Frown,
    Angry,
    MessageCircle,
    Loader2,
    // ... rest of your existing imports
} from "lucide-react";
import { Button } from "@/components/ui/button";

// ==================== ADD THESE CONFIGS & TYPES (BEFORE PostCard component) ====================
const REACTIONS = [
    { type: 'like', icon: ThumbsUp, color: 'text-rose-500', bgColor: 'bg-rose-50', label: 'Like' },
    { type: 'love', icon: Heart, color: 'text-red-500', bgColor: 'bg-red-50', label: 'Love' },
    { type: 'haha', icon: Laugh, color: 'text-amber-500', bgColor: 'bg-amber-50', label: 'Haha' },
    { type: 'sad', icon: Frown, color: 'text-blue-500', bgColor: 'bg-blue-50', label: 'Sad' },
    { type: 'angry', icon: Angry, color: 'text-orange-500', bgColor: 'bg-orange-50', label: 'Angry' },
] as const;

type ReactionType = typeof REACTIONS[number]['type'];

// ==================== CUSTOM HOOK ====================
const useReactionPicker = () => {
    const [showPicker, setShowPicker] = useState(false);
    const [isHovering, setIsHovering] = useState(false);
    const hoverTimeoutRef = useRef<NodeJS.Timeout | null>(null);
    const longPressTimeoutRef = useRef<NodeJS.Timeout | null>(null);
    const [isLongPress, setIsLongPress] = useState(false);

    const handleMouseEnter = () => {
        setIsHovering(true);
        hoverTimeoutRef.current = setTimeout(() => {
            setShowPicker(true);
        }, 400);
    };

    const handleMouseLeave = () => {
        setIsHovering(false);
        if (hoverTimeoutRef.current) {
            clearTimeout(hoverTimeoutRef.current);
        }
        setTimeout(() => {
            if (!isHovering) setShowPicker(false);
        }, 150);
    };

    const handleTouchStart = () => {
        setIsLongPress(false);
        longPressTimeoutRef.current = setTimeout(() => {
            setIsLongPress(true);
            setShowPicker(true);
        }, 500);
    };

    const handleTouchEnd = () => {
        if (longPressTimeoutRef.current) {
            clearTimeout(longPressTimeoutRef.current);
        }
    };

    const closePicker = () => {
        setShowPicker(false);
        setIsHovering(false);
    };

    useEffect(() => {
        return () => {
            if (hoverTimeoutRef.current) clearTimeout(hoverTimeoutRef.current);
            if (longPressTimeoutRef.current) clearTimeout(longPressTimeoutRef.current);
        };
    }, []);

    return {
        showPicker,
        isLongPress,
        handleMouseEnter,
        handleMouseLeave,
        handleTouchStart,
        handleTouchEnd,
        closePicker,
    };
};

// ==================== REACTION PICKER COMPONENT ====================
interface ReactionPickerProps {
    onSelect: (reactionType: ReactionType) => void;
    isOpen: boolean;
    onMouseEnter: () => void;
    onMouseLeave: () => void;
}

const ReactionPicker = memo(({ onSelect, isOpen, onMouseEnter, onMouseLeave }: ReactionPickerProps) => {
    return (
        <AnimatePresence>
            {isOpen && (
                <motion.div
                    initial={{ opacity: 0, y: 8, scale: 0.9 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 8, scale: 0.9 }}
                    transition={{ duration: 0.15, ease: [0.4, 0, 0.2, 1] }}
                    onMouseEnter={onMouseEnter}
                    onMouseLeave={onMouseLeave}
                    className="absolute bottom-full left-0 mb-2 bg-white rounded-full shadow-2xl border border-rose-100 px-2 sm:px-3 py-2 sm:py-2.5 flex items-center gap-0.5 sm:gap-1 z-50"
                >
                    {REACTIONS.map((reaction) => {
                        const Icon = reaction.icon;
                        return (
                            <motion.button
                                key={reaction.type}
                                onClick={(e) => {
                                    e.stopPropagation();
                                    onSelect(reaction.type);
                                }}
                                whileHover={{ scale: 1.3, y: -6 }}
                                whileTap={{ scale: 0.95 }}
                                transition={{ type: 'spring', stiffness: 500, damping: 20 }}
                                className={`relative p-2 sm:p-2.5 rounded-full ${reaction.bgColor} hover:shadow-md transition-shadow group`}
                                aria-label={reaction.label}
                            >
                                <Icon className={`h-4 w-4 sm:h-5 sm:w-5 ${reaction.color}`} strokeWidth={2.5} />
                                <span className="absolute -top-8 sm:-top-9 left-1/2 -translate-x-1/2 bg-gray-900 text-white text-xs px-2 sm:px-2.5 py-1 rounded-md whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none hidden sm:block">
                                    {reaction.label}
                                </span>
                            </motion.button>
                        );
                    })}
                </motion.div>
            )}
        </AnimatePresence>
    );
});

ReactionPicker.displayName = "ReactionPicker";

// ==================== REACTION BUTTON COMPONENT ====================
interface ReactionButtonProps {
    userReaction: ReactionType | null;

    onReact: (reactionType: ReactionType | 'unreact') => void;
    isLoading: boolean;
}

const ReactionButton = memo(({ userReaction, onReact, isLoading }: ReactionButtonProps) => {
    const {
        showPicker,
        isLongPress,
        handleMouseEnter,
        handleMouseLeave,
        handleTouchStart,
        handleTouchEnd,
        closePicker,
    } = useReactionPicker();

    const currentReaction = REACTIONS.find(r => r.type === userReaction);
    const Icon = currentReaction?.icon || Heart;
    const color = currentReaction?.color || 'text-gray-600';

    const handleReactionSelect = (reactionType: ReactionType) => {
        onReact(reactionType);
        closePicker();
    };

    const handleClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        if (!isLongPress) {
            if (userReaction) {
                onReact('unreact');
            } else {
                onReact('like');
            }
        }
    };

    return (
        <div className="relative">
            <Button
                variant="ghost"
                size="sm"
                onMouseEnter={handleMouseEnter}
                onMouseLeave={handleMouseLeave}
                onTouchStart={handleTouchStart}
                onTouchEnd={handleTouchEnd}
                onClick={handleClick}
                disabled={isLoading}
                className={`flex items-center gap-1.5 sm:gap-2 transition-all duration-200 px-2 sm:px-3 py-1.5 sm:py-2 rounded-lg hover:bg-rose-50 ${userReaction ? color : 'text-gray-600 hover:text-rose-600'
                    }`}
            >
                {isLoading ? (
                    <Loader2 className="h-4 w-4 sm:h-5 sm:w-5 animate-spin" />
                ) : (
                    <motion.div
                        key={userReaction || 'default'}
                        initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        transition={{ type: 'spring', stiffness: 500, damping: 25 }}
                    >
                        <Icon
                            className={`h-4 w-4 sm:h-5 sm:w-5 transition-all duration-200 ${userReaction ? 'fill-current' : ''
                                }`}
                            strokeWidth={2.5}
                        />
                    </motion.div>
                )}


                {userReaction && (
                    <span className="text-xs font-medium hidden sm:inline">
                        {currentReaction?.label}
                    </span>
                )}
            </Button>

            <ReactionPicker
                onSelect={handleReactionSelect}
                isOpen={showPicker}
                onMouseEnter={handleMouseEnter}
                onMouseLeave={handleMouseLeave}
            />
        </div>
    );
});

export default ReactionButton

ReactionButton.displayName = "ReactionButton";