
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import { Textarea } from '@/components/ui/textarea'
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip'
import { useCommentOnPost, useDeleteMyComment, useGetCommentsOnPost } from '@/lib/apis/communityApi'
import { useSupabaseAuth } from '@/lib/hooks/useSupabaseAuth'
import { cn } from '@/lib/utils'
import { uploadMultipleImages } from '@/lib/utils/supabase/fileUpload'

import { zodResolver } from '@hookform/resolvers/zod'
import { Heart, Image as ImageIcon, Loader2, MessageCircle, Reply, Send, Trash2, X } from 'lucide-react'
import Image from 'next/image'
import React, { useCallback, useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { toast } from 'sonner'
import { z } from 'zod'

const commentSchema = z.object({
    content: z.string().min(1, "Comment cannot be empty").max(500, "Comment too long"),
    images: z.array(z.string()).max(3, "Maximum 3 images allowed").optional()
})

type CommentFormData = z.infer<typeof commentSchema>

interface CommentDialogProps {
    post: any
    isOpen: boolean
    onClose: () => void
    formatTimeAgo: (date: Date) => string
    checkAuthentication: () => boolean
    refetch?: any
}

const CommentDialog: React.FC<CommentDialogProps> = ({
    post,
    isOpen,
    onClose,
    formatTimeAgo,
    checkAuthentication,
    refetch
}) => {

    const [isCommenting, setIsCommenting] = useState(false)
    const [selectedImages, setSelectedImages] = useState<string[]>([])
    const [previewImages, setPreviewImages] = useState<string[]>([])
    const [imagesLoading, setImagesLoading] = useState(false)
    const [isPostLoading, setIsPostLoading] = useState(true)
    const [replyingTo, setReplyingTo] = useState<any>(null)

    const { adminData } = useSupabaseAuth()
    const { commentOnPost } = useCommentOnPost()
    const { comments, isLoading: commentsLoading, refetch: refetchComments } = useGetCommentsOnPost({ post_id: post.id })

    const {
        register,
        handleSubmit,
        watch,
        setValue,
        reset,
        formState: { errors, isValid }
    } = useForm<CommentFormData>({
        resolver: zodResolver(commentSchema),
        defaultValues: { content: '', images: [] }
    })

    const watchedContent = watch('content')
    const hasReachedImageLimit = selectedImages.length >= 3
    const isOwnPost = adminData && post?.author?.id && adminData.id === post.author.id
    const replyAvatarUrl = adminData?.profileImage || ''
    const replyName = adminData?.username || 'You'

    useEffect(() => {
        if (isOpen) {
            setIsPostLoading(true)
            const timer = setTimeout(() => setIsPostLoading(false), 800)
            return () => clearTimeout(timer)
        }
    }, [isOpen])

    const handleImageUpload = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
        const files = event.target.files
        if (!files || files.length === 0) return

        if (selectedImages.length + files.length > 3) {
            toast.error("Maximum 3 images allowed")
            return
        }

        setImagesLoading(true)
        const newPreviews: string[] = []

        try {
            const imagePromises = Array.from(files).map(file => {
                return new Promise<void>((resolve) => {
                    if (!file.type.startsWith('image/')) {
                        resolve()
                        return
                    }

                    const reader = new FileReader()
                    reader.onload = (e) => {
                        const result = e.target?.result as string
                        if (result) newPreviews.push(result)
                        resolve()
                    }
                    reader.onerror = () => resolve()
                    reader.readAsDataURL(file)
                })
            })

            await Promise.all(imagePromises)

            if (newPreviews.length > 0) {
                const uploadResult = await uploadMultipleImages(
                    Array.from(files).filter(file => file.type.startsWith('image/'))
                )

                if (uploadResult.allSuccessful) {
                    const uploadedUrls = uploadResult.successful.map((result: any) => result.url as string)
                    setPreviewImages(prev => [...prev, ...newPreviews])
                    setSelectedImages(prev => [...prev, ...uploadedUrls])
                    setValue('images', [...selectedImages, ...uploadedUrls])
                } else {
                    toast.error("Failed to upload some images")
                }
            }
        } catch (error) {
            console.error('Error uploading images:', error)
            toast.error('Failed to upload images')
        } finally {
            setImagesLoading(false)
        }
    }, [selectedImages, setValue])

    const removeImage = useCallback((index: number) => {
        const newImages = selectedImages.filter((_, i) => i !== index)
        const newPreviews = previewImages.filter((_, i) => i !== index)
        setSelectedImages(newImages)
        setPreviewImages(newPreviews)
        setValue('images', newImages)
    }, [selectedImages, previewImages, setValue])

    const onSubmit = async (data: CommentFormData) => {
        if (!checkAuthentication() || isCommenting || !adminData) return

        setIsCommenting(true)
        try {
            const payload = {
                post_id: post.id,
                parent_comment_id: replyingTo?.id || null,
                commenter: {
                    user_id: adminData.id,
                    username: adminData.username,
                    user_avatar_url: adminData.profileImage || 'https://img.freepik.com/premium-vector/default-avatar-profile-icon-social-media-user-image-gray-avatar-icon-blank-profile-silhouette-vector-illustration_561158-3383.jpg'
                },
                comment: {
                    content: data.content,
                    images: data.images || []
                }
            }
            console.log("payload", payload)
            await commentOnPost(payload)
            refetch?.()
            refetchComments()
            reset()
            setSelectedImages([])
            setPreviewImages([])
            setReplyingTo(null)
            toast.success(replyingTo ? 'Reply posted' : 'Comment posted')
        } catch (error: any) {
            console.error(error)
            toast.error(error.message || 'Failed to post comment')
        } finally {
            setIsCommenting(false)
        }
    }

    const handleDialogClose = useCallback(() => {
        if (!isCommenting) onClose()
    }, [isCommenting, onClose])

    const handleReply = (comment: any) => {
        setReplyingTo(comment)
        setValue('content', `@${comment.author_name} `)
    }

    const cancelReply = () => {
        setReplyingTo(null)
        setValue('content', '')
    }

    return (
        <Dialog open={isOpen} onOpenChange={handleDialogClose}>
            <DialogContent className="max-w-6xl w-[95vw] p-0 overflow-hidden max-h-[90vh]">
                <div className="flex flex-col md:flex-row h-[calc(90vh-80px)]">
                    {/* Left Side - Post Image */}
                    <div className="w-full md:w-1/2 bg-black flex items-center justify-center border-b md:border-b-0 md:border-r">
                        {isPostLoading ? (
                            <Skeleton className="w-full h-full" />
                        ) : post.images?.length > 0 ? (
                            <div className="relative w-full h-full flex items-center justify-center">
                                <Image
                                    src={post.images[0]}
                                    alt="Post image"
                                    width={600}
                                    height={600}
                                    className="max-w-full max-h-full object-contain"
                                />
                            </div>
                        ) : (
                            <div className="flex flex-col items-center justify-center text-gray-400 space-y-3 p-4 text-center">
                                <MessageCircle size={64} />
                                <p className="text-lg">No image in this post</p>
                                <p className="text-sm text-gray-500">This post contains only text content</p>
                            </div>
                        )}
                    </div>

                    {/* Right Side - Comments and Form */}
                    <div className="w-full md:w-1/2 flex flex-col bg-white">
                        {/* Post Info Header */}
                        <div className="p-4 border-b bg-white rounded-2xl shadow-sm hover:shadow-md transition">
                            {/* Author Info */}
                            <div className="flex items-center gap-3">
                                <Avatar className="h-10 w-10">
                                    <AvatarImage
                                        src={post.author_info?.profile_image || post.author_avatar || ""}
                                        alt={post.author_name}
                                    />
                                    <AvatarFallback>
                                        {post.author_name
                                            ?.split(" ")
                                            .map((n: string) => n[0])
                                            .join("")
                                            .toUpperCase()}
                                    </AvatarFallback>
                                </Avatar>

                                <div className="flex-1 min-w-0">
                                    <p className="font-semibold text-sm truncate">{post.author_name}</p>
                                    <p className="text-xs text-gray-500">{formatTimeAgo(post.created_at)}</p>
                                </div>
                            </div>

                            {/* Post Content */}
                            {post.content && (
                                <p className="text-sm mt-3 leading-relaxed text-gray-700 break-words whitespace-pre-wrap">
                                    {post.content}
                                </p>
                            )}

                            {/* Post Images */}
                            {post.images?.length > 0 && (
                                <div className="mt-3 grid grid-cols-2 gap-2">
                                    {post.images.map((img: string, idx: number) => (
                                        <img
                                            key={idx}
                                            src={img}
                                            alt={`post-image-${idx}`}
                                            className="rounded-xl object-cover w-full h-48"
                                        />
                                    ))}
                                </div>
                            )}

                            {/* Reactions + Comments */}
                            <div className="flex items-center justify-between mt-4 pt-2 border-t border-gray-200 text-[13px] text-gray-600">
                                {/* Left: Reactions */}
                                <div className="flex items-center gap-2">
                                    {/* Reaction count */}
                                    <div className="flex items-center gap-1">
                                        <span className="font-medium">Reactions</span>
                                        <span className="text-gray-800 font-semibold">{post.reaction_count || 0}</span>
                                    </div>

                                    {/* Reactor avatars */}
                                    {post.reactions?.details?.length > 0 && (
                                        <div className="flex items-center -space-x-2">
                                            {post.reactions.details.slice(0, 15).map((detail: any) => (
                                                <Tooltip key={detail.user.uid}>
                                                    <TooltipTrigger asChild>
                                                        <div className="relative w-5 h-5">
                                                            <Image
                                                                src={detail.user.avatar}
                                                                alt={detail.user.name}
                                                                width={20}
                                                                height={20}
                                                                unoptimized
                                                                className="rounded-full border border-white shadow-sm hover:scale-105 transition-transform object-cover"
                                                            />
                                                        </div>
                                                    </TooltipTrigger>
                                                    <TooltipContent side="top" className="text-xs">
                                                        {detail.user.name} reacted {detail.reaction_type}
                                                    </TooltipContent>
                                                </Tooltip>
                                            ))}

                                            {/* +X more */}
                                            {post.reactions.details.length > 15 && (
                                                <span className="text-[11px] text-gray-500 ml-1">
                                                    +{post.reactions.details.length - 15}
                                                </span>
                                            )}
                                        </div>
                                    )}

                                    {/* Right: Comment Count */}
                                    <div
                                        className="flex items-center gap-1 cursor-pointer hover:text-blue-600 transition"
                                    >
                                        <MessageCircle size={16} strokeWidth={2.3} />
                                        <span className="font-medium">{post.comment_count || 0}</span>
                                    </div>

                                </div>
                            </div>

                        </div>


                        {/* Comments Section */}
                        <div className="flex-1 overflow-y-auto">
                            <div className="p-4">
                                {commentsLoading ? (
                                    <div className="space-y-4">
                                        {[...Array(3)].map((_, i) => (
                                            <div key={i} className="flex space-x-3">
                                                <Skeleton className="h-8 w-8 rounded-full flex-shrink-0" />
                                                <div className="flex-1 space-y-2">
                                                    <Skeleton className="h-4 w-24" />
                                                    <Skeleton className="h-16 w-full rounded-2xl" />
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                ) : comments.length > 0 ? (
                                    <div className="space-y-3">
                                        {comments.map((comment: any) => (
                                            <CommentItem
                                                key={comment.id}
                                                comment={comment}
                                                post={post}
                                                userRolesData={adminData}
                                                formatTimeAgo={formatTimeAgo}
                                                onReply={handleReply}
                                                refetch={refetchComments}
                                            />
                                        ))}
                                    </div>
                                ) : (
                                    <div className="text-center py-8 text-gray-500">
                                        <MessageCircle className="mx-auto h-12 w-12 mb-4 opacity-50" />
                                        <p>No comments yet</p>
                                        <p className="text-sm">Be the first to comment!</p>
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* Comment Form */}
                        <div className="border-t bg-white p-4">
                            <div className="space-y-3">
                                {/* Reply Banner */}
                                {replyingTo && (
                                    <div className="flex items-center justify-between bg-blue-50 rounded-lg px-3 py-2">
                                        <div className="flex items-center gap-2 text-sm text-blue-700">
                                            <Reply className="h-4 w-4" />
                                            <span>Replying to <strong>{replyingTo.author_name}</strong></span>
                                        </div>
                                        <Button
                                            type="button"
                                            variant="ghost"
                                            size="sm"
                                            onClick={cancelReply}
                                            className="h-6 w-6 p-0 hover:bg-blue-100"
                                        >
                                            <X className="h-4 w-4" />
                                        </Button>
                                    </div>
                                )}

                                {/* Comment Input */}
                                <div className="flex space-x-3">
                                    <Avatar className="h-8 w-8 flex-shrink-0">
                                        <AvatarImage src={replyAvatarUrl} alt={replyName} />
                                        <AvatarFallback className="text-xs">
                                            {replyName.split(" ").map((n: any) => n[0]).join("").toUpperCase()}
                                        </AvatarFallback>
                                    </Avatar>
                                    <div className="flex-1 space-y-2">
                                        <Textarea
                                            {...register("content")}
                                            placeholder={isOwnPost ? "Reply to your post..." : "Write a comment..."}
                                            className="resize-none min-h-[60px] rounded-xl border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                                            disabled={isCommenting}
                                            maxLength={500}
                                        />
                                        {errors.content && (
                                            <p className="text-sm text-red-500">{errors.content.message}</p>
                                        )}
                                    </div>
                                </div>

                                {/* Image Previews */}
                                {imagesLoading && (
                                    <div className="flex space-x-2 ml-11">
                                        {[...Array(2)].map((_, index) => (
                                            <Skeleton key={index} className="w-16 h-16 rounded-lg" />
                                        ))}
                                    </div>
                                )}

                                {previewImages.length > 0 && !imagesLoading && (
                                    <div className="flex flex-wrap gap-2 ml-11">
                                        {previewImages.map((img, index) => (
                                            <div key={index} className="relative group">
                                                <Image
                                                    src={img}
                                                    alt={`Preview ${index + 1}`}
                                                    className="w-16 h-16 object-cover rounded-lg border"
                                                    width={64}
                                                    height={64}
                                                />
                                                <Button
                                                    type="button"
                                                    variant="destructive"
                                                    size="icon"
                                                    className="absolute -top-2 -right-2 h-5 w-5 opacity-0 group-hover:opacity-100 transition-opacity"
                                                    onClick={() => removeImage(index)}
                                                    disabled={isCommenting}
                                                >
                                                    <X className="h-3 w-3" />
                                                </Button>
                                            </div>
                                        ))}
                                    </div>
                                )}

                                {/* Action Buttons */}
                                <div className="flex items-center justify-between ml-11">
                                    <div className="flex items-center space-x-3">
                                        <Label htmlFor="comment-images" className="cursor-pointer">
                                            <Button
                                                type="button"
                                                variant="ghost"
                                                size="sm"
                                                asChild
                                                disabled={isCommenting || imagesLoading || hasReachedImageLimit}
                                                className="text-gray-500 hover:text-gray-700"
                                            >
                                                <span>
                                                    {imagesLoading ? (
                                                        <Loader2 className="h-4 w-4 animate-spin" />
                                                    ) : (
                                                        <ImageIcon className="h-4 w-4" />
                                                    )}
                                                </span>
                                            </Button>
                                        </Label>
                                        <Input
                                            id="comment-images"
                                            type="file"
                                            multiple
                                            accept="image/jpeg,image/png,image/webp,image/gif"
                                            className="hidden"
                                            onChange={handleImageUpload}
                                            disabled={isCommenting || imagesLoading || hasReachedImageLimit}
                                        />
                                        <span className="text-xs text-gray-500">
                                            {selectedImages.length}/3 • {watchedContent?.length || 0}/500
                                        </span>
                                    </div>

                                    <Button
                                        onClick={handleSubmit(onSubmit)}
                                        disabled={!isValid || isCommenting || !watchedContent?.trim() || imagesLoading}
                                        size="sm"
                                        className="bg-blue-600 hover:bg-blue-700"
                                    >
                                        {isCommenting ? (
                                            <>
                                                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                                Posting...
                                            </>
                                        ) : (
                                            <>
                                                <Send className="h-4 w-4 mr-2" />
                                                Post
                                            </>
                                        )}
                                    </Button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    )
}

const CommentItem: React.FC<{
    comment: any
    post: any
    userRolesData: any
    formatTimeAgo: (date: Date) => string
    onReply: (comment: any) => void
    refetch?: any
}> = ({ comment, post, userRolesData, formatTimeAgo, onReply, refetch }) => {
    const { deleteMyComment, isDeleting } = useDeleteMyComment()
    const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)

    const handleDeleteClick = async (e: React.MouseEvent) => {
        e.stopPropagation()

        if (!showDeleteConfirm) {
            setShowDeleteConfirm(true)
            setTimeout(() => setShowDeleteConfirm(false), 3000)
            return
        }

        try {
            await deleteMyComment({ id: comment.id })
            await refetch?.()
            toast.success('Comment deleted')
        } catch (error) {
            console.error("Failed to delete comment:", error)
            toast.error((error as Error).message || "Failed to delete comment")
        } finally {
            setShowDeleteConfirm(false)
        }
    }

    const isCommentAuthor = userRolesData?.user_id === comment.author_id

    return (
        <div className="group flex gap-3 p-2 hover:bg-gray-50 rounded-lg transition-colors">
            <Avatar className="h-9 w-9 flex-shrink-0">
                <AvatarImage src={comment.author_avatar} alt={comment.author_name} />
                <AvatarFallback className="text-xs">
                    {comment.author_name.split(" ").map((n: string) => n[0]).join("").toUpperCase()}
                </AvatarFallback>
            </Avatar>

            <div className="flex-1 min-w-0">
                <div className="relative bg-gray-100 rounded-2xl px-3 py-2">
                    {isDeleting && (
                        <div className="absolute inset-0 z-20 bg-white/70 backdrop-blur-sm flex items-center justify-center rounded-2xl">
                            <Loader2 className="h-5 w-5 animate-spin text-gray-600" />
                        </div>
                    )}

                    <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                            <div className="flex flex-wrap items-center gap-1.5 mb-1">
                                <p className="text-sm font-semibold text-gray-900">{comment.author_name}</p>
                                {comment.author_id === post.author.id && (
                                    <span className="px-1.5 py-0.5 rounded bg-blue-100 text-blue-700 text-[10px] font-medium">
                                        Author
                                    </span>
                                )}
                                {comment.author_role && (
                                    <span className="px-1.5 py-0.5 rounded bg-green-100 text-green-700 text-[10px] font-medium">
                                        {comment.author_role}
                                    </span>
                                )}
                            </div>
                            <p className="text-sm text-gray-800 break-words">{comment.content}</p>
                        </div>

                        {isCommentAuthor && (
                            <Button
                                onClick={handleDeleteClick}
                                disabled={isDeleting}
                                variant="ghost"
                                size="icon"
                                className={`h-7 w-7 flex-shrink-0 -mt-1 -mr-1 transition-all ${showDeleteConfirm
                                    ? "bg-red-50 text-red-600 hover:bg-red-100"
                                    : "text-gray-400 hover:text-red-600 hover:bg-gray-200"
                                    }`}
                                title={showDeleteConfirm ? "Click again to confirm" : "Delete comment"}
                            >
                                {isDeleting ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                ) : (
                                    <Trash2 className="h-3.5 w-3.5" />
                                )}
                            </Button>
                        )}
                    </div>

                    {comment.images?.length > 0 && (
                        <div className="mt-2 grid grid-cols-2 gap-2">
                            {comment.images.map((img: string, idx: number) => (
                                <div key={idx} className="relative aspect-square rounded-lg overflow-hidden bg-gray-200">
                                    <Image
                                        src={img}
                                        alt={`Comment image ${idx + 1}`}
                                        fill
                                        className="object-cover"
                                        sizes="(max-width: 640px) 40vw, 150px"
                                    />
                                </div>
                            ))}
                        </div>
                    )}
                </div>
                {/* 
                <div className="flex items-center gap-4 mt-1 px-3">
                    <span className="text-xs text-gray-500">{formatTimeAgo(new Date(comment.created_at))}</span>
                    <button
                        onClick={() => onReply(comment)}
                        className="text-xs font-medium text-gray-600 hover:text-blue-600 transition-colors flex items-center gap-1"
                    >
                        <Reply className="h-3 w-3" />
                        Reply
                    </button>
                </div> */}
            </div>
        </div>
    )
}

export default CommentDialog
