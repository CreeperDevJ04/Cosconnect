import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

import { useSupabaseAuth } from "@/lib/hooks/useSupabaseAuth";

import {
    AlertCircle,
    Building2,
    Edit3,
    Loader2,
    MessageCircle,
    MoreHorizontal,
    Shield,
    ShoppingBag,
    Star,
    Store,
    Trash2,
    User,
    Verified,
} from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { memo, useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import CommentDialog from "./CommentDialog";
import ImageDialog from "./ImageDialog";
import OptimizedPostImage from "./OptimizedPostImage";
import ReactionButton from "./ReactionButton";
import { ReportPostDialog } from "./ReportPostDialog";
import { UpdatePostDialog } from "./UpdatePostDialog";
import { useDeleteCommunityPost, useLikePost, useUpdateMyPost } from "@/lib/apis/communityApi";

// ==================== TYPES ====================
export type LenderInfo = {
    business_name: string;
    business_type: string;
    business_profile_image: string | null;
};

export type BorrowerInfo = {
    fullname: string;
    profile_image: string;
    current_role: string;
};

// ==================== PROPS ====================
interface PostCardProps {
    post: any;
    onSelect?: (post: any) => void;
    refetch?: () => void;
}

// ==================== HELPER: GET AUTHOR DISPLAY INFO ====================
const getAuthorDisplay = (post: any) => {
    if (post.author_role === "admin") {
        return {
            name: post.author_name,
            avatar: post.author_avatar,
            isVerified: true,
            isAdmin: true,
            businessType: null,
        };
    }

    if (post.author_role === "lender" && post.author_info?.type === "lender") {
        return {
            name: post.author_info.business_name || post.author_name,
            avatar: post.author_info.business_profile_image || post.author_avatar,
            isVerified: true,
            isAdmin: false,
            businessType: post.author_info.business_type,
        };
    }

    if (post.author_role === "borrower" && post.author_info?.type === "borrower") {
        return {
            name: post.author_info.full_name || post.author_name,
            avatar: post.author_info.profile_image || post.author_avatar,
            isVerified: false,
            isAdmin: false,
            businessType: null,
        };
    }

    return {
        name: post.author_name,
        avatar: post.author_avatar,
        isVerified: false,
        isAdmin: false,
        businessType: null,
    };
};

// ==================== COMPONENT ====================
const PostCard = memo(({ post, onSelect, refetch }: PostCardProps) => {
    // Helper to cleanup body styles after dialog closes
    const cleanupBodyStyles = useCallback(() => {
        // Immediate cleanup
        document.body.style.pointerEvents = '';
        document.body.style.overflow = '';
        document.body.removeAttribute('data-scroll-locked');
        document.body.removeAttribute('inert');

        // Double-check after animation completes
        setTimeout(() => {
            document.body.style.pointerEvents = '';
            document.body.style.overflow = '';
            document.body.removeAttribute('data-scroll-locked');
            document.body.removeAttribute('inert');
        }, 300);
    }, []);

    // ==================== STATE ====================
    const [isImageDialogOpen, setIsImageDialogOpen] = useState(false);
    const [selectedImageIndex, setSelectedImageIndex] = useState(0);
    const [isCommentDialogOpen, setIsCommentDialogOpen] = useState(false);
    const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
    const [isUpdateDialogOpen, setIsUpdateDialogOpen] = useState(false);
    const [isReportDialogOpen, setIsReportDialogOpen] = useState(false);
    const [menuOpen, setMenuOpen] = useState(false);
    const [editedContent, setEditedContent] = useState(post.content);
    const [content, setContent] = useState(post.content);
    const [isRemoved, setIsRemoved] = useState(false);
    const [isFadingOut, setIsFadingOut] = useState(false);

    // Local reaction state for optimistic updates
    const [userReaction, setUserReaction] = useState<string | null>(post.user_reaction_type);
    const [reactionCount, setReactionCount] = useState(post.reaction_count);

    // Sync post content when it changes from parent (after refetch)
    useEffect(() => {
        setEditedContent(post.content);
        setContent(post.content);
    }, [post.content]);

    // Ensure any leftover global styles from dialogs are cleared when all dialogs are closed
    useEffect(() => {
        if (
            !isImageDialogOpen &&
            !isCommentDialogOpen &&
            !isDeleteDialogOpen &&
            !isUpdateDialogOpen &&
            !isReportDialogOpen
        ) {
            cleanupBodyStyles();
        }
    }, [isImageDialogOpen, isCommentDialogOpen, isDeleteDialogOpen, isUpdateDialogOpen, isReportDialogOpen, cleanupBodyStyles]);

    // ==================== HOOKS ====================
    const { adminData, isAuthenticated, isLoading: authLoading } = useSupabaseAuth();
    const { mutateAsync: reactToPost, isPending: isReacting } = useLikePost();
    const { mutateAsync: deletePost, isPending: isDeleting } = useDeleteCommunityPost();
    const { mutateAsync: updatePost, isPending: isUpdating } = useUpdateMyPost();

    // Fetch author's user data to get up-to-date username




    const currentUser = useMemo(() => {
        if (!adminData) return null;
        return {
            uid: adminData?.user_id,
            name: adminData?.personal_info?.full_name || adminData?.username || "Unknown User",
            avatar: adminData?.personal_info?.profile_image || "/placeholder-avatar.jpg",
            email: adminData?.email || "",
            role: adminData?.current_role || "borrower",
        };
    }, [adminData]);

    // Determine post type (previous behavior retained; includes viewer-role override)
    const userHasLenderRole = Array.isArray(adminData?.roles) && adminData?.roles.includes('lender')
    const isCurrentUsersPost = currentUser?.uid === post.author_id
    const authorHasLenderRole =
        !!post.lender_info ||
        (Array.isArray(post.author_roles) && post.author_roles.includes('lender')) ||
        post.author_role === 'lender' ||
        (isCurrentUsersPost && userHasLenderRole)
    const isLenderPost = authorHasLenderRole;
    const isBorrowerPost = !authorHasLenderRole && (post.author_role === 'borrower' || !!post.borrower_info);
    const isAdminPost = post.author_role === 'admin';

    const authorDisplay = useMemo(() => getAuthorDisplay(post), [post]);

    // ==================== HANDLERS ====================
    const checkAuth = useCallback(() => {
        if (!isAuthenticated || !currentUser) {
            toast.warning("Please login first");
            return false;
        }
        return true;
    }, [isAuthenticated, currentUser]);

    const formatTimeAgo = useCallback((date: string) => {
        const dateObj = new Date(date);
        const now = new Date();
        const diffInMs = now.getTime() - dateObj.getTime();
        const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
        const diffInHours = Math.floor(diffInMinutes / 60);

        if (diffInMinutes < 1) return "Just now";
        if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
        if (diffInHours < 24) return `${diffInHours}h ago`;
        if (diffInHours < 168) return `${Math.floor(diffInHours / 24)}d ago`;
        return dateObj.toLocaleDateString();
    }, []);

    const handleReact = useCallback(async (reactionType: string | "unreact") => {
        if (!checkAuth() || !currentUser) return;

        const prevReaction = userReaction;
        const prevCount = reactionCount;

        // Optimistic update
        if (reactionType === "unreact") {
            setUserReaction(null);
            setReactionCount((prev: any) => Math.max(0, prev - 1));
        } else if (userReaction === reactionType) {
            setUserReaction(null);
            setReactionCount((prev: any) => Math.max(0, prev - 1));
        } else if (userReaction) {
            setUserReaction(reactionType);
        } else {
            setUserReaction(reactionType);
            setReactionCount((prev: any) => prev + 1);
        }

        try {
            await reactToPost({
                action: reactionType === "unreact" ? "unreact" : "react",
                user: {
                    uid: currentUser.uid,
                    role: currentUser.role as "borrower" | "lender",
                    name: currentUser.name,
                },
                postId: post.id,
                reactionType: reactionType === "unreact" ? (prevReaction || "like") : reactionType,
            });
            refetch?.();
        } catch (_error) {
            setUserReaction(prevReaction);
            setReactionCount(prevCount);
        }
    }, [checkAuth, currentUser, post.id, userReaction, reactionCount, reactToPost, refetch]);

    const handleUpdate = useCallback(async () => {
        if (!checkAuth() || !editedContent.trim()) {
            toast.error("Post content cannot be empty");
            return;
        }

        try {
            await toast.promise(
                updatePost({ postId: post.id, content: editedContent }),
                {
                    loading: "Updating post...",
                    success: "Post updated successfully!",
                    error: "Failed to update post",
                }
            );
            setContent(editedContent);
            setIsUpdateDialogOpen(false);
            cleanupBodyStyles();
            refetch?.();
        } catch (error: unknown) {
            console.error("Failed to update post:", error);
        }
    }, [checkAuth, updatePost, post.id, editedContent, refetch, cleanupBodyStyles]);

    const handleDelete = useCallback(async () => {
        if (!checkAuth()) return;

        try {
            setIsDeleteDialogOpen(false);
            cleanupBodyStyles();

            // Start fade out immediately
            setIsFadingOut(true);

            await toast.promise(
                deletePost({ postId: post.id, author_id: post.author_id }),
                {
                    loading: "Deleting post...",
                    success: "Post deleted successfully!",
                    error: "Failed to delete post",
                }
            );

            // Remove after animation
            setTimeout(() => setIsRemoved(true), 400);
            refetch?.();
        } catch (error: unknown) {
            console.error("Failed to delete post:", error);
            // Revert fade out on error
            setIsFadingOut(false);
            setIsDeleteDialogOpen(true);
        }
    }, [checkAuth, deletePost, post.id, post.author_id, refetch, cleanupBodyStyles]);

    const handleCopyLink = useCallback(async () => {
        try {
            const postUrl = `${window.location.origin}/post/${post.id}`;
            await navigator.clipboard.writeText(postUrl);
            toast.success("Link copied to clipboard");
        } catch (error) {
            toast.error("Failed to copy link");
        }
    }, [post.id]);

    const handleCardClick = useCallback((e: React.MouseEvent) => {
        const target = e.target as HTMLElement;
        if (target.closest("button, a, [role='menuitem'], [role='dialog']")) return;
        onSelect?.(post);
    }, [onSelect, post]);

    // ==================== COMPUTED STYLES ====================
    const cardClassName = useMemo(() => {
        const base = "w-full cursor-pointer transition-all duration-300 hover:shadow-xl rounded-2xl";
        if (isAdminPost) return `${base} border-2 border-blue-200 shadow-lg hover:border-blue-300`;
        if (isLenderPost) return `${base} border-2 border-rose-200 shadow-lg hover:border-rose-300`;
        if (post.is_for_sale) return `${base} border-2 border-emerald-200 bg-emerald-50/30 shadow-lg`;
        return `${base} border-2 border-gray-200 hover:border-rose-200`;
    }, [isAdminPost, isLenderPost, post.is_for_sale]);

    const avatarClassName = useMemo(() => {
        const base = "h-12 w-12 ring-2 ring-offset-2";
        if (isAdminPost) return `${base} ring-blue-300`;
        if (isLenderPost) return `${base} ring-rose-300`;
        if (post.is_for_sale) return `${base} ring-emerald-300`;
        return `${base} ring-gray-200`;
    }, [isAdminPost, isLenderPost, post.is_for_sale]);

    const borderClassName = useMemo(() => {
        const base = "flex items-center justify-between pt-4 border-t-2";
        if (isAdminPost) return `${base} border-blue-100`;
        if (isLenderPost) return `${base} border-rose-100`;
        if (post.is_for_sale) return `${base} border-emerald-100`;
        return `${base} border-gray-100`;
    }, [isAdminPost, isLenderPost, post.is_for_sale]);

    // ==================== BADGES ====================
    const roleBadge = useMemo(() => {
        if (isLenderPost) {
            return (
                <Badge variant="secondary" className="bg-rose-100 text-rose-700 text-xs border-rose-200 font-medium">
                    <Store className="h-3 w-3 mr-1" />
                    Lender
                </Badge>
            );
        }
        if (post.author_role === "admin") {
            return (
                <Badge variant="secondary" className="bg-blue-100 text-blue-800 text-xs font-medium">
                    <Shield className="h-3 w-3 mr-2" />
                    Admin
                </Badge>
            );
        }
        if (post.author_role === "moderator") {
            return (
                <Badge variant="secondary" className="bg-blue-100 text-blue-800 text-xs font-medium">
                    <Star className="h-3 w-3 mr-1" />
                    Mod
                </Badge>
            );
        }
        return null;
    }, [isLenderPost, post.author_role]);

    const businessTypeBadge = useMemo(() => {
        if (!isLenderPost || !authorDisplay.businessType) return null;
        const isStore = authorDisplay.businessType.toUpperCase() === "STORE";
        return (
            <Badge
                variant="outline"
                className={`text-xs ${isStore
                    ? "bg-blue-50 text-blue-700 border-blue-200"
                    : "bg-gray-50 text-gray-700 border-gray-200"
                    }`}
            >
                {isStore ? <Building2 className="h-3 w-3 mr-1" /> : <User className="h-3 w-3 mr-1" />}
                {isStore ? "Store" : "Individual"}
            </Badge>
        );
    }, [isLenderPost, authorDisplay.businessType]);

    // ==================== IMAGE GRID ====================
    const imageGrid = useMemo(() => {
        const imageCount = post.images?.length || 0;
        if (imageCount === 0) return null;

        if (imageCount === 1) {
            return (
                <div
                    className="cursor-pointer w-full aspect-[4/3] rounded-xl overflow-hidden"
                    onClick={() => {
                        setSelectedImageIndex(0);
                        setIsImageDialogOpen(true);
                    }}
                >
                    <OptimizedPostImage src={post.images[0]} alt="Post image" index={0} />
                </div>
            );
        }

        return (
            <div className="grid grid-cols-2 gap-2 w-full">
                {post.images.slice(0, 4).map((img: any, idx: any) => (
                    <div
                        key={idx}
                        className="cursor-pointer relative rounded-xl overflow-hidden aspect-[4/3]"
                        onClick={() => {
                            setSelectedImageIndex(idx);
                            setIsImageDialogOpen(true);
                        }}
                    >
                        <OptimizedPostImage src={img} alt={`Post image ${idx + 1}`} index={idx} />
                        {idx === 3 && imageCount > 4 && (
                            <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                                <span className="text-white font-semibold text-lg">
                                    +{imageCount - 4} more
                                </span>
                            </div>
                        )}
                    </div>
                ))}
            </div>
        );
    }, [post.images]);

    // ==================== RENDER ====================
    if (isRemoved) return null;

    return (
        <>
            <Card
                className={`${cardClassName} transition-opacity duration-300 ${isFadingOut ? 'opacity-0' : 'opacity-100'}`}
                onClick={handleCardClick}
            >
                {/* Header Accent */}
                {isAdminPost && <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-blue-500 to-blue-600" />}
                {isLenderPost && !isAdminPost && <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-rose-500 to-rose-600" />}

                <CardHeader className="pb-3">
                    <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                            {/* Avatar */}
                            <div className="relative shrink-0">
                                <Avatar className={avatarClassName}>
                                    <AvatarImage src={authorDisplay.avatar} alt={authorDisplay.name} />
                                    <AvatarFallback className="font-semibold">
                                        {authorDisplay.name[0]?.toUpperCase() || "U"}
                                    </AvatarFallback>
                                </Avatar>
                                {(isAdminPost || (isLenderPost && authorDisplay.isVerified)) && (
                                    <div className="absolute -bottom-1 -right-1 bg-white rounded-full p-0.5 shadow-md">
                                        <Verified
                                            className={`h-4 w-4 ${isAdminPost ? "text-blue-500 fill-blue-500" : "text-rose-500 fill-rose-500"
                                                }`}
                                        />
                                    </div>
                                )}
                            </div>

                            {/* Author Info */}
                            <div className="min-w-0 flex-1">
                                <div className="flex items-center gap-2 flex-wrap mb-1">
                                    <Link
                                        href={`/profile?id=${post.author_id}&role=${post.author_role}`}
                                        className="font-semibold text-sm hover:underline text-gray-900"
                                        onClick={(e) => e.stopPropagation()}
                                    >
                                        @{authorDisplay.name}
                                    </Link>
                                    {roleBadge}
                                    {businessTypeBadge}
                                </div>

                                <div className="flex items-center gap-2 flex-wrap">
                                    <span className="text-xs text-gray-500">
                                        {formatTimeAgo(post.created_at)}
                                    </span>
                                    {post.is_for_sale && (
                                        <Badge variant="outline" className="text-xs bg-emerald-50 text-emerald-700 border-emerald-200 font-medium">
                                            <ShoppingBag className="h-3 w-3 mr-1" />
                                            For Sale
                                        </Badge>
                                    )}
                                </div>
                            </div>
                        </div>

                        {/* Menu */}
                        <DropdownMenu>
                            <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                                <Button variant="ghost" size="icon" className="shrink-0 hover:bg-rose-50 rounded-full">
                                    <MoreHorizontal className="h-4 w-4 text-gray-600" />
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-48">
                                {authLoading ? (
                                    <div className="flex justify-center items-center px-4 py-3">
                                        <Loader2 className="h-4 w-4 animate-spin text-gray-400" />
                                    </div>
                                ) : (
                                    <>
                                        {post.is_own_post && (
                                            <>
                                                <DropdownMenuItem
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        setEditedContent(post.content);
                                                        setIsUpdateDialogOpen(true);
                                                    }}
                                                    disabled={isUpdating}
                                                    className="text-blue-600 focus:text-blue-600 cursor-pointer font-medium"
                                                >
                                                    <Edit3 className="h-4 w-4 mr-2" />
                                                    Edit Post
                                                </DropdownMenuItem>
                                                <DropdownMenuItem
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        setIsDeleteDialogOpen(true);
                                                    }}
                                                    disabled={isDeleting}
                                                    className="text-red-600 focus:text-red-600 cursor-pointer font-medium"
                                                >
                                                    {isDeleting ? (
                                                        <>
                                                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                                            Deleting...
                                                        </>
                                                    ) : (
                                                        <>
                                                            <Trash2 className="h-4 w-4 mr-2" />
                                                            Delete Post
                                                        </>
                                                    )}
                                                </DropdownMenuItem>
                                            </>
                                        )}
                                        <DropdownMenuItem
                                            className="cursor-pointer font-medium"
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                handleCopyLink();
                                            }}
                                        >
                                            Copy Link
                                        </DropdownMenuItem>
                                        <DropdownMenuItem
                                            className="cursor-pointer font-medium"
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                setIsReportDialogOpen(true);
                                            }}
                                        >
                                            Report
                                        </DropdownMenuItem>
                                    </>
                                )}
                            </DropdownMenuContent>
                        </DropdownMenu>
                    </div>
                </CardHeader>

                <CardContent className="pt-0 space-y-4">
                    {/* Content */}
                    <p className="text-sm text-gray-800 whitespace-pre-wrap break-words leading-relaxed">
                        {content}
                    </p>

                    {/* Images */}
                    {imageGrid}

                    {/* Reactions and Comments Counts */}
                    <div className="mt-2 flex items-center justify-between">
                        {/* Left: Reaction summary */}
                        {post.reactions?.details?.length > 0 && (
                            <div className="flex items-center gap-2">
                                {/* Reaction counts */}
                                {Object.entries(post.reactions.counts).map(([type, count]) => (
                                    <span
                                        key={type}
                                        className="text-[11px] text-gray-600 font-medium capitalize"
                                    >
                                        {type}:{ }
                                    </span>
                                ))}

                                {/* Reactor avatars */}
                                <div className="flex items-center -space-x-2">
                                    {post.reactions.details.slice(0, 15).map((detail: any, id: number) => (
                                        <Tooltip key={`${detail.user.uid}-${id}`}>
                                            <TooltipTrigger asChild>
                                                <div className="relative w-5 h-5">
                                                    <Image
                                                        src={detail.user.avatar}
                                                        alt={detail.user.name}
                                                        width={20}
                                                        height={20}
                                                        unoptimized
                                                        className="rounded-full border border-white shadow-sm hover:scale-105 transition-transform object-cover"
                                                    />
                                                </div>
                                            </TooltipTrigger>
                                            <TooltipContent side="top" className="text-xs">
                                                {detail.user.name} reacted {detail.reaction_type}
                                            </TooltipContent>
                                        </Tooltip>
                                    ))}
                                </div>

                                {/* +X more */}
                                {post.reactions.details.length > 15 && (
                                    <span className="text-[10px] text-gray-500 ml-1">
                                        +{post.reactions.details.length - 15}
                                    </span>
                                )}
                            </div>
                        )}

                        {/* Right: Comment count */}
                        {post.comment_count > 0 && (
                            <span className="text-[11px] text-gray-700 font-semibold">
                                {post.comment_count} Comment{post.comment_count !== 1 ? "s" : ""}
                            </span>
                        )}
                    </div>

                    {/* Actions */}
                    <div className={borderClassName}>
                        <div className="flex items-center gap-2 sm:gap-3">
                            <ReactionButton
                                userReaction={userReaction as any}
                                onReact={handleReact}
                                isLoading={isReacting}
                            />

                            <Button
                                variant="ghost"
                                size="sm"
                                onClick={(e) => {
                                    e.stopPropagation();
                                    if (checkAuth()) setIsCommentDialogOpen(true);
                                }}
                                className="flex items-center gap-1.5 sm:gap-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 transition-colors px-2 sm:px-3 py-1.5 sm:py-2 rounded-lg"
                            >
                                <MessageCircle className="h-4 w-4 sm:h-5 sm:w-5" strokeWidth={2.5} />
                                <span className="text-xs font-medium hidden sm:inline">
                                    Comment{post.comment_count !== 1 ? "s" : ""}
                                </span>
                            </Button>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Dialogs */}
            {post.images?.length > 0 && (
                <ImageDialog
                    images={post.images}
                    isOpen={isImageDialogOpen}
                    onClose={() => {
                        setIsImageDialogOpen(false);
                        cleanupBodyStyles();
                    }}
                    initialIndex={selectedImageIndex}
                />
            )}

            <CommentDialog
                post={{
                    isLiked: post.user_has_reacted,
                    comments: post.comment_count,
                    ...post,
                    author: {
                        id: post.author_id,
                        name: authorDisplay.name,
                        avatar: authorDisplay.avatar,
                        role: post.author_role,
                    },
                }}
                isOpen={isCommentDialogOpen}
                onClose={() => {
                    setIsCommentDialogOpen(false);
                    cleanupBodyStyles();
                }}
                formatTimeAgo={formatTimeAgo as any}
                checkAuthentication={checkAuth}
                refetch={refetch}
            />

            <AlertDialog
                open={isDeleteDialogOpen}
                onOpenChange={(open) => {
                    setIsDeleteDialogOpen(open);
                    if (!open) {
                        cleanupBodyStyles();
                    }
                }}
            >
                <AlertDialogContent onClick={(e) => e.stopPropagation()}>
                    <AlertDialogHeader>
                        <AlertDialogTitle className="flex items-center gap-2">
                            <AlertCircle className="h-5 w-5 text-red-500" />
                            Delete Post?
                        </AlertDialogTitle>
                        <AlertDialogDescription>
                            This action cannot be undone. This will permanently delete your post and all associated comments and reactions.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel
                            disabled={isDeleting}
                            onClick={(e) => {
                                e.stopPropagation();
                                setIsDeleteDialogOpen(false);
                                cleanupBodyStyles();
                            }}
                        >
                            Cancel
                        </AlertDialogCancel>
                        <AlertDialogAction
                            onClick={(e) => {
                                e.stopPropagation();
                                handleDelete();
                            }}
                            disabled={isDeleting}
                            className="bg-red-500 hover:bg-red-600"
                        >
                            {isDeleting ? (
                                <>
                                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                    Deleting...
                                </>
                            ) : (
                                <>
                                    <Trash2 className="h-4 w-4 mr-2" />
                                    Delete
                                </>
                            )}
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>

            <UpdatePostDialog
                post={post}
                isOpen={isUpdateDialogOpen}
                onOpenChange={(open) => {
                    if (!open) {
                        setIsUpdateDialogOpen(false);
                        setEditedContent(post.content);
                        cleanupBodyStyles();
                    }
                }}
                editedContent={editedContent}
                onContentChange={setEditedContent}
                onSave={handleUpdate}
                isUpdating={isUpdating}
            />

            <ReportPostDialog
                open={isReportDialogOpen}
                onOpenChange={(open) => {
                    setIsReportDialogOpen(open);
                    if (!open) {
                        cleanupBodyStyles();
                    }
                }}
                postId={post.id}
                reporterId={currentUser?.uid || ""}
            />
        </>
    );
});
PostCard.displayName = "PostCard";

export default PostCard;