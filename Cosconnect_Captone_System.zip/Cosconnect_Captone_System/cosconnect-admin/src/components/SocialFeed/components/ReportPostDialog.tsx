"use client";

import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Textarea } from "@/components/ui/textarea";
import { useReportPost } from "@/lib/apis/communityApi";
import { zodResolver } from '@hookform/resolvers/zod';
import { Flag } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { toast } from 'sonner';
import { z } from 'zod';

// Define Zod schema
const reportFormSchema = z.object({
    reason: z.string().min(1, "Please select a reason"),
    details: z.string().max(500, "Details must be less than 500 characters").optional()
});

type ReportFormValues = z.infer<typeof reportFormSchema>;

export interface ReportData {
    postId: string;
    reason: string;
    details?: string;
    reporterId?: string;
}

interface ReportPostDialogProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    postId: string;
    reporterId?: string;
    onReportSubmit?: (report: any) => void;
}

const REPORT_REASONS = [
    'Spam or misleading',
    'Nudity or sexual content',
    'Hate speech or symbols',
    'Violence or dangerous organizations',
    'Bullying or harassment',
    'Intellectual property violation',
    'Something else'
] as const;

export function ReportPostDialog({
    open,
    onOpenChange,
    postId,
    reporterId,
    onReportSubmit
}: ReportPostDialogProps) {
    const { mutate: reportPost, isPending: isReporting } = useReportPost();
    const form = useForm<ReportFormValues>({
        resolver: zodResolver(reportFormSchema),
        defaultValues: {
            reason: '',
            details: ''
        }
    });

    const handleClose = () => {
        form.reset();
        onOpenChange(false);
    };

    const handleSubmit = (data: ReportFormValues) => {
        if (!reporterId) {
            toast.error('You must be logged in to report a post');
            return;
        }

        const reportData = {
            post_id: postId,
            user_id: reporterId,
            reason: data.reason,
            details: data.details
        };

        reportPost(reportData as any, {
            onSuccess: () => {
                const reportResponse: any = {
                    postId,
                    reason: data.reason,
                    details: data.details,
                    reporterId
                };

                toast.success('Report submitted. Thank you for keeping our community safe!');
                handleClose();
                onReportSubmit?.(reportResponse);
            }
        });
    };

    return (
        <Dialog open={open} onOpenChange={(isOpen) => {
            if (!isOpen) handleClose();
            else onOpenChange(true);
        }}>
            <DialogContent className="w-full">
                <DialogHeader>
                    <div className="flex items-center gap-2">
                        <Flag className="h-5 w-5 text-destructive" />
                        <DialogTitle>Report Post</DialogTitle>
                    </div>
                    <DialogDescription>
                        Help us understand the problem. Why are you reporting this post?
                    </DialogDescription>
                </DialogHeader>

                <Form {...form}>
                    <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4 py-2">
                        <FormField
                            control={form.control}
                            name="reason"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Select a reason</FormLabel>
                                    <div className="grid gap-2">
                                        {REPORT_REASONS.map((reason) => (
                                            <div
                                                key={reason}
                                                className={`flex items-center p-3 rounded-lg border cursor-pointer transition-colors ${field.value === reason
                                                    ? 'bg-accent border-primary'
                                                    : 'hover:bg-accent/50'
                                                    }`}
                                                onClick={() => field.onChange(reason)}
                                            >
                                                <div
                                                    className={`h-4 w-4 rounded-full border flex items-center justify-center mr-3 ${field.value === reason
                                                        ? 'border-primary bg-primary'
                                                        : 'border-muted-foreground'
                                                        }`}
                                                >
                                                    {field.value === reason && (
                                                        <div className="h-2 w-2 rounded-full bg-white" />
                                                    )}
                                                </div>
                                                <span>{reason}</span>
                                            </div>
                                        ))}
                                    </div>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />

                        <FormField
                            control={form.control}
                            name="details"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Additional details (optional)</FormLabel>
                                    <FormControl>
                                        <Textarea
                                            {...field}
                                            placeholder="Please provide more details about your report..."
                                            className="min-h-[100px]"
                                            disabled={isReporting}
                                        />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />

                        <DialogFooter className="mt-4">
                            <Button
                                type="button"
                                variant="outline"
                                onClick={handleClose}
                                disabled={isReporting}
                            >
                                Cancel
                            </Button>
                            <Button
                                type="submit"
                                variant="destructive"
                                disabled={!form.formState.isValid || isReporting}
                            >
                                {isReporting ? 'Reporting...' : 'Submit Report'}
                            </Button>
                        </DialogFooter>
                    </form>
                </Form>
            </DialogContent>
        </Dialog>
    );
}