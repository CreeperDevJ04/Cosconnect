"use client";

import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, Edit3 } from 'lucide-react';
import Image from 'next/image';

interface UpdatePostDialogProps {
    post: any;
    isOpen: boolean;
    onOpenChange: (open: boolean) => void;
    editedContent: string;
    onContentChange: (content: string) => void;
    onSave: () => void;
    isUpdating: boolean;
}

export function UpdatePostDialog({
    post,
    isOpen,
    onOpenChange,
    editedContent,
    onContentChange,
    onSave,
    isUpdating,
}: UpdatePostDialogProps) {
    return (
        <Dialog open={isOpen} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[550px]">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                        <Edit3 className="h-5 w-5 text-blue-500" />
                        Edit Post
                    </DialogTitle>
                    <DialogDescription>
                        Make changes to your post. Click save when you're done.
                    </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                    <Textarea
                        value={editedContent}
                        onChange={(e) => onContentChange(e.target.value)}
                        placeholder="What's on your mind?"
                        className="min-h-[150px] resize-none"
                        disabled={isUpdating}
                    />
                    {post.images && post.images.length > 0 && (
                        <div className="border rounded-lg p-3 bg-muted/50">
                            <p className="text-xs text-muted-foreground mb-2">
                                {post.images.length} image{post.images.length > 1 ? 's' : ''} attached
                            </p>
                            <div className="grid grid-cols-4 gap-2">
                                {post.images.slice(0, 4).map((img: any, idx: any) => (
                                    <div key={idx} className="aspect-square rounded overflow-hidden">
                                        <img
                                            src={img}
                                            alt={`Post image ${idx + 1}`}
                                            className="w-full h-full object-cover"
                                        />
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
                <DialogFooter>
                    <Button
                        variant="outline"
                        onClick={() => onOpenChange(false)}
                        disabled={isUpdating}
                    >
                        Cancel
                    </Button>
                    <Button
                        onClick={onSave}
                        disabled={isUpdating || !editedContent.trim()}
                    >
                        {isUpdating ? (
                            <>
                                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                Updating...
                            </>
                        ) : (
                            'Save Changes'
                        )}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}
