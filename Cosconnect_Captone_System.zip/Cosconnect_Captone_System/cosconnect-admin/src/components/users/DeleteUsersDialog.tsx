import React from 'react'
import {
    AlertDialog,
    AlertDialogContent,
    AlertDialogHeader,
    AlertDialogFooter,
    AlertDialogTitle,
    AlertDialogDescription,
    AlertDialogAction,
    AlertDialogCancel,
} from '../ui/alert-dialog'
import { Button } from '../ui/button'
import type { User } from '../../types/adminType'
import { Loader2 } from 'lucide-react'

interface DeleteUsersDialogProps {
    open: boolean
    onOpenChange: (open: boolean) => void
    mode: 'single' | 'bulk'
    user?: any | null
    count?: number
    onConfirm: () => void
    loading?: boolean
}

const DeleteUsersDialog: React.FC<DeleteUsersDialogProps> = ({
    open,
    onOpenChange,
    mode,
    user,
    count,
    onConfirm,
    loading = false,
}) => {
    const isBulk = mode === 'bulk'
    return (
        <AlertDialog open={open} onOpenChange={onOpenChange}>
            <AlertDialogContent>
                <AlertDialogHeader>
                    <AlertDialogTitle>
                        {isBulk
                            ? `Delete ${count} user${count && count > 1 ? 's' : ''}?`
                            : `Delete user?`}
                    </AlertDialogTitle>
                    <AlertDialogDescription>
                        {isBulk
                            ? `This action cannot be undone. This will permanently delete all selected users and remove all their data from the system.`
                            : `This action cannot be undone. This will permanently delete the user "${user?.username || user?.email}" and remove all their data from the system.`}
                    </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                    <AlertDialogCancel asChild>
                        <Button variant="outline" disabled={loading}>Cancel</Button>
                    </AlertDialogCancel>
                    <AlertDialogAction asChild>
                        <Button
                            variant="destructive"
                            onClick={onConfirm}
                            disabled={loading}
                        >
                            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            {loading ? (isBulk ? 'Deleting Users...' : 'Deleting...') : (isBulk ? 'Delete Users' : 'Delete')}
                        </Button>
                    </AlertDialogAction>
                </AlertDialogFooter>
            </AlertDialogContent>
        </AlertDialog>
    )
}

export default DeleteUsersDialog