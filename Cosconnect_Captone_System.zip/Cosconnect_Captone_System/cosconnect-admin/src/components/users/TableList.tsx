import React, { useRef, useEffect } from 'react';
import Image from 'next/image';
import {
    Table,
    TableHeader,
    TableBody,
    TableRow,
    TableHead,
    TableCell
} from '../ui/table';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Checkbox } from '../ui/checkbox';
import {
    DropdownMenu,
    DropdownMenuTrigger,
    DropdownMenuContent,
    DropdownMenuItem,
} from '../ui/dropdown-menu';
import {
    MoreHorizontal,
    Eye,
    Shield,
    CheckCircle2,
    XCircle,
    User as UserIcon
} from 'lucide-react';

// Updated User type based on your JSON response
interface User {
    uid: string;
    id: string;
    username: string;
    email: string;
    phone_number: string;
    full_name: string | null;
    first_name: string | null;
    last_name: string | null;
    profile_image: string | null;
    role: string[];
    current_role: string | null;
    status: 'active' | 'inactive' | 'suspended' | 'pending_verification' | 'verified' | 'rejected';
    email_verified: boolean | null;
    phone_verified: boolean | null;
    created_at: string;
}

interface TableListProps {
    users: User[];
    selectedUserIds: string[];
    onSelectUser: (uid: string, selected: boolean) => void;
    onSelectAll: (selected: boolean) => void;
    onView: (user: User) => void;
    onBlockUser: (user: User) => void;
}

// Status configuration
const STATUS_CONFIG = {
    active: {
        color: 'bg-green-100 text-green-800 border-green-200',
        icon: CheckCircle2,
        iconColor: 'text-green-500'
    },
    verified: {
        color: 'bg-blue-100 text-blue-800 border-blue-200',
        icon: CheckCircle2,
        iconColor: 'text-blue-500'
    },
    pending_verification: {
        color: 'bg-yellow-100 text-yellow-800 border-yellow-200',
        icon: null,
        iconColor: null,
        dot: 'bg-yellow-400'
    },
    suspended: {
        color: 'bg-red-100 text-red-800 border-red-200',
        icon: XCircle,
        iconColor: 'text-red-500'
    },
    rejected: {
        color: 'bg-red-100 text-red-800 border-red-200',
        icon: XCircle,
        iconColor: 'text-red-500'
    },
    inactive: {
        color: 'bg-gray-100 text-gray-800 border-gray-200',
        icon: XCircle,
        iconColor: 'text-gray-500'
    },
} as const;

// Role configuration
const ROLE_CONFIG = {
    admin: 'bg-purple-50 text-purple-700 border-purple-100',
    lender: 'bg-blue-50 text-blue-700 border-blue-100',
    borrower: 'bg-green-50 text-green-700 border-green-100',
} as const;

// Components
const UserAvatar = React.memo<{ profileImage: string | null; username: string }>(
    ({ profileImage, username }) => {
        const [imgSrc, setImgSrc] = React.useState(
            profileImage || '/avatar-default.png'
        );

        return (
            <div className="relative w-8 h-8 flex-shrink-0">
                <Image
                    src={imgSrc}
                    alt={username}
                    fill
                    className="rounded-full object-cover border border-gray-200"
                    onError={() => setImgSrc('/avatar-default.png')}
                    sizes="32px"
                />
            </div>
        );
    }
);
UserAvatar.displayName = 'UserAvatar';

const StatusBadge = React.memo<{ status: User['status'] }>(({ status }) => {
    const config = STATUS_CONFIG[status];
    const Icon = config.icon;

    return (
        <div className={`inline-flex items-center gap-2 px-2 py-1 rounded-full border text-xs font-medium ${config.color}`}>
            {Icon && <Icon className={`w-3 h-3 ${config.iconColor}`} />}
            <span className="capitalize">
                {status === 'pending_verification' ? 'Pending' : status}
            </span>
        </div>
    );
});
StatusBadge.displayName = 'StatusBadge';

const RoleBadge = React.memo<{ role: string }>(({ role }) => (
    <Badge
        variant="outline"
        className={`text-xs ${ROLE_CONFIG[role as keyof typeof ROLE_CONFIG] || 'bg-gray-50 text-gray-700 border-gray-100'}`}
    >
        {role}
    </Badge>
));
RoleBadge.displayName = 'RoleBadge';

const VerificationStatus = React.memo<{
    emailVerified: boolean | null;
    phoneVerified: boolean | null;
}>(({ emailVerified, phoneVerified }) => (
    <div className="flex flex-col gap-1">
        <div className="flex items-center gap-1">
            <div className={`w-2 h-2 rounded-full ${emailVerified ? 'bg-green-500' : 'bg-gray-300'}`} />
            <span className="text-xs text-gray-600">Email</span>
        </div>
        <div className="flex items-center gap-1">
            <div className={`w-2 h-2 rounded-full ${phoneVerified ? 'bg-green-500' : 'bg-gray-300'}`} />
            <span className="text-xs text-gray-600">Phone</span>
        </div>
    </div>
));
VerificationStatus.displayName = 'VerificationStatus';

const UserActions = React.memo<{
    user: User;
    onView: (user: User) => void;
    onBlockUser: (user: User) => void;
}>(({ user, onView, onBlockUser }) => (
    <DropdownMenu>
        <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8">
                <MoreHorizontal className="w-4 h-4" />
            </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="min-w-[120px]">
            <DropdownMenuItem onClick={() => onView(user)}>
                <Eye className="w-4 h-4 mr-2" />
                View
            </DropdownMenuItem>
            <DropdownMenuItem
                onClick={() => onBlockUser(user)}
                disabled={user.status === 'suspended'}
                className="text-red-600 focus:text-red-600"
            >
                <Shield className="w-4 h-4 mr-2" />
                Block User
            </DropdownMenuItem>
        </DropdownMenuContent>
    </DropdownMenu>
));
UserActions.displayName = 'UserActions';

const BulkActionToolbar = React.memo<{
    selectedCount: number;
    onBulkBlock: () => void;
}>(({ selectedCount, onBulkBlock }) => (
    <div className="flex items-center justify-between bg-blue-50 border-b border-blue-200 px-4 py-3">
        <div className="flex items-center gap-2 text-blue-900 font-medium">
            <UserIcon className="w-5 h-5 text-blue-600" />
            <span>{selectedCount} user{selectedCount !== 1 ? 's' : ''} selected</span>
        </div>
        <Button
            variant="destructive"
            size="sm"
            onClick={onBulkBlock}
            className="flex items-center gap-2"
        >
            <Shield className="w-4 h-4" />
            Block Users
            <span className="bg-white text-red-600 font-bold rounded-full w-5 h-5 text-xs flex items-center justify-center">
                {selectedCount}
            </span>
        </Button>
    </div>
));
BulkActionToolbar.displayName = 'BulkActionToolbar';

// Main component
const TableList: React.FC<TableListProps> = ({
    users,
    selectedUserIds,
    onSelectUser,
    onSelectAll,
    onView,
    onBlockUser,
}) => {
    const masterCheckboxRef = useRef<HTMLSpanElement>(null);

    const allSelected = users.length > 0 && users.every(u => selectedUserIds.includes(u.uid));
    const indeterminate = selectedUserIds.length > 0 && !allSelected;

    useEffect(() => {
        const checkbox = masterCheckboxRef.current?.querySelector('input[type="checkbox"]') as HTMLInputElement;
        if (checkbox) checkbox.indeterminate = indeterminate;
    }, [indeterminate]);

    const handleBulkBlock = () => {
        selectedUserIds.forEach(uid => {
            const user = users.find(u => u.uid === uid);
            if (user && user.status !== 'suspended') {
                onBlockUser(user);
            }
        });
    };

    const formatDate = (dateString: string) =>
        new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });

    const getDisplayName = (user: User) =>
        user.full_name || `${user.first_name || ''} ${user.last_name || ''}`.trim() || 'No name';

    if (!users.length) {
        return (
            <div className="text-center py-12 text-gray-500">
                <UserIcon className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                <p className="text-lg font-medium">No users found</p>
            </div>
        );
    }

    return (
        <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
            {selectedUserIds.length > 0 && (
                <BulkActionToolbar
                    selectedCount={selectedUserIds.length}
                    onBulkBlock={handleBulkBlock}
                />
            )}

            <div className="overflow-x-auto">
                <Table>
                    <TableHeader>
                        <TableRow className="bg-gray-50 border-b">
                            <TableHead className="w-12">
                                <span ref={masterCheckboxRef}>
                                    <Checkbox
                                        checked={allSelected}
                                        onCheckedChange={onSelectAll}
                                        aria-label="Select all users"
                                    />
                                </span>
                            </TableHead>
                            <TableHead className="min-w-[200px] font-semibold">User</TableHead>
                            <TableHead className="min-w-[180px] font-semibold">Email</TableHead>
                            <TableHead className="min-w-[100px] font-semibold">Roles</TableHead>
                            <TableHead className="min-w-[120px] font-semibold">Status</TableHead>
                            <TableHead className="min-w-[100px] font-semibold">Verification</TableHead>
                            <TableHead className="min-w-[100px] font-semibold">Created</TableHead>
                            <TableHead className="w-16 text-center font-semibold">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {users.map((user, idx) => (
                            <TableRow
                                key={user.uid}
                                className={`transition-colors hover:bg-gray-50 ${idx % 2 === 0 ? 'bg-white' : 'bg-gray-25'}`}
                            >
                                <TableCell>
                                    <Checkbox
                                        checked={selectedUserIds.includes(user.uid)}
                                        onCheckedChange={(checked) => onSelectUser(user.uid, !!checked)}
                                        aria-label={`Select ${user.username}`}
                                    />
                                </TableCell>

                                <TableCell>
                                    <div className="flex items-center gap-3">
                                        <UserAvatar
                                            profileImage={user.profile_image}
                                            username={user.username}
                                        />
                                        <div className="min-w-0">
                                            <p className="font-medium text-gray-900 truncate">
                                                {user.username}
                                            </p>
                                            <p className="text-sm text-gray-500 truncate">
                                                {getDisplayName(user)}
                                            </p>
                                        </div>
                                    </div>
                                </TableCell>

                                <TableCell>
                                    <div className="min-w-0">
                                        <p className="text-sm truncate">{user.email}</p>
                                        {user.phone_number && (
                                            <p className="text-xs text-gray-500 truncate">
                                                {user.phone_number}
                                            </p>
                                        )}
                                    </div>
                                </TableCell>

                                <TableCell>
                                    <div className="flex flex-wrap gap-1">
                                        {user.role.map(role => (
                                            <RoleBadge key={role} role={role} />
                                        ))}
                                    </div>
                                </TableCell>

                                <TableCell>
                                    <StatusBadge status={user.status} />
                                </TableCell>

                                <TableCell>
                                    <VerificationStatus
                                        emailVerified={user.email_verified}
                                        phoneVerified={user.phone_verified}
                                    />
                                </TableCell>

                                <TableCell>
                                    <span className="text-sm text-gray-600">
                                        {formatDate(user.created_at)}
                                    </span>
                                </TableCell>

                                <TableCell>
                                    <UserActions
                                        user={user}
                                        onView={onView}
                                        onBlockUser={onBlockUser}
                                    />
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </div>
        </div>
    );
};

export default TableList;