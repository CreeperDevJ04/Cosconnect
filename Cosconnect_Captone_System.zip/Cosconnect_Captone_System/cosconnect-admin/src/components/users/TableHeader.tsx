import { zodResolver } from '@hookform/resolvers/zod';
import { Filter, Search, X, Users } from 'lucide-react';
import React from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '../ui/button';
import { FormControl, FormField, FormItem, FormLabel } from '../ui/form';
import { Input } from '../ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Badge } from '../ui/badge';

const filterSchema = z.object({
    search: z.string().optional(),
    status: z.string().optional(),
});

export type FilterFormValues = z.infer<typeof filterSchema>;

interface TableHeaderProps {
    onFilter: (values: FilterFormValues) => void;
    defaultValues?: FilterFormValues;
    totalUsers?: number;
    filteredUsers?: number;
    isFiltered?: boolean;
}

const TableHeader: React.FC<TableHeaderProps> = ({
    onFilter,
    defaultValues,
    totalUsers = 0,
    filteredUsers = 0,
    isFiltered = false
}) => {
    const methods = useForm<FilterFormValues>({
        resolver: zodResolver(filterSchema),
        defaultValues: defaultValues || { search: '', status: 'all' },
    });

    const { handleSubmit, reset, watch, setValue } = methods;

    const currentFilters = watch();
    const hasActiveFilters = !!(currentFilters.search || (currentFilters.status && currentFilters.status !== 'all'));

    const handleReset = () => {
        reset({ search: '', status: 'all' });
        onFilter({ search: '', status: 'all' });
    };

    const clearSearch = () => {
        setValue('search', '');
        const newFilters = { ...currentFilters, search: '' };
        onFilter(newFilters);
    };

    const clearStatus = () => {
        setValue('status', 'all');
        const newFilters = { ...currentFilters, status: 'all' };
        onFilter(newFilters);
    };

    const getStatusLabel = (status: string) => {
        switch (status) {
            case 'active': return 'Active';
            case 'verified': return 'Verified';
            case 'pending': return 'Pending';
            case 'suspended': return 'Suspended';
            case 'rejected': return 'Rejected';
            default: return 'All Status';
        }
    };

    return (
        <div className="bg-white rounded-lg border border-gray-200 shadow-md p-4 md:p-6 mb-2">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
                <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2">
                        <Users className="w-5 h-5 text-gray-500" />
                        <h2 className="text-xl font-semibold tracking-tight text-gray-900">
                            Users Management
                        </h2>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                        <span>
                            {isFiltered ? (
                                <>
                                    Showing <span className="font-medium">{filteredUsers}</span> of <span className="font-medium">{totalUsers}</span> users
                                </>
                            ) : (
                                <>
                                    <span className="font-medium">{totalUsers}</span> users total
                                </>
                            )}
                        </span>
                    </div>
                </div>

                <div className="flex gap-2 flex-wrap">
                    <Button
                        variant="outline"
                        size="sm"
                        type="submit"
                        form="user-table-filter-form"
                        className="border-gray-300"
                    >
                        <Filter className="w-4 h-4 mr-1" />
                        Apply Filters
                    </Button>
                    {hasActiveFilters && (
                        <Button
                            variant="ghost"
                            size="sm"
                            type="button"
                            onClick={handleReset}
                            className="text-gray-500"
                        >
                            <X className="w-4 h-4 mr-1" />
                            Clear All
                        </Button>
                    )}
                </div>
            </div>

            {/* Active Filters Display */}
            {hasActiveFilters && (
                <div className="mb-4 flex flex-wrap gap-2 items-center">
                    <span className="text-sm font-medium text-gray-700">Active filters:</span>
                    {currentFilters.search && (
                        <Badge variant="secondary" className="flex items-center gap-1">
                            Search: "{currentFilters.search}"
                            <button
                                type="button"
                                onClick={clearSearch}
                                className="ml-1 hover:bg-gray-300 rounded-full p-0.5"
                            >
                                <X className="w-3 h-3" />
                            </button>
                        </Badge>
                    )}
                    {currentFilters.status && currentFilters.status !== 'all' && (
                        <Badge variant="secondary" className="flex items-center gap-1">
                            Status: {getStatusLabel(currentFilters.status)}
                            <button
                                type="button"
                                onClick={clearStatus}
                                className="ml-1 hover:bg-gray-300 rounded-full p-0.5"
                            >
                                <X className="w-3 h-3" />
                            </button>
                        </Badge>
                    )}
                </div>
            )}

            <FormProvider {...methods}>
                <form
                    id="user-table-filter-form"
                    onSubmit={handleSubmit(onFilter)}
                    className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4"
                >
                    <FormField
                        name="search"
                        control={methods.control}
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel className="text-xs font-medium text-gray-700">
                                    Search Users
                                </FormLabel>
                                <FormControl>
                                    <div className="relative">
                                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                                        <Input
                                            placeholder="Username, email, or name..."
                                            {...field}
                                            className="pl-10 h-10 text-sm border-gray-300 rounded-md focus:border-blue-500 focus:ring-blue-500"
                                            autoComplete="off"
                                        />
                                        {field.value && (
                                            <button
                                                type="button"
                                                onClick={clearSearch}
                                                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                                            >
                                                <X className="w-4 h-4" />
                                            </button>
                                        )}
                                    </div>
                                </FormControl>
                            </FormItem>
                        )}
                    />

                    <FormField
                        name="status"
                        control={methods.control}
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel className="text-xs font-medium text-gray-700">
                                    Filter by Status
                                </FormLabel>
                                <FormControl>
                                    <Select value={field.value} onValueChange={field.onChange}>
                                        <SelectTrigger className="w-full h-10 text-sm border-gray-300 rounded-md focus:border-blue-500 focus:ring-blue-500">
                                            <SelectValue placeholder="All status" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="all">All Status</SelectItem>
                                            <SelectItem value="active">
                                                <div className="flex items-center gap-2">
                                                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                                                    Active
                                                </div>
                                            </SelectItem>
                                            <SelectItem value="verified">
                                                <div className="flex items-center gap-2">
                                                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                                                    Verified
                                                </div>
                                            </SelectItem>
                                            <SelectItem value="pending">
                                                <div className="flex items-center gap-2">
                                                    <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                                                    Pending Verification
                                                </div>
                                            </SelectItem>
                                            <SelectItem value="suspended">
                                                <div className="flex items-center gap-2">
                                                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                                                    Suspended
                                                </div>
                                            </SelectItem>
                                            <SelectItem value="rejected">
                                                <div className="flex items-center gap-2">
                                                    <div className="w-2 h-2 bg-gray-500 rounded-full"></div>
                                                    Rejected
                                                </div>
                                            </SelectItem>
                                        </SelectContent>
                                    </Select>
                                </FormControl>
                            </FormItem>
                        )}
                    />

                    {/* Empty space for grid alignment */}
                    <div className="hidden md:block"></div>
                </form>
            </FormProvider>
        </div>
    );
};

export default TableHeader;