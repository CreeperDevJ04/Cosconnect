import { Button } from "@/components/ui/button";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useGetUserDataById } from "@/lib/apis/userApi";
import { useVerifyUserDocument } from "@/lib/apis/adminApi";
import { useUpdateUserDocumentStatus, useUpdateUserStatus } from "@/lib/apis/adminApi";
import { useSupabaseAuth } from "@/lib/hooks/useSupabaseAuth";
import { toast } from "sonner";
import {
    Loader2,
    User,
    Building2,
    MapPin,
    FileText,
    Phone,
    Mail,
    Calendar,
    ExternalLink,
    CheckCircle,
    XCircle,
    Clock,
    AlertTriangle
} from "lucide-react";
import { format } from "date-fns";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface UserDetailsDialogProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    userId: string | undefined;
    onApprove?: (user: any) => void;
    onReject?: (user: any) => void;
}

export function UserDetailsDialog({
    open,
    onOpenChange,
    userId,
    onApprove,
    onReject
}: UserDetailsDialogProps) {
    const { data: userData, isLoading, error } = useGetUserDataById(userId);
    const { verifyDocument, isVerifying } = useVerifyUserDocument();
    const { adminUid } = useSupabaseAuth();
    const { mutateAsync: updateDocumentStatus, isLoading: isUpdatingDocument } = useUpdateUserDocumentStatus();
    const { mutateAsync: updateUserStatus, isLoading: isUpdatingUserStatus } = useUpdateUserStatus();
    // Helper functions
    const formatDate = (dateString?: string | null) => {
        if (!dateString) return 'N/A';
        try {
            return format(new Date(dateString), 'MMM d, yyyy');
        } catch {
            return 'Invalid date';
        }
    };

    const getStatusColor = (status: string) => {
        switch (status.toLowerCase()) {
            case 'verified':
                return 'bg-green-100 text-green-800 border-green-200';
            case 'pending':
                return 'bg-yellow-100 text-yellow-800 border-yellow-200';
            case 'rejected':
                return 'bg-red-100 text-red-800 border-red-200';
            default:
                return 'bg-gray-100 text-gray-800 border-gray-200';
        }
    };

    const getVerificationIcon = (isVerified: boolean) => {
        return isVerified ? (
            <CheckCircle className="h-4 w-4 text-green-600" />
        ) : (
            <XCircle className="h-4 w-4 text-red-600" />
        );
    };

    const getDocumentTypeLabel = (type: string) => {
        const labels: Record<string, string> = {
            'VALID_ID': 'Valid ID',
            'SELFIE_WITH_ID': 'Selfie with ID',
            'BUSINESS_PERMIT': 'Business Permit',
            'DTI_CERTIFICATE': 'DTI Certificate',
            'STOREFRONT_PHOTO': 'Storefront Photo'
        };
        return labels[type] || type.replace(/_/g, ' ');
    };

    const handleVerifyDocument = async (documentType: "VALID_ID" | "SELFIE_WITH_ID") => {
        if (!userId) return;

        try {
            await verifyDocument({
                userId,
                documentType
            });
        } catch (error) {
            console.error('Error verifying document:', error);
        }
    };

    const handleApproveIdentityDocuments = async () => {
        if (!userId || !adminUid) {
            console.error('User ID or Admin ID not available');
            return;
        }

        try {
            // Approve both VALID_ID and SELFIE_WITH_ID documents
            await Promise.all([
                updateDocumentStatus({
                    userId,
                    documentType: "VALID_ID",
                    adminId: adminUid
                }),
                updateDocumentStatus({
                    userId,
                    documentType: "SELFIE_WITH_ID",
                    adminId: adminUid
                })
            ]);

            // Update user status to active
            await updateUserStatus({
                userId,
                status: "active",
                adminId: adminUid
            });

            // Show success message
            toast.success("Identity documents approved successfully! User account is now active.");
        } catch (error) {
            console.error('Failed to approve identity documents:', error);
            toast.error("Failed to approve identity documents. Please try again.");
        }
    };

    // Helper to safely get city name
    const getCityName = (city: string | { id: string; name: string }): string => {
        if (typeof city === 'string') return city;
        if (typeof city === 'object' && city.name) return city.name;
        return 'N/A';
    };

    // Component for address display
    const AddressCard = ({
        address,
        index,
        type = 'personal'
    }: {
        address: any;
        index: number;
        type?: 'personal' | 'business'
    }) => (
        <div className="border rounded-lg p-4 bg-gray-50/50">
            <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium">
                    {type === 'business' ? `Business Location ${index + 1}` : `Address ${index + 1}`}
                </h4>
                {address.is_primary && (
                    <Badge variant="secondary">Primary</Badge>
                )}
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-sm">
                <div>
                    <p className="text-muted-foreground font-medium">
                        {type === 'business' ? 'Business Address' : 'Full Address'}
                    </p>
                    <p className="font-medium break-words">
                        {type === 'business' ? address.business_address : address.address || 'N/A'}
                    </p>
                </div>
                <div>
                    <p className="text-muted-foreground font-medium">Street</p>
                    <p className="font-medium">{address.street || 'N/A'}</p>
                </div>
                <div>
                    <p className="text-muted-foreground font-medium">Barangay</p>
                    <p className="font-medium">{address.barangay || 'N/A'}</p>
                </div>
                <div>
                    <p className="text-muted-foreground font-medium">City</p>
                    <p className="font-medium">{getCityName(address.city)}</p>
                </div>
                <div>
                    <p className="text-muted-foreground font-medium">Province</p>
                    <p className="font-medium">{address.province || 'N/A'}</p>
                </div>
                <div>
                    <p className="text-muted-foreground font-medium">Region</p>
                    <p className="font-medium">{address.region || 'N/A'}</p>
                </div>
                <div>
                    <p className="text-muted-foreground font-medium">Postal Code</p>
                    <p className="font-medium">{address.zip_code || 'N/A'}</p>
                </div>
                <div>
                    <p className="text-muted-foreground font-medium">Country</p>
                    <p className="font-medium">{address.country || 'N/A'}</p>
                </div>
            </div>
        </div>
    );

    if (error) {
        return (
            <Dialog open={open} onOpenChange={onOpenChange}>
                <DialogContent>
                    <Alert>
                        <AlertTriangle className="h-4 w-4" />
                        <AlertDescription>
                            Error loading user details. Please try again.
                        </AlertDescription>
                    </Alert>
                    <DialogFooter>
                        <Button onClick={() => onOpenChange(false)}>Close</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        );
    }

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-6xl max-h-[90vh]">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                        <User className="h-5 w-5" />
                        User Profile Details
                    </DialogTitle>
                    <DialogDescription>
                        Complete user information including personal and business details
                    </DialogDescription>
                </DialogHeader>

                {isLoading ? (
                    <div className="flex justify-center py-12">
                        <div className="text-center">
                            <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
                            <p className="text-muted-foreground">Loading user details...</p>
                        </div>
                    </div>
                ) : userData ? (
                    <ScrollArea className="max-h-[70vh] pr-4">
                        <Tabs defaultValue="personal" className="w-full">
                            <TabsList className="grid w-full grid-cols-4">
                                <TabsTrigger value="personal" className="flex items-center gap-2">
                                    <User className="h-4 w-4" />
                                    Personal
                                </TabsTrigger>
                                <TabsTrigger value="addresses" className="flex items-center gap-2">
                                    <MapPin className="h-4 w-4" />
                                    Addresses
                                </TabsTrigger>
                                <TabsTrigger
                                    value="business"
                                    className="flex items-center gap-2"
                                    disabled={!userData.lenderInfo}
                                >
                                    <Building2 className="h-4 w-4" />
                                    Business
                                </TabsTrigger>
                                <TabsTrigger value="documents" className="flex items-center gap-2">
                                    <FileText className="h-4 w-4" />
                                    Documents
                                </TabsTrigger>
                            </TabsList>

                            {/* Personal Information Tab */}
                            <TabsContent value="personal" className="mt-6">
                                <Card>
                                    <CardHeader>
                                        <CardTitle className="flex items-center justify-between">
                                            Personal Information
                                            <Badge className={getStatusColor(userData.userInfo.status)}>
                                                {userData.userInfo.status}
                                            </Badge>
                                        </CardTitle>
                                        <CardDescription>
                                            Basic user account information and status
                                        </CardDescription>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                            <div className="space-y-2">
                                                <p className="text-sm font-medium text-muted-foreground">Full Name</p>
                                                <p className="text-lg font-semibold">{userData.userInfo.full_name}</p>
                                            </div>
                                            <div className="space-y-2">
                                                <p className="text-sm font-medium text-muted-foreground">Username</p>
                                                <p className="font-medium">{userData.userInfo.username}</p>
                                            </div>
                                            <div className="space-y-2">
                                                <p className="text-sm font-medium text-muted-foreground">User ID</p>
                                                <p className="font-mono text-sm break-all">{userData.userInfo.uid}</p>
                                            </div>
                                            <div className="space-y-2">
                                                <div className="flex items-center gap-2">
                                                    <Mail className="h-4 w-4 text-muted-foreground" />
                                                    <p className="text-sm font-medium text-muted-foreground">Email</p>
                                                </div>
                                                <p className="font-medium break-all">{userData.userInfo.email}</p>
                                            </div>
                                            <div className="space-y-2">
                                                <div className="flex items-center gap-2">
                                                    <Phone className="h-4 w-4 text-muted-foreground" />
                                                    <p className="text-sm font-medium text-muted-foreground">Phone</p>
                                                </div>
                                                <p className="font-medium">
                                                    {userData.userInfo.phone_number || 'Not provided'}
                                                </p>
                                            </div>
                                            <div className="space-y-2">
                                                <p className="text-sm font-medium text-muted-foreground">Current Role</p>
                                                <Badge variant="outline" className="capitalize">
                                                    {userData.userInfo.current_role}
                                                </Badge>
                                            </div>
                                            <div className="space-y-2">
                                                <div className="flex items-center gap-2">
                                                    <Calendar className="h-4 w-4 text-muted-foreground" />
                                                    <p className="text-sm font-medium text-muted-foreground">Member Since</p>
                                                </div>
                                                <p className="font-medium">{formatDate(userData.userInfo.created_at)}</p>
                                            </div>
                                            <div className="space-y-2">
                                                <div className="flex items-center gap-2">
                                                    <Clock className="h-4 w-4 text-muted-foreground" />
                                                    <p className="text-sm font-medium text-muted-foreground">Last Updated</p>
                                                </div>
                                                <p className="font-medium">{formatDate(userData.userInfo.updated_at)}</p>
                                            </div>
                                            <div className="space-y-2">
                                                <p className="text-sm font-medium text-muted-foreground">Online Status</p>
                                                <div className="flex items-center gap-2">
                                                    <div className={`w-2 h-2 rounded-full ${userData.userInfo.is_online ? 'bg-green-500' : 'bg-gray-400'}`} />
                                                    <span className="text-sm">
                                                        {userData.userInfo.is_online ? 'Online' : 'Offline'}
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>
                            </TabsContent>

                            {/* Addresses Tab */}
                            <TabsContent value="addresses" className="mt-6">
                                <div className="space-y-6">
                                    {/* Personal Addresses */}
                                    {userData.borrowerInfo?.addresses && userData.borrowerInfo.addresses.length > 0 ? (
                                        <Card>
                                            <CardHeader>
                                                <CardTitle>Personal Addresses</CardTitle>
                                                <CardDescription>
                                                    Registered personal addresses ({userData.borrowerInfo.addresses.length} total)
                                                </CardDescription>
                                            </CardHeader>
                                            <CardContent className="space-y-4">
                                                {userData.borrowerInfo.addresses.map((address, index) => (
                                                    <AddressCard
                                                        key={address.id || `personal-${index}`}
                                                        address={address}
                                                        index={index}
                                                        type="personal"
                                                    />
                                                ))}
                                            </CardContent>
                                        </Card>
                                    ) : null}

                                    {/* Business Addresses */}
                                    {userData.lenderInfo?.addresses && userData.lenderInfo.addresses.length > 0 ? (
                                        <Card>
                                            <CardHeader>
                                                <CardTitle>Business Addresses</CardTitle>
                                                <CardDescription>
                                                    Registered business locations ({userData.lenderInfo.addresses.length} total)
                                                </CardDescription>
                                            </CardHeader>
                                            <CardContent className="space-y-4">
                                                {userData.lenderInfo.addresses.map((address, index) => (
                                                    <AddressCard
                                                        key={address.id || `business-${index}`}
                                                        address={address}
                                                        index={index}
                                                        type="business"
                                                    />
                                                ))}
                                            </CardContent>
                                        </Card>
                                    ) : null}

                                    {/* No addresses message */}
                                    {(!userData.borrowerInfo?.addresses?.length &&
                                        !userData.lenderInfo?.addresses?.length) && (
                                            <Card>
                                                <CardContent className="py-12 text-center">
                                                    <MapPin className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                                                    <p className="text-muted-foreground text-lg">No addresses registered</p>
                                                    <p className="text-muted-foreground text-sm mt-2">
                                                        User hasn't added any personal or business addresses yet.
                                                    </p>
                                                </CardContent>
                                            </Card>
                                        )}
                                </div>
                            </TabsContent>

                            {/* Business Information Tab */}
                            <TabsContent value="business" className="mt-6">
                                {userData.lenderInfo ? (
                                    <Card>
                                        <CardHeader>
                                            <CardTitle className="flex items-center justify-between">
                                                <div className="flex items-center gap-2">
                                                    <Building2 className="h-5 w-5" />
                                                    {userData.lenderInfo.business_name}
                                                </div>
                                                <div className="flex items-center gap-2">
                                                    {getVerificationIcon(userData.lenderInfo.is_verified)}
                                                    <Badge className={userData.lenderInfo.is_verified ?
                                                        'bg-green-100 text-green-800 border-green-200' :
                                                        'bg-red-100 text-red-800 border-red-200'
                                                    }>
                                                        {userData.lenderInfo.is_verified ? 'Verified' : 'Not Verified'}
                                                    </Badge>
                                                </div>
                                            </CardTitle>
                                            <CardDescription>
                                                Business registration and verification details
                                            </CardDescription>
                                        </CardHeader>
                                        <CardContent>
                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                                <div className="space-y-2">
                                                    <p className="text-sm font-medium text-muted-foreground">Business Type</p>
                                                    <Badge variant="outline">{userData.lenderInfo.business_type}</Badge>
                                                </div>
                                                <div className="space-y-2">
                                                    <p className="text-sm font-medium text-muted-foreground">Terms Status</p>
                                                    <p className="font-medium">{userData.lenderInfo.terms_and_conditions}</p>
                                                </div>
                                                <div className="md:col-span-2 space-y-2">
                                                    <p className="text-sm font-medium text-muted-foreground">Business Description</p>
                                                    <p className="text-muted-foreground">{userData.lenderInfo.business_description}</p>
                                                </div>
                                                <div className="space-y-2">
                                                    <div className="flex items-center gap-2">
                                                        <Mail className="h-4 w-4 text-muted-foreground" />
                                                        <p className="text-sm font-medium text-muted-foreground">Business Email</p>
                                                    </div>
                                                    <p className="font-medium break-all">{userData.lenderInfo.business_email}</p>
                                                </div>
                                                <div className="space-y-2">
                                                    <div className="flex items-center gap-2">
                                                        <Phone className="h-4 w-4 text-muted-foreground" />
                                                        <p className="text-sm font-medium text-muted-foreground">Business Phone</p>
                                                    </div>
                                                    <p className="font-medium">{userData.lenderInfo.business_phone_number}</p>
                                                </div>
                                                <div className="space-y-2">
                                                    <p className="text-sm font-medium text-muted-foreground">Business Telephone</p>
                                                    <p className="font-medium">{userData.lenderInfo.business_telephone || 'Not provided'}</p>
                                                </div>
                                                <div className="space-y-2">
                                                    <p className="text-sm font-medium text-muted-foreground">Verified Date</p>
                                                    <p className="font-medium">{formatDate(userData.lenderInfo.verified_at)}</p>
                                                </div>
                                            </div>

                                            {userData.lenderInfo.rejection_reason && (
                                                <Alert className="mt-6">
                                                    <AlertTriangle className="h-4 w-4" />
                                                    <AlertDescription>
                                                        <strong>Rejection Reason:</strong> {userData.lenderInfo.rejection_reason}
                                                    </AlertDescription>
                                                </Alert>
                                            )}
                                        </CardContent>
                                    </Card>
                                ) : (
                                    <Card>
                                        <CardContent className="py-12 text-center">
                                            <Building2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                                            <p className="text-muted-foreground text-lg">No business information available</p>
                                            <p className="text-muted-foreground text-sm mt-2">
                                                This user hasn't registered as a lender or business owner.
                                            </p>
                                        </CardContent>
                                    </Card>
                                )}
                            </TabsContent>
                            {/* Documents Tab */}
                            <TabsContent value="documents" className="mt-6">
                                <Card>
                                    <CardHeader>
                                        <CardTitle>Document Verification</CardTitle>
                                        <CardDescription>
                                            Uploaded documents and their verification status
                                        </CardDescription>
                                    </CardHeader>
                                    <CardContent>
                                        {userData.borrowerInfo ? (
                                            <div className="grid gap-4">
                                                {/* List of known document fields */}
                                                {[
                                                    {
                                                        label: "Valid ID",
                                                        url: userData.borrowerInfo.documents.find((doc: any) => doc.document_type === "VALID_ID")?.file_url,
                                                        type: "VALID_ID" as const,
                                                        isVerified: userData.borrowerInfo.documents.find((doc: any) => doc.document_type === "VALID_ID")?.status === "verified",
                                                    },
                                                    {
                                                        label: "Selfie with ID",
                                                        url: userData.borrowerInfo.documents.find((doc: any) => doc.document_type === "SELFIE_WITH_ID")?.file_url,
                                                        type: "SELFIE_WITH_ID" as const,
                                                        isVerified: userData.borrowerInfo.documents.find((doc: any) => doc.document_type === "SELFIE_WITH_ID")?.status === "verified",
                                                    },
                                                    {
                                                        label: "Business Permit",
                                                        url: userData.lenderInfo?.upload_business_permit,
                                                    },
                                                    {
                                                        label: "DTI Certificate",
                                                        url: userData.lenderInfo?.upload_dti_certificate,
                                                    },
                                                    {
                                                        label: "Storefront Photo",
                                                        url: userData.lenderInfo?.upload_storefront_photo,
                                                    },
                                                ]
                                                    .filter((doc) => !!doc.url)
                                                    .map((doc, index) => (
                                                        <div
                                                            key={index}
                                                            className="border rounded-lg p-4 bg-gray-50/50 flex flex-col gap-3"
                                                        >
                                                            <div className="flex items-center justify-between">
                                                                <div className="flex items-center gap-3">
                                                                    <FileText className="h-5 w-5 text-muted-foreground" />
                                                                    <div>
                                                                        <h4 className="font-medium">{doc.label}</h4>
                                                                        {doc.isVerified && (
                                                                            <Badge className="bg-green-100 text-green-800 border-green-200 text-xs">
                                                                                Verified
                                                                            </Badge>
                                                                        )}
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                                                                <Button variant="outline" size="sm" asChild>
                                                                    <a
                                                                        href={doc.url}
                                                                        target="_blank"
                                                                        rel="noopener noreferrer"
                                                                        className="flex items-center gap-2"
                                                                    >
                                                                        <ExternalLink className="h-4 w-4" />
                                                                        View Document
                                                                    </a>
                                                                </Button>

                                                            </div>
                                                        </div>
                                                    ))}

                                                {/* Single approve button for identity documents */}
                                                {(() => {
                                                    const validIdDoc = userData.borrowerInfo.documents.find((doc: any) => doc.document_type === "VALID_ID");
                                                    const selfieDoc = userData.borrowerInfo.documents.find((doc: any) => doc.document_type === "SELFIE_WITH_ID");
                                                    const hasBothDocuments = validIdDoc?.file_url && selfieDoc?.file_url;
                                                    const bothNotVerified = validIdDoc?.status !== "verified" && selfieDoc?.status !== "verified";

                                                    return hasBothDocuments && bothNotVerified ? (
                                                        <div className="border rounded-lg p-4 bg-blue-50/50 border-blue-200">
                                                            <div className="flex items-center justify-between">
                                                                <div className="flex items-center gap-3">
                                                                    <CheckCircle className="h-5 w-5 text-blue-600" />
                                                                    <div>
                                                                        <h4 className="font-medium text-blue-900">Approve Identity Documents</h4>
                                                                        <p className="text-sm text-blue-700">Approve both Valid ID and Selfie with ID documents</p>
                                                                    </div>
                                                                </div>
                                                                <Button
                                                                    variant="default"
                                                                    size="sm"
                                                                    className="bg-blue-600 hover:bg-blue-700"
                                                                    onClick={handleApproveIdentityDocuments}
                                                                    disabled={isUpdatingDocument || isUpdatingUserStatus}
                                                                >
                                                                    {isUpdatingDocument ? (
                                                                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                                                                    ) : (
                                                                        <CheckCircle className="h-4 w-4 mr-2" />
                                                                    )}
                                                                    Approve Both Documents
                                                                </Button>
                                                            </div>
                                                        </div>
                                                    ) : null;
                                                })()}

                                                {/* If no documents at all */}
                                                {!userData.lenderInfo?.upload_business_permit &&
                                                    !userData.lenderInfo?.upload_dti_certificate &&
                                                    !userData.lenderInfo?.upload_storefront_photo ? (
                                                    <div className="py-12 text-center">
                                                        <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                                                        <p className="text-muted-foreground text-lg">
                                                            No documents uploaded
                                                        </p>
                                                        <p className="text-muted-foreground text-sm mt-2">
                                                            User hasn’t submitted any verification documents yet.
                                                        </p>
                                                    </div>
                                                ) : null}
                                            </div>
                                        ) : (
                                            <div className="py-12 text-center">
                                                <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                                                <p className="text-muted-foreground text-lg">No user data found</p>
                                            </div>
                                        )}
                                    </CardContent>
                                </Card>
                            </TabsContent>

                        </Tabs>
                    </ScrollArea>
                ) : (
                    <div className="py-12 text-center">
                        <User className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                        <p className="text-muted-foreground text-lg">No user data available</p>
                        <p className="text-muted-foreground text-sm mt-2">
                            Unable to load user information at this time.
                        </p>
                    </div>
                )}

                {(() => {
                    const hasBusinessDocuments = userData?.lenderInfo?.upload_business_permit &&
                                                userData?.lenderInfo?.upload_dti_certificate &&
                                                userData?.lenderInfo?.upload_storefront_photo;
                    const isNotVerified = !userData?.lenderInfo?.is_verified;

                    return hasBusinessDocuments && isNotVerified ? (
                        <DialogFooter className="flex gap-2 border-t">
                            <Button variant="outline" onClick={() => onOpenChange(false)}>
                                Close
                            </Button>
                            {onApprove && userData && (
                                <Button
                                    variant="default"
                                    className="bg-green-600 hover:bg-green-700"
                                    onClick={() => onApprove(userData || '')}
                                >
                                    <CheckCircle className="h-4 w-4 mr-2" />
                                    Approve Lender Account
                                </Button>
                            )}
                            {onReject && userData && (
                                <Button
                                    variant="destructive"
                                    onClick={() => onReject(userData || '')}
                                >
                                    <XCircle className="h-4 w-4 mr-2" />
                                    Reject User
                                </Button>
                            )}
                        </DialogFooter>
                    ) : null;
                })()}
            </DialogContent>
        </Dialog>
    );
}