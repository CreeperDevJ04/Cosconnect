import { AlertCircle, Users } from "lucide-react"
import { useRouter, useSearchParams } from "next/navigation"
import type React from "react"
import { useCallback, useEffect, useMemo, useState } from "react"
import { toast } from "sonner"
import DeleteUsersDialog from "./DeleteUsersDialog"
import TableHeader, { type FilterFormValues } from "./TableHeader"
import TableList from "./TableList"
import TablePagination from "./TablePagination"
import { useDeleteUserById, useDeleteUsersByBulkIds, useUpdateUserStatus } from "@/lib/apis/adminApi"
import { useSupabaseAuth } from "@/lib/hooks/useSupabaseAuth"
import { UserDetailsDialog } from "./UserDetailsDialog"
import { useGetAllUsersCreated } from "@/lib/apis/adminApi"

// Updated User type matching your JSON response
interface User {
    uid: string;
    id: string;
    username: string;
    email: string;
    phone_number: string;
    full_name: string | null;
    first_name: string | null;
    last_name: string | null;
    profile_image: string | null;
    role: string[];
    current_role: string | null;
    status: 'active' | 'inactive' | 'suspended' | 'pending_verification' | 'verified' | 'rejected';
    email_verified: boolean | null;
    phone_verified: boolean | null;
    created_at: string;
}

const DEFAULT_PAGE_SIZE = 10;

type DeleteDialogState =
    | { open: false }
    | { open: true; mode: "single"; user: User }
    | { open: true; mode: "bulk"; users: User[] };

const parseQueryParams = (params: URLSearchParams) => ({
    search: params.get("search") || "",
    status: params.get("status") || "all",
    page: Number(params.get("page")) || 1,
    limit: Number(params.get("limit")) || DEFAULT_PAGE_SIZE,
});

const UsersManagementSection: React.FC = () => {
    const router = useRouter();
    const searchParams = useSearchParams();

    // State management
    const [filters, setFilters] = useState<FilterFormValues>({
        search: "",
        status: "all",
    });
    const [currentPage, setCurrentPage] = useState(1);
    const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
    const [selectedUserIds, setSelectedUserIds] = useState<string[]>([]);
    const [deleteDialog, setDeleteDialog] = useState<DeleteDialogState>({ open: false });
    const [viewDialog, setViewDialog] = useState<{ open: boolean; userId?: string }>({
        open: false,
    });

    const { adminUid } = useSupabaseAuth();

    // Initialize from URL params
    useEffect(() => {
        const params = parseQueryParams(searchParams);
        setFilters({ search: params.search, status: params.status });
        setCurrentPage(params.page);
        setPageSize(params.limit);
    }, [searchParams]);

    // API hooks
    const { users, pagination, isLoading, isError, refetch } = useGetAllUsersCreated({
        page: currentPage,
        limit: pageSize,
    });

    const { mutateAsync: deleteUserById, isLoading: isDeleting } = useDeleteUserById();
    const { mutateAsync: deleteUsersByBulkIds, isLoading: isBulkDeleting } = useDeleteUsersByBulkIds();
    const { mutateAsync: updateUserStatus } = useUpdateUserStatus();

    // URL state management
    const updateQueryParams = useCallback(
        (newFilters: FilterFormValues, page = 1, limit = pageSize) => {
            const params = new URLSearchParams();
            if (newFilters.search) params.set("search", newFilters.search);
            if (newFilters.status !== "all") params.set("status", newFilters?.status as any);
            if (page > 1) params.set("page", String(page));
            if (limit !== DEFAULT_PAGE_SIZE) params.set("limit", String(limit));

            const url = params.toString() ? `?${params}` : window.location.pathname;
            router.replace(url);
        },
        [router, pageSize]
    );

    // Client-side filtering
    const filteredUsers = useMemo(() => {
        if (!users?.length) return [];

        return users.filter((user) => {
            // Search filter
            if (filters.search) {
                const searchTerm = filters.search.toLowerCase();
                const searchableFields = [
                    user.username,
                    user.email,
                    user.full_name,
                    user.first_name,
                    user.last_name,
                ].filter(Boolean);

                if (!searchableFields.some(field =>
                    field?.toLowerCase().includes(searchTerm)
                )) return false;
            }

            // Status filter
            if (filters.status !== "all") {
                const statusMapping = {
                    pending: "pending_verification",
                    active: "active",
                    verified: "verified",
                    suspended: "suspended",
                    rejected: "rejected",
                };

                const mappedStatus = statusMapping[filters.status as keyof typeof statusMapping];
                if (mappedStatus && user.status !== mappedStatus) return false;
            }

            return true;
        });
    }, [users, filters]);

    // Event handlers
    const handleSelectUser = useCallback((uid: string, selected: boolean) => {
        setSelectedUserIds(prev =>
            selected ? [...prev, uid] : prev.filter(id => id !== uid)
        );
    }, []);

    const handleSelectAll = useCallback((selected: boolean) => {
        setSelectedUserIds(selected ? filteredUsers.map(u => u.uid) : []);
    }, [filteredUsers]);

    const handleView = useCallback((user: User) => {
        setViewDialog({ open: true, userId: user.uid });
    }, []);

    const handleBlockUser = useCallback(async (user: any) => {
        console.log("approve", user)
        if (!adminUid) {
            toast.error("Admin authentication required");
            return;
        }

        try {
            /*  await updateUserStatus({
                 userId: user.uid,
                 status: "reject",
                 adminId: adminUid
             });
             toast.success(`User ${user.username} has been blocked`);
             refetch(); */
        } catch (error) {
            toast.error("Failed to block user");
        }
    }, [adminUid, updateUserStatus, refetch]);


    const handleApproveUser = useCallback(async (user: any) => {
        console.log("userrr", user)
        if (!adminUid) {
            toast.error("Admin authentication required");
            return;
        }
        console.log("user", user)
        try {
            await updateUserStatus({
                userId: user.userInfo.uid,
                status: "approve",
                adminId: adminUid
            });
            toast.success(`User ${user.userInfo.username} has been approved`);
            refetch();
        } catch (error) {
            toast.error("Failed to block user");
        }
    }, [adminUid, updateUserStatus, refetch]);

    const handleBulkDelete = useCallback(async () => {
        if (!adminUid || !selectedUserIds.length) return;

        try {
            await deleteUsersByBulkIds({
                userIds: selectedUserIds,
                adminId: adminUid
            });
            toast.success(`Successfully deleted ${selectedUserIds.length} users`);
            setSelectedUserIds([]);
            setDeleteDialog({ open: false });
            refetch();
        } catch {
            toast.error("Failed to delete users");
        }
    }, [adminUid, selectedUserIds, deleteUsersByBulkIds, refetch]);

    const handleSingleDelete = useCallback(async (user: User) => {
        if (!adminUid) return;

        try {
            await deleteUserById({ userId: user.uid, adminId: adminUid });
            toast.success(`User ${user.username} deleted successfully`);
            setSelectedUserIds(prev => prev.filter(id => id !== user.uid));
            setDeleteDialog({ open: false });
            refetch();
        } catch {
            toast.error("Failed to delete user");
        }
    }, [adminUid, deleteUserById, refetch]);

    const handleFilterChange = useCallback((values: FilterFormValues) => {
        setFilters(values);
        setCurrentPage(1);
        setSelectedUserIds([]);
        updateQueryParams(values, 1, pageSize);
    }, [updateQueryParams, pageSize]);

    const handlePageChange = useCallback((page: number) => {
        setCurrentPage(page);
        setSelectedUserIds([]);
        updateQueryParams(filters, page, pageSize);
    }, [updateQueryParams, filters, pageSize]);

    const handlePageSizeChange = useCallback((newPageSize: number) => {
        setPageSize(newPageSize);
        setCurrentPage(1);
        setSelectedUserIds([]);
        updateQueryParams(filters, 1, newPageSize);
    }, [updateQueryParams, filters]);

    // Display totals calculation
    const displayTotals = useMemo(() => ({
        showing: filteredUsers.length,
        total: pagination?.total || 0,
        isFiltered: Boolean(filters.search || filters.status !== "all"),
    }), [filteredUsers.length, pagination?.total, filters]);

    // Render loading state
    if (isLoading) {
        return (
            <div className="p-12 text-center">
                <div className="w-12 h-12 bg-blue-50 rounded-full mx-auto mb-4 flex items-center justify-center">
                    <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
                </div>
                <p className="text-gray-600 font-medium">Loading users...</p>
            </div>
        );
    }

    // Render error state
    if (isError) {
        return (
            <div className="p-12 text-center">
                <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
                <p className="text-red-600 font-medium mb-2">Failed to load users</p>
                <button
                    onClick={() => refetch()}
                    className="px-4 py-2 bg-red-50 text-red-600 rounded-md hover:bg-red-100 transition-colors"
                >
                    Try Again
                </button>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <TableHeader
                onFilter={handleFilterChange}
                defaultValues={filters}
                totalUsers={displayTotals.total}
                filteredUsers={displayTotals.showing}
                isFiltered={displayTotals.isFiltered}
            />

            <TableList
                users={filteredUsers}
                selectedUserIds={selectedUserIds}
                onSelectUser={handleSelectUser}
                onSelectAll={handleSelectAll}
                onView={handleView}
                onBlockUser={handleBlockUser}
            />

            {filteredUsers.length > 0 && pagination && (
                <TablePagination
                    currentPage={currentPage}
                    total={pagination.total}
                    pageSize={pageSize}
                    onPageChange={handlePageChange}
                    onPageSizeChange={handlePageSizeChange}
                    hasNextPage={pagination.hasNextPage}
                    hasPrevPage={pagination.hasPrevPage}
                    totalPages={pagination.totalPages}
                />
            )}

            {/* Dialogs */}
            <DeleteUsersDialog
                open={deleteDialog.open}
                onOpenChange={(open) => !open && setDeleteDialog({ open: false })}
                mode={deleteDialog.open ? deleteDialog.mode : "single"}
                user={deleteDialog.open && deleteDialog.mode === "single" ? deleteDialog.user : undefined}
                count={deleteDialog.open && deleteDialog.mode === "bulk" ? deleteDialog.users.length : undefined}
                onConfirm={
                    deleteDialog.open && deleteDialog.mode === "bulk"
                        ? handleBulkDelete
                        : deleteDialog.open && deleteDialog.mode === "single"
                            ? () => handleSingleDelete(deleteDialog.user)
                            : () => { }
                }
                loading={isBulkDeleting || isDeleting}
            />

            <UserDetailsDialog
                open={viewDialog.open}
                onOpenChange={(open) => setViewDialog({ open })}
                userId={viewDialog.userId}
                onApprove={handleApproveUser} // Repurpose for blocking
                onReject={handleApproveUser}  // Repurpose for blocking
            />
        </div>
    );
};

export default UsersManagementSection;