import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"

interface SkeletonTableProps {
    title?: string
    description?: string
    rows?: number
}

export function SkeletonTable({ title, description, rows = 5 }: SkeletonTableProps) {
    return (
        <Card className="rounded-xl shadow-sm">
            <CardHeader>
                {title ? (
                    <CardTitle className="text-lg font-semibold">{title}</CardTitle>
                ) : (
                    <Skeleton className="h-6 w-40 mb-2" />
                )}
                {description ? <CardDescription>{description}</CardDescription> : <Skeleton className="h-4 w-56" />}
            </CardHeader>
            <CardContent>
                <div className="space-y-3">
                    {Array.from({ length: rows }).map((_, i) => (
                        <div key={i} className="flex items-center justify-between py-2">
                            <Skeleton className="h-4 w-32" />
                            <Skeleton className="h-4 w-20" />
                        </div>
                    ))}
                </div>
            </CardContent>
        </Card>
    )
}
