// file: components/analytics/rentals-chart.tsx
"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { Package } from "lucide-react"

interface MonthlyData {
  month: string
  label: string
  rentals?: {
    total: number
    completed: number
    returned: number
    pending: number
  }
}

interface RentalsChartProps {
  data: MonthlyData[]
}

export function RentalsChart({ data = [] }: RentalsChartProps) {
  // Transform data with fallbacks
  const chartData = data.map((item) => ({
    month: item.label,
    total: item.rentals?.total || 0,
    completed: item.rentals?.completed || 0,
    returned: item.rentals?.returned || 0,
    pending: item.rentals?.pending || 0,
  }))

  // Calculate totals
  const totalRentals = chartData.reduce((sum, item) => sum + item.total, 0)
  const hasData = totalRentals > 0

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Package className="h-5 w-5 text-primary" />
          Rental Activity
        </CardTitle>
        <CardDescription>
          {hasData
            ? `Monthly rental statistics - Total: ${totalRentals} rentals`
            : "No rental data available for the selected period"
          }
        </CardDescription>
      </CardHeader>
      <CardContent>
        {hasData ? (
          <ResponsiveContainer width="100%" height={350}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis
                dataKey="month"
                className="text-xs"
                tick={{ fill: 'currentColor' }}
              />
              <YAxis
                className="text-xs"
                tick={{ fill: 'currentColor' }}
              />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="rounded-lg border bg-background p-3 shadow-md">
                        <p className="font-semibold mb-2">{payload[0].payload.month}</p>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <div className="h-3 w-3 rounded-full bg-blue-500" />
                            <span className="text-sm">Total: </span>
                            <span className="font-medium">{payload[0].payload.total}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="h-3 w-3 rounded-full bg-green-500" />
                            <span className="text-sm">Returned: </span>
                            <span className="font-medium">{payload[0].payload.returned}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="h-3 w-3 rounded-full bg-emerald-500" />
                            <span className="text-sm">Completed: </span>
                            <span className="font-medium">{payload[0].payload.completed}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="h-3 w-3 rounded-full bg-amber-500" />
                            <span className="text-sm">Pending: </span>
                            <span className="font-medium">{payload[0].payload.pending}</span>
                          </div>
                        </div>
                      </div>
                    )
                  }
                  return null
                }}
              />
              <Legend
                wrapperStyle={{ paddingTop: '20px' }}
                iconType="circle"
              />
              <Line
                type="monotone"
                dataKey="total"
                name="Total"
                stroke="hsl(var(--chart-1))"
                strokeWidth={2}
                dot={{ fill: 'hsl(var(--chart-1))' }}
              />
              <Line
                type="monotone"
                dataKey="returned"
                name="Returned"
                stroke="hsl(var(--chart-2))"
                strokeWidth={2}
                dot={{ fill: 'hsl(var(--chart-2))' }}
              />
              <Line
                type="monotone"
                dataKey="completed"
                name="Completed"
                stroke="hsl(var(--chart-3))"
                strokeWidth={2}
                dot={{ fill: 'hsl(var(--chart-3))' }}
              />
              <Line
                type="monotone"
                dataKey="pending"
                name="Pending"
                stroke="hsl(var(--chart-4))"
                strokeWidth={2}
                dot={{ fill: 'hsl(var(--chart-4))' }}
              />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <div className="flex items-center justify-center h-[350px] text-muted-foreground">
            <div className="text-center space-y-2">
              <Package className="h-12 w-12 mx-auto opacity-20" />
              <p className="text-sm">No rental data to display</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}