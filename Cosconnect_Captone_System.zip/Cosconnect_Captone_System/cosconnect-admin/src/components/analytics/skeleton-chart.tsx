import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"

interface SkeletonChartProps {
    title?: string
    description?: string
}

export function SkeletonChart({ title, description }: SkeletonChartProps) {
    return (
        <Card className="rounded-xl shadow-sm">
            <CardHeader>
                {title ? (
                    <CardTitle className="text-lg font-semibold">{title}</CardTitle>
                ) : (
                    <Skeleton className="h-6 w-48 mb-2" />
                )}
                {description ? <CardDescription>{description}</CardDescription> : <Skeleton className="h-4 w-64" />}
            </CardHeader>
            <CardContent>
                <div className="space-y-3">
                    <Skeleton className="h-[300px] w-full rounded-lg" />
                    <div className="flex items-center justify-center gap-6">
                        <Skeleton className="h-4 w-24" />
                        <Skeleton className="h-4 w-24" />
                        <Skeleton className="h-4 w-24" />
                    </div>
                </div>
            </CardContent>
        </Card>
    )
}
