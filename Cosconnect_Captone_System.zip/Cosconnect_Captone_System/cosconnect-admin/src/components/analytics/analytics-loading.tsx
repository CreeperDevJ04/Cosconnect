import { SkeletonChart } from "./skeleton-chart";
import { SkeletonStatCard } from "./skeleton-start-card";
import { SkeletonTable } from "./skeleton-table";


export function AnalyticsLoading() {
    return (
        <div className="space-y-6">
            {/* Stats Cards Loading */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                {Array.from({ length: 8 }).map((_, i) => (
                    <SkeletonStatCard key={i} />
                ))}
            </div>

            {/* Charts Loading */}
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-2">
                <SkeletonChart title="User Registrations" description="Monthly user growth trends" />
                <SkeletonChart title="Rental Activity" description="Monthly rental statistics" />
            </div>

            <div className="grid gap-6">
                <SkeletonChart title="Revenue Trends" description="Monthly revenue and transaction data" />
            </div>

            {/* Tables Loading */}
            <div className="grid gap-6 md:grid-cols-2">
                <SkeletonTable title="Transaction Breakdown" description="Revenue by transaction type" rows={5} />
                <SkeletonTable title="Rental Status Breakdown" description="Rentals by current status" rows={9} />
            </div>
        </div>
    )
}
