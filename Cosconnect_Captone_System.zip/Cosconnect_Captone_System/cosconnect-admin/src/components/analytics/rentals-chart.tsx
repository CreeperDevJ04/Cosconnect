// file: components/analytics/revenue-chart.tsx
"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { TrendingUp } from "lucide-react"

interface MonthlyData {
    month: string
    label: string
    revenue?: {
        total: number
        rentalFees: number
        extensionFees: number
        damageFees: number
        transactionCount: number
    }
}

interface RevenueChartProps {
    data: MonthlyData[]
}

export function RevenueChart({ data = [] }: RevenueChartProps) {
    // Transform data with fallbacks for missing revenue property
    const chartData = data.map((item) => ({
        month: item.label,
        revenue: item.revenue?.total || 0,
        rentalFees: item.revenue?.rentalFees || 0,
        extensionFees: item.revenue?.extensionFees || 0,
        damageFees: item.revenue?.damageFees || 0,
    }))

    // Calculate totals for display
    const totalRevenue = chartData.reduce((sum, item) => sum + item.revenue, 0)
    const hasData = totalRevenue > 0

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-primary" />
                    Revenue Trends
                </CardTitle>
                <CardDescription>
                    {hasData
                        ? `Monthly revenue and transaction breakdown - Total: ₱${totalRevenue.toLocaleString('en-PH', { minimumFractionDigits: 2 })}`
                        : "No revenue data available for the selected period"
                    }
                </CardDescription>
            </CardHeader>
            <CardContent>
                {hasData ? (
                    <ResponsiveContainer width="100%" height={350}>
                        <BarChart data={chartData}>
                            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                            <XAxis
                                dataKey="month"
                                className="text-xs"
                                tick={{ fill: 'currentColor' }}
                            />
                            <YAxis
                                className="text-xs"
                                tick={{ fill: 'currentColor' }}
                                tickFormatter={(value) => `₱${(value / 1000).toFixed(0)}k`}
                            />
                            <Tooltip
                                content={({ active, payload }) => {
                                    if (active && payload && payload.length) {
                                        return (
                                            <div className="rounded-lg border bg-background p-3 shadow-md">
                                                <p className="font-semibold mb-2">{payload[0].payload.month}</p>
                                                <div className="space-y-1">
                                                    <div className="flex items-center gap-2">
                                                        <div className="h-3 w-3 rounded-full bg-blue-500" />
                                                        <span className="text-sm">Rental Fees: </span>
                                                        <span className="font-medium">
                                                            ₱{payload[0].payload.rentalFees.toLocaleString('en-PH', { minimumFractionDigits: 2 })}
                                                        </span>
                                                    </div>
                                                    <div className="flex items-center gap-2">
                                                        <div className="h-3 w-3 rounded-full bg-purple-500" />
                                                        <span className="text-sm">Extension Fees: </span>
                                                        <span className="font-medium">
                                                            ₱{payload[0].payload.extensionFees.toLocaleString('en-PH', { minimumFractionDigits: 2 })}
                                                        </span>
                                                    </div>
                                                    <div className="flex items-center gap-2">
                                                        <div className="h-3 w-3 rounded-full bg-red-500" />
                                                        <span className="text-sm">Damage Fees: </span>
                                                        <span className="font-medium">
                                                            ₱{payload[0].payload.damageFees.toLocaleString('en-PH', { minimumFractionDigits: 2 })}
                                                        </span>
                                                    </div>
                                                    <div className="border-t pt-1 mt-1">
                                                        <div className="flex items-center gap-2">
                                                            <span className="text-sm font-semibold">Total: </span>
                                                            <span className="font-bold">
                                                                ₱{payload[0].payload.revenue.toLocaleString('en-PH', { minimumFractionDigits: 2 })}
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        )
                                    }
                                    return null
                                }}
                            />
                            <Legend
                                wrapperStyle={{ paddingTop: '20px' }}
                                iconType="circle"
                            />
                            <Bar
                                dataKey="rentalFees"
                                name="Rental Fees"
                                fill="hsl(var(--chart-1))"
                                radius={[4, 4, 0, 0]}
                                stackId="revenue"
                            />
                            <Bar
                                dataKey="extensionFees"
                                name="Extension Fees"
                                fill="hsl(var(--chart-2))"
                                radius={[4, 4, 0, 0]}
                                stackId="revenue"
                            />
                            <Bar
                                dataKey="damageFees"
                                name="Damage Fees"
                                fill="hsl(var(--chart-3))"
                                radius={[4, 4, 0, 0]}
                                stackId="revenue"
                            />
                        </BarChart>
                    </ResponsiveContainer>
                ) : (
                    <div className="flex items-center justify-center h-[350px] text-muted-foreground">
                        <div className="text-center space-y-2">
                            <TrendingUp className="h-12 w-12 mx-auto opacity-20" />
                            <p className="text-sm">No revenue data to display</p>
                        </div>
                    </div>
                )}
            </CardContent>
        </Card>
    )
}