// file: app/(dashboard)/analytics/page.tsx
"use client"

import { AnalyticsError } from "@/components/analytics/analytics-error"
import { AnalyticsLoading } from "@/components/analytics/analytics-loading"
import { RentalStatusBreakdown } from "@/components/analytics/rental-status-breakdown"
import { StatCard } from "@/components/analytics/stat-card"
import { RevenueBreakdown } from "@/components/analytics/revenue-breakdown"
import { UserRegistrationsChart } from "@/components/analytics/user-registration-chart"
import { useGetAnalytics } from "@/lib/apis/analyticsApi"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

import {
    Users,
    UserCheck,
    UserPlus,
    Coins,
    Package,
    CheckCircle,
    TrendingUp,
    Download,
    DollarSign,
    Receipt,
} from "lucide-react"
import React, { useState, useEffect } from "react"
import jsPDF from 'jspdf'
import autoTable from 'jspdf-autotable'
import { RentalsChart } from "./rental-chart"
import { RevenueChart } from "./revenue-chart"

function AnalyticsSection() {
    const [dateRange, setDateRange] = useState<'30' | '90' | '180' | '365' | 'all'>('30')
    const [startDate, setStartDate] = useState<string>('')
    const [endDate, setEndDate] = useState<string>('')
    const [selectedSections, setSelectedSections] = useState<string[]>([
        'users', 'rentals', 'revenue', 'breakdown'
    ])

    const filters = startDate && endDate ? { startDate, endDate } : undefined
    console.log('Analytics filters:', filters)
    const { data, isLoading, error, refetch } = useGetAnalytics(filters)
    const { data: chartData } = useGetAnalytics() // No filters for charts to get all monthly data

    // Calculate date ranges
    useEffect(() => {
        const now = new Date()

        if (dateRange === 'all') {
            setStartDate('')
            setEndDate('')
            return
        }

        const days = parseInt(dateRange)
        const start = new Date(now)
        start.setDate(now.getDate() - days)
        const end = new Date(now)

        setStartDate(start.getFullYear() + '-' + String(start.getMonth() + 1).padStart(2, '0') + '-' + String(start.getDate()).padStart(2, '0'))
        setEndDate(end.getFullYear() + '-' + String(end.getMonth() + 1).padStart(2, '0') + '-' + String(end.getDate()).padStart(2, '0'))
    }, [dateRange])

    const generatePDF = () => {
        if (!data?.data) return

        const doc = new jsPDF()
        const { users, rentals, revenue } = data.data

        // Calculate lender earnings before commission
        const lenderEarningsBeforeCommission =
            (revenue?.breakdown?.rentalFees ?? 0) +
            (revenue?.breakdown?.extensionFees ?? 0) +
            (revenue?.breakdown?.damageFees ?? 0)

        // Create safe revenue object for PDF generation
        const safeRevenue = {
            totalRevenue: revenue?.totalRevenue ?? 0,
            totalCollected: revenue?.totalCollected ?? 0,
            platformRevenue: revenue?.platformRevenue ?? 0,
            lenderPayout: revenue?.lenderPayout ?? 0,
            lenderEarningsBeforeCommission: revenue?.lenderEarningsBeforeCommission ?? lenderEarningsBeforeCommission,
            netRevenue: revenue?.netRevenue ?? 0,
            thisMonthRevenue: revenue?.thisMonthRevenue ?? 0,
            totalTransactions: revenue?.totalTransactions ?? 0,
            thisMonthTransactions: revenue?.thisMonthTransactions ?? 0,
            breakdown: {
                rentalFees: revenue?.breakdown?.rentalFees ?? 0,
                securityDeposits: revenue?.breakdown?.securityDeposits ?? revenue?.breakdown?.deposits ?? 0,
                extensionFees: revenue?.breakdown?.extensionFees ?? 0,
                damageFees: revenue?.breakdown?.damageFees ?? 0,
                processingFees: revenue?.breakdown?.processingFees ?? 0,
                platformCommissions: revenue?.breakdown?.platformCommissions ?? 0,
            },
            fees: {
                processingFeeRate: revenue?.fees?.processingFeeRate ?? 0.03,
                commissionRate: revenue?.fees?.commissionRate ?? 0.05,
                totalProcessingFees: revenue?.fees?.totalProcessingFees ?? 0,
                totalCommissions: revenue?.fees?.totalCommissions ?? 0,
            },
            payoutStatus: {
                completed: revenue?.payoutStatus?.completed ?? 0,
                pending: revenue?.payoutStatus?.pending ?? 0,
            },
            refundStatus: {
                completed: revenue?.refundStatus?.completed ?? 0,
                pending: revenue?.refundStatus?.pending ?? 0,
            },
        }
        const pageWidth = doc.internal.pageSize.getWidth()
        let yPos = 20

        // Header
        doc.setFillColor(99, 102, 241)
        doc.rect(0, 0, pageWidth, 35, 'F')
        doc.setTextColor(255, 255, 255)
        doc.setFontSize(22)
        doc.setFont('helvetica', 'bold')
        doc.text('CosConnect Analytics Report', pageWidth / 2, 18, { align: 'center' })
        doc.setFontSize(10)
        doc.setFont('helvetica', 'normal')
        doc.text(`Generated: ${new Date().toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        })}`, pageWidth / 2, 28, { align: 'center' })

        doc.setTextColor(0, 0, 0)
        yPos = 45

        // Date Range
        if (startDate && endDate) {
            doc.setFontSize(10)
            doc.setTextColor(100, 100, 100)
            const rangeText = `Period: ${new Date(startDate).toLocaleDateString('en-US')} - ${new Date(endDate).toLocaleDateString('en-US')}`
            doc.text(rangeText, pageWidth / 2, yPos, { align: 'center' })
            yPos += 12
        } else {
            doc.setFontSize(10)
            doc.setTextColor(100, 100, 100)
            doc.text('Period: All Time', pageWidth / 2, yPos, { align: 'center' })
            yPos += 12
        }

        // User Statistics
        if (selectedSections.includes('users')) {
            doc.setFillColor(239, 246, 255)
            doc.rect(15, yPos - 3, pageWidth - 30, 8, 'F')
            doc.setFontSize(12)
            doc.setFont('helvetica', 'bold')
            doc.setTextColor(59, 130, 246)
            doc.text('User Statistics', 20, yPos + 3)
            yPos += 12

            autoTable(doc, {
                startY: yPos,
                head: [['Metric', 'Count']],
                body: [
                    ['Total Users', users.total.toLocaleString()],
                    ['Borrowers', users.borrowers.toLocaleString()],
                    ['Lenders', users.lenders.toLocaleString()],
                    ['Both Roles', users.bothRoles.toLocaleString()],
                    ['New This Month', users.thisMonth.toLocaleString()],
                ],
                theme: 'striped',
                headStyles: { fillColor: [59, 130, 246], fontSize: 10 },
                styles: { fontSize: 9, cellPadding: 4 },
                margin: { left: 15, right: 15 },
            })
            yPos = (doc as any).lastAutoTable.finalY + 15
        }

        // Rental Statistics
        if (selectedSections.includes('rentals')) {
            if (yPos > 240) {
                doc.addPage()
                yPos = 20
            }

            doc.setFillColor(239, 246, 255)
            doc.rect(15, yPos - 3, pageWidth - 30, 8, 'F')
            doc.setFontSize(12)
            doc.setFont('helvetica', 'bold')
            doc.setTextColor(16, 185, 129)
            doc.text('Rental Statistics', 20, yPos + 3)
            yPos += 12

            autoTable(doc, {
                startY: yPos,
                head: [['Status', 'Count']],
                body: [
                    ['Total Rentals', rentals.total.toLocaleString()],
                    ['Pending', rentals.pending.toLocaleString()],
                    ['Confirmed', rentals.confirmed.toLocaleString()],
                    ['Accepted', rentals.accepted.toLocaleString()],
                    ['Delivered', rentals.delivered.toLocaleString()],
                    ['Returned', rentals.returned.toLocaleString()],
                    ['Completed', rentals.completed.toLocaleString()],
                    ['Cancelled', rentals.cancelled.toLocaleString()],
                    ['Rejected', rentals.rejected.toLocaleString()],

                ],
                theme: 'striped',
                headStyles: { fillColor: [16, 185, 129], fontSize: 10 },
                styles: { fontSize: 9, cellPadding: 4 },
                margin: { left: 15, right: 15 },
            })
            yPos = (doc as any).lastAutoTable.finalY + 15
        }

        // Revenue Statistics
        if (selectedSections.includes('revenue')) {
            if (yPos > 220) {
                doc.addPage()
                yPos = 20
            }

            doc.setFillColor(254, 243, 199)
            doc.rect(15, yPos - 3, pageWidth - 30, 8, 'F')
            doc.setFontSize(12)
            doc.setFont('helvetica', 'bold')
            doc.setTextColor(245, 158, 11)
            doc.text('Revenue Overview', 20, yPos + 3)
            yPos += 12

            autoTable(doc, {
                startY: yPos,
                head: [['Metric', 'Amount (PHP)']],
                body: [
                    ['Total Revenue', `PHP ${safeRevenue.totalRevenue.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`],
                    ['Net Revenue', `PHP ${safeRevenue.netRevenue.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`],
                    ['This Month Revenue', `PHP ${safeRevenue.thisMonthRevenue.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`],
                    ['Total Transactions', safeRevenue.totalTransactions.toLocaleString()],
                    ['This Month Transactions', safeRevenue.thisMonthTransactions.toLocaleString()],
                ],
                theme: 'striped',
                headStyles: { fillColor: [245, 158, 11], fontSize: 10 },
                styles: { fontSize: 9, cellPadding: 4 },
                margin: { left: 15, right: 15 },
            })
            yPos = (doc as any).lastAutoTable.finalY + 15
        }

        // Revenue Breakdown
        if (selectedSections.includes('breakdown')) {
            if (yPos > 200) {
                doc.addPage()
                yPos = 20
            }

            // Revenue Sources Section
            doc.setFillColor(243, 244, 246)
            doc.rect(15, yPos - 3, pageWidth - 30, 8, 'F')
            doc.setFontSize(12)
            doc.setFont('helvetica', 'bold')
            doc.setTextColor(107, 114, 128)
            doc.text('Revenue Sources', 20, yPos + 3)
            yPos += 12

            autoTable(doc, {
                startY: yPos,
                head: [['Category', 'Amount (PHP)']],
                body: [
                    ['Rental Fees', `PHP ${safeRevenue.breakdown.rentalFees.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`],
                    ['Extension Fees', `PHP ${safeRevenue.breakdown.extensionFees.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`],
                    ['Damage Fees', `PHP ${safeRevenue.breakdown.damageFees.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`],
                    ['Security Deposits (Refundable)', `PHP ${safeRevenue.breakdown.securityDeposits.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`],
                ],
                theme: 'striped',
                headStyles: { fillColor: [107, 114, 128], fontSize: 10 },
                styles: { fontSize: 9, cellPadding: 4 },
                margin: { left: 15, right: 15 },
            })
            yPos = (doc as any).lastAutoTable.finalY + 15

            // Platform Fees Section
            if (yPos > 220) {
                doc.addPage()
                yPos = 20
            }

            doc.setFillColor(220, 252, 231)
            doc.rect(15, yPos - 3, pageWidth - 30, 8, 'F')
            doc.setFontSize(12)
            doc.setFont('helvetica', 'bold')
            doc.setTextColor(22, 163, 74)
            doc.text('Platform Fees', 20, yPos + 3)
            yPos += 12

            autoTable(doc, {
                startY: yPos,
                head: [['Fee Type', 'Rate', 'Amount (PHP)', 'Paid By']],
                body: [
                    [
                        'Processing Fee',
                        `${(safeRevenue.fees.processingFeeRate * 100).toFixed(1)}%`,
                        `PHP ${safeRevenue.breakdown.processingFees.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
                        'Borrowers'
                    ],
                    [
                        'Platform Commission',
                        `${(safeRevenue.fees.commissionRate * 100).toFixed(1)}%`,
                        `PHP ${safeRevenue.breakdown.platformCommissions.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
                        'Lenders'
                    ],
                ],
                theme: 'striped',
                headStyles: { fillColor: [22, 163, 74], fontSize: 10 },
                styles: { fontSize: 9, cellPadding: 4 },
                margin: { left: 15, right: 15 },
            })
            yPos = (doc as any).lastAutoTable.finalY + 10

            // Fee Calculation Notes
            doc.setFontSize(9)
            doc.setFont('helvetica', 'italic')
            doc.setTextColor(100, 100, 100)
            doc.text('Processing Fee: 3% of (Rental Fees + Extension Fees), charged to borrowers', 20, yPos)
            yPos += 5
            doc.text('Platform Commission: 5% of Lender\'s Earnings, deducted from lenders', 20, yPos)
            yPos += 15

            // Financial Summary Section
            if (yPos > 200) {
                doc.addPage()
                yPos = 20
            }

            doc.setFillColor(254, 243, 199)
            doc.rect(15, yPos - 3, pageWidth - 30, 8, 'F')
            doc.setFontSize(12)
            doc.setFont('helvetica', 'bold')
            doc.setTextColor(245, 158, 11)
            doc.text('Financial Summary', 20, yPos + 3)
            yPos += 12

            autoTable(doc, {
                startY: yPos,
                head: [['Description', 'Amount (PHP)']],
                body: [
                    ['Total Revenue (Base)', `PHP ${safeRevenue.totalRevenue.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`],
                    ['Total Collected from Borrowers', `PHP ${safeRevenue.totalCollected.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`],
                    ['', ''],
                    ['Lender Payout', `PHP ${safeRevenue.lenderPayout.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`],
                    ['Platform Revenue', `PHP ${safeRevenue.platformRevenue.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`],
                ],
                theme: 'striped',
                headStyles: { fillColor: [245, 158, 11], fontSize: 10 },
                styles: { fontSize: 9, cellPadding: 4 },
                columnStyles: {
                    0: { fontStyle: 'bold' }
                },
                margin: { left: 15, right: 15 },
            })
            yPos = (doc as any).lastAutoTable.finalY + 15

            // Lender Earnings Calculation
            if (yPos > 210) {
                doc.addPage()
                yPos = 20
            }

            doc.setFillColor(239, 246, 255)
            doc.rect(15, yPos - 3, pageWidth - 30, 8, 'F')
            doc.setFontSize(11)
            doc.setFont('helvetica', 'bold')
            doc.setTextColor(59, 130, 246)
            doc.text('How Lender Earnings Are Calculated', 20, yPos + 3)
            yPos += 12

            // Calculation steps
            doc.setFontSize(9)
            doc.setFont('helvetica', 'normal')
            doc.setTextColor(0, 0, 0)

            doc.text('1. Lender\'s Earnings = Rental Fees + Extension Fees + Damage Fees', 20, yPos)
            yPos += 5
            doc.setFont('helvetica', 'bold')
            doc.text(`   = PHP ${safeRevenue.lenderEarningsBeforeCommission.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 20, yPos)
            yPos += 8

            doc.setFont('helvetica', 'normal')
            doc.text(`2. Platform Commission = 5% of Lender's Earnings`, 20, yPos)
            yPos += 5
            doc.setFont('helvetica', 'bold')
            doc.text(`   = PHP ${safeRevenue.breakdown.platformCommissions.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 20, yPos)
            yPos += 8

            doc.setFont('helvetica', 'normal')
            doc.text('3. Lender Receives = Lender\'s Earnings - Platform Commission', 20, yPos)
            yPos += 5
            doc.setFont('helvetica', 'bold')
            doc.setTextColor(22, 163, 74)
            doc.text(`   = PHP ${safeRevenue.lenderPayout.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 20, yPos)
            yPos += 8

            doc.setFont('helvetica', 'italic')
            doc.setFontSize(8)
            doc.setTextColor(100, 100, 100)
            doc.text('Note: Security deposits are excluded from calculations as they are fully refundable to borrowers.', 20, yPos)
            yPos += 15

            // Payout & Refund Status
            if (yPos > 240) {
                doc.addPage()
                yPos = 20
            }

            doc.setFillColor(243, 232, 255)
            doc.rect(15, yPos - 3, pageWidth - 30, 8, 'F')
            doc.setFontSize(12)
            doc.setFont('helvetica', 'bold')
            doc.setTextColor(139, 92, 246)
            doc.text('Processing Status', 20, yPos + 3)
            yPos += 12

            autoTable(doc, {
                startY: yPos,
                head: [['Type', 'Completed', 'Pending']],
                body: [
                    [
                        'Payouts',
                        safeRevenue.payoutStatus.completed.toLocaleString(),
                        safeRevenue.payoutStatus.pending.toLocaleString()
                    ],
                    [
                        'Refunds',
                        safeRevenue.refundStatus.completed.toLocaleString(),
                        safeRevenue.refundStatus.pending.toLocaleString()
                    ],
                ],
                theme: 'striped',
                headStyles: { fillColor: [139, 92, 246], fontSize: 10 },
                styles: { fontSize: 9, cellPadding: 4 },
                margin: { left: 15, right: 15 },
            })
        }

        // Footer on each page
        const pageCount = (doc as any).internal.getNumberOfPages()
        for (let i = 1; i <= pageCount; i++) {
            doc.setPage(i)
            doc.setFontSize(8)
            doc.setTextColor(150, 150, 150)
            doc.text(
                `Page ${i} of ${pageCount} | CosConnect Analytics`,
                pageWidth / 2,
                doc.internal.pageSize.getHeight() - 10,
                { align: 'center' }
            )
        }

        // Save
        const dateStr = new Date().toISOString().split('T')[0]
        const rangeStr = dateRange === 'all' ? 'all-time' : `${dateRange}days`
        doc.save(`cosconnect-analytics-${rangeStr}-${dateStr}.pdf`)
    }

    if (isLoading) {
        return (
            <div className="container mx-auto p-6">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold tracking-tight">Analytics Dashboard</h1>
                    <p className="text-muted-foreground mt-2">
                        Monitor your platform performance and insights
                    </p>
                </div>
                <AnalyticsLoading />
            </div>
        )
    }

    if (error) {
        return (
            <div className="container mx-auto p-6">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold tracking-tight">Analytics Dashboard</h1>
                    <p className="text-muted-foreground mt-2">
                        Monitor your platform performance and insights
                    </p>
                </div>
                <AnalyticsError error={error} onRetry={() => refetch()} />
            </div>
        )
    }

    if (!data?.data) {
        return null
    }

    const { users, rentals, revenue, charts } = data.data

    // Calculate lenderEarningsBeforeCommission from the revenue breakdown
    const lenderEarningsBeforeCommission =
        (revenue?.breakdown?.rentalFees ?? 0) +
        (revenue?.breakdown?.extensionFees ?? 0) +
        (revenue?.breakdown?.damageFees ?? 0)

    // Add safe defaults for revenue properties with the calculated lenderEarningsBeforeCommission
    const safeRevenue = {
        totalRevenue: revenue?.totalRevenue ?? 0,
        totalCollected: revenue?.totalCollected ?? 0,
        platformRevenue: revenue?.platformRevenue ?? 0,
        lenderPayout: revenue?.lenderPayout ?? 0,
        lenderEarningsBeforeCommission: revenue?.lenderEarningsBeforeCommission ?? lenderEarningsBeforeCommission,
        netRevenue: revenue?.netRevenue ?? 0,
        thisMonthRevenue: revenue?.thisMonthRevenue ?? 0,
        totalTransactions: revenue?.totalTransactions ?? 0,
        thisMonthTransactions: revenue?.thisMonthTransactions ?? 0,
        breakdown: {
            rentalFees: revenue?.breakdown?.rentalFees ?? 0,
            securityDeposits: revenue?.breakdown?.securityDeposits ?? revenue?.breakdown?.deposits ?? 0,
            extensionFees: revenue?.breakdown?.extensionFees ?? 0,
            damageFees: revenue?.breakdown?.damageFees ?? 0,
            processingFees: revenue?.breakdown?.processingFees ?? 0,
            platformCommissions: revenue?.breakdown?.platformCommissions ?? 0,
        },
        fees: {
            processingFeeRate: revenue?.fees?.processingFeeRate ?? 0,
            commissionRate: revenue?.fees?.commissionRate ?? 0,
            totalProcessingFees: revenue?.fees?.totalProcessingFees ?? 0,
            totalCommissions: revenue?.fees?.totalCommissions ?? 0,
        },
        byStatus: {
            returned: {
                revenue: revenue?.byStatus?.returned?.revenue ?? 0,
                count: revenue?.byStatus?.returned?.count ?? 0,
            },
            completed: {
                revenue: revenue?.byStatus?.completed?.revenue ?? 0,
                count: revenue?.byStatus?.completed?.count ?? 0,
            },
        },
        payoutStatus: {
            completed: revenue?.payoutStatus?.completed ?? 0,
            pending: revenue?.payoutStatus?.pending ?? 0,
        },
        refundStatus: {
            completed: revenue?.refundStatus?.completed ?? 0,
            pending: revenue?.refundStatus?.pending ?? 0,
        },
    }

    return (
        <div className="container mx-auto p-6 space-y-6">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight">Analytics Dashboard</h1>
                    <p className="text-muted-foreground mt-1">
                        Monitor your platform performance and insights
                    </p>
                </div>
                <Button onClick={generatePDF} className="flex items-center gap-2">
                    <Download className="h-4 w-4" />
                    Generate Report
                </Button>
            </div>

            {/* Filters Card */}
            <Card>
                <CardHeader>
                    <CardTitle className="text-lg">Filters & Export Options</CardTitle>
                    <CardDescription>Customize your analytics view and report generation</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="dateRange">Date Range</Label>
                            <Select value={dateRange} onValueChange={(value: any) => setDateRange(value)}>
                                <SelectTrigger>
                                    <SelectValue placeholder="Select range" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="30">Last 30 days</SelectItem>
                                    <SelectItem value="90">Last 90 days</SelectItem>
                                    <SelectItem value="180">Last 180 days</SelectItem>
                                    <SelectItem value="365">Last 365 days</SelectItem>
                                    <SelectItem value="all">All time</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="startDate">Start Date</Label>
                            <Input
                                id="startDate"
                                type="date"
                                value={startDate}
                                onChange={(e) => setStartDate(e.target.value)}
                            />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="endDate">End Date</Label>
                            <Input
                                id="endDate"
                                type="date"
                                value={endDate}
                                onChange={(e) => setEndDate(e.target.value)}
                            />
                        </div>
                    </div>

                    <div className="space-y-2">
                        <Label>Report Sections</Label>
                        <div className="flex flex-wrap gap-4">
                            {[
                                { id: 'users', label: 'User Statistics' },
                                { id: 'rentals', label: 'Rental Statistics' },
                                { id: 'revenue', label: 'Revenue Overview' },
                                { id: 'breakdown', label: 'Revenue Breakdown' },
                            ].map((section) => (
                                <div key={section.id} className="flex items-center space-x-2">
                                    <Checkbox
                                        id={section.id}
                                        checked={selectedSections.includes(section.id)}
                                        onCheckedChange={(checked) => {
                                            setSelectedSections(
                                                checked
                                                    ? [...selectedSections, section.id]
                                                    : selectedSections.filter(s => s !== section.id)
                                            )
                                        }}
                                    />
                                    <Label htmlFor={section.id} className="text-sm font-normal cursor-pointer">
                                        {section.label}
                                    </Label>
                                </div>
                            ))}
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Stats Overview */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <StatCard
                    title="Total Users"
                    value={users.total.toLocaleString("en-PH")}
                    icon={Users}
                    description="All registered users"
                    trend={users.thisMonth > 0 ? `+${users.thisMonth} this month` : undefined}
                />
                <StatCard
                    title="Borrowers"
                    value={users.borrowers.toLocaleString("en-PH")}
                    icon={UserCheck}
                    description="Active borrowers"
                />
                <StatCard
                    title="Lenders"
                    value={users.lenders.toLocaleString("en-PH")}
                    icon={UserPlus}
                    description="Active lenders"
                />
                <StatCard
                    title="Both Roles"
                    value={users.bothRoles.toLocaleString("en-PH")}
                    icon={Users}
                    description="Users with both roles"
                />
            </div>

            {/* Rental Stats */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <StatCard
                    title="Total Rentals"
                    value={rentals.total.toLocaleString("en-PH")}
                    icon={Package}
                    description="All time rentals"
                    trend={rentals.thisMonth > 0 ? `+${rentals.thisMonth} this month` : undefined}
                />
                <StatCard
                    title="Returned"
                    value={rentals.returned.toLocaleString("en-PH")}
                    icon={CheckCircle}
                    description="Successfully returned"
                    className="border-green-200 dark:border-green-900"
                />
                <StatCard
                    title="Completed"
                    value={rentals.completed.toLocaleString("en-PH")}
                    icon={CheckCircle}
                    description="Fully completed"
                    className="border-emerald-200 dark:border-emerald-900"
                />
                <StatCard
                    title="Pending"
                    value={rentals.pending.toLocaleString("en-PH")}
                    icon={TrendingUp}
                    description="Awaiting action"
                    className="border-amber-200 dark:border-amber-900"
                />
            </div>

            {/* Revenue Stats */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <StatCard
                    title="Total Revenue"
                    value={`₱${(safeRevenue.fees.totalProcessingFees + safeRevenue.fees.totalCommissions).toLocaleString("en-PH", { minimumFractionDigits: 2 })}`}
                    icon={Coins}
                    description="All time revenue"
                    className="col-span-1 md:col-span-2"
                />
                <StatCard
                    title="This Month"
                    value={`₱${(safeRevenue.fees.totalProcessingFees + safeRevenue.fees.totalCommissions).toLocaleString("en-PH", { minimumFractionDigits: 2 })}`}
                    icon={Receipt}
                    description={`${safeRevenue.thisMonthTransactions} transactions`}
                />
                <StatCard
                    title="Transactions"
                    value={safeRevenue.totalTransactions.toLocaleString("en-PH")}
                    icon={Receipt}
                    description="Total completed"
                />
            </div>

            {/* Charts Section */}
            <div className="grid gap-6">
                <UserRegistrationsChart data={chartData?.data?.charts?.monthly} />
                <div className="grid gap-6 lg:grid-cols-2">
                    <RentalsChart data={chartData?.data?.charts?.monthly} />
                    <RevenueChart data={chartData?.data?.charts?.monthly} totalRevenue={safeRevenue.platformRevenue} />
                </div>
            </div>

            {/* Breakdown Tables */}
            <div className="grid gap-6 lg:grid-cols-2">
                <RevenueBreakdown revenue={safeRevenue} />
                <RentalStatusBreakdown rentals={rentals} />
            </div>
        </div>
    )
}

export default React.memo(AnalyticsSection)