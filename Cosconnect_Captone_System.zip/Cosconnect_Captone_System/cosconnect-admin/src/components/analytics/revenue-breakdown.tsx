// file: components/analytics/revenue-breakdown.tsx
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Coins, CreditCard, Clock, AlertCircle, TrendingUp, CheckCircle2, Percent, DollarSign, Info, PhilippinePeso } from "lucide-react"

interface RevenueBreakdownProps {
  revenue: {
    totalRevenue: number
    totalCollected: number
    platformRevenue: number
    lenderPayout: number
    lenderEarningsBeforeCommission: number
    totalTransactions: number
    thisMonthRevenue: number
    thisMonthTransactions: number
    breakdown: {
      rentalFees: number
      securityDeposits: number
      extensionFees: number
      damageFees: number
      processingFees: number
      platformCommissions: number
    }
    fees: {
      processingFeeRate: number
      commissionRate: number
      totalProcessingFees: number
      totalCommissions: number
    }
    byStatus: {
      returned: {
        revenue: number
        count: number
      }
      completed: {
        revenue: number
        count: number
      }
    }
    payoutStatus: {
      completed: number
      pending: number
    }
    refundStatus: {
      completed: number
      pending: number
    }
  }
}

export function RevenueBreakdown({ revenue }: RevenueBreakdownProps) {
  const formatCurrency = (amount: number) => {
    return `₱${amount.toLocaleString("en-PH", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    })}`
  }

  const totalProcessingFees = revenue.fees.totalProcessingFees
  const totalCommissionFees = revenue.fees.totalCommissions
  const totalPlatformRevenue = totalProcessingFees + totalCommissionFees

  const breakdownItems = [
    {
      label: "Rental Fees",
      amount: revenue.breakdown.rentalFees,
      icon: Coins,
      color: "text-blue-600 dark:text-blue-400",
      bgColor: "bg-blue-50 dark:bg-blue-950",
    },
    {
      label: "Extension Fees",
      amount: revenue.breakdown.extensionFees,
      icon: Clock,
      color: "text-purple-600 dark:text-purple-400",
      bgColor: "bg-purple-50 dark:bg-purple-950",
    },
    {
      label: "Damage Fees",
      amount: revenue.breakdown.damageFees,
      icon: AlertCircle,
      color: "text-red-600 dark:text-red-400",
      bgColor: "bg-red-50 dark:bg-red-950",
    },
    {
      label: "Security Deposits",
      amount: revenue.breakdown.securityDeposits,
      icon: CreditCard,
      color: "text-amber-600 dark:text-amber-400",
      bgColor: "bg-amber-50 dark:bg-amber-950",
      note: "Refundable to borrowers"
    },
  ]

  const feeItems = [
    {
      label: "Processing Fees",
      amount: revenue.breakdown.processingFees,
      rate: revenue.fees.processingFeeRate * 100,
      icon: Percent,
      color: "text-green-600 dark:text-green-400",
      bgColor: "bg-green-50 dark:bg-green-950",
      description: "3% of (Rental + Extension Fees)",
      detail: "Charged to borrowers"
    },
    {
      label: "Platform Commission",
      amount: revenue.breakdown.platformCommissions,
      rate: revenue.fees.commissionRate * 100,
      icon: Percent,
      color: "text-indigo-600 dark:text-indigo-400",
      bgColor: "bg-indigo-50 dark:bg-indigo-950",
      description: "5% of Lender's Earnings",
      detail: "Deducted from lenders"
    },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-primary" />
          Revenue Breakdown
        </CardTitle>
        <CardDescription>
          Detailed financial breakdown with platform fees
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Revenue Sources */}
        <div className="space-y-3">
          <h4 className="text-sm font-semibold text-muted-foreground">Revenue Sources</h4>
          {breakdownItems.map((item) => {
            const Icon = item.icon
            return (
              <div
                key={item.label}
                className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${item.bgColor}`}>
                    <Icon className={`h-4 w-4 ${item.color}`} />
                  </div>
                  <div>
                    <p className="text-sm font-medium">{item.label}</p>
                    {item.note && (
                      <p className="text-xs text-muted-foreground">{item.note}</p>
                    )}
                  </div>
                </div>
                <p className="text-sm font-bold">
                  {formatCurrency(item.amount)}
                </p>
              </div>
            )
          })}
        </div>

        <Separator />

        {/* Platform Fees */}
        <div className="space-y-3">
          <h4 className="text-sm font-semibold text-muted-foreground">Platform Fees</h4>
          {feeItems.map((item) => {
            const Icon = item.icon
            return (
              <div
                key={item.label}
                className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${item.bgColor}`}>
                    <Icon className={`h-4 w-4 ${item.color}`} />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{item.label}</p>
                    <p className="text-xs text-muted-foreground">
                      {item.description}
                    </p>
                    <p className="text-xs text-muted-foreground italic">
                      {item.detail}
                    </p>
                  </div>
                </div>
                <p className="text-sm font-bold text-green-600 dark:text-green-400">
                  +{formatCurrency(item.amount)}
                </p>
              </div>
            )
          })}
        </div>

        <Separator />

        {/* Financial Summary */}
        <div className="space-y-3 p-4 rounded-lg bg-gradient-to-br from-muted/50 to-muted/30 border">
          <h4 className="text-sm font-semibold flex items-center gap-2">
            <PhilippinePeso className="h-4 w-4" />
            Financial Summary
          </h4>
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Total Collected from Borrowers</span>
              <span className="font-semibold">
                {formatCurrency(totalProcessingFees)}
              </span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Total Collected from Lenders</span>
              <span className="font-semibold">
                {formatCurrency(totalCommissionFees)}
              </span>
            </div>
            <Separator className="my-2" />

            <div className="flex items-center justify-between bg-green-50 dark:bg-green-950/30 p-2 rounded">
              <span className="text-green-900 dark:text-green-100 font-semibold">Platform Revenue</span>
              <span className="font-bold text-lg text-green-700 dark:text-green-300">
                {formatCurrency(totalPlatformRevenue)}
              </span>
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              (Processing Fees: {formatCurrency(totalProcessingFees)} + Commission Fees: {formatCurrency(totalCommissionFees)})
            </div>
          </div>
        </div>

        {/* How Lender Earnings Are Calculated */}
        <Alert className="border-blue-200 dark:border-blue-900 bg-blue-50/50 dark:bg-blue-950/20">
          <Info className="h-4 w-4 text-blue-600 dark:text-blue-400" />
          <AlertDescription className="text-sm space-y-2">
            <p className="font-semibold text-blue-900 dark:text-blue-100">
              How Lender Earnings Are Calculated:
            </p>
            <div className="space-y-1 text-xs text-blue-800 dark:text-blue-200">
              <p>1. <strong>Lender's Earnings</strong> = Rental Fees + Extension Fees + Damage Fees</p>
              <p className="ml-4">= {formatCurrency(revenue.lenderEarningsBeforeCommission)}</p>

              <p className="mt-2">2. <strong>Platform Commission</strong> = 5% of Lender's Earnings</p>
              <p className="ml-4">= {formatCurrency(revenue.breakdown.platformCommissions)}</p>

              <p className="mt-2">3. <strong>Lender Receives</strong> = Lender's Earnings - Platform Commission</p>
              <p className="ml-4 font-bold">= {formatCurrency(revenue.lenderPayout)}</p>

              <Separator className="my-2" />

              <p className="mt-2 italic">
                <strong>Note:</strong> Security deposits are excluded from calculations as they are fully refundable to borrowers.
              </p>
            </div>
          </AlertDescription>
        </Alert>

        {/* Status Breakdown */}
        <div className="space-y-3 pt-2">
          <h4 className="text-sm font-semibold text-muted-foreground">Revenue by Status</h4>
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 rounded-lg border bg-emerald-50 dark:bg-emerald-950/30">
              <div className="flex items-center gap-2 mb-1">
                <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                <p className="text-xs font-medium text-emerald-900 dark:text-emerald-100">Completed</p>
              </div>
              <p className="text-lg font-bold text-emerald-700 dark:text-emerald-300">
                {formatCurrency(totalPlatformRevenue)}
              </p>
              <p className="text-xs text-emerald-600 dark:text-emerald-400">
                {revenue.byStatus.completed.count} {revenue.byStatus.completed.count === 1 ? 'rental' : 'rentals'}
              </p>
            </div>
          </div>
        </div>

        {/* Processing Status */}
        <div className="space-y-2 pt-2 border-t">
          <h4 className="text-sm font-semibold text-muted-foreground">Processing Status</h4>
          <div className="space-y-2">
            <div className="flex items-center justify-between p-2 rounded bg-muted/50">
              <span className="text-sm font-medium">Payouts</span>
              <div className="flex gap-2">
                <Badge variant="outline" className="bg-green-50 dark:bg-green-950 text-green-700 dark:text-green-300 border-green-200 dark:border-green-800">
                  ✓ {revenue.payoutStatus.completed}
                </Badge>
                {revenue.payoutStatus.pending > 0 && (
                  <Badge variant="outline" className="bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800">
                    ⏳ {revenue.payoutStatus.pending}
                  </Badge>
                )}
              </div>
            </div>
            <div className="flex items-center justify-between p-2 rounded bg-muted/50">
              <span className="text-sm font-medium">Refunds</span>
              <div className="flex gap-2">
                <Badge variant="outline" className="bg-green-50 dark:bg-green-950 text-green-700 dark:text-green-300 border-green-200 dark:border-green-800">
                  ✓ {revenue.refundStatus.completed}
                </Badge>
                {revenue.refundStatus.pending > 0 && (
                  <Badge variant="outline" className="bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800">
                    ⏳ {revenue.refundStatus.pending}
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
