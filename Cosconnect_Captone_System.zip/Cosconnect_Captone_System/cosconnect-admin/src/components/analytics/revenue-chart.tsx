"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import type { AnalyticsMonthlyChart } from "@/types/analytics/analyticsType"
import { CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"

interface RevenueChartProps {
    data?: AnalyticsMonthlyChart[]
    totalRevenue?: number
}

export function RevenueChart({ data, totalRevenue = 0 }: RevenueChartProps) {
    if (!data || data.length === 0) {
        return (
            <Card className="rounded-xl shadow-sm">
                <CardHeader>
                    <CardTitle>Revenue Trends</CardTitle>
                    <CardDescription>Monthly platform revenue and rental activity</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="flex items-center justify-center h-[350px] text-muted-foreground">
                        No data available
                    </div>
                </CardContent>
            </Card>
        )
    }

    const averageRevenue = data.length > 0 ? totalRevenue / data.length : 0
    const chartData = data.map((item) => ({
        month: item.label || item.month,
        revenue: item.revenue && typeof item.revenue === 'object' ? ((item.revenue as any).processingFees ?? 0) + ((item.revenue as any).platformCommissions ?? 0) : (item.revenue ?? item.transactions?.revenue ?? averageRevenue),
        rentals: item.rentals?.total ?? item.transaction_count ?? item.transactions?.count ?? 0,
    }))

    return (
        <Card className="rounded-xl shadow-sm">
            <CardHeader>
                <CardTitle>Rental Trends</CardTitle>
                <CardDescription>Monthly rental activity</CardDescription>
            </CardHeader>
            <CardContent>
                <ResponsiveContainer width="100%" height={350}>
                    <LineChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                        <XAxis dataKey="month" className="text-xs" tick={{ fill: "hsl(var(--muted-foreground))" }} />
                        <YAxis
                            yAxisId="left"
                            className="text-xs"
                            tick={{ fill: "hsl(var(--muted-foreground))" }}
                            label={{ value: "Revenue (₱)", angle: -90, position: "insideLeft" }}
                        />
                        <YAxis
                            yAxisId="right"
                            orientation="right"
                            className="text-xs"
                            tick={{ fill: "hsl(var(--muted-foreground))" }}
                            label={{ value: "Rentals", angle: 90, position: "insideRight" }}
                        />
                        <Tooltip
                            content={({ active, payload, label }) => {
                                if (active && payload && payload.length) {
                                    return (
                                        <div className="bg-popover border border-border rounded-lg p-2">
                                            <p className="text-sm">{`Month: ${label}`}</p>
                                            {payload.map((entry, index) => (
                                                <p key={index} className="text-sm" style={{ color: entry.color }}>
                                                    {entry.dataKey === 'revenue' ? `Platform Revenue: ₱${entry.payload.revenue && typeof entry.payload.revenue === 'object' ? ((entry.payload.revenue as any).processingFees ?? 0) + ((entry.payload.revenue as any).platformCommissions ?? 0) : entry.payload.revenue}` : `Rentals: ${entry.payload.rentals}`}
                                                </p>
                                            ))}
                                        </div>
                                    );
                                }
                                return null;
                            }}
                        />
                        <Legend />
                        <Line
                            yAxisId="left"
                            type="monotone"
                            dataKey="revenue"
                            stroke="hsl(var(--chart-5))"
                            strokeWidth={2}
                            name="Revenue"
                            dot={{ fill: "hsl(var(--chart-5))" }}
                        />
                        <Line
                            yAxisId="right"
                            type="monotone"
                            dataKey="rentals"
                            stroke="hsl(var(--chart-1))"
                            strokeWidth={2}
                            name="Rentals"
                            dot={{ fill: "hsl(var(--chart-1))" }}
                        />
                    </LineChart>
                </ResponsiveContainer>
            </CardContent>
        </Card>
    )
}

