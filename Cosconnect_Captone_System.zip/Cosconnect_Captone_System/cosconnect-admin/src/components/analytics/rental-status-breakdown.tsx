// file: components/analytics/rental-status-breakdown.tsx
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
    Clock,
    CheckCircle2,
    XCircle,
    Package,
    Truck,
    RotateCcw,
    AlertTriangle,
    Ban
} from "lucide-react"

interface RentalStatusBreakdownProps {
    rentals: {
        total: number
        pending: number
        confirmed: number
        accepted: number
        delivered: number
        returned: number
        completed: number
        cancelled: number
        rejected: number
        overdue: number
        thisMonth: number
    }
}

export function RentalStatusBreakdown({ rentals }: RentalStatusBreakdownProps) {
    const statusItems = [
        {
            label: "Pending",
            count: rentals.pending,
            icon: Clock,
            color: "text-amber-600 dark:text-amber-400",
            bgColor: "bg-amber-50 dark:bg-amber-950",
            badgeVariant: "secondary" as const
        },
        {
            label: "Confirmed",
            count: rentals.confirmed,
            icon: CheckCircle2,
            color: "text-blue-600 dark:text-blue-400",
            bgColor: "bg-blue-50 dark:bg-blue-950",
            badgeVariant: "secondary" as const
        },
        {
            label: "Accepted",
            count: rentals.accepted,
            icon: CheckCircle2,
            color: "text-indigo-600 dark:text-indigo-400",
            bgColor: "bg-indigo-50 dark:bg-indigo-950",
            badgeVariant: "secondary" as const
        },
        {
            label: "Delivered",
            count: rentals.delivered,
            icon: Truck,
            color: "text-purple-600 dark:text-purple-400",
            bgColor: "bg-purple-50 dark:bg-purple-950",
            badgeVariant: "secondary" as const
        },
        {
            label: "Returned",
            count: rentals.returned,
            icon: RotateCcw,
            color: "text-green-600 dark:text-green-400",
            bgColor: "bg-green-50 dark:bg-green-950",
            badgeVariant: "outline" as const
        },
        {
            label: "Completed",
            count: rentals.completed,
            icon: CheckCircle2,
            color: "text-emerald-600 dark:text-emerald-400",
            bgColor: "bg-emerald-50 dark:bg-emerald-950",
            badgeVariant: "outline" as const
        },
        {
            label: "Cancelled",
            count: rentals.cancelled,
            icon: XCircle,
            color: "text-gray-600 dark:text-gray-400",
            bgColor: "bg-gray-50 dark:bg-gray-950",
            badgeVariant: "outline" as const
        },
        {
            label: "Rejected",
            count: rentals.rejected,
            icon: Ban,
            color: "text-red-600 dark:text-red-400",
            bgColor: "bg-red-50 dark:bg-red-950",
            badgeVariant: "destructive" as const
        },
    ]

    const activeRentals = rentals.pending + rentals.confirmed + rentals.accepted + rentals.delivered
    const completedRentals = rentals.returned + rentals.completed
    const unsuccessfulRentals = rentals.cancelled + rentals.rejected

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Package className="h-5 w-5 text-primary" />
                    Rental Status
                </CardTitle>
                <CardDescription>
                    Breakdown of all rental statuses
                </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                {/* Quick Stats */}
                <div className="grid grid-cols-3 gap-3">
                    <div className="p-3 rounded-lg border bg-blue-50 dark:bg-blue-950/30">
                        <p className="text-xs font-medium text-blue-900 dark:text-blue-100">Active</p>
                        <p className="text-xl font-bold text-blue-700 dark:text-blue-300">{activeRentals}</p>
                    </div>
                    <div className="p-3 rounded-lg border bg-green-50 dark:bg-green-950/30">
                        <p className="text-xs font-medium text-green-900 dark:text-green-100">Success</p>
                        <p className="text-xl font-bold text-green-700 dark:text-green-300">{completedRentals}</p>
                    </div>
                    <div className="p-3 rounded-lg border bg-red-50 dark:bg-red-950/30">
                        <p className="text-xs font-medium text-red-900 dark:text-red-100">Failed</p>
                        <p className="text-xl font-bold text-red-700 dark:text-red-300">{unsuccessfulRentals}</p>
                    </div>
                </div>

                {/* Status List */}
                <div className="space-y-3">
                    {statusItems.map((item) => {
                        const Icon = item.icon
                        const percentage = rentals.total > 0
                            ? (item.count / rentals.total * 100).toFixed(1)
                            : "0"

                        return (
                            <div key={item.label} className="space-y-2">
                                <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-2">
                                        <div className={`p-1.5 rounded ${item.bgColor}`}>
                                            <Icon className={`h-3.5 w-3.5 ${item.color}`} />
                                        </div>
                                        <span className="text-sm font-medium">{item.label}</span>
                                    </div>
                                    <div className="flex items-center gap-3">
                                        <Badge variant={item.badgeVariant} className="min-w-[40px] justify-center">
                                            {item.count}
                                        </Badge>
                                    </div>
                                </div>
                                <Progress
                                    value={parseFloat(percentage)}
                                    className="h-1.5"
                                />
                            </div>
                        )
                    })}
                </div>

                {/* Summary */}
                <div className="pt-4 border-t">
                    <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-muted-foreground">Total Rentals</span>
                        <span className="text-lg font-bold">{rentals.total}</span>
                    </div>
                    <div className="flex items-center justify-between mt-2">
                        <span className="text-xs text-muted-foreground">This Month</span>
                        <Badge variant="secondary">{rentals.thisMonth}</Badge>
                    </div>
                </div>
            </CardContent>
        </Card>
    )
}