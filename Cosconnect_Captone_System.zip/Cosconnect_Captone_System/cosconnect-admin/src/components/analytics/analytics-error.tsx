"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertCircle } from "lucide-react"

interface AnalyticsErrorProps {
    error: Error
    onRetry: () => void
}

export function AnalyticsError({ error, onRetry }: AnalyticsErrorProps) {
    return (
        <Card className="rounded-xl shadow-sm">
            <CardHeader>
                <div className="flex items-center gap-2">
                    <AlertCircle className="h-5 w-5 text-destructive" />
                    <CardTitle>Failed to Load Analytics</CardTitle>
                </div>
                <CardDescription>We encountered an error while fetching your analytics data.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">{error.message}</p>
                <Button onClick={onRetry} variant="default">
                    Retry
                </Button>
            </CardContent>
        </Card>
    )
}
