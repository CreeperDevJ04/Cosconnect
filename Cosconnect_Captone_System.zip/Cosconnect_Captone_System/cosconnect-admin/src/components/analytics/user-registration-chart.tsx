// file: components/analytics/user-registration-chart.tsx
"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { Users } from "lucide-react"

interface MonthlyData {
    month: string
    label: string
    users?: {
        total: number
        borrowers: number
        lenders: number
    }
}

interface UserRegistrationsChartProps {
    data: MonthlyData[]
}

export function UserRegistrationsChart({ data = [] }: UserRegistrationsChartProps) {
    // Transform data with fallbacks
    const chartData = data.map((item) => ({
        month: item.label,
        total: item.users?.total || 0,
        borrowers: item.users?.borrowers || 0,
        lenders: item.users?.lenders || 0,
    }))

    // Calculate totals
    const totalUsers = chartData.reduce((sum, item) => sum + item.total, 0)
    const hasData = totalUsers > 0

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-primary" />
                    User Registrations
                </CardTitle>
                <CardDescription>
                    {hasData
                        ? `Monthly borrower and lender registrations - Total: ${totalUsers} users`
                        : "No user registration data available for the selected period"
                    }
                </CardDescription>
            </CardHeader>
            <CardContent>
                {hasData ? (
                    <ResponsiveContainer width="100%" height={350}>
                        <AreaChart data={chartData}>
                            <defs>
                                <linearGradient id="colorBorrowers" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="hsl(var(--chart-1))" stopOpacity={0.8} />
                                    <stop offset="95%" stopColor="hsl(var(--chart-1))" stopOpacity={0.1} />
                                </linearGradient>
                                <linearGradient id="colorLenders" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="hsl(var(--chart-2))" stopOpacity={0.8} />
                                    <stop offset="95%" stopColor="hsl(var(--chart-2))" stopOpacity={0.1} />
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                            <XAxis
                                dataKey="month"
                                className="text-xs"
                                tick={{ fill: 'currentColor' }}
                            />
                            <YAxis
                                className="text-xs"
                                tick={{ fill: 'currentColor' }}
                            />
                            <Tooltip
                                content={({ active, payload }) => {
                                    if (active && payload && payload.length) {
                                        return (
                                            <div className="rounded-lg border bg-background p-3 shadow-md">
                                                <p className="font-semibold mb-2">{payload[0].payload.month}</p>
                                                <div className="space-y-1">
                                                    <div className="flex items-center gap-2">
                                                        <div className="h-3 w-3 rounded-full bg-blue-500" />
                                                        <span className="text-sm">Borrowers: </span>
                                                        <span className="font-medium">{payload[0].payload.borrowers}</span>
                                                    </div>
                                                    <div className="flex items-center gap-2">
                                                        <div className="h-3 w-3 rounded-full bg-green-500" />
                                                        <span className="text-sm">Lenders: </span>
                                                        <span className="font-medium">{payload[0].payload.lenders}</span>
                                                    </div>
                                                    <div className="border-t pt-1 mt-1">
                                                        <div className="flex items-center gap-2">
                                                            <span className="text-sm font-semibold">Total: </span>
                                                            <span className="font-bold">{payload[0].payload.total}</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        )
                                    }
                                    return null
                                }}
                            />
                            <Legend
                                wrapperStyle={{ paddingTop: '20px' }}
                                iconType="circle"
                            />
                            <Area
                                type="monotone"
                                dataKey="borrowers"
                                name="Borrowers"
                                stroke="hsl(var(--chart-1))"
                                fillOpacity={1}
                                fill="url(#colorBorrowers)"
                                strokeWidth={2}
                            />
                            <Area
                                type="monotone"
                                dataKey="lenders"
                                name="Lenders"
                                stroke="hsl(var(--chart-2))"
                                fillOpacity={1}
                                fill="url(#colorLenders)"
                                strokeWidth={2}
                            />
                        </AreaChart>
                    </ResponsiveContainer>
                ) : (
                    <div className="flex items-center justify-center h-[350px] text-muted-foreground">
                        <div className="text-center space-y-2">
                            <Users className="h-12 w-12 mx-auto opacity-20" />
                            <p className="text-sm">No user registration data to display</p>
                        </div>
                    </div>
                )}
            </CardContent>
        </Card>
    )
}