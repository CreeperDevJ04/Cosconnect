// file: components/analytics/transaction-breakdown.tsx

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import type { AnalyticsTransactionBreakdown } from "@/types/analytics/analyticsType"
import { Coins } from "lucide-react"

interface TransactionBreakdownProps {
    breakdown: AnalyticsTransactionBreakdown
}

export function TransactionBreakdown({ breakdown }: TransactionBreakdownProps) {
    const items = [
        { label: "Rental Fees", value: breakdown.rentalFees, color: "text-chart-1" },
        { label: "Deposits", value: breakdown.deposits, color: "text-chart-2" },
        { label: "Extension Fees", value: breakdown.extensionFees, color: "text-chart-3" },
        { label: "Damage Fees", value: breakdown.damageFees, color: "text-chart-4" },
        { label: "Refunds", value: breakdown.refunds, color: "text-chart-5" },
    ]

    return (
        <Card className="rounded-xl shadow-sm">
            <CardHeader>
                <CardTitle>Transaction Breakdown</CardTitle>
                <CardDescription>Revenue by transaction type</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="space-y-4">
                    {items.map((item) => (
                        <div key={item.label} className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                                <Coins className={`h-4 w-4 ${item.color}`} />
                                <span className="text-sm font-medium">{item.label}</span>
                            </div>
                            <span className="text-sm font-bold">
                                ₱{item.value.toLocaleString("en-PH")}
                            </span>
                        </div>
                    ))}
                </div>
            </CardContent>
        </Card>
    )
}
