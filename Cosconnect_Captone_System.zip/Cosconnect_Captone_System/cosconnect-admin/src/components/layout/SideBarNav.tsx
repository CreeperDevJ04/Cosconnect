'use client';

import { signOut } from "@/../actions/auth";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import {
    BookIcon,
    CoinsIcon,
    LayoutDashboard,
    LogOut,
    LucideUserSquare2,
    Menu,
    Podcast,
    Settings,
    Users
} from "lucide-react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useState } from "react";

const SIDEBAR_COLLAPSED_WIDTH = 20;
const SIDEBAR_EXPANDED_WIDTH = 72;
const HOVER_DELAY = 200;

// ✅ Explicit type for nav items
type NavItem = {
    id: string;
    label: string;
    href?: string;
    icon: React.ComponentType<{ size?: number; className?: string }>;
    children?: NavItem[];
};

const SideBarNav = () => {
    const pathname = usePathname();
    const router = useRouter();


    const [isMobileOpen, setIsMobileOpen] = useState(false);
    const [isMobile, setIsMobile] = useState(false);
    const [isCollapsed, setIsCollapsed] = useState(true);
    const [hoverTimeout, setHoverTimeout] = useState<NodeJS.Timeout | null>(null);


    // ✅ Use NavItem[] type
    const navItems: NavItem[] = useMemo(() => [
        {
            id: 'dashboard',
            label: 'Dashboard',
            href: '/',
            icon: LayoutDashboard,
        },
        {
            id: 'users',
            label: 'Users',
            href: '/users',
            icon: Users
        },
        {
            id: 'rentals',
            label: 'Rentals',
            href: '/rentals',
            icon: BookIcon,
        },
        {
            id: 'transaction-logs',
            label: 'Transaction Logs',
            href: '/transaction-logs',
            icon: CoinsIcon, // you can replace this with a more fitting icon like `ReceiptText` or `FileText`
        },
        /*         {
                    id: 'community',
                    label: 'Community',
                    href: '/community',
                    icon: LucideUserSquare2,
                }, */
        {
            id: 'view-post-reports',
            label: 'View Post Reports',
            href: '/view-post-reports',
            icon: Podcast,
        },
        {
            id: 'settings',
            label: 'Settings',
            href: '/settings',
            icon: Settings,
        },
    ], []);


    const isPathActive = useCallback((path?: string): boolean => {
        if (!path) return false;
        return pathname === path || pathname.startsWith(`${path}/`);
    }, [pathname]);

    const handleSidebarMouseEnter = useCallback(() => {
        if (isMobile) return;
        if (hoverTimeout) clearTimeout(hoverTimeout);
        const timeout = setTimeout(() => setIsCollapsed(false), HOVER_DELAY);
        setHoverTimeout(timeout);
    }, [isMobile, hoverTimeout]);

    const handleSidebarMouseLeave = useCallback(() => {
        if (isMobile) return;
        if (hoverTimeout) clearTimeout(hoverTimeout);
        const timeout = setTimeout(() => setIsCollapsed(true), HOVER_DELAY);
        setHoverTimeout(timeout);
    }, [isMobile, hoverTimeout]);

    const handleLogout = useCallback(async () => {
        await signOut();
        router.push("/signin");
    }, [router]);

    useEffect(() => {
        const checkIfMobile = () => {
            const mobile = window.innerWidth < 768;
            setIsMobile(mobile);
            if (mobile) setIsCollapsed(false);
        };
        checkIfMobile();
        window.addEventListener('resize', checkIfMobile);
        return () => window.removeEventListener('resize', checkIfMobile);
    }, []);

    useEffect(() => setIsMobileOpen(false), [pathname]);

    useEffect(() => () => hoverTimeout && clearTimeout(hoverTimeout as any) as any, [hoverTimeout]);

    const SidebarContent = (
        <div className="flex flex-col h-full bg-white border-r border-gray-200">
            <nav className="flex-1 px-4 py-6 space-y-1">
                {navItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = isPathActive(item.href);
                    return (
                        <div key={item.id} className="w-full">
                            {item.href ? (
                                <Link href={item.href}>
                                    <div className={cn(
                                        "w-full group flex items-center gap-3 px-3 py-2 rounded-md transition-all duration-150 cursor-pointer",
                                        isCollapsed && "justify-center px-2",
                                        isActive
                                            ? "bg-blue-50 text-black font-semibold border border-blue-200"
                                            : "text-black hover:bg-gray-100"
                                    )}>
                                        <Icon size={20} className={cn(
                                            "transition-colors duration-150 flex-shrink-0",
                                            isActive ? "text-black" : "text-black group-hover:text-blue-600"
                                        )} />
                                        {!isCollapsed && <span className="truncate flex-1 text-base">{item.label}</span>}
                                    </div>
                                </Link>
                            ) : (
                                <div className={cn(
                                    "w-full group flex items-center gap-3 px-3 py-2 rounded-md transition-all duration-150 cursor-pointer",
                                    isCollapsed && "justify-center px-2",
                                    "text-black hover:bg-gray-100"
                                )}>
                                    <Icon size={20} className="text-black group-hover:text-blue-600" />
                                    {!isCollapsed && <span className="truncate flex-1 text-base">{item.label}</span>}
                                </div>
                            )}
                            {item.children && !isCollapsed && (
                                <div className="ml-8 mt-1 space-y-1 border-l border-gray-100 pl-4">
                                    {item.children.map((child) => {
                                        const ChildIcon = child.icon;
                                        const childIsActive = isPathActive(child.href);
                                        return (
                                            <Link key={child.id} href={child.href!}>
                                                <div className={cn(
                                                    "flex items-center gap-3 px-3 py-2 rounded-md transition-all duration-150 cursor-pointer",
                                                    childIsActive
                                                        ? "bg-blue-50 text-black font-semibold border border-blue-200"
                                                        : "text-black hover:bg-gray-100"
                                                )}>
                                                    <ChildIcon size={17} className={cn(
                                                        "transition-colors duration-150 flex-shrink-0",
                                                        childIsActive ? "text-black" : "text-black"
                                                    )} />
                                                    <span className="truncate flex-1 text-sm">{child.label}</span>
                                                </div>
                                            </Link>
                                        );
                                    })}
                                </div>
                            )}
                        </div>
                    );
                })}
            </nav>
        </div>
    );

    if (isMobile) {
        return (
            <>
                <Button
                    variant="ghost"
                    size="icon"
                    className="fixed top-4 right-4 z-50 md:hidden shadow-md"
                    onClick={() => setIsMobileOpen(true)}
                >
                    <Menu className="h-5 w-5" />
                </Button>
                {isMobileOpen && (
                    <div className="fixed inset-0 z-40 bg-black bg-opacity-30" onClick={() => setIsMobileOpen(false)} />
                )}
                <div className={cn(
                    "fixed top-0 left-0 z-50 h-full bg-white shadow-lg transition-all duration-300 border-r border-gray-200 w-80",
                    isMobileOpen ? "translate-x-0" : "-translate-x-full"
                )}>
                    {SidebarContent}
                </div>
            </>
        );
    }

    return (
        <div
            className={cn(
                "flex-shrink-0 border-r border-gray-200 transition-all duration-300 ease-in-out relative",
                isCollapsed ? `w-[${SIDEBAR_COLLAPSED_WIDTH}rem]` : `w-[${SIDEBAR_EXPANDED_WIDTH}rem]`
            )}
            onMouseEnter={handleSidebarMouseEnter}
            onMouseLeave={handleSidebarMouseLeave}
        >
            {SidebarContent}

            <div className="mt-auto p-4">
                <Button
                    variant="ghost"
                    className="w-full flex items-center justify-start gap-3 text-red-600 hover:bg-red-50 hover:text-red-700"
                    onClick={handleLogout}
                >
                    <LogOut className="h-5 w-5" />
                    {!isCollapsed && <span>Sign Out</span>}
                </Button>
            </div>
        </div>
    );
};

export default SideBarNav;
