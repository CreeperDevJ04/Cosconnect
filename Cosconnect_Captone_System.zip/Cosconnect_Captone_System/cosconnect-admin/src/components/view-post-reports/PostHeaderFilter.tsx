"use client"

import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card } from "@/components/ui/card"
import { Search, RefreshCw, Filter, TrendingDown, ShieldAlert } from "lucide-react"

interface PostReportsHeaderProps {
    searchTerm: string
    onSearchChange: (value: string) => void
    statusFilter: string
    onStatusFilterChange: (value: string) => void
    sortBy: string
    onSortByChange: (value: "report_count" | "created_at") => void
    uniqueStatuses: string[]
    uniqueReasons: string[]
    totalReports: number
    filteredCount: number
    onRefresh: () => void
}

export function PostReportsHeader({
    searchTerm,
    onSearchChange,
    statusFilter,
    onStatusFilterChange,
    sortBy,
    onSortByChange,
    uniqueStatuses,
    uniqueReasons,
    totalReports,
    filteredCount,
    onRefresh,
}: PostReportsHeaderProps) {
    return (
        <div className="space-y-4">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="p-4">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-sm text-muted-foreground">Total Reports</p>
                            <p className="text-3xl font-bold text-foreground mt-1">{totalReports}</p>
                        </div>
                        <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center">
                            <ShieldAlert className="w-6 h-6 text-red-600" />
                        </div>
                    </div>
                </Card>

                <Card className="p-4">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-sm text-muted-foreground">Filtered Results</p>
                            <p className="text-3xl font-bold text-foreground mt-1">{filteredCount}</p>
                        </div>
                        <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                            <Filter className="w-6 h-6 text-blue-600" />
                        </div>
                    </div>
                </Card>

                <Card className="p-4">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-sm text-muted-foreground">Unique Reasons</p>
                            <p className="text-3xl font-bold text-foreground mt-1">{uniqueReasons.length}</p>
                        </div>
                        <div className="w-12 h-12 rounded-full bg-amber-100 flex items-center justify-center">
                            <TrendingDown className="w-6 h-6 text-amber-600" />
                        </div>
                    </div>
                </Card>
            </div>

            {/* Filters */}
            <Card className="p-4">
                <div className="flex flex-col lg:flex-row gap-4">
                    {/* Search */}
                    <div className="flex-1">
                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                            <Input
                                placeholder="Search by post content, author, reporter, or reason..."
                                value={searchTerm}
                                onChange={(e) => onSearchChange(e.target.value)}
                                className="pl-10"
                            />
                        </div>
                    </div>

                    {/* Status Filter */}
                    <Select value={statusFilter} onValueChange={onStatusFilterChange}>
                        <SelectTrigger className="w-full lg:w-[200px]">
                            <SelectValue placeholder="Filter by status" />
                        </SelectTrigger>
                        <SelectContent>
                            {uniqueStatuses.map((status) => (
                                <SelectItem key={status} value={status}>
                                    <span className="capitalize">{status === "all" ? "All Statuses" : status}</span>
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>

                    {/* Sort By */}
                    <Select value={sortBy} onValueChange={(value) => onSortByChange(value as "report_count" | "created_at")}>
                        <SelectTrigger className="w-full lg:w-[200px]">
                            <SelectValue placeholder="Sort by" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="report_count">Most Reports</SelectItem>
                            <SelectItem value="created_at">Latest Report</SelectItem>
                        </SelectContent>
                    </Select>

                    {/* Refresh Button */}
                    <Button variant="outline" size="icon" onClick={() => onRefresh()} className="w-full lg:w-auto">
                        <RefreshCw className="w-4 h-4" />
                    </Button>
                </div>

                {/* Active Filters Info */}
                {(searchTerm || statusFilter !== "all") && (
                    <div className="mt-4 pt-4 border-t">
                        <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-sm text-muted-foreground">Active filters:</span>
                            {searchTerm && (
                                <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-md">Search: "{searchTerm}"</span>
                            )}
                            {statusFilter !== "all" && (
                                <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-md capitalize">
                                    Status: {statusFilter}
                                </span>
                            )}
                            <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                    onSearchChange("")
                                    onStatusFilterChange("all")
                                }}
                                className="text-xs h-6"
                            >
                                Clear all
                            </Button>
                        </div>
                    </div>
                )}
            </Card>
        </div>
    )
}
