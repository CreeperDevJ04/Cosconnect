// ReportDetailDialog.tsx
"use client"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog"
import { Separator } from "@/components/ui/separator"

import {
    useApprovedReportRemovePost,
    useSendWarningBlockAccountUser,
    useUpdateUserAccountStatus
} from "@/lib/apis/communityApi"
import type { PostReportItem } from "@/types/report-posts/typeReportPosts"
import { format } from "date-fns"
import {
    AlertCircle,
    AlertTriangle,
    Ban,
    Calendar,
    CheckCircle2,
    FileText,
    Loader2,
    MessageSquare,
    ShieldAlert,
    ShieldCheck,
    User,
} from "lucide-react"
import { toast } from "sonner"


interface ReportDetailDialogProps {
    report: PostReportItem | null
    isOpen: boolean
    onClose: () => void
    onStatusUpdate?: (reportId: string, newStatus: 'under_review' | 'resolved') => void
    onRefresh?: () => void
}

const REASON_CONFIG: Record<string, { variant: "destructive" | "default" | "secondary" | "outline"; icon: string }> = {
    spam: { variant: "destructive", icon: "🚫" },
    harassment: { variant: "destructive", icon: "⚠️" },
    "violence or dangerous organizations": { variant: "destructive", icon: "🔴" },
    "hate speech": { variant: "destructive", icon: "❌" },
    inappropriate: { variant: "destructive", icon: "🔞" },
    misleading: { variant: "default", icon: "⚡" },
    scam: { variant: "destructive", icon: "💰" },
    "false information": { variant: "default", icon: "📰" },
    "nudity or sexual content": { variant: "destructive", icon: "🔞" },
}

const STATUS_CONFIG: Record<string, { color: string; label: string; icon: any }> = {
    pending: {
        color: "text-yellow-600 bg-yellow-50 border-yellow-200",
        label: "Pending Review",
        icon: <AlertTriangle className="w-4 h-4" />
    },
    under_review: {
        color: "text-blue-600 bg-blue-50 border-blue-200",
        label: "Under Review",
        icon: <AlertTriangle className="w-4 h-4" />
    },
    reviewed: {
        color: "text-purple-600 bg-purple-50 border-purple-200",
        label: "Reviewed",
        icon: <CheckCircle2 className="w-4 h-4" />
    },
    resolved: {
        color: "text-green-600 bg-green-50 border-green-200",
        label: "Resolved",
        icon: <CheckCircle2 className="w-4 h-4" />
    },
}

export function ReportDetailDialog({
    report,
    isOpen,
    onClose,
    onStatusUpdate,
    onRefresh,
}: ReportDetailDialogProps) {

    const {
        sendWarning,
        isSending: isSendingWarning
    } = useSendWarningBlockAccountUser()

    const {
        blockUser,
        isUpdating: isBlockingUser
    } = useUpdateUserAccountStatus()
    const {
        mutate: approveReport,
        isPending: isApproving
    } = useApprovedReportRemovePost()

    if (!report) return null

    const reasonConfig = REASON_CONFIG[report.report.reason.toLowerCase()] || {
        variant: "secondary" as const,
        icon: "📋"
    }

    const statusConfig = STATUS_CONFIG[report.report.status] || STATUS_CONFIG.pending

    const createBasePayload = () => ({
        postAuthorId: report.post.author_id,
        postAuthorName: report.post.author_name,
        postContent: report.post.content,
        postId: report.post.id,
        reason: report.report.reason,
        reportId: report.report.id,
        reporterId: report.reporter.uid,
        reporterUsername: report.reporter.username,
        timestamp: new Date().toISOString(),
        metadata: {
            currentStatus: report.report.status,
            postCreatedAt: report.post.created_at,
            reportCreatedAt: report.report.created_at
        }
    })

    const handleBlockUser = () => {
        const blockPayload: any = {
            ...createBasePayload(),
            adminAction: 'approved'
        }


        blockUser(blockPayload, {
            onSuccess: (_) => {
                toast.success("User Blocked Successfully", {
                    description: `${report.post.author_name}'s account has been suspended.`,
                })

                onStatusUpdate?.(report.report.id, 'resolved')
                onRefresh?.()

                setTimeout(() => onClose(), 1500)
            },
            onError: (error: any) => {
                toast.error("Failed to Block User", {
                    description: error.message || "An error occurred. Please try again.",
                })
            }
        })
    }

    const handleApproveReportedPost = () => {
        const approveData = {
            ...createBasePayload(),  // Reuse the base payload function
            adminAction: 'approved' as const
        }

        approveReport(approveData, {
            onSuccess: () => {
                toast.success("Post Removed Successfully", {
                    description: "The reported post has been removed.",
                })
                onStatusUpdate?.(report.report.id, 'resolved')
                onRefresh?.()
                setTimeout(() => onClose(), 1500)
            },
            onError: (error: any) => {
                toast.error("Failed to Remove Post", {
                    description: error.message || "An error occurred. Please try again.",
                })
            }
        })
    }


    const handleSendWarning = () => {
        const warningPayload: any = {
            ...createBasePayload(),
            adminAction: 'warning'
        }

        sendWarning(warningPayload, {
            onSuccess: (_) => {
                toast.success("Warning Sent Successfully", {
                    description: `A warning email has been sent to ${report.post.author_name}.`,
                })

                onStatusUpdate?.(report.report.id, 'under_review')
                onRefresh?.()

                setTimeout(() => onClose(), 1500)
            },
            onError: (error: any) => {
                toast.error("Failed to Send Warning", {
                    description: error.message || "An error occurred. Please try again.",
                })
            }
        })
    }

    const isProcessing = isSendingWarning || isBlockingUser
    const isResolved = report.report.status === 'resolved'

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
                <DialogHeader className="space-y-3">
                    <div className="flex items-center justify-between">
                        <DialogTitle className="flex items-center gap-2 text-xl">
                            <ShieldAlert className="w-5 h-5 text-amber-500" />
                            Report Details
                        </DialogTitle>
                        <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full border ${statusConfig?.color}`}>
                            {statusConfig?.icon}
                            <span className="text-sm font-medium">{statusConfig?.label}</span>
                        </div>
                    </div>
                    <DialogDescription>
                        Review the reported content and take appropriate moderation action
                    </DialogDescription>
                </DialogHeader>

                <Separator />

                <div className="space-y-6 py-2">
                    {/* Report Information */}
                    <section className="space-y-3">
                        <div className="flex items-center gap-2">
                            <FileText className="w-4 h-4 text-muted-foreground" />
                            <h3 className="font-semibold text-sm">Report Information</h3>
                        </div>

                        <Card className="p-4 space-y-4 bg-muted/30 border-muted">
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-1">
                                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                                        Report ID
                                    </label>
                                    <p className="text-sm font-mono bg-background px-2 py-1 rounded border truncate">
                                        {report.report.id}
                                    </p>
                                </div>

                                <div className="space-y-1">
                                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                                        Violation Type
                                    </label>
                                    <Badge
                                        variant={reasonConfig.variant}
                                        className="text-xs whitespace-normal text-left h-auto min-h-[32px] flex items-start py-1.5"
                                    >
                                        <span className="mr-1.5">{reasonConfig.icon}</span>
                                        <span className="text-wrap break-words">{report.report.reason}</span>
                                    </Badge>
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-1">
                                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                                        Reported Date
                                    </label>
                                    <div className="flex items-center gap-2">
                                        <Calendar className="w-3.5 h-3.5 text-muted-foreground" />
                                        <p className="text-sm">
                                            {format(new Date(report.report.created_at), "PPp")}
                                        </p>
                                    </div>
                                </div>

                                <div className="space-y-1">
                                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                                        Last Updated
                                    </label>
                                    <div className="flex items-center gap-2">
                                        <Calendar className="w-3.5 h-3.5 text-muted-foreground" />
                                        <p className="text-sm">
                                            {format(new Date(report.report.updated_at), "PPp")}
                                        </p>
                                    </div>
                                </div>
                            </div>

                            {report.report.details && (
                                <div className="space-y-1">
                                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                                        Additional Details
                                    </label>
                                    <p className="text-sm p-3 bg-background rounded-md border italic leading-relaxed">
                                        "{report.report.details}"
                                    </p>
                                </div>
                            )}
                        </Card>
                    </section>

                    {/* Reported Post */}
                    <section className="space-y-3">
                        <div className="flex items-center gap-2">
                            <MessageSquare className="w-4 h-4 text-muted-foreground" />
                            <h3 className="font-semibold text-sm">Reported Post</h3>
                        </div>

                        <Card className="p-4 space-y-4 bg-destructive/5 border-destructive/20">
                            <div className="space-y-2">
                                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                                    Post Content
                                </label>
                                <div className="text-sm leading-relaxed p-3 bg-background rounded-md border max-h-[200px] overflow-y-auto">
                                    {report.post.content}
                                </div>
                            </div>

                            <div className="grid grid-cols-3 gap-3">
                                <div className="space-y-1">
                                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                                        Post ID
                                    </label>
                                    <p className="text-xs font-mono bg-background px-2 py-1 rounded border truncate">
                                        {report.post.id}
                                    </p>
                                </div>

                                <div className="space-y-1">
                                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                                        Author
                                    </label>
                                    <p className="text-sm font-medium truncate">
                                        {report.post.author_name}
                                    </p>
                                </div>

                                <div className="space-y-1">
                                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                                        Posted
                                    </label>
                                    <p className="text-sm">
                                        {format(new Date(report.post.created_at), "MMM dd, yyyy")}
                                    </p>
                                </div>
                            </div>
                        </Card>
                    </section>

                    {/* Reporter Information */}
                    <section className="space-y-3">
                        <div className="flex items-center gap-2">
                            <User className="w-4 h-4 text-muted-foreground" />
                            <h3 className="font-semibold text-sm">Reporter Information</h3>
                        </div>

                        <Card className="p-4 bg-muted/30 border-muted">
                            <div className="grid grid-cols-3 gap-4">
                                <div className="space-y-1">
                                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                                        Username
                                    </label>
                                    <p className="text-sm font-medium truncate">
                                        {report.reporter.username}
                                    </p>
                                </div>

                                <div className="space-y-1">
                                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                                        Email
                                    </label>
                                    <p className="text-sm truncate">
                                        {report.reporter.email}
                                    </p>
                                </div>

                                <div className="space-y-1">
                                    <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                                        User ID
                                    </label>
                                    <p className="text-xs font-mono truncate">
                                        {report.reporter.uid}
                                    </p>
                                </div>
                            </div>
                        </Card>
                    </section>
                </div>

                <Separator />

                {/* Action Buttons */}
                <div className="space-y-3">
                    <div className="flex items-center justify-between">
                        <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide">
                            Moderation Actions
                        </h3>
                        {isResolved && (
                            <Badge variant="outline" className="text-green-600 border-green-600">
                                <CheckCircle2 className="w-3 h-3 mr-1" />
                                Already Resolved
                            </Badge>
                        )}
                    </div>

                    <Button
                        variant="destructive"
                        onClick={handleApproveReportedPost}
                        className="w-full"
                        disabled={isApproving}
                    >
                        <ShieldCheck className="w-4 h-4 mr-2" />
                        {isApproving ? 'Processing...' : 'Approve Report & Remove Post'}
                    </Button>


                    <div className="grid grid-cols-2 gap-3">
                        <Button
                            variant="destructive"
                            onClick={handleBlockUser}
                            disabled={isProcessing || isResolved}
                            className="w-full"
                        >
                            {isBlockingUser ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Blocking...
                                </>
                            ) : (
                                <>
                                    <Ban className="w-4 h-4 mr-2" />
                                    Block User
                                </>
                            )}
                        </Button>


                        <Button
                            variant="outline"
                            onClick={handleSendWarning}
                            disabled={isProcessing || isResolved}
                            className="w-full border-amber-500 text-amber-600 hover:bg-amber-50"
                        >
                            {isSendingWarning ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Sending...
                                </>
                            ) : (
                                <>
                                    <AlertCircle className="w-4 h-4 mr-2" />
                                    Send Warning
                                </>
                            )}
                        </Button>
                    </div>

                    <Button
                        variant="ghost"
                        onClick={onClose}
                        disabled={isProcessing}
                        className="w-full"
                    >
                        Close
                    </Button>
                </div>
            </DialogContent>
        </Dialog>
    )
}