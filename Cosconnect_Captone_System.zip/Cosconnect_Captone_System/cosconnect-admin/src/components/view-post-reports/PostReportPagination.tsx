"use client"

import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight } from "lucide-react"

interface PostReportsPaginationProps {
    currentPage: number
    totalPages: number
    totalItems: number
    itemsPerPage: number
    onPageChange: (page: number) => void
    onItemsPerPageChange?: (itemsPerPage: number) => void
}

export function PostReportsPagination({
    currentPage,
    totalPages,
    totalItems,
    itemsPerPage,
    onPageChange,
    onItemsPerPageChange,
}: PostReportsPaginationProps) {
    const startItem = totalItems === 0 ? 0 : (currentPage - 1) * itemsPerPage + 1
    const endItem = Math.min(currentPage * itemsPerPage, totalItems)

    const canGoPrevious = currentPage > 1
    const canGoNext = currentPage < totalPages

    const handleFirstPage = () => {
        if (canGoPrevious) onPageChange(1)
    }

    const handlePreviousPage = () => {
        if (canGoPrevious) onPageChange(currentPage - 1)
    }

    const handleNextPage = () => {
        if (canGoNext) onPageChange(currentPage + 1)
    }

    const handleLastPage = () => {
        if (canGoNext) onPageChange(totalPages)
    }

    // Generate page numbers to display
    const getPageNumbers = () => {
        const pages: (number | string)[] = []
        const maxVisible = 7

        if (totalPages <= maxVisible) {
            for (let i = 1; i <= totalPages; i++) {
                pages.push(i)
            }
        } else {
            pages.push(1)

            if (currentPage > 3) {
                pages.push("...")
            }

            const start = Math.max(2, currentPage - 1)
            const end = Math.min(totalPages - 1, currentPage + 1)

            for (let i = start; i <= end; i++) {
                pages.push(i)
            }

            if (currentPage < totalPages - 2) {
                pages.push("...")
            }

            if (totalPages > 1) {
                pages.push(totalPages)
            }
        }

        return pages
    }

    if (totalItems === 0) {
        return null
    }

    return (
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 px-2 py-4 border-t bg-background">
            <div className="flex flex-col sm:flex-row items-center gap-4">
                <p className="text-sm text-muted-foreground whitespace-nowrap">
                    Showing <span className="font-medium text-foreground">{startItem}</span> to{" "}
                    <span className="font-medium text-foreground">{endItem}</span> of{" "}
                    <span className="font-medium text-foreground">{totalItems}</span> results
                </p>

                {onItemsPerPageChange && (
                    <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground whitespace-nowrap">Rows per page:</span>
                        <Select value={itemsPerPage.toString()} onValueChange={(value) => onItemsPerPageChange(Number(value))}>
                            <SelectTrigger className="w-[70px] h-8">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="5">5</SelectItem>
                                <SelectItem value="10">10</SelectItem>
                                <SelectItem value="20">20</SelectItem>
                                <SelectItem value="50">50</SelectItem>
                                <SelectItem value="100">100</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                )}
            </div>

            <div className="flex items-center gap-2">
                <Button
                    variant="outline"
                    size="icon"
                    onClick={handleFirstPage}
                    disabled={!canGoPrevious}
                    className="h-8 w-8 bg-transparent"
                    title="First page"
                >
                    <ChevronsLeft className="h-4 w-4" />
                    <span className="sr-only">First page</span>
                </Button>

                <Button
                    variant="outline"
                    size="icon"
                    onClick={handlePreviousPage}
                    disabled={!canGoPrevious}
                    className="h-8 w-8 bg-transparent"
                    title="Previous page"
                >
                    <ChevronLeft className="h-4 w-4" />
                    <span className="sr-only">Previous page</span>
                </Button>

                <div className="hidden md:flex items-center gap-1">
                    {getPageNumbers().map((page, index) => {
                        if (page === "...") {
                            return (
                                <span key={`ellipsis-${index}`} className="px-2 py-1 text-sm text-muted-foreground">
                                    ⋯
                                </span>
                            )
                        }

                        return (
                            <Button
                                key={page}
                                variant={currentPage === page ? "default" : "outline"}
                                size="sm"
                                onClick={() => onPageChange(page as number)}
                                className="h-8 min-w-8 px-2"
                            >
                                {page}
                            </Button>
                        )
                    })}
                </div>

                <div className="md:hidden flex items-center gap-2 px-3 py-1 text-sm font-medium border rounded-md bg-muted/50">
                    <span className="text-muted-foreground">Page</span>
                    <span className="text-foreground">{currentPage}</span>
                    <span className="text-muted-foreground">of</span>
                    <span className="text-foreground">{totalPages}</span>
                </div>

                <Button
                    variant="outline"
                    size="icon"
                    onClick={handleNextPage}
                    disabled={!canGoNext}
                    className="h-8 w-8 bg-transparent"
                    title="Next page"
                >
                    <ChevronRight className="h-4 w-4" />
                    <span className="sr-only">Next page</span>
                </Button>

                <Button
                    variant="outline"
                    size="icon"
                    onClick={handleLastPage}
                    disabled={!canGoNext}
                    className="h-8 w-8 bg-transparent"
                    title="Last page"
                >
                    <ChevronsRight className="h-4 w-4" />
                    <span className="sr-only">Last page</span>
                </Button>
            </div>
        </div>
    )
}
