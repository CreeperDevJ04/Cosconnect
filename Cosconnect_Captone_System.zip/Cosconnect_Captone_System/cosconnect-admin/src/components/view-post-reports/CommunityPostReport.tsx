"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Loader2 } from "lucide-react"

import { useGetAllPostReports } from "@/lib/apis/communityApi"
import type { PostReportItem } from "@/types/report-posts/typeReportPosts"
import { PostReportsHeader } from "./PostHeaderFilter"
import { PostReportsTable } from "./PostReportTable"
import { PostReportsPagination } from "./PostReportPagination"

export default function CommunityPostReportsSection() {
    const [statusFilter, setStatusFilter] = useState<string>("all")
    const [searchTerm, setSearchTerm] = useState("")
    const [currentPage, setCurrentPage] = useState(1)
    const [itemsPerPage, setItemsPerPage] = useState(10)

    const { data, isLoading, isError, error, refetch } = useGetAllPostReports({
        page: currentPage,
        limit: itemsPerPage,
        status: statusFilter !== "all" ? statusFilter : undefined,
    })

    console.log("Reports data:", data)

    const filteredReports =
        data?.reports?.filter((reportItem: PostReportItem) => {
            if (!searchTerm) return true

            const searchLower = searchTerm.toLowerCase()
            return (
                reportItem.post.content.toLowerCase().includes(searchLower) ||
                reportItem.post.author_name.toLowerCase().includes(searchLower) ||
                reportItem.report.reason.toLowerCase().includes(searchLower) ||
                reportItem.reporter.username.toLowerCase().includes(searchLower) ||
                reportItem.reporter.email.toLowerCase().includes(searchLower)
            )
        }) || []

    const totalPages = data?.data?.pagination?.totalPages || 1
    const totalItems = data?.data?.pagination?.total || 0

    const handleSearchChange = (value: string) => {
        setSearchTerm(value)
    }

    const handleStatusFilterChange = (value: string) => {
        setStatusFilter(value)
        setCurrentPage(1)
    }

    const handlePageChange = (page: number) => {
        setCurrentPage(page)
        setSearchTerm("")
        window.scrollTo({ top: 0, behavior: "smooth" })
    }

    const handleItemsPerPageChange = (items: number) => {
        setItemsPerPage(items)
        setCurrentPage(1)
    }

    if (isLoading) {
        return (
            <div className="flex items-center justify-center min-h-[400px]">
                <div className="flex flex-col items-center gap-2">
                    <Loader2 className="w-8 h-8 animate-spin text-primary" />
                    <p className="text-sm text-muted-foreground">Loading reports...</p>
                </div>
            </div>
        )
    }

    if (isError) {
        return (
            <Card className="p-6">
                <div className="text-center">
                    <p className="text-red-600 font-medium">Error loading reports</p>
                    <p className="text-sm text-muted-foreground mt-2">
                        {error instanceof Error ? error.message : "An unknown error occurred"}
                    </p>
                    <button
                        onClick={() => refetch()}
                        className="mt-4 px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90"
                    >
                        Try Again
                    </button>
                </div>
            </Card>
        )
    }

    const uniqueStatuses = ["all", "pending", "reviewed", "resolved", "dismissed"]
    const uniqueReasons = Array.from(
        new Set(data?.reports?.map((item: PostReportItem) => item.report.reason) || []),
    )
    console.log("data", data)
    const displayReports = searchTerm ? filteredReports : data?.reports || []
    const hasResults = displayReports.length > 0
    console.log("displayReports", displayReports)
    return (
        <div className="space-y-4 p-6">
            <PostReportsHeader
                searchTerm={searchTerm}
                onSearchChange={handleSearchChange}
                statusFilter={statusFilter}
                onStatusFilterChange={handleStatusFilterChange}
                sortBy="report_count"
                onSortByChange={() => { }}
                uniqueStatuses={uniqueStatuses}
                uniqueReasons={uniqueReasons as string[]}
                totalReports={totalItems}
                filteredCount={searchTerm ? filteredReports.length : totalItems}
                onRefresh={refetch}
            />

            {hasResults ? (
                <>
                    <PostReportsTable reports={displayReports} />

                    {!searchTerm && (
                        <PostReportsPagination
                            currentPage={currentPage}
                            totalPages={totalPages}
                            totalItems={totalItems}
                            itemsPerPage={itemsPerPage}
                            onPageChange={handlePageChange}
                            onItemsPerPageChange={handleItemsPerPageChange}
                        />
                    )}

                    {searchTerm && (
                        <div className="text-center py-4">
                            <p className="text-sm text-muted-foreground">
                                Found {filteredReports.length} result{filteredReports.length !== 1 ? "s" : ""} on this page
                            </p>
                        </div>
                    )}
                </>
            ) : (
                <Card className="p-12">
                    <div className="text-center space-y-2">
                        {searchTerm ? (
                            <>
                                <p className="text-lg font-medium text-muted-foreground">No matching results</p>
                                <p className="text-sm text-muted-foreground">
                                    Try adjusting your search terms or{" "}
                                    <button onClick={() => setSearchTerm("")} className="text-primary hover:underline">
                                        clear the search
                                    </button>
                                </p>
                            </>
                        ) : (
                            <>
                                <p className="text-lg font-medium text-muted-foreground">No reports found</p>
                                <p className="text-sm text-muted-foreground">
                                    {statusFilter !== "all"
                                        ? `No reports with status: ${statusFilter}`
                                        : "There are no reports to display"}
                                </p>
                            </>
                        )}
                    </div>
                </Card>
            )}
        </div>
    )
}
