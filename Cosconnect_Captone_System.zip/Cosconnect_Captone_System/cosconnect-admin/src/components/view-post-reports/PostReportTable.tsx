// PostReportsTable.tsx
"use client"

import { useState } from "react"
import type { PostReportItem } from "@/types/report-posts/typeReportPosts"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
    AlertCircle,
    Eye,
    Calendar,
    MessageSquare,
    MoreVertical,
    User,
    CheckCircle2,
    XCircle,
    AlertTriangle,
} from "lucide-react"
import { format } from "date-fns"
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { ReportDetailDialog } from "./ViewDialogReportPost"

interface PostReportsTableProps {
    reports: PostReportItem[]
    onStatusUpdate?: (reportId: string, newStatus: 'under_review' | 'resolved') => void
    onRefresh?: () => void
}

export function PostReportsTable({ reports, onStatusUpdate, onRefresh }: PostReportsTableProps) {
    const [selectedReport, setSelectedReport] = useState<PostReportItem | null>(null)
    const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false)

    if (reports.length === 0) {
        return (
            <Card className="p-12 border-2 border-dashed">
                <div className="flex flex-col items-center justify-center text-center">
                    <div className="rounded-full bg-muted p-3 mb-4">
                        <AlertCircle className="w-8 h-8 text-muted-foreground" />
                    </div>
                    <h3 className="text-lg font-semibold text-foreground mb-2">No reports found</h3>
                    <p className="text-sm text-muted-foreground max-w-sm">
                        Try adjusting your filters or search terms to find the reports you're looking for
                    </p>
                </div>
            </Card>
        )
    }

    const getReasonConfig = (reason: string) => {
        const configs: Record<string, { variant: "destructive" | "default" | "secondary" | "outline"; icon: string }> = {
            spam: { variant: "destructive", icon: "🚫" },
            harassment: { variant: "destructive", icon: "⚠️" },
            "violence or dangerous organizations": { variant: "destructive", icon: "🔴" },
            "hate speech": { variant: "destructive", icon: "❌" },
            inappropriate: { variant: "destructive", icon: "🔞" },
            misleading: { variant: "default", icon: "⚡" },
            scam: { variant: "destructive", icon: "💰" },
            "false information": { variant: "default", icon: "📰" },
            "nudity or sexual content": { variant: "destructive", icon: "🔞" },
        }

        const key = reason.toLowerCase()
        return configs[key] || { variant: "secondary" as const, icon: "📋" }
    }

    const getStatusIcon = (status: string) => {
        switch (status) {
            case "pending":
                return <AlertTriangle className="w-4 h-4 text-yellow-500" />
            case "under_review":
                return <Eye className="w-4 h-4 text-blue-500" />
            case "reviewed":
                return <CheckCircle2 className="w-4 h-4 text-purple-500" />
            case "resolved":
                return <CheckCircle2 className="w-4 h-4 text-green-500" />
            case "dismissed":
                return <XCircle className="w-4 h-4 text-gray-500" />
            default:
                return <AlertCircle className="w-4 h-4 text-gray-500" />
        }
    }

    const getStatusBadgeVariant = (status: string): "default" | "secondary" | "destructive" | "outline" => {
        switch (status) {
            case "pending":
                return "default"
            case "under_review":
                return "secondary"
            case "reviewed":
            case "resolved":
                return "outline"
            case "dismissed":
                return "outline"
            default:
                return "secondary"
        }
    }

    const handleViewDetails = (report: PostReportItem) => {
        setSelectedReport(report)
        setIsDetailDialogOpen(true)
    }

    const handleStatusUpdate = (reportId: string, newStatus: 'under_review' | 'resolved') => {
        onStatusUpdate?.(reportId, newStatus)
    }

    const truncateId = (id: string) => {
        return `${id.slice(0, 8)}...${id.slice(-4)}`
    }

    const formatStatus = (status: string) => {
        return status.replace(/_/g, ' ')
    }

    return (
        <>
            <Card className="overflow-hidden">
                <div className="overflow-x-auto">
                    <Table>
                        <TableHeader>
                            <TableRow className="bg-muted/50">
                                <TableHead className="font-semibold">Report ID</TableHead>
                                <TableHead className="font-semibold">Post Details</TableHead>
                                <TableHead className="font-semibold">Author</TableHead>
                                <TableHead className="font-semibold">Reporter</TableHead>
                                <TableHead className="font-semibold">Reason</TableHead>
                                <TableHead className="font-semibold">Status</TableHead>
                                <TableHead className="font-semibold">Reported At</TableHead>
                                <TableHead className="text-right font-semibold w-[80px]">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {reports.map((reportItem) => {
                                const reasonConfig = getReasonConfig(reportItem.report.reason)

                                return (
                                    <TableRow key={reportItem.report.id} className="hover:bg-muted/50 transition-colors">
                                        <TableCell className="font-mono text-xs">{truncateId(reportItem.report.id)}</TableCell>

                                        <TableCell className="max-w-[350px]">
                                            <div className="space-y-2">
                                                <div className="flex items-start gap-2">
                                                    <MessageSquare className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                                                    <p className="text-sm line-clamp-2 text-foreground leading-relaxed">
                                                        {reportItem.post.content}
                                                    </p>
                                                </div>
                                                <span className="text-xs text-muted-foreground">Post ID: {truncateId(reportItem.post.id)}</span>
                                            </div>
                                        </TableCell>

                                        <TableCell>
                                            <div className="flex items-center gap-2">
                                                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white text-xs font-semibold">
                                                    {reportItem.post.author_name.charAt(0).toUpperCase()}
                                                </div>
                                                <div className="flex flex-col">
                                                    <span className="text-sm font-medium text-foreground">{reportItem.post.author_name}</span>
                                                    <span className="text-xs text-muted-foreground">
                                                        {format(new Date(reportItem.post.created_at), "MMM dd, yyyy")}
                                                    </span>
                                                </div>
                                            </div>
                                        </TableCell>

                                        <TableCell>
                                            <div className="flex items-center gap-2">
                                                <User className="w-4 h-4 text-muted-foreground" />
                                                <div className="flex flex-col">
                                                    <span className="text-sm font-medium text-foreground">{reportItem.reporter.username}</span>
                                                    <span className="text-xs text-muted-foreground">{reportItem.reporter.email}</span>
                                                </div>
                                            </div>
                                        </TableCell>

                                        <TableCell>
                                            <Badge variant={reasonConfig.variant} className="font-medium">
                                                <span className="mr-1">{reasonConfig.icon}</span>
                                                {reportItem.report.reason}
                                            </Badge>
                                        </TableCell>

                                        <TableCell>
                                            <Badge
                                                variant={getStatusBadgeVariant(reportItem.report.status)}
                                                className="flex items-center gap-1 w-fit"
                                            >
                                                {getStatusIcon(reportItem.report.status)}
                                                <span className="capitalize">{formatStatus(reportItem.report.status)}</span>
                                            </Badge>
                                        </TableCell>

                                        <TableCell>
                                            <div className="flex items-start gap-2">
                                                <Calendar className="w-4 h-4 text-muted-foreground mt-0.5" />
                                                <div className="flex flex-col">
                                                    <span className="text-sm text-foreground font-medium">
                                                        {format(new Date(reportItem.report.created_at), "MMM dd, yyyy")}
                                                    </span>
                                                    <span className="text-xs text-muted-foreground">
                                                        {format(new Date(reportItem.report.created_at), "hh:mm a")}
                                                    </span>
                                                </div>
                                            </div>
                                        </TableCell>

                                        <TableCell className="text-right">
                                            <DropdownMenu>
                                                <DropdownMenuTrigger asChild>
                                                    <Button variant="ghost" size="icon" className="h-8 w-8 p-0">
                                                        <MoreVertical className="h-4 w-4" />
                                                        <span className="sr-only">Open menu</span>
                                                    </Button>
                                                </DropdownMenuTrigger>
                                                <DropdownMenuContent align="end" className="w-48">
                                                    <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                                    <DropdownMenuSeparator />
                                                    <DropdownMenuItem onClick={() => handleViewDetails(reportItem)}>
                                                        <Eye className="w-4 h-4 mr-2" />
                                                        View & Take Action
                                                    </DropdownMenuItem>
                                                </DropdownMenuContent>
                                            </DropdownMenu>
                                        </TableCell>
                                    </TableRow>
                                )
                            })}
                        </TableBody>
                    </Table>
                </div>
            </Card>

            <ReportDetailDialog
                report={selectedReport}
                isOpen={isDetailDialogOpen}
                onClose={() => setIsDetailDialogOpen(false)}
                onStatusUpdate={handleStatusUpdate}
                {...(onRefresh ? { onRefresh } : {})}
            />
        </>
    )
}