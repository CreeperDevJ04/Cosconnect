"use client"
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export interface UserGrowthDataPoint {
    month: string;
    lenders: number;
    borrowers: number;
}

interface UserGrowthChartProps {
    data: UserGrowthDataPoint[];
}

const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
        return (
            <div className="bg-white p-3 border border-rose-100 rounded-md shadow-sm">
                <p className="text-sm font-medium text-rose-900">{label}</p>
                <div className="mt-2 space-y-1">
                    <p className="text-xs text-rose-700">
                        <span className="inline-block w-3 h-3 bg-rose-500 rounded-full mr-2"></span>
                        Lenders: {payload[0].value}
                    </p>
                    <p className="text-xs text-rose-700">
                        <span className="inline-block w-3 h-3 bg-rose-300 rounded-full mr-2"></span>
                        Borrowers: {payload[1].value}
                    </p>
                </div>
            </div>
        );
    }

    return null;
};

const UserGrowthChart: React.FC<UserGrowthChartProps> = ({ data }) => {
    return (
        <Card className="border-rose-100 hover:shadow-md transition-all duration-300">
            <CardHeader className="pb-2">
                <CardTitle className="text-lg font-medium text-rose-900">User Growth</CardTitle>
                <CardDescription className="text-xs text-rose-500">Monthly growth of lenders and borrowers</CardDescription>
            </CardHeader>
            <CardContent>
                <Tabs defaultValue="chart" className="w-full">
                    <TabsList className="mb-4">
                        <TabsTrigger value="chart">Chart</TabsTrigger>
                        <TabsTrigger value="comparison">Comparison</TabsTrigger>
                    </TabsList>
                    <TabsContent value="chart" className="w-full">
                        <div className="h-[300px] w-full">
                            <ResponsiveContainer width="100%" height="100%">
                                <LineChart
                                    data={data}
                                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                                >
                                    <CartesianGrid strokeDasharray="3 3" stroke="#FEE2E2" />
                                    <XAxis
                                        dataKey="month"
                                        tick={{ fontSize: 12, fill: '#9D174D' }}
                                    />
                                    <YAxis
                                        tick={{ fontSize: 12, fill: '#9D174D' }}
                                    />
                                    <Tooltip content={<CustomTooltip />} />
                                    <Legend
                                        wrapperStyle={{
                                            paddingTop: 10,
                                            fontSize: 12
                                        }}
                                    />
                                    <Line
                                        type="monotone"
                                        dataKey="lenders"
                                        name="Lenders"
                                        stroke="#F43F5E"
                                        strokeWidth={2}
                                        activeDot={{ r: 6 }}
                                    />
                                    <Line
                                        type="monotone"
                                        dataKey="borrowers"
                                        name="Borrowers"
                                        stroke="#FDA4AF"
                                        strokeWidth={2}
                                        activeDot={{ r: 6 }}
                                    />
                                </LineChart>
                            </ResponsiveContainer>
                        </div>
                    </TabsContent>
                    <TabsContent value="comparison" className="w-full">
                        <div className="space-y-4">
                            {data.map((item, index) => (
                                <div key={index} className="flex items-center justify-between border-b border-rose-100 pb-2">
                                    <span className="text-sm font-medium text-rose-900">{item.month}</span>
                                    <div className="flex items-center gap-4">
                                        <div className="flex items-center">
                                            <div className="w-3 h-3 bg-rose-500 rounded-full mr-2"></div>
                                            <span className="text-sm text-rose-700">{item.lenders}</span>
                                        </div>
                                        <div className="flex items-center">
                                            <div className="w-3 h-3 bg-rose-300 rounded-full mr-2"></div>
                                            <span className="text-sm text-rose-700">{item.borrowers}</span>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </TabsContent>
                </Tabs>
            </CardContent>
        </Card>
    );
};

export default UserGrowthChart; 