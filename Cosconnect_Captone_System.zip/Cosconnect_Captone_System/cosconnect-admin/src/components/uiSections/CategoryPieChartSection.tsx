"use client"
import React, { useMemo } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

type CategoryData = {
  name: string;
  value: number;
};

interface CostumeCategoryChartProps {
  data?: CategoryData[];
}

const CostumeCategoryChart: React.FC<CostumeCategoryChartProps> = ({ data }) => {
  // Default data if none provided
  const categoryData = useMemo(() => data || [
    { name: "Anime & Manga", value: 30 },
    { name: "Video Games", value: 25 },
    { name: "Movies & TV", value: 15 },
    { name: "Comics", value: 10 },
    { name: "Traditional", value: 8 },
    { name: "Original", value: 5 },
    { name: "Vtubers", value: 4 },
    { name: "K/J-pop", value: 3 },
  ], [data]);

  const COLORS = useMemo(() => [
    '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4',
    '#FFEEAD', '#FF9F9F', '#A8E6CF', '#DCD3FF'
  ], []);

  return (
    <Card className="border-rose-100 hover:shadow-md transition-all duration-300 h-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-medium text-rose-900">Costume Categories</CardTitle>
        <CardDescription className="text-xs text-rose-500">Distribution of costumes by category</CardDescription>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="h-[300px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={categoryData}
                cx="50%"
                cy="50%"
                labelLine={true}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              >
                {categoryData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip
                formatter={(value) => [`${value} costumes`, 'Count']}
                contentStyle={{
                  backgroundColor: 'white',
                  borderColor: '#FED7D7',
                  borderRadius: '0.375rem',
                  boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)'
                }}
              />
              <Legend
                layout="horizontal"
                verticalAlign="bottom"
                align="center"
                wrapperStyle={{ fontSize: '12px' }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

export default CostumeCategoryChart;