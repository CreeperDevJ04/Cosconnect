"use client"
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table";
import useAdminStore from '@/lib/zustand/adminStore';
import { Plus } from "lucide-react";
import { useState } from 'react';
import TagsPagination from './components/TagsPagination';
import TagsSearch from './components/TagsSearch';
import TagsTable from './components/TagsTable';
import CreateTagsDialog from "./CreateTagsDialog";
import DeleteTagsDialog from './DeleteTagsDialog';
import EditTagsDialog from "./EditTagsDialog";
import { useTags } from "./hooks/useTags";
import { useUpdateTags } from "@/lib/apis/tagsApi";

interface AdminDetails {
  adminId: string;
  adminName: string;
  adminEmail: string;
  adminRole: string;
}

interface Tag {
  id: string;
  tagName: string;
  status: string;
  productListingCount: number;
  totalRentalCount: number;
  createdAt: string;
  updatedAt: string;
  adminDetails: AdminDetails;
}

const ListTagsSection = () => {
  const { user } = useAdminStore();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedTag, setSelectedTag] = useState<Tag | null>(null);

  const {
    tags,
    pagination,
    isLoading,
    isError,
    error,
    searchTerm,
    currentPage,
    handleSearchChange,
    handlePageChange,
    refetch,
  } = useTags();

  const handleEditTag = async (tag: any) => {
    try {
      console.log("tag", tag)
      setSelectedTag(tag);
      setIsEditDialogOpen(true);
    } catch (error) {
      console.log("errror", error)
    }
  };

  const handleDeleteClick = (tag: Tag) => {
    setSelectedTag(tag);
    setIsDeleteDialogOpen(true);
  };




  return (
    <Card className="w-full shadow-sm border-rose-100">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-xl font-medium text-black">Cosplay Tags</CardTitle>
          <Button
            onClick={() => setIsCreateDialogOpen(true)}
            className="bg-rose-500 hover:bg-rose-600 text-white"
            size="sm"
          >
            <Plus className="mr-1 h-4 w-4" /> Create Tag
          </Button>
        </div>
        <div className="relative mt-2">
          <TagsSearch
            value={searchTerm}
            onChange={handleSearchChange}
          />
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>

              <TableHead>Tag Name</TableHead>
              <TableHead className="text-center">Product Listings</TableHead>
              <TableHead className="text-center">Rental Count</TableHead>
              <TableHead className="text-center">Created Date</TableHead>
              <TableHead className="text-center">Status</TableHead>
              <TableHead className="text-right w-[100px]">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <TagsTable
              tags={tags as any}
              isLoading={isLoading}
              isError={isError}
              error={error}
              onEdit={handleEditTag}
              onDelete={handleDeleteClick}
            />
          </TableBody>
        </Table>

        <TagsPagination
          pagination={pagination}
          currentPage={currentPage}
          onPageChange={handlePageChange}
        />
      </CardContent>

      <CreateTagsDialog
        isOpen={isCreateDialogOpen}
        onClose={() => setIsCreateDialogOpen(false)}
      />

      {selectedTag && (
        <EditTagsDialog
          isOpen={isEditDialogOpen}
          onClose={() => setIsEditDialogOpen(false)}
          tag={selectedTag as any}
        />
      )}

      {selectedTag && (
        <DeleteTagsDialog
          isOpen={isDeleteDialogOpen}
          onClose={() => setIsDeleteDialogOpen(false)}
          tag={selectedTag as any}
        />
      )}
    </Card>
  );
};

export default ListTagsSection;