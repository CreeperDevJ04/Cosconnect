"use client"
import React, { useEffect } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from "@hookform/resolvers/zod";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
    Form,
    FormControl,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Loader2 } from "lucide-react";
import { useUpdateTags } from '@/lib/apis/tagsApi';
import { toast } from 'sonner';

interface AdminDetails {
    adminId: string;
    adminName: string;
    adminEmail: string;
    adminRole: string;
}

interface Tag {
    id: string;
    tagName: string;
    status: string;
    productListingCount: number;
    totalRentalCount: number;
    createdAt: string;
    updatedAt: string;
    adminDetails: AdminDetails;
}

const formSchema = z.object({
    tagName: z.string()
        .min(2, { message: "Tag name must be at least 2 characters" })
        .max(50, { message: "Tag name must be less than 50 characters" })
        .refine(value => /^[a-zA-Z0-9\s&-]+$/.test(value), {
            message: "Tag name can only contain letters, numbers, spaces, &, and -"
        }),
    status: z.enum(['active', 'inactive']),
});

type FormValues = z.infer<typeof formSchema>;

interface EditTagsDialogProps {
    isOpen: boolean;
    onClose: () => void;
    tag: Tag;
}

const EditTagsDialog: React.FC<EditTagsDialogProps> = ({
    isOpen,
    onClose,
    tag,
}) => {
    const {
        updateTagAsync,
        isLoading: isUpdating,
        isError,
        error,
    } = useUpdateTags();

    const form = useForm<FormValues>({
        resolver: zodResolver(formSchema),
        defaultValues: {
            tagName: tag.tagName,
            status: tag.status as 'active' | 'inactive',
        },
    });

    const onSubmit = async (data: FormValues) => {
        try {
            const tagData = {
                tagId: tag.id,
                tagName: data.tagName,
                status: data.status === 'active',
                adminDetails: tag.adminDetails,
            };

            await updateTagAsync(tagData);
            toast.success('Tag updated successfully');
            onClose();
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Failed to update tag';
            toast.error(errorMessage);
        }
    };

    useEffect(() => {
        if (isOpen) {
            form.reset({
                tagName: tag.tagName,
                status: tag.status as 'active' | 'inactive',
            });
        }
    }, [isOpen, form, tag]);

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                    <DialogTitle className="text-xl font-semibold text-black">Edit Tag</DialogTitle>
                    <DialogDescription className="text-rose-500">
                        Update the tag details.
                    </DialogDescription>
                </DialogHeader>

                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                        <FormField
                            control={form.control}
                            name="tagName"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel className="text-black">Tag Name</FormLabel>
                                    <FormControl>
                                        <Input
                                            placeholder="e.g. Anime & Manga"
                                            className="border-rose-100 focus:border-rose-300"
                                            disabled={isUpdating}
                                            {...field}
                                        />
                                    </FormControl>
                                    <FormMessage className="text-rose-500" />
                                </FormItem>
                            )}
                        />

                        <FormField
                            control={form.control}
                            name="status"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel className="text-black">Status</FormLabel>
                                    <FormControl>
                                        <select
                                            className="w-full p-2 border border-rose-100 rounded-md focus:border-rose-300"
                                            disabled={isUpdating}
                                            value={field.value}
                                            onChange={(e) => field.onChange(e.target.value as 'active' | 'inactive')}
                                            aria-label="Tag status"
                                        >
                                            <option value="active">Active</option>
                                            <option value="inactive">Inactive</option>
                                        </select>
                                    </FormControl>
                                    <FormMessage className="text-rose-500" />
                                </FormItem>
                            )}
                        />

                        <DialogFooter className="mt-6">
                            <Button
                                type="button"
                                variant="outline"
                                onClick={onClose}
                                className="border-rose-100 text-rose-500 hover:bg-rose-50"
                                disabled={isUpdating}
                            >
                                Cancel
                            </Button>
                            <Button
                                type="submit"
                                className="bg-rose-500 hover:bg-rose-600 text-white"
                                disabled={isUpdating}
                            >
                                {isUpdating ? (
                                    <>
                                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                        Updating...
                                    </>
                                ) : (
                                    'Update Tag'
                                )}
                            </Button>
                        </DialogFooter>
                    </form>
                </Form>
            </DialogContent>
        </Dialog>
    );
};

export default EditTagsDialog; 