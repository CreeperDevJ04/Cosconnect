"use client"
import React, { useState } from 'react';
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { Tag } from './types/tags';

interface DeleteTagsDialogProps {
    isOpen: boolean;
    onClose: () => void;

    tag: Tag;
}

const DeleteTagsDialog: React.FC<DeleteTagsDialogProps> = ({
    isOpen,
    onClose,

    tag,
}) => {
    const [isLoading, setIsLoading] = useState(false);

    const handleDelete = async () => {
        try {
            setIsLoading(true);

        } catch (error) {
            console.error('Error deleting tag:', error);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <AlertDialog open={isOpen} onOpenChange={onClose}>
            <AlertDialogContent>
                <AlertDialogHeader>
                    <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                    <AlertDialogDescription>
                        This will permanently delete the tag "{tag.name}".
                        This action cannot be undone.
                    </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                    <AlertDialogCancel
                        className="border-rose-100 text-rose-500 hover:bg-rose-50"
                        disabled={isLoading}
                    >
                        Cancel
                    </AlertDialogCancel>
                    <Button
                        onClick={handleDelete}
                        className="bg-rose-500 hover:bg-rose-600 text-white"
                        disabled={isLoading}
                    >
                        {isLoading ? (
                            <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Deleting...
                            </>
                        ) : (
                            'Delete'
                        )}
                    </Button>
                </AlertDialogFooter>
            </AlertDialogContent>
        </AlertDialog>
    );
};

export default DeleteTagsDialog; 