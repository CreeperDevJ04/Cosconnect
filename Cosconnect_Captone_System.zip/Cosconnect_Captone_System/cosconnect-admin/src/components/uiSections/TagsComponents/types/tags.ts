import { z } from 'zod';

export const tagSchema = z.object({
    id: z.number(),
    name: z.string()
        .min(2, { message: "Tag name must be at least 2 characters" })
        .max(50, { message: "Tag name must be less than 50 characters" })
        .refine(value => /^[a-zA-Z0-9\s&-]+$/.test(value), {
            message: "Tag name can only contain letters, numbers, spaces, &, and -"
        }),
    count: z.number(),
    status: z.enum(['active', 'inactive']),
    dateCreated: z.date(),
});

export type Tag = z.infer<typeof tagSchema>;

export interface TagsPagination {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
    hasMore: boolean;
}

export interface TagsResponse {
    tags: Tag[];
    pagination: TagsPagination;
}

export interface TagsParams {
    adminId: string;
    page?: number;
    limit?: number;
    search?: string;
} 