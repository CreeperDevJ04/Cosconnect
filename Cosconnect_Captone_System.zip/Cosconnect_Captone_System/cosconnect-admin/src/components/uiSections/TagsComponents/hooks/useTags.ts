import { useState, useCallback, useMemo } from 'react';
import { useGetAllTags } from '@/lib/apis/tagsApi';
import { Tag, TagsParams } from '../types/tags';
import { debounce } from 'lodash';
import useAdminStore from '@/lib/zustand/adminStore';

export const useTags = () => {
    const { user } = useAdminStore();
    const [searchTerm, setSearchTerm] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 10;

    const params: TagsParams = useMemo(() => ({
        adminId: user?.uid || '',
        page: currentPage,
        limit: itemsPerPage,
        search: searchTerm,
    }), [currentPage, searchTerm, user?.uid]);

    const {
        tags,
        pagination,
        isLoading,
        isError,
        error,
        refetch
    } = useGetAllTags(params);

    // Debounced search handler
    const debouncedSearch = useCallback(
        debounce((value: string) => {
            setSearchTerm(value);
            setCurrentPage(1);
        }, 300),
        []
    );

    const handleSearchChange = useCallback((value: string) => {
        debouncedSearch(value);
    }, [debouncedSearch]);

    const handlePageChange = useCallback((page: number) => {
        setCurrentPage(page);
    }, []);

    return {
        tags,
        pagination,
        isLoading,
        isError,
        error,
        searchTerm,
        currentPage,
        handleSearchChange,
        handlePageChange,
        refetch,
    };
}; 