"use client"
import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
    Form,
    FormControl,
    FormDescription,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Loader2 } from "lucide-react";
import useAdminStore from '@/lib/zustand/adminStore';
import { useCreateTags } from '@/lib/apis/tagsApi';

// Define the form schema with Zod
const formSchema = z.object({
    name: z.string()
        .min(2, { message: "Tag name must be at least 2 characters" })
        .max(50, { message: "Tag name must be less than 50 characters" })
        .refine(value => /^[a-zA-Z0-9\s&-]+$/.test(value), {
            message: "Tag name can only contain letters, numbers, spaces, &, and -"
        }),
});

// Infer the type from the schema
type FormValues = z.infer<typeof formSchema>;

interface CreateTagsDialogProps {
    isOpen: boolean;
    onClose: () => void;
}

const CreateTagsDialog: React.FC<CreateTagsDialogProps> = ({
    isOpen,
    onClose,
}) => {
    const { user } = useAdminStore();
    const { createTag, isLoading } = useCreateTags();

    // Initialize form with React Hook Form and Zod resolver
    const form = useForm<FormValues>({
        resolver: zodResolver(formSchema),
        defaultValues: {
            name: '',
        },
    });

    // Handle form submission
    const onSubmit = async (data: FormValues) => {
        try {
            if (!user) {
                throw new Error('User not authenticated');
            }

            const tagData = {
                tagName: data.name,
                adminDetails: {
                    adminId: user.uid,
                    adminName: user.adminName || '',
                    adminEmail: user.email || '',
                    adminRole: user.role || '',
                },
            };
            console.log("tags", tagData)
            await createTag(tagData);
            onClose();
        } catch (error) {
            console.error('Error creating tag:', error);
        }
    };

    // Reset form when dialog closes
    React.useEffect(() => {
        if (!isOpen) {
            form.reset();
        }
    }, [isOpen, form]);

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                    <DialogTitle className="text-xl font-semibold text-black">Create New Tag</DialogTitle>
                    <DialogDescription className="text-rose-500">
                        Add a new cosplay tag to the platform.
                    </DialogDescription>
                </DialogHeader>

                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                        <FormField
                            control={form.control}
                            name="name"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel className="text-black">Tag Name</FormLabel>
                                    <FormControl>
                                        <Input
                                            placeholder="e.g. My Hero Academia"
                                            className="border-rose-100 focus:border-rose-300"
                                            disabled={isLoading}
                                            {...field}
                                        />
                                    </FormControl>
                                    <FormDescription className="text-xs text-muted-foreground">
                                        Enter a unique tag name for cosplay items.
                                    </FormDescription>
                                    <FormMessage className="text-rose-500" />
                                </FormItem>
                            )}
                        />

                        <DialogFooter className="mt-6">
                            <Button
                                type="button"
                                variant="outline"
                                onClick={onClose}
                                className="border-rose-100 text-rose-500 hover:bg-rose-50"
                                disabled={isLoading}
                            >
                                Cancel
                            </Button>
                            <Button
                                type="submit"
                                className="bg-rose-500 hover:bg-rose-600 text-white"
                                disabled={isLoading}
                            >
                                {isLoading ? (
                                    <>
                                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                        Creating...
                                    </>
                                ) : (
                                    'Create Tag'
                                )}
                            </Button>
                        </DialogFooter>
                    </form>
                </Form>
            </DialogContent>
        </Dialog>
    );
};

export default CreateTagsDialog;