import React from 'react';
import {
    TableCell,
    TableRow,
} from "@/components/ui/table";

import { Loader2, Tag as TagIcon } from "lucide-react";
import { format } from 'date-fns';
import TagsStatusBadge from './TagsStatusBadge';
import TagsActions from './TagsActions';
import { useQueryClient } from '@tanstack/react-query';

interface AdminDetails {
    adminId: string;
    adminName: string;
    adminEmail: string;
    adminRole: string;
}

interface Tag {
    id: string;
    tagName: string;
    status: string;
    productListingCount: number;
    totalRentalCount: number;
    createdAt: string;
    updatedAt: string;
    adminDetails: AdminDetails;
}

interface CachedTagsData {
    data: {
        tags: Tag[];
        pagination: {
            total: number;
            page: number;
            limit: number;
            totalPages: number;
            hasMore: boolean;
        };
    };
}

interface TagsTableProps {
    tags: Tag[];
    isLoading: boolean;
    isError: boolean;
    error: Error | null;
    onEdit: (tag: Tag) => void;
    onDelete: (tag: Tag) => void;
}

const TagsTable: React.FC<TagsTableProps> = ({
    tags,
    isLoading,
    isError,
    error,
    onEdit,
    onDelete,
}) => {
    const queryClient = useQueryClient();

    // Get cached data
    const cachedData = queryClient.getQueryData<CachedTagsData>(['tags']);
    const displayTags = cachedData?.data?.tags || tags;

    if (isLoading) {
        return (
            <TableRow>
                <TableCell colSpan={6} className="text-center py-8">
                    <div className="flex items-center justify-center space-x-2">
                        <Loader2 className="h-6 w-6 animate-spin text-rose-500" />
                        <span className="text-rose-500">Loading tags...</span>
                    </div>
                </TableCell>
            </TableRow>
        );
    }

    if (isError) {
        return (
            <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-rose-500">
                    {error?.message || 'Failed to load tags'}
                </TableCell>
            </TableRow>
        );
    }

    if (displayTags.length === 0) {
        return (
            <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                    No tags found
                </TableCell>
            </TableRow>
        );
    }

    return (
        <>
            {displayTags.map((tag: Tag) => (
                <TableRow key={tag.id}>
                    <TableCell className="flex items-center gap-2">
                        <TagIcon className="h-4 w-4 text-rose-500" />
                        {tag.tagName}
                    </TableCell>
                    <TableCell className="text-center">{tag.productListingCount}</TableCell>
                    <TableCell className="text-center">{tag.totalRentalCount}</TableCell>
                    <TableCell className="text-center">
                        {format(new Date(tag.createdAt), 'MMM d, yyyy')}
                    </TableCell>
                    <TableCell className="text-center">
                        <TagsStatusBadge status={tag.status} />
                    </TableCell>
                    <TableCell className="text-right">
                        <TagsActions
                            tag={tag}
                            onEdit={onEdit}
                            onDelete={onDelete}
                        />
                    </TableCell>
                </TableRow>
            ))}
        </>
    );
};

export default TagsTable;