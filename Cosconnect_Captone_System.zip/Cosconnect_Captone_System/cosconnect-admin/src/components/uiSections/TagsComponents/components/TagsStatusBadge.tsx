import React from 'react';
import { Badge } from "@/components/ui/badge";

interface TagsStatusBadgeProps {
    status: string;
}

const TagsStatusBadge: React.FC<TagsStatusBadgeProps> = ({ status }) => {
    const getStatusVariant = (status: string) => {
        switch (status) {
            case 'active':
                return 'outline';
            case 'inactive':
                return 'secondary';
            default:
                return 'outline';
        }
    };

    const getStatusColor = (status: string) => {
        switch (status) {
            case 'active':
                return 'bg-emerald-50 text-emerald-600 border-emerald-100';
            case 'inactive':
                return 'bg-rose-50 text-rose-600 border-rose-100';
            default:
                return 'bg-gray-50 text-gray-600 border-gray-100';
        }
    };

    return (
        <Badge
            variant={getStatusVariant(status)}
            className={`${getStatusColor(status)}`}
        >
            {status}
        </Badge>
    );
};

export default TagsStatusBadge; 