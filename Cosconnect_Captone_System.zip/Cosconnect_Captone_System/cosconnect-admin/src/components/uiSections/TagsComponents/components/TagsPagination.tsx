import React from 'react';
import {
    Pagination,
    PaginationContent,
    PaginationEllipsis,
    PaginationItem,
    PaginationLink,
    PaginationNext,
    PaginationPrevious,
} from "@/components/ui/pagination";
import { TagsPagination as TagsPaginationType } from '../types/tags';

interface TagsPaginationProps {
    pagination: TagsPaginationType;
    currentPage: number;
    onPageChange: (page: number) => void;
}

const TagsPagination: React.FC<TagsPaginationProps> = ({
    pagination,
    currentPage,
    onPageChange,
}) => {
    const { totalPages } = pagination;

    if (totalPages <= 1) return null;

    const pageNumbers = React.useMemo(() => {
        const pages = [];
        const maxVisiblePages = 3;

        if (totalPages <= maxVisiblePages) {
            for (let i = 1; i <= totalPages; i++) {
                pages.push(i);
            }
        } else {
            if (currentPage <= 2) {
                pages.push(1, 2, 3);
            } else if (currentPage >= totalPages - 1) {
                pages.push(totalPages - 2, totalPages - 1, totalPages);
            } else {
                pages.push(currentPage - 1, currentPage, currentPage + 1);
            }
        }

        return pages;
    }, [currentPage, totalPages]);

    return (
        <div className="mt-4">
            <Pagination>
                <PaginationContent>
                    <PaginationItem>
                        <PaginationPrevious
                            onClick={() => onPageChange(currentPage - 1)}
                            className={currentPage === 1 ? "pointer-events-none opacity-50" : "cursor-pointer"}
                        />
                    </PaginationItem>

                    {pageNumbers.map(number => (
                        <PaginationItem key={number}>
                            <PaginationLink
                                onClick={() => onPageChange(number)}
                                isActive={currentPage === number}
                                className="cursor-pointer"
                            >
                                {number}
                            </PaginationLink>
                        </PaginationItem>
                    ))}

                    {totalPages > 3 && currentPage < totalPages - 1 && (
                        <PaginationItem>
                            <PaginationEllipsis />
                        </PaginationItem>
                    )}

                    <PaginationItem>
                        <PaginationNext
                            onClick={() => onPageChange(currentPage + 1)}
                            className={currentPage === totalPages ? "pointer-events-none opacity-50" : "cursor-pointer"}
                        />
                    </PaginationItem>
                </PaginationContent>
            </Pagination>
        </div>
    );
};

export default TagsPagination; 