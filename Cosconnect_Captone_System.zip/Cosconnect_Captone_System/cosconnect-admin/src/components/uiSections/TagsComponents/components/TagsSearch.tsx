import React from 'react';
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";

interface TagsSearchProps {
    value: string;
    onChange: (value: string) => void;
    placeholder?: string;
}

const TagsSearch: React.FC<TagsSearchProps> = ({
    value,
    onChange,
    placeholder = "Search tags...",
}) => {
    return (
        <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-rose-500" />
            <Input
                placeholder={placeholder}
                className="pl-8 bg-white border-rose-100 focus:border-rose-300"
                value={value}
                onChange={(e) => onChange(e.target.value)}
            />
        </div>
    );
};

export default TagsSearch; 