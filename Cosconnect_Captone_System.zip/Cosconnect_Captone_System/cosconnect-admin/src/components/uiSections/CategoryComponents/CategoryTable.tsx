// CategoryTable.tsx
import React from 'react';
import {
    TableCell,
    TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Edit, Trash2, MoreHorizontal, Loader2, Package } from "lucide-react";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { format } from 'date-fns';

interface AdminDetails {
    adminId: string;
    adminName: string;
    adminEmail: string;
    adminRole: string;
}

interface Category {
    id: string;
    categoryName: string;
    status: string;
    productListingCount: number;
    totalRentalCount: number;
    createdAt: string;
    updatedAt: string;
    adminDetails: AdminDetails;
}

interface CategoryTableProps {
    categories: Category[];
    isLoading: boolean;
    isError?: boolean;
    error?: Error | null;
    onEditCategory: (category: Category) => void;
    onDeleteCategory: (category: Category) => void;
}

export const CategoryTable: React.FC<CategoryTableProps> = ({
    categories,
    isLoading,
    isError = false,
    error = null,
    onEditCategory,
    onDeleteCategory,
}) => {

    console.log("categories", categories)
    if (isLoading) {
        return <LoadingRow />;
    }

    if (isError) {
        return <ErrorRow error={error} />;
    }

    if (categories.length === 0) {
        return <EmptyRow />;
    }

    return (
        <>
            {categories.map((category) => (
                <CategoryRow
                    key={category.id}
                    category={category}
                    onEdit={onEditCategory}
                    onDelete={onDeleteCategory}
                    isLoading={isLoading}
                />
            ))}
        </>
    );
};

const LoadingRow = () => (
    <TableRow>
        <TableCell colSpan={6} className="text-center py-8">
            <div className="flex items-center justify-center space-x-2">
                <Loader2 className="h-6 w-6 animate-spin text-rose-500" />
                <span className="text-rose-500">Loading categories...</span>
            </div>
        </TableCell>
    </TableRow>
);

const ErrorRow = ({ error }: { error: Error | null }) => (
    <TableRow>
        <TableCell colSpan={6} className="text-center py-8 text-rose-500">
            {error?.message || 'Failed to load categories'}
        </TableCell>
    </TableRow>
);

const EmptyRow = () => (
    <TableRow>
        <TableCell colSpan={6} className="text-center py-8 text-gray-500">
            No categories found
        </TableCell>
    </TableRow>
);

const CategoryRow: React.FC<{
    category: Category;
    onEdit: (category: Category) => void;
    onDelete: (category: Category) => void;
    isLoading: boolean;
}> = ({ category, onEdit, onDelete, isLoading }) => (
    <TableRow>
        <TableCell className="flex items-center gap-2">
            <Package className="h-4 w-4 text-rose-500" />
            {category.categoryName}
        </TableCell>
        <TableCell className="text-center">
            <span className="inline-flex items-center justify-center min-w-[40px] px-2 py-1 rounded-full bg-rose-50 text-rose-600 text-sm">
                {category.productListingCount}
            </span>
        </TableCell>
        <TableCell className="text-center">
            <span className="inline-flex items-center justify-center min-w-[40px] px-2 py-1 rounded-full bg-blue-50 text-blue-600 text-sm">
                {category.totalRentalCount}
            </span>
        </TableCell>
        <TableCell className="text-center">
            {format(new Date(category.createdAt), 'MMM d, yyyy')}
        </TableCell>
        <TableCell className="text-center">
            <Badge
                variant="outline"
                className={
                    category.status === 'active'
                        ? "bg-emerald-50 text-emerald-600 border-emerald-100"
                        : "bg-gray-50 text-gray-600 border-gray-100"
                }
            >
                {category.status}
            </Badge>
        </TableCell>
        <TableCell className="text-right">
            <DropdownMenu>
                <DropdownMenuTrigger asChild>
                    <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        disabled={isLoading}
                    >
                        <MoreHorizontal className="h-4 w-4" />
                        <span className="sr-only">Open menu</span>
                    </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                    <DropdownMenuItem
                        onClick={() => onEdit(category)}
                        disabled={isLoading}
                    >
                        <Edit className="mr-2 h-4 w-4" />
                        Edit
                    </DropdownMenuItem>
                    <DropdownMenuItem
                        onClick={() => onDelete(category)}
                        className="text-red-600 focus:text-red-600"
                        disabled={isLoading}
                    >
                        <Trash2 className="mr-2 h-4 w-4" />
                        Delete
                    </DropdownMenuItem>
                </DropdownMenuContent>
            </DropdownMenu>
        </TableCell>
    </TableRow>
);

export default CategoryTable;