import React from 'react';
import {
    Pagination,
    PaginationContent,
    PaginationEllipsis,
    PaginationItem,
    PaginationLink,
    PaginationNext,
    PaginationPrevious,
} from "@/components/ui/pagination";

interface CategoryPaginationProps {
    currentPage: number;
    totalPages: number;
    pageNumbers: number[];
    onPageChange: (page: number) => void;
}

export const CategoryPagination: React.FC<CategoryPaginationProps> = ({
    currentPage,
    totalPages,
    pageNumbers,
    onPageChange,
}) => {
    return (
        <div className="mt-4 flex justify-center">
            <Pagination>
                <PaginationContent>
                    <PaginationItem>
                        <PaginationPrevious
                            onClick={() => onPageChange(Math.max(currentPage - 1, 1))}
                            className={`${currentPage === 1 ? 'pointer-events-none opacity-50' : 'cursor-pointer hover:bg-rose-50'}`}
                        />
                    </PaginationItem>

                    {pageNumbers.map(number => (
                        <PaginationItem key={number}>
                            <PaginationLink
                                onClick={() => onPageChange(number)}
                                isActive={currentPage === number}
                                className={`cursor-pointer ${currentPage === number ? 'bg-rose-500 text-white hover:bg-rose-600' : 'hover:bg-rose-50'}`}
                            >
                                {number}
                            </PaginationLink>
                        </PaginationItem>
                    ))}

                    {totalPages > 3 && currentPage < totalPages - 1 && (
                        <PaginationItem>
                            <PaginationEllipsis />
                        </PaginationItem>
                    )}

                    <PaginationItem>
                        <PaginationNext
                            onClick={() => onPageChange(Math.min(currentPage + 1, totalPages))}
                            className={`${currentPage === totalPages ? 'pointer-events-none opacity-50' : 'cursor-pointer hover:bg-rose-50'}`}
                        />
                    </PaginationItem>
                </PaginationContent>
            </Pagination>
        </div>
    );
};