"use client"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Card, CardContent } from "@/components/ui/card";
import { useCreateCategory, useFetchAllCategories, useUpdateCategory } from '@/lib/apis/categoryApi';
import useAdminStore from '@/lib/zustand/adminStore';
import { debounce } from 'lodash';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { CategoryHeader } from './CategoryHeader';
import { CategoryPagination } from './CategoryPagination';
import { CategoryTable } from './CategoryTable';
import CreateCategoryDialog from './CreateCategoryDialog';

import { Table, TableHeader, TableRow, TableHead, TableBody } from "@/components/ui/table";
import EditCategory from "./EditCategory";

interface AdminDetails {
  adminId: string;
  adminName: string;
  adminEmail: string;
  adminRole: string;
}

interface Category {
  id: string;
  categoryName: string;
  status: string;
  productListingCount: number;
  totalRentalCount: number;
  createdAt: string;
  updatedAt: string;
  adminDetails: AdminDetails;
}

const ListCategorySection = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [categoryToDelete, setCategoryToDelete] = useState<Category | null>(null);

  const { user } = useAdminStore();
  const itemsPerPage = 5;

  // Query parameters for API call
  const queryParams = useMemo(() => ({
    adminId: user?.uid,
    page: currentPage,
    limit: itemsPerPage,
    search: searchTerm
  }), [user?.uid, currentPage, itemsPerPage, searchTerm]);

  // Fetch categories using the hook
  const {
    data,
    isLoading,
    isError,
    error,
    refetch
  } = useFetchAllCategories(queryParams);

  // Get categories and pagination from API response
  const categories = data?.data?.categories || [];
  const pagination = data?.data?.pagination || {
    total: 0,
    page: 1,
    limit: itemsPerPage,
    totalPages: 0,
    hasMore: false
  };

  // Debounced search function
  const debouncedSearch = useCallback(
    debounce((value: string) => {
      setSearchTerm(value);
      setCurrentPage(1);
    }, 300),
    []
  );

  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    debouncedSearch(e.target.value);
  };

  // Create category mutation hook
  const mutation = useCreateCategory();

  // Category creation handler
  const handleCreateCategory = async (formData: { categoryName: string }) => {
    try {
      const adminDetails = {
        adminId: user?.uid,
        adminName: user?.adminName || 'Admin',
        adminEmail: user?.email || '',
        adminRole: user?.role || 'admin'
      };

      const categoryData = {
        categoryName: formData.categoryName,
        adminDetails
      };

      await mutation.mutateAsync(categoryData as any);
      setIsCreateDialogOpen(false);
      await refetch(); // Refresh the categories list
    } catch (error) {
      console.error("Error creating category:", error);
    }
  };

  // Handle edit category
  const handleEditCategory = (category: Category) => {
    try {
      setSelectedCategory(category);
      setIsEditDialogOpen(true);

    } catch (error) {
      console.log("error", error)
    }
  };


  // Handle delete click
  const handleDeleteClick = (category: Category) => {
    setCategoryToDelete(category);
    setDeleteDialogOpen(true);
  };

  // Confirm delete
  const confirmDelete = async () => {
    if (categoryToDelete) {
      try {
        // Implement delete logic here
        console.log('Deleting category:', categoryToDelete);
        setDeleteDialogOpen(false);
        setCategoryToDelete(null);
        await refetch();
      } catch (error) {
        console.error("Error deleting category:", error);
      }
    }
  };

  return (
    <Card className="w-full shadow-sm border-rose-100">
      <CategoryHeader
        onCreateClick={() => setIsCreateDialogOpen(true)}
        onSearchChange={handleSearchChange}
        onSearchBlur={(e) => setSearchTerm(e.target.value)}
      />
      <CardContent>
        <div className="min-h-[400px]">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Category Name</TableHead>
                <TableHead className="text-center">Product Listings</TableHead>
                <TableHead className="text-center">Rental Count</TableHead>
                <TableHead className="text-center">Created Date</TableHead>
                <TableHead className="text-center">Status</TableHead>
                <TableHead className="text-right w-[100px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <CategoryTable
                categories={categories as any}
                isLoading={isLoading}
                isError={isError}
                error={error as Error | null}
                onEditCategory={handleEditCategory}
                onDeleteCategory={handleDeleteClick}
              />
            </TableBody>
          </Table>

          {pagination.totalPages > 1 && (
            <CategoryPagination
              currentPage={currentPage}
              totalPages={pagination.totalPages}
              pageNumbers={Array.from({ length: pagination.totalPages }, (_, i) => i + 1)}
              onPageChange={setCurrentPage}
            />
          )}
        </div>
      </CardContent>

      {/* Create Category Dialog */}
      <CreateCategoryDialog
        isOpen={isCreateDialogOpen}
        onClose={() => setIsCreateDialogOpen(false)}
        onCreateCategory={handleCreateCategory}
      />

      {/* Edit Category Dialog */}
      {selectedCategory && (
        <EditCategory
          isOpen={isEditDialogOpen}
          onClose={() => setIsEditDialogOpen(false)}
          category={selectedCategory as any}
        />
      )}

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the category "{categoryToDelete?.categoryName}".
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-rose-100 text-rose-500 hover:bg-rose-50">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-rose-500 hover:bg-rose-600 text-white"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
};

export default ListCategorySection;