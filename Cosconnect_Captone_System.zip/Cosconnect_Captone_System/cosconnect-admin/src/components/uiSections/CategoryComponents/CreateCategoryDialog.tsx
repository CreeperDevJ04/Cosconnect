"use client"
import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
    Form,
    FormControl,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import useAdminStore from '@/lib/zustand/adminStore';
import { Loader2 } from "lucide-react";

// Define the form schema with Zod
const formSchema = z.object({
    categoryName: z.string()
        .min(2, { message: "Category name must be at least 2 characters" })
        .max(50, { message: "Category name must be less than 50 characters" })
        .refine(value => /^[a-zA-Z0-9\s&-]+$/.test(value), {
            message: "Category name can only contain letters, numbers, spaces, &, and -"
        })
});

// Infer the type from the schema
type FormValues = z.infer<typeof formSchema>;

interface CreateCategoryDialogProps {
    isOpen: boolean;
    onClose: () => void;
    onCreateCategory: (data: any) => Promise<void>;
    isLoading?: boolean;
}

const CreateCategoryDialog: React.FC<CreateCategoryDialogProps> = ({
    isOpen,
    onClose,
    onCreateCategory,
}) => {
    const { user } = useAdminStore();
    const [isLoading, setIsLoading] = useState(false);

    // Initialize form with React Hook Form and Zod resolver
    const form = useForm<FormValues>({
        resolver: zodResolver(formSchema),
        defaultValues: {
            categoryName: '',
        },
    });

    // Handle form submission
    const onSubmit = async (data: FormValues) => {
        try {
            setIsLoading(true);
            const prepareData = {
                categoryName: data.categoryName,
                adminDetails: {
                    adminId: user?.uid,
                    adminName: user?.adminName,
                    adminEmail: user?.email,
                    adminRole: user?.role
                },
            };

            await onCreateCategory(prepareData);
            onClose();

            setIsLoading(false);
            form.reset();
        } catch (error) {
            setIsLoading(false);
            console.error('Error creating category:', error);
        }
    };

    // Reset form when dialog closes
    React.useEffect(() => {
        if (!isOpen) {
            form.reset();
        }
    }, [isOpen, form]);

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                    <DialogTitle className="text-xl font-semibold text-black">Create New Category</DialogTitle>
                    <DialogDescription className="text-rose-500">
                        Add a new costume category to the platform.
                    </DialogDescription>
                </DialogHeader>

                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                        <FormField
                            control={form.control}
                            name="categoryName"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel className="text-black">Category Name</FormLabel>
                                    <FormControl>
                                        <Input
                                            placeholder="e.g. Anime & Manga"
                                            className="border-rose-100 focus:border-rose-300"
                                            disabled={isLoading}
                                            {...field}
                                        />
                                    </FormControl>
                                    <FormMessage className="text-rose-500" />
                                </FormItem>
                            )}
                        />

                        <DialogFooter className="mt-6">
                            <Button
                                type="button"
                                variant="outline"
                                onClick={onClose}
                                className="border-rose-100 text-rose-500 hover:bg-rose-50"
                                disabled={isLoading}
                            >
                                Cancel
                            </Button>
                            <Button
                                type="submit"
                                className="bg-rose-500 hover:bg-rose-600 text-white"
                                disabled={isLoading}
                            >
                                {isLoading ? (
                                    <>
                                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                        Creating...
                                    </>
                                ) : (
                                    'Create Category'
                                )}
                            </Button>
                        </DialogFooter>
                    </form>
                </Form>
            </DialogContent>
        </Dialog>
    );
};

export default CreateCategoryDialog;