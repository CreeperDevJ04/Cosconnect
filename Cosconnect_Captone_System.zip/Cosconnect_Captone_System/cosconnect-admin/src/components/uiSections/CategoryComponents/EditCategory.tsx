"use client"
import React, { useEffect } from 'react';
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useUpdateCategory } from '@/lib/apis/categoryApi';
import { Loader2 } from 'lucide-react';
import { toast } from 'sonner';

interface FormValues {
    categoryName: string;
    status: boolean;
}

interface EditCategoryProps {
    isOpen: boolean;
    onClose: () => void;
    category: {
        id: string;
        categoryName: string;
        status: string;
    };
}

const formSchema = z.object({
    categoryName: z.string().min(1, "Category name is required"),
    status: z.boolean(),
});

const EditCategory: React.FC<EditCategoryProps> = ({
    isOpen,
    onClose,
    category,
}) => {
    const {
        register,
        handleSubmit,
        reset,
        formState: { errors, isSubmitting },
    } = useForm<FormValues>({
        resolver: zodResolver(formSchema),
        defaultValues: {
            categoryName: category?.categoryName || '',
            status: category?.status === 'active',
        },
    });

    const {
        updateCategoryAsync,
        isLoading: isUpdating,
        isError,
        error,
    } = useUpdateCategory();

    // Reset form when dialog opens/closes
    useEffect(() => {
        if (isOpen) {
            reset({
                categoryName: category?.categoryName || '',
                status: category?.status === 'active',
            });
        }
    }, [isOpen, category, reset]);

    // Handle form submission
    const onSubmit = async (data: FormValues) => {
        try {
            const categoryData = {
                categoryName: data.categoryName,
                status: data.status ? 'active' : 'inactive',
            };

            await updateCategoryAsync({ categoryId: category.id, categoryData });
            toast.success('Category updated successfully');
            onClose();
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Failed to update category';
            toast.error(errorMessage);
        }
    };

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                    <DialogTitle>Edit Category</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="categoryName">Category Name</Label>
                        <Input
                            id="categoryName"
                            {...register("categoryName")}
                            placeholder="Enter category name"
                            className={errors.categoryName ? "border-red-500" : ""}
                        />
                        {errors.categoryName && (
                            <p className="text-sm text-red-500">{errors.categoryName.message}</p>
                        )}
                    </div>

                    <div className="flex items-center space-x-2">
                        <Switch
                            id="status"
                            {...register("status")}
                            checked={category?.status === 'active'}
                        />
                        <Label htmlFor="status">Active Status</Label>
                    </div>

                    <div className="flex justify-end space-x-2">
                        <Button
                            type="button"
                            variant="outline"
                            onClick={onClose}
                            disabled={isUpdating || isSubmitting}
                        >
                            Cancel
                        </Button>
                        <Button
                            type="submit"
                            className="bg-rose-500 hover:bg-rose-600 text-white"
                            disabled={isUpdating || isSubmitting}
                        >
                            {isUpdating || isSubmitting ? (
                                <>
                                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                    Updating...
                                </>
                            ) : (
                                'Update Category'
                            )}
                        </Button>
                    </div>
                </form>
            </DialogContent>
        </Dialog>
    );
};

export default EditCategory;