import React from 'react';
import { CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Plus } from "lucide-react";

interface CategoryHeaderProps {
    onCreateClick: () => void;
    onSearchChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onSearchBlur: (e: React.FocusEvent<HTMLInputElement>) => void;
}

export const CategoryHeader: React.FC<CategoryHeaderProps> = ({
    onCreateClick,
    onSearchChange,
    onSearchBlur,
}) => {
    return (
        <CardHeader className="pb-2">
            <div className="flex justify-between items-center">
                <CardTitle className="text-xl font-medium text-black">Costume Categories</CardTitle>
                <Button
                    onClick={onCreateClick}
                    className="bg-rose-500 hover:bg-rose-600 text-white"
                    size="sm"
                >
                    <Plus className="mr-1 h-4 w-4" /> Create Category
                </Button>
            </div>
            <div className="relative mt-2">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-rose-500" />
                <Input
                    placeholder="Search categories..."
                    className="pl-8 bg-white border-rose-100 focus:border-rose-300"
                    onChange={onSearchChange}
                    onBlur={onSearchBlur}
                />
            </div>
        </CardHeader>
    );
};

