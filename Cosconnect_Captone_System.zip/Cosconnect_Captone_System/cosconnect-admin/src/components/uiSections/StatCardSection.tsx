import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { TrendingUp } from "lucide-react";
import { FC, memo } from "react";

export interface StatCardProps {
    title: string;
    value: string | number;
    description: string;
    icon: React.ReactNode;
    trend?: number;
    trendText?: string;
    className?: string;
}

const StatCardSection: FC<StatCardProps> = memo(({
    title,
    value,
    description,
    icon,
    trend,
    trendText,
    className
}) => (
    <Card className={cn("overflow-hidden border-rose-100 bg-white hover:shadow-md transition-all duration-300 h-full", className)}>
        <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-medium text-black">{title}</CardTitle>
                <div className="p-2 bg-rose-50 rounded-lg text-rose-600">
                    {icon}
                </div>
            </div>
        </CardHeader>
        <CardContent>
            <div className="text-2xl font-bold text-black mb-1">{value}</div>
            <CardDescription className="text-rose-600 text-xs">{description}</CardDescription>
        </CardContent>
        {trend !== undefined && (
            <CardFooter className="pt-0">
                <div className="flex items-center gap-2">
                    <Badge
                        variant="outline"
                        className={cn(
                            "font-medium text-xs",
                            trend >= 0 ? "text-emerald-600 bg-white border-emerald-100" : "text-rose-600 bg-white border-rose-100"
                        )}
                    >
                        <TrendingUp
                            size={14}
                            className={cn("mr-1", trend < 0 && "rotate-180")}
                        />
                        {Math.abs(trend)}%
                    </Badge>
                    <span className="text-xs text-black/60">{trendText}</span>
                </div>
            </CardFooter>
        )}
    </Card>
));

StatCardSection.displayName = 'StatCardSection';

export default StatCardSection;