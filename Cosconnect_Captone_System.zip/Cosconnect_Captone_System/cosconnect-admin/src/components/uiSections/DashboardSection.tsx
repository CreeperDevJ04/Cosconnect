"use client"

import AnalyticsSection from "../analytics/AnalyticsSection";

const DashboardSection = () => {

  return (
    <div className="w-full h-full">
      <AnalyticsSection />
    </div>
  );
};

export default DashboardSection;