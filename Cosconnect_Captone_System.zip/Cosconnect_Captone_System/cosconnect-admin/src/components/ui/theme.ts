// ui/theme.ts
export const theme = {
    colors: {
        primary: {
            50: '#fff1f2',
            100: '#ffe4e6',
            200: '#fecdd3',
            300: '#fda4af',
            400: '#fb7185',
            500: '#f43f5e', // rose-500
            600: '#e11d48',
            700: '#be123c',
            800: '#9f1239',
            900: '#881337',
            950: '#4c0519',
        },
        neutral: {
            50: '#fafafa',
            100: '#f5f5f5',
            200: '#e5e5e5',
            300: '#d4d4d4',
            400: '#a3a3a3',
            500: '#737373',
            600: '#525252',
            700: '#404040',
            800: '#262626',
            900: '#171717',
            950: '#0a0a0a',
        },
        white: '#ffffff',
        black: '#000000',
    },
    typography: {
        fontFamily: {
            sans: ['Inter', 'system-ui', 'sans-serif'],
            mono: ['JetBrains Mono', 'monospace'],
        },
        fontSize: {
            xs: ['0.75rem', { lineHeight: '1rem' }],
            sm: ['0.875rem', { lineHeight: '1.25rem' }],
            base: ['1rem', { lineHeight: '1.5rem' }],
            lg: ['1.125rem', { lineHeight: '1.75rem' }],
            xl: ['1.25rem', { lineHeight: '1.75rem' }],
            '2xl': ['1.5rem', { lineHeight: '2rem' }],
            '3xl': ['1.875rem', { lineHeight: '2.25rem' }],
            '4xl': ['2.25rem', { lineHeight: '2.5rem' }],
        },
        fontWeight: {
            light: '300',
            normal: '400',
            medium: '500',
            semibold: '600',
            bold: '700',
        },
    },
    spacing: {
        xs: '0.5rem',
        sm: '0.75rem',
        md: '1rem',
        lg: '1.5rem',
        xl: '2rem',
        '2xl': '3rem',
        '3xl': '4rem',
    },
    borderRadius: {
        sm: '0.25rem',
        md: '0.375rem',
        lg: '0.5rem',
        xl: '0.75rem',
        '2xl': '1rem',
    },
    shadows: {
        sm: '0 1px 2px 0 rgb(0 0 0 / 0.05)',
        md: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)',
        lg: '0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1)',
        xl: '0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1)',
    },
    transitions: {
        fast: '150ms cubic-bezier(0.4, 0, 0.2, 1)',
        normal: '300ms cubic-bezier(0.4, 0, 0.2, 1)',
        slow: '500ms cubic-bezier(0.4, 0, 0.2, 1)',
    },
} as const;

export type ThemeColors = typeof theme.colors;
export type ThemeTypography = typeof theme.typography;

// CSS-in-JS utilities for consistent styling
export const themeClasses = {
    // Layout
    container: 'max-w-7xl mx-auto px-4 sm:px-6 lg:px-8',
    section: 'py-12 lg:py-16',

    // Typography
    heading: {
        h1: 'text-4xl font-bold text-neutral-900',
        h2: 'text-3xl font-semibold text-neutral-900',
        h3: 'text-2xl font-semibold text-neutral-800',
        h4: 'text-xl font-medium text-neutral-800',
        h5: 'text-lg font-medium text-neutral-700',
        h6: 'text-base font-medium text-neutral-700',
    },
    text: {
        body: 'text-base text-neutral-600',
        small: 'text-sm text-neutral-500',
        muted: 'text-sm text-neutral-400',
        caption: 'text-xs text-neutral-400',
    },

    // Buttons
    button: {
        primary: 'bg-rose-600 hover:bg-rose-700 text-white font-medium transition-colors duration-200',
        secondary: 'bg-neutral-100 hover:bg-neutral-200 text-neutral-900 font-medium transition-colors duration-200',
        ghost: 'hover:bg-neutral-100 text-neutral-700 font-medium transition-colors duration-200',
        outline: 'border border-neutral-300 hover:border-neutral-400 bg-white text-neutral-700 font-medium transition-colors duration-200',
    },

    // Cards
    card: {
        base: 'bg-white rounded-xl shadow-md border border-neutral-200',
        elevated: 'bg-white rounded-xl shadow-lg border border-neutral-200',
        glass: 'bg-white/80 backdrop-blur-md rounded-xl shadow-lg border border-white/20',
    },

    // Form elements
    input: {
        base: 'w-full px-3 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-rose-500 focus:border-rose-500 transition-colors duration-200',
        error: 'border-red-500 focus:ring-red-500 focus:border-red-500',
    },

    // Overlays
    overlay: {
        light: 'bg-black/20',
        medium: 'bg-black/40',
        dark: 'bg-black/60',
    },
} as const;