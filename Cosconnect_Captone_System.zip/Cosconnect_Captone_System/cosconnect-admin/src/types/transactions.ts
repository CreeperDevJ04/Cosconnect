// Transaction API Response Types

export interface PaymentServiceResponse {
    amount: number;
    status: string;
    currency: string;
    metadata: any;
}

export interface PaymentMethodInfo {
    type: string;
    payment_number: string;
    refund_details: {
        method: string;
        account_name: string;
        account_number: string;
    };
}

export interface SessionDetails {
    created_via: string;
    frontend_url: string;
    session_error: string | null;
    redirect_failed: string;
    redirect_success: string;
}

export interface RentalDetails {
    end_date: string;
    start_date: string;
    total_days: number;
    delivery_method: string;
}

export interface CustomerInfo {
    name: string;
    email: string;
    phone: string;
}

export interface Metadata {
    customer_info: CustomerInfo;
    rental_details: RentalDetails;
    session_details: SessionDetails;
    last_status_check: string;
    payment_method_info: PaymentMethodInfo;
    status_check_method: string;
    payment_method_details: {
        type: string;
        amount: number;
        currency: string;
    };
    payment_service_response: PaymentServiceResponse;
}

export interface Paymongo {
    paymentIntentId: string;
    sourceId: string | null;
    sessionId: string;
    checkoutUrl: string;
    sessionExpiresAt: string;
}

export interface Rental {
    id: string;
    referenceCode: string;
    status: string;
    startDate: string;
    endDate: string;
    actualReturnDate: string | null;
    rentalAmount: string;
    securityDeposit: string;
    totalAmount: string;
    extensionFee: string;
    damageCost: string;
    costumeName: string;
    costumeBrand: string;
    costumeCategory: string;
    renterName: string;
    renterEmail: string;
    renterPhone: string;
    lenderName: string;
    lenderPhone: string;
}

export interface Transaction {
    id: string;
    referenceCode: string;
    rentalId: string;
    paymentType: string;
    paymentMethod: string;
    paymentReference: string;
    description: string;
    amount: string;
    currency: string;
    status: string;
    gatewayStatus: string;
    gatewayStatusUpdatedAt: string;
    processedAt: string;
    processorNotes: string;
    receiptUrl: string | null;
    receiptNumber: string | null;
    paymongo: Paymongo;
    metadata: Metadata;
    createdAt: string;
    updatedAt: string;
    rental: Rental;
}

export interface Pagination {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
    hasNext: boolean;
    hasPrev: boolean;
}

export interface Filters {
    status: string | null;
    paymentType: string | null;
    paymentMethod: string | null;
    search: string | null;
    dateFrom: string | null;
    dateTo: string | null;
    sortOrder: 'asc' | 'desc';
}

export interface TransactionData {
    transactions: Transaction[];
    pagination: Pagination;
    filters: Filters;
}

export interface TransactionApiResponse {
    success: boolean;
    data: TransactionData;
    timestamp: string;
}
