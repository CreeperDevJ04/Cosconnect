export type BusinessType = 'STORE' | 'INDIVIDUAL';

export interface BusinessInfo {
    businessName: string;
    businessAddress: string;
    businessType: BusinessType;
    businessDescription: string;
    businessPhoneNumber: string;
    businessPermitNumber: string | null;
    businessPermitFile: string | null;
    hasValidId: boolean;
    secondaryIdType1?: string;
    secondaryIdFile1?: string;
    secondaryIdType2?: string;
    secondaryIdFile2?: string;
}

export interface LenderProfile {
    id: string;
    uid: string;
    email: string;
    fullName: string;
    username: string;
    role: "lender";
    status: "pending" | "approved" | "rejected";
    createdAt: string;
    updatedAt: string;
    isVerified: boolean;
    businessInfo: BusinessInfo;
}

export interface LenderListResponse {
    success: boolean;
    lenders: LenderProfile[];
    totalLenders: number;
    pagination: {
        total: number;
        page: number;
        limit: number;
        totalPages: number;
        hasMore: boolean;
        lastDocId: string;
    };
}