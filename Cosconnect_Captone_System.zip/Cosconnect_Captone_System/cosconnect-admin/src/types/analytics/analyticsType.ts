// file: types/analytics/analyticsType.ts

export interface AnalyticsResponse {
    success: boolean
    data: AnalyticsData
}

export interface AnalyticsData {
    users: AnalyticsUsers
    rentals: AnalyticsRentals
    transactions: AnalyticsTransactions
    charts: AnalyticsCharts
}

export interface AnalyticsUsers {
    total: number
    borrowers: number
    lenders: number
    bothRoles: number
    thisMonth: number
}

export interface AnalyticsRentals {
    total: number
    pending: number
    confirmed: number
    accepted: number
    delivered: number
    returned: number
    completed: number
    cancelled: number
    rejected: number
    overdue: number
    thisMonth: number
}

export interface AnalyticsTransactions {
    totalRevenue: number
    totalPayments: number
    thisMonthRevenue: number
    thisMonthPayments: number
    netRevenue: number
    breakdown: AnalyticsTransactionBreakdown
}

export interface AnalyticsTransactionBreakdown {
    rentalFees: number
    deposits: number
    extensionFees: number
    damageFees: number
    refunds: number
}

// Database query interfaces for backend implementation
export interface AnalyticsQueryFilters {
    startDate?: string
    endDate?: string
    period?: 'weekly' | 'monthly' | 'yearly'
}

export interface DatabaseQueryResult {
    rental_fees: number
    deposits: number
    extension_fees: number
    damage_fees: number
    refunds: number
}

export interface AnalyticsCharts {
    monthly: AnalyticsMonthlyChart[]
}

export interface AnalyticsMonthlyChart {
    month: string // e.g. "2025-10"
    label: string // e.g. "Oct 2025"
    year?: number
    revenue?: number
    transaction_count?: number
    users: AnalyticsMonthlyUsers
    rentals: AnalyticsMonthlyRentals
    transactions: AnalyticsMonthlyTransactions
}

export interface AnalyticsMonthlyUsers {
    total: number
    borrowers: number
    lenders: number
}

export interface AnalyticsMonthlyRentals {
    total: number
    completed: number
    pending: number
}

export interface AnalyticsMonthlyTransactions {
    count: number
    revenue: number
}
