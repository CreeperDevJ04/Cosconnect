// types/report-posts/typeReportPosts.ts

// --- Individual Report Info ---
export interface IndividualReport {
    id: string;
    reason: string;
    details: string | null;
    status: 'pending' | 'resolved';
    created_at: string;
    updated_at: string;
}

// --- Reported Post Info ---
export interface ReportedPost {
    id: string;
    content: string;
    author_name: string;
    author_id: string;
    created_at: string;
}

// --- Reporter Info ---
export interface Reporter {
    uid: string;
    username: string;
    email: string;
}

// --- Full Report Item (1 entry = report + post + reporter) ---
export interface PostReportItem {
    report: IndividualReport;
    post: ReportedPost;
    reporter: Reporter;
}

// --- Pagination Info ---
export interface Pagination {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
}

// --- Filters ---
export interface ReportFilters {
    status: string;
}

// --- Full API Response ---
export interface PostReportsResponse {
    success: boolean;
    data: {
        reports: PostReportItem[];
        pagination: Pagination;
        filters: ReportFilters;
    };
    message: string;
}

// --- Report Post Request ---
export interface ReportPostRequest {
    post_id: string;
    user_id: string;
    reason: string;
    details?: string;
}

// --- Report Post Response ---
export interface ReportPostResponse {
    success: boolean;
    message: string;
    data?: {
        report_id: string;
        post_id: string;
        reporter: {
            username: string;
            email: string;
        };
    };
    report_id?: string; // For duplicate report error
}

// --- Update Report Status Request ---
export interface UpdateReportStatusRequest {
    status: 'pending' | 'reviewed' | 'resolved' | 'dismissed';
    admin_id: string;
    review_notes?: string;
}

// --- Single Report Detail Response ---
export interface ReportDetailResponse {
    success: boolean;
    data: {
        report: {
            id: string;
            reason: string;
            details: string | null;
            status: 'pending' | 'reviewed' | 'resolved' | 'dismissed';
            created_at: string;
            updated_at: string;
            reviewed_at?: string | null;
            review_notes?: string | null;
        };
        post: {
            id: string;
            content: string;
            author_name: string;
            author_id: string;
            created_at: string;
        };
        reporter: {
            uid: string;
            username: string;
            email: string;
        };
    };
    message: string;
}
