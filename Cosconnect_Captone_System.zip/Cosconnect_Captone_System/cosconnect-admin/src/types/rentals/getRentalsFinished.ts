// Timeline for the rental process
export interface RentalTimeline {
    current_status: string;
    created: string;
    accepted: string | null;
    delivered: string | null;
    returned: string | null;
    payout_completed: string | null;
    refund_completed: string | null;
    fully_completed: string | null;
    updated: string;
}

// Amounts related to the rental transaction
export interface RentalAmounts {
    rental_amount: string;
    security_deposit: string;
    extension_fee: string;
    damage_cost: string;
    total_amount: string;
}

// Borrower payment details
export interface BorrowerPaymentsRefundDetails {
    processed: boolean;
    status: string;
    account_name: string;
    amount: number;
    gcash_number: string;
    borrower_id: string;
    notes: string;
    processed_at: string;
    transaction_type: string;
    completed_timestamp: string | null;
}

export interface BorrowerPayments {
    security_deposit_paid: string;
    rental_fee_paid: string;
    extension_fee_paid: string;
    damage_fee_paid: string;
    total_paid: string;
    total_refunded: string;
    refund_amount: string;
    refund_details: BorrowerPaymentsRefundDetails;
}

// Borrower information
export interface Borrower {
    uid: string;
    name: string;
    email: string;
    phone: string;
    address: string;
    payments: BorrowerPayments;
}

// Lender earnings details
export interface LenderEarningsPayoutDetails {
    processed: boolean;
    status: string;
    account_name: string;
    amount: number;
    gcash_number: string;
    lender_id: string;
    notes: string;
    processed_at: string;
    transaction_type: string;
    completed_timestamp: string | null;
}

export interface LenderEarnings {
    rental_fee: string;
    extension_fee: string;
    damage_charges: string;
    gross_earnings: string;
    security_deposit_received: string;
    security_deposit_held: string;
    net_earnings: string;
    payout_details: LenderEarningsPayoutDetails;
}

// Lender information
export interface Lender {
    uid: string;
    name: string;
    email: string;
    phone_number: string;
    earnings: LenderEarnings;
}

// Damage information related to the rental
export interface Damage {
    reported: boolean;
    cost: string;
    description: string | null;
    initial_condition: string | null;
}

// Location details for pickup or delivery
export interface Location {
    pickup: string;
    method: string;
}

// Costume image details
export interface CostumeImages {
    back: string;
    front: string;
}

// Costume details
export interface Costume {
    id: string;
    name: string;
    brand: string;
    category: string;
    sizes: string;
    images: CostumeImages;
}

// Payment details for the rental
export interface Payment {
    id: string;
    rental_id: string;
    payment_type: string;
    amount: string;
    status: string;
    currency: string;
    payment_method: string;
    payment_reference: string;
    processed_at: string;
    description: string;
    receipt_url: string | null;
    receipt_number: string | null;
    created_at: string;
    updated_at: string;
}

// Payment details like GCash numbers
export interface PaymentDetails {
    gcash_number: string;
    refund_gcash_number: string;
    refund_account_name: string;
}

// Completion status of the rental process
export interface CompletionStatusPendingActions {
    payout_pending: boolean;
    refund_pending: boolean;
}

export interface CompletionStatus {
    is_fully_completed: boolean;
    payout_completed: boolean;
    refund_completed: boolean;
    both_completed: boolean;
    pending_actions: CompletionStatusPendingActions;
}

// Transaction summary for payout and refund
export interface TransactionSummaryPayout {
    processed: boolean;
    status: string;
    account_name: string;
    amount: number;
    gcash_number: string;
    lender_id: string;
    notes: string;
    processed_at: string;
    transaction_type: string;
    completed_timestamp: string | null;
}

export interface TransactionSummaryRefund {
    processed: boolean;
    status: string;
    account_name: string;
    amount: number;
    gcash_number: string;
    borrower_id: string;
    notes: string;
    processed_at: string;
    transaction_type: string;
    completed_timestamp: string | null;
}

export interface TransactionSummary {
    payout: TransactionSummaryPayout;
    refund: TransactionSummaryRefund;
    both_processed: boolean;
}

// Main Rental interface
export interface Rental {
    id: string;
    reference_code: string;
    timeline: RentalTimeline;
    status: string;
    completion_status: CompletionStatus;
    amounts: RentalAmounts;
    borrower: Borrower;
    lender: Lender;
    damage: Damage;
    location: Location;
    costume: Costume;
    payments: Payment[];
    payment_details: PaymentDetails;
    transaction_summary: TransactionSummary;
    created_at: string;
    updated_at: string;
}

// Pagination information for the response
export interface PaginationInfo {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
    hasNext: boolean;
    hasPrev: boolean;
}

// Response structure for fetching all rentals
export interface AdminGetAllRentalsResponse {
    data: Rental[];
    pagination: PaginationInfo;
}

// Filters for querying rentals
export interface RentalsFilters {
    search: string;
    status: string;
    dateRange: {
        from: Date | null;
        to: Date | null;
    };
    sortBy: string;
    sortOrder: "asc" | "desc";
}

// Simplified Rental Details (if needed for a specific use case)
export interface RentalDetails {
    id: string;
    reference_code: string;
    status: string;
    timeline: RentalTimeline;
    completion_status: CompletionStatus;
    amounts: RentalAmounts;
    borrower: Borrower;
    lender: Lender;
    damage: Damage;
    location: Location;
    costume: Costume;
    payments: Payment[];
    payment_details: PaymentDetails;
    transaction_summary: TransactionSummary;
    created_at: string;

    updated_at: string;
}