export interface UserResponse {
    message: string;
    status: 'success' | 'error';
    statusCode: number;
    data: User[];
    pagination: Pagination;
}

export interface User {
    uid: string;
    id: string;
    username: string;
    email: string;
    phone_number: string;
    full_name: string | null;
    first_name: string | null;
    middle_name: string | null;
    last_name: string | null;
    password_hash: string | null;
    bio: string | null;
    profile_image: string | null;
    profile_background: string | null;
    avatar: string | null;
    address: string | null;
    street: string | null;
    barangay: string | null;
    zip_code: string | null;
    country: string | null;
    region: string | null;
    province: string | null;
    city: City | null;
    role: string[];
    current_role: string;
    status: 'active' | 'verified' | 'pending' | string;
    is_online: boolean;
    has_valid_id: boolean;
    valid_id_type: string | null;
    valid_id_number: string | null;
    valid_id_file: string | null;
    selfie_with_id: string | null;
    secondary_id_type1: string | null;
    secondary_id_type2: string | null;
    secondary_id_file1: string | null;
    secondary_id_file2: string | null;
    business_info: BusinessInfo | null;
    email_verified: boolean;
    phone_verified: boolean;
    last_seen: string | null;
    last_account_status_email_sent: string | null;
    reset_token: string | null;
    reset_token_expiry: string | null;
    created_at: string;
    updated_at: string;
}

export interface City {
    id: string;
    name: string;
    region: string;
    country: string;
    province: string;
}

export interface BusinessInfo {
    city: City;
    region: string;
    street: string;
    country: string;
    barangay: string;
    province: string;
    zip_code: string;
    business_name: string;
    business_type: string;
    business_address: string;
    business_telephone: string;
    business_description: string;
    business_phone_number: string;
    upload_business_permit?: string;
    upload_dti_certificate?: string;
    upload_storefront_photo?: string;
}

export interface Pagination {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
    hasNextPage: boolean;
    hasPrevPage: boolean;
}




// Types for better type safety
export interface UpdateUserStatusParams {
    userId: string;
    status: 'approve' | 'reject' | 'active';
    rejected_message?: string;
}

export interface DeleteUserByIdParams {
    userId: string;
}

export interface DeleteUsersByBulkIdsParams {
    userIds: string[];
}

export interface SuspendUserAccountParams {
    userId: string;
    message: string;
}

export interface ApiResponse<T = any> {
    message: string;
    status: 'success' | 'fail' | 'error';
    statusCode: number;
    data: T;
}
