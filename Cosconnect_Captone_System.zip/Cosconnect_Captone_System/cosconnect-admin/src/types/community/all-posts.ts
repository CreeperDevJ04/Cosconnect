
// Nested type for lender info (appears in posts with author_role: "lender")
export type LenderInfo = {
    business_name: string;
    business_type: string;
    business_profile_image: string | null;
};
// Nested type for borrower info (appears in posts with author_role: "borrower")
export type BorrowerInfo = {
    fullname: string;
    profile_image: string;
    current_role: string;
};

export type PostItem = {
    id: string;
    author_id: string;
    author_name: string;
    author_role: string;
    author_avatar: string;
    content: string;
    images: string[];
    is_for_sale: boolean;
    created_at: string;
    updated_at: string;

    // Counts
    heart_count: number;
    likes: number;
    report_count: number;
    comment_count: number;
    reaction_count: number;

    // Flags
    is_own_post: boolean;
    is_reported: boolean;
    user_has_reacted: boolean;
    user_reaction_type: string | null;

    // Nested info
    author_info: AuthorInfo;
    reactions: Reactions;
};

export type Reactions = {
    total: number;
    counts: Record<string, number>; // e.g., { "heart": 2, "angry": 1 }
    user_reaction: string | null; // type of reaction current user gave, if any
    details: ReactionDetail[];
};

// =========================
// REACTIONS
// =========================
export type ReactionUser = {
    uid: string;
    name: string;
    avatar: string;
};

export type ReactionDetail = {
    reaction_type: string; // e.g., "like", "heart", "angry"
    user_uid: string;
    user_role: string;
    reacted_at: string;
    user: ReactionUser;
};

export type AuthorInfo =
    | {
        type: "borrower";
        full_name: string;
        profile_image: string;
    }
    | {
        type: "lender";
        business_name: string;
        business_type: string;
        business_profile_image: string | null;
    };

export type PaginationMeta = {
    current_page: number;
    per_page: number;
    total: number;
    total_pages: number;
    has_next_page: boolean;
    has_previous_page: boolean;
};
// New type for filters (top-level in the response)
export type Filters = {
    search: string | null;
    onlyForSale: boolean;
};

export type AllPostsResponse = {
    success: boolean;
    data: PostItem[];
    pagination: PaginationMeta;
    filters: Filters
};