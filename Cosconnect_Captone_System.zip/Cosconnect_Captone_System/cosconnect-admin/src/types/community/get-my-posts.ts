// ============================================================================
// TYPES FOR: GET /community/get-my-posts
// ============================================================================

export interface GetMyPostsItem {
    id: string
    author_id: string
    author_name: string
    author_role: "borrower" | "lender" | "admin" | string
    author_avatar: string | null
    content: string
    images: string[]
    is_for_sale: boolean
    heart_count: number
    likes: number
    report_count: number
    is_reported: boolean
    created_at: string
    updated_at: string
  }
  
  export interface GetMyPostsPageInfo {
    hasNextPage: boolean
    nextCursor: string | null
    limit: number
  }
  
  export interface GetMyPostsFilters {
    user_id: string
    user_role?: string
  }
  
  export interface GetMyPostsResponse {
    success: boolean
    data: GetMyPostsItem[]
    pageInfo: GetMyPostsPageInfo
    filters: GetMyPostsFilters
  }
  