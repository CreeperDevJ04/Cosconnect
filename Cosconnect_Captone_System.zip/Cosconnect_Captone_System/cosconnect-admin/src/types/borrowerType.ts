// types/borrowerTypes.ts
import { z } from "zod";

export type BorrowerStatus = "pending" | "approved" | "rejected";

// Base schema for common borrower properties
export const BaseBorrowerSchema = z.object({
    id: z.string(),
    uid: z.string(),
    fullName: z.string(),
    username: z.string(),
    email: z.string().email(),
    phoneNumber: z.string(),
    address: z.string(),
    role: z.literal("borrower"),
    isVerified: z.boolean(),
    createdAt: z.string(),
    updatedAt: z.string(),
    status: z.enum(["pending", "approved", "rejected"]).optional(),
});

// Schema for borrowers with valid ID
export const BorrowerWithValidIdSchema = BaseBorrowerSchema.extend({
    hasValidId: z.literal(true),
    validIdType: z.string(),
    validIdNumber: z.string(),
    validIdFile: z.string(),
});

// Schema for borrowers with secondary IDs
export const BorrowerWithSecondaryIdsSchema = BaseBorrowerSchema.extend({
    hasValidId: z.literal(false),
    secondaryIdType1: z.string(),
    secondaryIdFile1: z.string(),
    secondaryIdType2: z.string().optional(),
    secondaryIdFile2: z.string().optional(),
    lastAccountStatusEmailSent: z.number().optional(),
});

// Combined borrower type
export const BorrowerProfileSchema = z.discriminatedUnion("hasValidId", [
    BorrowerWithValidIdSchema,
    BorrowerWithSecondaryIdsSchema,
]);

// Pagination schema
export const PaginationSchema = z.object({
    total: z.number(),
    page: z.number(),
    limit: z.number(),
    totalPages: z.number(),
    hasMore: z.boolean(),
    lastDocId: z.string().optional(),
});

// Response schema for borrower list
export const BorrowerListResponseSchema = z.object({
    success: z.boolean(),
    borrowers: z.array(BorrowerProfileSchema),
    totalBorrowers: z.number(),
    pagination: PaginationSchema,
});

// TypeScript types inferred from Zod schemas
export type BaseBorrowerProfile = z.infer<typeof BaseBorrowerSchema>;
export type BorrowerWithValidId = z.infer<typeof BorrowerWithValidIdSchema>;
export type BorrowerWithSecondaryIds = z.infer<typeof BorrowerWithSecondaryIdsSchema>;
export type BorrowerProfile = z.infer<typeof BorrowerProfileSchema>;
export type Pagination = z.infer<typeof PaginationSchema>;
export type BorrowerListResponse = z.infer<typeof BorrowerListResponseSchema>;

// Schema for search and filter form
export const BorrowerSearchFilterSchema = z.object({
    search: z.string().optional(),
    status: z.enum(["pending", "approved", "rejected"]).optional().nullable(),
});

export type BorrowerSearchFilter = z.infer<typeof BorrowerSearchFilterSchema>;