import { NextRequest, NextResponse } from "next/server"
import PDFDocument from "pdfkit"
import nodemailer from "nodemailer"
import type { Transaction } from "@/types/transactions"

function createTransactionsPdf(transactions: Transaction[], filters: any, dateRange: any) {
  return new Promise<Buffer>((resolve, reject) => {
    const doc = new PDFDocument({ margin: 40, size: "A4" })
    const chunks: Buffer[] = []

    doc.on("data", (chunk: any) => chunks.push(chunk as Buffer))
    doc.on("end", () => resolve(Buffer.concat(chunks)))
    doc.on("error", (err: any) => reject(err))

    doc.fontSize(18).text("Transactions Report", { align: "center" })
    doc.moveDown()

    if (dateRange?.startDate || dateRange?.endDate) {
      doc
        .fontSize(10)
        .text(
          `Date range: ${dateRange.startDate || "(any)"} - ${dateRange.endDate || "(any)"}`,
          { align: "center" }
        )
      doc.moveDown()
    }

    doc.font("Courier").fontSize(9)

    const headers = [
      "Reference",
      "Renter",
      "Costume",
      "Pay Type",
      "Method",
      "Status",
      "Amount",
      "Date",
    ]

    const columnWidths = [70, 80, 80, 60, 55, 55, 60, 95]

    const printRow = (cols: string[]) => {
      let x = doc.x
      const y = doc.y
      cols.forEach((col, i) => {
        const width = columnWidths[i] ?? 60
        doc.text(col, x, y, { width, ellipsis: true })
        x += width
      })
      doc.moveDown(1)
    }

    printRow(headers)
    doc.moveTo(40, doc.y).lineTo(555, doc.y).stroke()

    transactions.forEach((t) => {
      const formattedAmount = Number.parseFloat(t.amount).toLocaleString("en-US", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      })

      const formattedDate = new Date(t.createdAt).toLocaleString("en-PH", {
        year: "numeric",
        month: "short",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      })

      printRow([
        t.referenceCode,
        t.rental?.renterName || "—",
        t.rental?.costumeName || "—",
        t.paymentType,
        t.paymentMethod,
        t.status,
        `₱${formattedAmount}`,
        formattedDate,
      ])
    })

    if (transactions.length === 0) {
      doc.moveDown().text("No transactions for the selected filters.")
    }

    doc.end()
  })
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const transactions: Transaction[] = body.transactions || []
    const filters = body.filters || {}
    const dateRange = body.dateRange || {}
    const adminEmail: string | undefined = body.adminEmail || process.env.REPORT_ADMIN_EMAIL

    if (!adminEmail) {
      return NextResponse.json({ error: "Admin email not configured" }, { status: 500 })
    }

    const pdfBuffer = await createTransactionsPdf(transactions, filters, dateRange)

    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT) || 587,
      secure: process.env.SMTP_SECURE === "true",
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    })

    const subject = "CosConnect Transactions Report"

    await transporter.sendMail({
      from: process.env.SMTP_FROM || process.env.SMTP_USER,
      to: adminEmail,
      subject,
      text: "Attached is the latest transactions report based on your selected filters.",
      attachments: [
        {
          filename: "transactions-report.pdf",
          content: pdfBuffer,
        },
      ],
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error sending transactions report:", error)
    return NextResponse.json({ error: "Failed to generate or send report" }, { status: 500 })
  }
}
