import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'

interface User {
  id: string
  role: string
  created_at: string
}

interface Rental {
  id: string
  status: string
  created_at: string
  amounts?: any
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const startDate = searchParams.get('startDate')
    const endDate = searchParams.get('endDate')

    console.log('Analytics API called with:', { startDate, endDate, hasFilters: !!(startDate && endDate) })

    // Build date filter for Supabase
    const dateFilter = startDate && endDate ? {
      gte: startDate,
      lte: endDate
    } : {}

    // Get this month's start date
    const thisMonthStart = new Date()
    thisMonthStart.setDate(1)
    thisMonthStart.setHours(0, 0, 0, 0)

    let totalUsers = 0
    let borrowers = 0
    let lenders = 0
    let bothRoles = 0
    let thisMonthUsers = 0

    try {
      // Get users statistics
      const usersQuery = supabaseAdmin
        .from('users')
        .select('id, role, created_at', { count: 'exact' })

      if (startDate && endDate) {
        usersQuery.gte('created_at', startDate).lte('created_at', endDate)
      }

      const { data: usersData, error: usersError, count: totalUsersCount } = await usersQuery

      if (usersError) {
        console.warn('Users query error:', usersError)
      } else {
        const usersTyped = usersData as User[] | null
        totalUsers = totalUsersCount || 0
        borrowers = usersTyped?.filter((u: User) => u.role === 'borrower').length || 0
        lenders = usersTyped?.filter((u: User) => u.role === 'lender').length || 0
        bothRoles = usersTyped?.filter((u: User) => u.role === 'both').length || 0

        // Get this month's users
        thisMonthUsers = usersTyped?.filter((u: User) => new Date(u.created_at) >= thisMonthStart).length || 0
      }
    } catch (error) {
      console.warn('Users query failed:', error)
      // Use fallback values
    }

    // Initialize rentals variables
    let totalRentals = 0
    let rentalsByStatus = {
      pending: 0, confirmed: 0, accepted: 0, delivered: 0,
      returned: 0, completed: 0, cancelled: 0, rejected: 0
    }
    let thisMonthRentals = 0

    try {
      // Get rentals statistics - filter by creation date
      const rentalsQuery = supabaseAdmin
        .from('rentals')
        .select('id, status, created_at', { count: 'exact' })

      if (startDate && endDate) {
        rentalsQuery.gte('created_at', startDate).lte('created_at', endDate)
      }

      const { data: rentalsData, error: rentalsError, count: totalRentalsCount } = await rentalsQuery

      if (!rentalsError && rentalsData) {
        const rentalsTyped = rentalsData as Rental[]
        totalRentals = totalRentalsCount || 0
        rentalsByStatus = {
          pending: rentalsTyped.filter((r: Rental) => r.status === 'pending').length,
          confirmed: rentalsTyped.filter((r: Rental) => r.status === 'confirmed').length,
          accepted: rentalsTyped.filter((r: Rental) => r.status === 'active').length, // Map 'active' to 'accepted'
          delivered: rentalsTyped.filter((r: Rental) => r.status === 'active').length, // Approximation
          returned: rentalsTyped.filter((r: Rental) => r.status === 'returned').length,
          completed: rentalsTyped.filter((r: Rental) => r.status === 'completed').length,
          cancelled: rentalsTyped.filter((r: Rental) => r.status === 'cancelled').length,
          rejected: rentalsTyped.filter((r: Rental) => r.status === 'cancelled').length, // Approximation
        }
        thisMonthRentals = rentalsTyped.filter((r: Rental) => new Date(r.created_at) >= thisMonthStart).length
      }
    } catch (error) {
      console.warn('Rentals query failed:', error)
    }

    // Initialize revenue variables
    let rentalFees = 0
    let extensionFees = 0
    let securityDeposits = 0
    let processingFees = 0
    let platformCommissions = 0
    let totalPlatformRevenue = 0
    let thisMonthPlatformRevenue = 0

    try {
      // Get revenue data with proper calculations from rentals table
      const revenueQuery = supabaseAdmin
        .from('rentals')
        .select('rental_amount, security_deposit, extension_fee, damage_cost, status, created_at')

      if (startDate && endDate) {
        revenueQuery.gte('created_at', startDate).lte('created_at', endDate)
      }

      const { data: revenueData, error: revenueError } = await revenueQuery

      if (!revenueError && revenueData) {
        // Calculate revenue breakdown
        revenueData.forEach((rental: any) => {
          if (rental.status === 'completed') {
            rentalFees += parseFloat(rental.rental_amount || '0')
          }
          extensionFees += parseFloat(rental.extension_fee || '0')
          securityDeposits += parseFloat(rental.security_deposit || '0')
          // Note: damage_cost is not included in revenue breakdown as it's a separate fee
        })

        // Calculate fees (3% processing on rental + extension fees, 5% commission on lender earnings)
        processingFees = (rentalFees + extensionFees) * 0.03
        platformCommissions = (rentalFees + extensionFees) * 0.05
        totalPlatformRevenue = processingFees + platformCommissions

        // Get this month's revenue
        const thisMonthRevenueData = revenueData.filter((r: any) => new Date(r.created_at) >= thisMonthStart)
        let thisMonthRentalFees = 0
        let thisMonthExtensionFees = 0

        thisMonthRevenueData.forEach((rental: any) => {
          if (rental.status === 'completed') {
            thisMonthRentalFees += parseFloat(rental.rental_amount || '0')
          }
          thisMonthExtensionFees += parseFloat(rental.extension_fee || '0')
        })

        thisMonthPlatformRevenue = (thisMonthRentalFees + thisMonthExtensionFees) * 0.08
      }
    } catch (error) {
      console.warn('Revenue query failed:', error)
    }

    // Initialize charts data
    let monthlyCharts: any[] = []

    try {
      // Get monthly charts data
      const chartsQuery = supabaseAdmin
        .from('rentals')
        .select('created_at, rental_amount, status')
        .order('created_at', { ascending: true })

      if (startDate && endDate) {
        chartsQuery.gte('created_at', startDate).lte('created_at', endDate)
      }

      const { data: chartsData, error: chartsError } = await chartsQuery

      if (!chartsError && chartsData) {
        // Process charts data into monthly aggregation
        const monthlyData: { [key: string]: { users: number, rentals: number, revenue: number } } = {}

        chartsData.forEach((rental: any) => {
          const month = new Date(rental.created_at).toISOString().slice(0, 7) // YYYY-MM
          if (!monthlyData[month]) {
            monthlyData[month] = { users: 0, rentals: 0, revenue: 0 }
          }
          monthlyData[month].rentals++
          if (rental.status === 'completed') {
            monthlyData[month].revenue += parseFloat(rental.rental_amount || '0')
          }
        })

        monthlyCharts = Object.entries(monthlyData)
          .map(([month, data]) => ({
            month,
            users: data.users,
            rentals: data.rentals,
            revenue: data.revenue
          }))
          .sort((a, b) => a.month.localeCompare(b.month))
      }
    } catch (error) {
      console.warn('Charts query failed:', error)
    }

    // Return data (filtered or all)
    console.log('Returning data:', startDate && endDate ? 'filtered' : 'all')
    const data = {
      success: true,
      data: {
        users: {
          total: totalUsers,
          borrowers,
          lenders,
          bothRoles,
          thisMonth: thisMonthUsers
        },
        rentals: {
          total: totalRentals,
          ...rentalsByStatus,
          thisMonth: thisMonthRentals
        },
        revenue: {
          totalRevenue: rentalFees + extensionFees,
          totalCollected: processingFees,
          platformRevenue: totalPlatformRevenue,
          lenderPayout: (rentalFees + extensionFees) - platformCommissions,
          lenderEarningsBeforeCommission: rentalFees + extensionFees,
          netRevenue: rentalFees + extensionFees,
          thisMonthRevenue: thisMonthPlatformRevenue,
          totalTransactions: totalRentals,
          thisMonthTransactions: thisMonthRentals,
          breakdown: {
            rentalFees,
            securityDeposits,
            extensionFees,
            damageFees: 0, // TODO: Add damage fees calculation
            processingFees,
            platformCommissions
          },
          fees: {
            processingFeeRate: 0.03,
            commissionRate: 0.05,
            totalProcessingFees: processingFees,
            totalCommissions: platformCommissions
          },
          byStatus: {
            returned: {
              revenue: rentalFees * 0.8, // Approximation
              count: rentalsByStatus.returned
            },
            completed: {
              revenue: rentalFees,
              count: rentalsByStatus.completed
            }
          },
          payoutStatus: {
            completed: rentalsByStatus.completed,
            pending: rentalsByStatus.delivered
          },
          refundStatus: {
            completed: rentalsByStatus.returned,
            pending: rentalsByStatus.delivered
          }
        },
        charts: {
          monthly: monthlyCharts
        }
      }
    }

    return NextResponse.json(data)
  } catch (error) {
    console.error('Analytics API error:', error)
    return NextResponse.json(
      { success: false, message: 'Failed to fetch analytics' },
      { status: 500 }
    )
  }
}