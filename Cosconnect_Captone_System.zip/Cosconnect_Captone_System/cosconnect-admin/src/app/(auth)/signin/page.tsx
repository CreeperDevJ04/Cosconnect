'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { signInSchema, type SignInFormData } from '@/lib/zodScehma/auth';
import { zodResolver } from '@hookform/resolvers/zod';
import { Eye, EyeOff, Loader2, LogIn } from 'lucide-react';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { signIn } from '../../../../actions/auth';
import { Button } from '@/components/ui/button';

const MAX_ATTEMPTS = 5;
const LOCK_TIME = 15 * 60 * 1000; // 15 minutes
const STORAGE_KEY = "signin-attempts";

const SignInPage = () => {
    const [showPassword, setShowPassword] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [lockMessage, setLockMessage] = useState<string | null>(null);
    const [timeLeft, setTimeLeft] = useState<number>(0);

    const form = useForm<SignInFormData>({
        resolver: zodResolver(signInSchema),
        defaultValues: {
            email: '',
            password: '',
            rememberMe: false,
        },
    });

    useEffect(() => {
        checkLock();
        const interval = setInterval(checkLock, 1000);
        return () => clearInterval(interval);
    }, []);

    const checkLock = () => {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (!raw) return;
        const data = JSON.parse(raw) as { attempts: number; lockUntil: number };

        if (data.lockUntil && Date.now() < data.lockUntil) {
            const msLeft = data.lockUntil - Date.now();
            setTimeLeft(msLeft);
            const mins = Math.floor(msLeft / 60000);
            const secs = Math.floor((msLeft % 60000) / 1000);
            setLockMessage(`Too many failed attempts. Try again in ${mins}:${secs.toString().padStart(2, '0')}`);
        } else if (data.lockUntil && Date.now() >= data.lockUntil) {
            localStorage.removeItem(STORAGE_KEY);
            setLockMessage(null);
            setTimeLeft(0);
        }
    };

    const recordFailure = () => {
        const raw = localStorage.getItem(STORAGE_KEY);
        let data = raw ? JSON.parse(raw) as { attempts: number; lockUntil: number } : { attempts: 0, lockUntil: 0 };
        data.attempts += 1;
        if (data.attempts >= MAX_ATTEMPTS) {
            data.lockUntil = Date.now() + LOCK_TIME;
            setLockMessage("Too many failed attempts. Try again in 15 minutes.");
        }
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    };

    const resetAttempts = () => {
        localStorage.removeItem(STORAGE_KEY);
        setLockMessage(null);
        setTimeLeft(0);
    };

    const onSubmit = async (data: SignInFormData) => {
        checkLock();
        if (lockMessage) return;

        setIsLoading(true);
        try {
            const result = await signIn({ email: data.email, password: data.password });
            if (result.status === "success") {
                resetAttempts();
                window.location.href = "/";
            } else {
                recordFailure();
                form.setError("email", { message: result.status || "Sign in failed" });
            }
        } catch (error) {
            recordFailure();
            form.setError("email", { message: "An unexpected error occurred" });
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
            <div className="w-full max-w-md">
                <Card className="w-full shadow-lg">
                    <CardHeader className="space-y-1 text-center">
                        <CardTitle className="text-2xl font-bold">Admin Sign In</CardTitle>
                        <p className="text-sm text-gray-600">
                            Enter your credentials to access the dashboard
                        </p>
                    </CardHeader>
                    <CardContent>
                        <Form {...form}>
                            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                                <FormField
                                    control={form.control}
                                    name="email"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Email</FormLabel>
                                            <FormControl>
                                                <Input
                                                    type="email"
                                                    placeholder="Enter your email"
                                                    disabled={isLoading}
                                                    {...field}
                                                />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />

                                <FormField
                                    control={form.control}
                                    name="password"
                                    render={({ field }) => (
                                        <FormItem>
                                            <div className="flex items-center justify-between">
                                                <FormLabel>Password</FormLabel>
                                                <Link
                                                    href="/forgot-password"
                                                    className="text-sm font-medium text-blue-600 hover:underline"
                                                >
                                                    Forgot password?
                                                </Link>
                                            </div>
                                            <FormControl>
                                                <div className="relative">
                                                    <Input
                                                        type={showPassword ? "text" : "password"}
                                                        placeholder="Enter your password"
                                                        disabled={isLoading}
                                                        className="pr-10"
                                                        {...field}
                                                    />
                                                    <button
                                                        type="button"
                                                        onClick={() => setShowPassword(!showPassword)}
                                                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                                                    >
                                                        {showPassword ? (
                                                            <EyeOff className="h-4 w-4" />
                                                        ) : (
                                                            <Eye className="h-4 w-4" />
                                                        )}
                                                    </button>
                                                </div>
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />

                                {lockMessage && (
                                    <div className="text-destructive text-sm mt-4">
                                        {lockMessage} {timeLeft > 0 && `Please try again in ${Math.ceil(timeLeft / 1000)} seconds.`}
                                    </div>
                                )}
                                <Button
                                    type="submit"
                                    className="w-full"
                                    disabled={isLoading || !!lockMessage}
                                >
                                    {isLoading ? (
                                        <>
                                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                            Signing in...
                                        </>
                                    ) : (
                                        <>
                                            <LogIn className="mr-2 h-4 w-4" />
                                            Sign In
                                        </>
                                    )}
                                </Button>

                                <div className="relative my-4">
                                    <div className="absolute inset-0 flex items-center">
                                        <Separator className="w-full" />
                                    </div>
                                    <div className="relative flex justify-center text-xs uppercase">
                                        <span className="bg-white px-2 text-muted-foreground">
                                            Secure admin access
                                        </span>
                                    </div>
                                </div>

                                <div className="text-center text-sm text-gray-500">
                                    Need help? Contact your system administrator
                                </div>
                            </form>
                        </Form>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
};

export default SignInPage;