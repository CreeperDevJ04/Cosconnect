import { createClient } from '@/lib/utils/supabase/server'
import { NextResponse } from 'next/server'
// The client you created from the Server-Side Auth instructions

export async function GET(request: Request) {
    const { searchParams, origin } = new URL(request.url)
    const code = searchParams.get('code')
    // if "next" is in param, use it as the redirect URL
    let next = searchParams.get('next') ?? '/'
    if (!next.startsWith('/')) {
        // if "next" is not a relative URL, use the default
        next = '/'
    }

    console.log("OAuth Callback - Code:", code ? "Present" : "Missing");
    console.log("OAuth Callback - Next URL:", next);
    console.log("OAuth Callback - Origin:", origin);

    if (code) {
        const supabase = await createClient()
        const { data, error } = await supabase.auth.exchangeCodeForSession(code)

        console.log("Session Exchange - Error:", error);
        console.log("Session Exchange - User Data:", data?.user ? {
            id: data.user.id,
            email: data.user.email,
            user_metadata: data.user.user_metadata
        } : "No user data");

        if (error) {
            console.error("OAuth Error - Session exchange failed:", error);
            return NextResponse.redirect(`${origin}/error`)
        }

        // Get the current user after session exchange
        const { data: { user }, error: userError } = await supabase.auth.getUser();

        if (userError || !user) {
            console.error("Error getting user:", userError);
            return NextResponse.redirect(`${origin}/error`)
        }

        // Check if user exists in users table using uid (Supabase auth ID)
        const { data: existingUser } = await supabase
            .from("users")
            .select("uid, username, email, phone_number, role")
            .eq("uid", user.id) // Use uid instead of email for lookup
            .single();

        // Only create user record if it doesn't exist
        if (!existingUser) {
            // Extract data from user_metadata for Google OAuth
            const { user_metadata } = user;
            const email = user_metadata?.email || user.email;
            const fullName = user_metadata?.full_name || user_metadata?.name || "User";
            const profileImage = user_metadata?.picture || user_metadata?.avatar_url || "";

            // Create username from full name (slug, lowercase)
            const username = fullName
                .toLowerCase()
                .replace(/[^a-z0-9\s-]/g, '') // Remove special characters
                .replace(/\s+/g, '-') // Replace spaces with hyphens
                .replace(/-+/g, '-') // Replace multiple hyphens with single hyphen
                .trim();

            const userData = {
                uid: user.id, // Use uid as primary key (Supabase auth ID)
                username: username,
                email: email!,
                phone_number: user_metadata?.phone_number || user.phone || '',
                profile_image: profileImage,
                role: ['borrower'], // Role should be an array of strings
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString()
            };

            console.log('Attempting to insert user data:', userData);

            const { error: insertError } = await supabase
                .from("users")
                .insert(userData);

            if (insertError) {
                console.error('Error inserting user:', insertError);
                console.error('Error details:', {
                    message: insertError.message,
                    details: insertError.details,
                    hint: insertError.hint,
                    code: insertError.code
                });
                return NextResponse.redirect(`${origin}/error`)
            }

            console.log('Successfully inserted user into database');

            // Store role in user metadata after successful user creation
            const { error: metadataError } = await supabase.auth.updateUser({
                data: { role: 'borrower' }
            });

            if (metadataError) {
                console.error('Error updating user metadata:', metadataError);
                // Don't fail the entire flow, just log the error
            } else {
                console.log('Successfully stored role "borrower" in user metadata');
            }
        }

        console.log("OAuth Success - Redirecting to:", next);
        const forwardedHost = request.headers.get('x-forwarded-host') // original origin before load balancer
        const isLocalEnv = process.env.NODE_ENV === 'development'
        if (isLocalEnv) {
            // we can be sure that there is no load balancer in between, so no need to watch for X-Forwarded-Host
            return NextResponse.redirect(`${origin}${next}`)
        } else if (forwardedHost) {
            return NextResponse.redirect(`https://${forwardedHost}${next}`)
        } else {
            return NextResponse.redirect(`${origin}${next}`)
        }
    }

    console.log("OAuth Callback - Redirecting to error page");
    // return the user to an error page with instructions
    return NextResponse.redirect(`${origin}/error`)
}