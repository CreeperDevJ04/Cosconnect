"use client"

import RentalsManagement from "@/components/rentals-management/RentalsManagement"

export default function AdminRentalsPage() {
    return (
        <div className="min-h-screen bg-background">
            <div className="container mx-auto">
                <RentalsManagement />
            </div>
        </div>
    )
}
