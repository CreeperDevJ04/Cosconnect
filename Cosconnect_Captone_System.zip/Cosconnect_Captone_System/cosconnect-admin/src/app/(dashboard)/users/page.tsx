"use client"
import React from 'react'
import UsersManagementSection from '@/components/users/UsersManagementSection'

const UsersManagementPage = () => {
    return (
        <UsersManagementSection />
    )
}

export default UsersManagementPage