import DashboardSection from "@/components/uiSections/DashboardSection"

export default function Page() {
  return (
    <div className="w-full min-h-full">
      <DashboardSection />
    </div>
  )
}
