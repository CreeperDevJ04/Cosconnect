import ListTagsSection from '@/components/uiSections/TagsComponents/ListTagsSection'
import React from 'react'

const TagsListPage = () => {
  return <ListTagsSection />
}

export default TagsListPage