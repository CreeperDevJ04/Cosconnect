'use client'
import { TransactionsTable } from "@/components/Transaction-Logs/transactions-table";

export default function TransactionsPage() {
    return (
        <main className="min-h-screen bg-background p-6">
            <div className="mx-auto max-w-7xl space-y-6">
                        

                <TransactionsTable />
            </div>
        </main>
    )
}
