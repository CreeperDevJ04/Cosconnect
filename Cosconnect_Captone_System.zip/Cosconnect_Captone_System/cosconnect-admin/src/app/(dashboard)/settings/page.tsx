'use client';

import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Camera, User, Eye, EyeOff, Loader2 } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { useSupabaseAuth } from '@/lib/hooks/useSupabaseAuth';
import { uploadImage } from '@/lib/utils/supabase/fileUpload';
import { useUpdateAdminInfo } from '@/lib/apis/adminApi';

// Profile schema with improved validation
const profileSchema = z.object({
  email: z.string().email('Invalid email address'),
  phoneNumber: z
    .string()
    .optional()
    .refine(
      (val) => !val || val === '' || /^\+63\d{10}$/.test(val),
      'Phone number must be a valid Philippine number'
    ),
  username: z
    .string()
    .min(3, 'Username must be at least 3 characters')
    .regex(/^[a-zA-Z0-9_]+$/, 'Username can only contain letters, numbers, and underscores'),
  fullName: z
    .string()
    .min(2, 'Full name must be at least 2 characters')
    .regex(/^[a-zA-Z\s]+$/, 'Full name can only contain letters and spaces'),
  profileImage: z.string().optional().or(z.literal('')),
});

// Password schema with improved validation
const passwordSchema = z
  .object({
    currentPassword: z.string().min(8, 'Password must be at least 8 characters'),
    newPassword: z
      .string()
      .min(8, 'Password must be at least 8 characters')
      .regex(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/,
        'Password must contain at least one uppercase letter, one lowercase letter, and one number'
      ),
    confirmPassword: z.string().min(8, 'Password must be at least 8 characters'),
  })
  .refine((data) => data.newPassword === data.confirmPassword, {
    message: "Passwords don't match",
    path: ['confirmPassword'],
  });

type ProfileForm = z.infer<typeof profileSchema>;
type PasswordForm = z.infer<typeof passwordSchema>;

export default function AdminSettings() {
  const [activeTab, setActiveTab] = useState<'profile' | 'password'>('profile');
  const [previewImage, setPreviewImage] = useState<string>('');
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const DEFAULT_PROFILE_IMAGE = '/images/default-profile.png';


  // Get admin data from Supabase auth
  const { adminData, isLoading, error } = useSupabaseAuth();
  const { updateAdminInfo, isUpdating } = useUpdateAdminInfo(); // ✅ use the hook

  const profileForm = useForm<ProfileForm>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      email: '',
      phoneNumber: '',
      username: '',
      fullName: '',
      profileImage: adminData?.profile_image || '',
    },
  });

  const passwordForm = useForm<PasswordForm>({
    resolver: zodResolver(passwordSchema),
    defaultValues: {
      currentPassword: '',
      newPassword: '',
      confirmPassword: '',
    },
  });

  useEffect(() => {
    if (adminData) {
      console.log('Admin Data Loaded:', adminData);

      // ✅ Always use a fallback image if no profile image
      const imageUrl =
        adminData.profile_image && adminData.profile_image.trim() !== ''
          ? adminData.profile_image
          : DEFAULT_PROFILE_IMAGE;

      setPreviewImage(imageUrl);

      profileForm.reset({
        email: adminData.email || '',
        phoneNumber: adminData.phone_number || '',
        username: adminData.username || '',
        fullName: adminData.full_name || '',
        profileImage: imageUrl,
      });
    }
  }, [adminData]);


  // Handle phone number input for Philippine format (+63)
  const handleNumberChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    onChange: (value: string) => void
  ) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.startsWith('63')) {
      value = value.substring(2);
    }
    if (value.length > 0 && value[0] !== '9') {
      value = '9' + value.slice(0, 9);
    } else if (value.length > 10) {
      value = value.substring(0, 10);
    }
    onChange('+63' + value);
  };



  // Handle text-only input (for full name)
  const handleTextChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    onChange: (value: string) => void
  ) => {
    const value = e.target.value.replace(/[^a-zA-Z\s]/g, '');
    onChange(value);
  };

  // Handle alphanumeric input (for username)
  const handleUsernameChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    onChange: (value: string) => void
  ) => {
    const value = e.target.value.replace(/[^a-zA-Z0-9_]/g, '');
    onChange(value);
  };

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file size and type
    if (file.size > 5 * 1024 * 1024) {
      alert('Image size must be less than 5MB');
      return;
    }
    if (!file.type.startsWith('image/')) {
      alert('Please upload an image file');
      return;
    }

    try {
      setIsUploading(true);

      // Upload to Supabase
      const { url, error } = await uploadImage({ file });

      if (error || !url) {
        console.error('Upload failed:', error);
        alert('Image upload failed. Please try again.');
        return;
      }

      // Set Supabase public URL to preview and form
      setPreviewImage(url);
      profileForm.setValue('profileImage', url);

    } catch (err) {
      console.error('Error uploading image:', err);
      alert('Unexpected error during upload.');
    } finally {
      setIsUploading(false);
    }
  };

  console.log("adminData?.id", adminData)
  const onProfileSubmit = profileForm.handleSubmit(async (data: ProfileForm) => {
    const preparedData = {
      id: adminData?.id,
      email: data.email,
      phone_number: data.phoneNumber || null,
      username: data.username,
      full_name: data.fullName,
      profile_image: data.profileImage || null,
      role: 'admin' as const,
      updated_at: new Date().toISOString(),
    };

    console.log('✅ Prepared Profile Data:', preparedData);
    try {
      await updateAdminInfo(preparedData as any)
    } catch (error: any) {
      console.log("error", error)
    }
  });

  const onPasswordSubmit = passwordForm.handleSubmit((data: PasswordForm) => {
    const preparedData = {
      admin_id: adminData?.id,
      current_password: data.currentPassword,
      new_password: data.newPassword,
      updated_at: new Date().toISOString(),
    };

    console.log('✅ Prepared Password Data:', preparedData);
    passwordForm.reset();
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="flex items-center space-x-2">
          <Loader2 className="h-5 w-5 animate-spin text-black" />
          <span className="text-sm text-gray-600">Loading admin data...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <p className="text-sm text-gray-900">Error loading admin data</p>

        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-black">Settings</h1>
              <p className="mt-2 text-sm text-gray-600">Manage your account settings</p>
            </div>
            <Badge variant="outline" className="border-black text-black">
              {adminData?.role || 'Admin'}
            </Badge>
          </div>
        </div>

        <Separator className="mb-8" />

        {/* Tabs */}
        <div className="border-b border-gray-200 mb-8">
          <div className="flex space-x-8">
            <button
              onClick={() => setActiveTab('profile')}
              className={`pb-4 px-1 border-b-2 font-medium text-sm transition-colors ${activeTab === 'profile'
                ? 'border-black text-black'
                : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
            >
              Profile
            </button>
            <button
              onClick={() => setActiveTab('password')}
              className={`pb-4 px-1 border-b-2 font-medium text-sm transition-colors ${activeTab === 'password'
                ? 'border-black text-black'
                : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
            >
              Password
            </button>
          </div>
        </div>

        {/* Profile Tab */}
        {activeTab === 'profile' && (
          <div className="space-y-8">
            {/* Profile Image */}
            <div className="flex items-center space-x-6">
              <div className="relative">
                <div className="w-20 h-20 rounded-full bg-gray-100 border border-gray-200 flex items-center justify-center overflow-hidden">
                  {isUploading ? (
                    <Loader2 className="w-6 h-6 text-gray-400 animate-spin" />
                  ) : previewImage ? (
                    <img src={previewImage} alt="Profile" className="w-full h-full object-cover" />
                  ) : (
                    <User className="w-10 h-10 text-gray-400" />
                  )}
                </div>
                <Label
                  htmlFor="profile-image"
                  className="absolute bottom-0 right-0 bg-black rounded-full p-1.5 cursor-pointer hover:bg-gray-800 transition-colors"
                >
                  <Camera className="w-3.5 h-3.5 text-white" />
                </Label>
                <Input
                  id="profile-image"
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                  className="hidden"
                />
              </div>

              <div>
                <h3 className="text-sm font-medium text-black">Profile Photo</h3>
                <p className="text-xs text-gray-500 mt-1">Max size: 5MB (JPG, PNG)</p>
              </div>
            </div>

            <Separator />

            {/* Full Name */}
            <div className="space-y-2">
              <Label htmlFor="fullName">Full Name</Label>
              <Input
                id="fullName"
                placeholder="John Doe"
                value={profileForm.watch('fullName')}
                onChange={(e) => handleTextChange(e, (value) => profileForm.setValue('fullName', value))}
              />
              <p className="text-xs text-gray-500">Letters and spaces only</p>
              {profileForm.formState.errors.fullName && (
                <p className="text-xs text-red-600">
                  {profileForm.formState.errors.fullName.message}
                </p>
              )}
            </div>

            {/* Username */}
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                placeholder="johndoe"
                value={profileForm.watch('username')}
                onChange={(e) =>
                  handleUsernameChange(e, (value) => profileForm.setValue('username', value))
                }
              />
              <p className="text-xs text-gray-500">Letters, numbers, and underscores only</p>
              {profileForm.formState.errors.username && (
                <p className="text-xs text-red-600">
                  {profileForm.formState.errors.username.message}
                </p>
              )}
            </div>

            {/* Email */}
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="john@example.com"
                {...profileForm.register('email')}
              />
              {profileForm.formState.errors.email && (
                <p className="text-xs text-red-600">{profileForm.formState.errors.email.message}</p>
              )}
            </div>

            {/* Phone Number */}
            <div className="space-y-2">
              <Label htmlFor="phoneNumber">
                Phone Number <span className="text-gray-400 font-normal">(Optional)</span>
              </Label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <span className="text-gray-500 text-sm">+63</span>
                </div>
                <Input
                  id="phoneNumber"
                  type="tel"
                  placeholder="912 345 6789"
                  className="pl-12"
                  value={
                    profileForm.watch('phoneNumber')
                      ? profileForm.watch('phoneNumber')?.replace('+63', '')
                      : ''
                  }
                  onChange={(e) =>
                    handleNumberChange(e, (value) => profileForm.setValue('phoneNumber', value))
                  }
                  maxLength={10}
                />
              </div>
              <p className="text-xs text-gray-500">Philippine mobile number format (starts with 9)</p>
              {profileForm.formState.errors.phoneNumber && (
                <p className="text-xs text-red-600">
                  {profileForm.formState.errors.phoneNumber.message}
                </p>
              )}
            </div>

            <Separator />

            {/* Submit Button */}
            <Button
              type="button"
              onClick={onProfileSubmit}
              disabled={isUpdating || isUploading}
              className="w-full bg-black hover:bg-gray-800 flex items-center justify-center"
            >
              {isUpdating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...
                </>
              ) : (
                'Save Changes'
              )}
            </Button>
          </div>
        )}

        {/* Password Tab */}
        {activeTab === 'password' && (
          <div className="space-y-8">
            <p className="text-sm text-gray-600">Update your password to keep your account secure</p>

            <Separator />

            {/* Current Password */}
            <div className="space-y-2">
              <Label htmlFor="currentPassword">Current Password</Label>
              <div className="relative">
                <Input
                  id="currentPassword"
                  type={showCurrentPassword ? 'text' : 'password'}
                  placeholder="Enter current password"
                  {...passwordForm.register('currentPassword')}
                />
                <button
                  type="button"
                  onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                >
                  {showCurrentPassword ? (
                    <EyeOff className="h-4 w-4 text-gray-400" />
                  ) : (
                    <Eye className="h-4 w-4 text-gray-400" />
                  )}
                </button>
              </div>
              {passwordForm.formState.errors.currentPassword && (
                <p className="text-xs text-red-600">
                  {passwordForm.formState.errors.currentPassword.message}
                </p>
              )}
            </div>

            {/* New Password */}
            <div className="space-y-2">
              <Label htmlFor="newPassword">New Password</Label>
              <div className="relative">
                <Input
                  id="newPassword"
                  type={showNewPassword ? 'text' : 'password'}
                  placeholder="Enter new password"
                  {...passwordForm.register('newPassword')}
                />
                <button
                  type="button"
                  onClick={() => setShowNewPassword(!showNewPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                >
                  {showNewPassword ? (
                    <EyeOff className="h-4 w-4 text-gray-400" />
                  ) : (
                    <Eye className="h-4 w-4 text-gray-400" />
                  )}
                </button>
              </div>
              <p className="text-xs text-gray-500">
                Must contain uppercase, lowercase, and number (min 8 characters)
              </p>
              {passwordForm.formState.errors.newPassword && (
                <p className="text-xs text-red-600">
                  {passwordForm.formState.errors.newPassword.message}
                </p>
              )}
            </div>

            {/* Confirm Password */}
            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirm New Password</Label>
              <div className="relative">
                <Input
                  id="confirmPassword"
                  type={showConfirmPassword ? 'text' : 'password'}
                  placeholder="Confirm new password"
                  {...passwordForm.register('confirmPassword')}
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                >
                  {showConfirmPassword ? (
                    <EyeOff className="h-4 w-4 text-gray-400" />
                  ) : (
                    <Eye className="h-4 w-4 text-gray-400" />
                  )}
                </button>
              </div>
              {passwordForm.formState.errors.confirmPassword && (
                <p className="text-xs text-red-600">
                  {passwordForm.formState.errors.confirmPassword.message}
                </p>
              )}
            </div>

            <Separator />

            {/* Submit Button */}
            <Button
              type="button"
              onClick={onPasswordSubmit}
              className="w-full bg-black hover:bg-gray-800"
            >
              Update Password
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}