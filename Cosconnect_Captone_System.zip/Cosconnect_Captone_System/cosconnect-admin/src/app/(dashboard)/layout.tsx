"use client";

import { useEffect, useRef, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import SideBarNav from "@/components/layout/SideBarNav";
import { useSupabaseAuth } from '@/lib/hooks/useSupabaseAuth'; // Update this path
import { signOut } from '../../../actions/auth';

// Loading component
const LoadingSpinner = () => (
    <div className="flex items-center justify-center min-h-screen bg-muted/40">
        <div className="flex flex-col items-center space-y-4">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            <p className="text-sm text-muted-foreground">Loading...</p>
        </div>
    </div>
);


export default function DashboardLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    const router = useRouter();
    const { adminData, user, session, isLoading, error } = useSupabaseAuth();

    // Refs for auto-logout functionality
    const lastActivityTime = useRef<number>(Date.now());
    const timeoutId = useRef<NodeJS.Timeout | null>(null);
    const isActive = useRef<boolean>(true);

    // Auto-logout timeout (10 minutes = 600,000 milliseconds)
    const AUTO_LOGOUT_TIME = 10 * 60 * 1000; // 10 minutes

    // Handle auto logout
    const handleAutoLogout = useCallback(async () => {
        console.log('Auto-logout triggered due to inactivity');
        await signOut();
    }, []);

    // Reset the auto-logout timer
    const resetAutoLogoutTimer = useCallback(() => {
        if (timeoutId.current) {
            clearTimeout(timeoutId.current);
        }

        lastActivityTime.current = Date.now();

        // Only set timeout if user is authenticated
        if (session && isActive.current) {
            timeoutId.current = setTimeout(handleAutoLogout, AUTO_LOGOUT_TIME);
        }
    }, [session, handleAutoLogout]);

    // Activity detection
    const handleActivity = useCallback(() => {
        resetAutoLogoutTimer();
    }, [resetAutoLogoutTimer]);

    // Set up activity listeners and auto-logout timer
    useEffect(() => {
        if (!session) return;

        // Activity events to monitor
        const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click'];

        // Add event listeners
        events.forEach(event => {
            document.addEventListener(event, handleActivity, true);
        });

        // Start the auto-logout timer
        resetAutoLogoutTimer();

        // Cleanup
        return () => {
            events.forEach(event => {
                document.removeEventListener(event, handleActivity, true);
            });

            if (timeoutId.current) {
                clearTimeout(timeoutId.current);
            }
        };
    }, [session, handleActivity, resetAutoLogoutTimer]);

    // Handle component unmount
    useEffect(() => {
        return () => {
            isActive.current = false;
            if (timeoutId.current) {
                clearTimeout(timeoutId.current);
            }
        };
    }, []);

    // Handle authentication errors
    useEffect(() => {
        if (error) {
            console.error('Authentication error:', error);
            // You might want to show a toast notification here
        }
    }, [error]);

    // Show loading spinner while checking authentication
    if (isLoading) {
        return <LoadingSpinner />;
    }

    // Redirect to sign-in if not authenticated
    if (!session || !user) {
        router.push('/signin');
        return <LoadingSpinner />;
    }

    // Optional: Check if user has admin role
    if (adminData && adminData.role !== 'admin') {
        router.push('/unauthorized'); // or wherever you want to redirect non-admin users
        return <LoadingSpinner />;
    }

    return (
        <div className="flex min-h-screen bg-muted/40">
            {/* Main content area */}
            <div className="flex flex-1 flex-col w-full mx-auto">
                <div className="flex-1 flex flex-row h-full">
                    <SideBarNav />
                    <main className="flex-1 p-4 overflow-auto">
                        {children}
                    </main>
                </div>
            </div>
        </div>
    );
}