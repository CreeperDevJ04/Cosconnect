import ListCategorySection from '@/components/uiSections/CategoryComponents/ListCategorySection'
import React from 'react'

const CategoriesListPage = () => {
  return <ListCategorySection />
}

export default CategoriesListPage