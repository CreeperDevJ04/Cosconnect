"use client"

import CommunityPostReportsSection from "@/components/view-post-reports/CommunityPostReport";

export default function ReportsPage() {
    return (
        <div className="container mx-auto py-6">
            <CommunityPostReportsSection />
        </div>
    )
}
