import { createClient } from '@/lib/utils/supabase/client'
import { redirect } from 'next/navigation'

export default async function PrivatePage() {
    const supabase = await createClient()

    const { data, error } = await supabase.auth.getUser()
    if (error || !data?.user) {
        redirect('/signin')
    }

    return <p>Hello {data.user.email}</p>
}