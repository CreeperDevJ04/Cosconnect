// file: hooks/useGetAnalytics.ts
// Frontend analytics API hook
// Backend implementation should use queries from analyticsQueries.ts

import { useQuery } from '@tanstack/react-query'
import { axiosApiClient } from './axiosApiClient'
import { AnalyticsResponse } from '@/types/analytics/analyticsType'

interface AnalyticsFilters {
    startDate?: string
    endDate?: string
    period?: 'weekly' | 'monthly' | 'yearly'
}

export const useGetAnalytics = (filters?: AnalyticsFilters) => {
    const getAnalytics = async (): Promise<any> => {
        try {
            const params = new URLSearchParams()
            if (filters?.startDate) params.append('startDate', filters.startDate)
            if (filters?.endDate) params.append('endDate', filters.endDate)
            if (filters?.period) params.append('period', filters.period)

            const url = `/analytics${params.toString() ? `?${params.toString()}` : ''}`
            const response = await axiosApiClient.get<any>(url)
            console.log('Analytics API Response:', response.data)

            // TODO: Backend should implement proper database queries
            // See src/lib/apis/analyticsQueries.ts for optimized query examples
            // Currently returns mock data - needs backend implementation

            return response.data
        } catch (error: any) {
            console.error('Error getting analytics:', error)
            throw new Error(error.response?.data?.message || 'Failed to get analytics')
        }
    }

    const query = useQuery<any>({
        queryKey: ['analytics', filters],
        queryFn: getAnalytics,
    })

    return {
        isLoading: query.isLoading,
        data: query.data,
        error: query.error,
        refetch: query.refetch,
    }
}
