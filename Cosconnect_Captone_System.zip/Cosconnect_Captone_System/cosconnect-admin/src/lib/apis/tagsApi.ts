import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import axios, { AxiosError } from 'axios';
import { toast } from 'sonner';

const API_BASE_URL = 'http://localhost:8000/api/v1';

interface TagsParams {
    adminId: string;
    page?: number;
    limit?: number;
}

interface Tag {
    id: string;
    tagName: string;
    createdAt: string;
    updatedAt: string;
    adminDetails: {
        adminId: string;
        adminName: string;
        adminEmail: string;
        adminRole: string;
    };
}

interface PaginationInfo {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
    hasMore: boolean;
}

interface GetAllTagsResponse {
    success: boolean;
    message?: string;
    data: {
        tags: Tag[];
        pagination: PaginationInfo;
    };
}

const apiClient = axios.create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json',
    },
});

export const useGetAllTags = (params: TagsParams) => {
    const getAllTagsApiRequest = async (): Promise<GetAllTagsResponse> => {
        if (!params.adminId) {
            throw new Error('Admin ID is required');
        }

        try {
            const response = await apiClient.get(`/products/get-all-tags`, {
                params: {
                    page: params.page || 1,
                    limit: params.limit || 10,
                },
            });

            if (!response.data.success) {
                throw new Error(response.data.message || 'Failed to fetch tags');
            }

            return response.data;
        } catch (error) {
            const axiosError = error as AxiosError<{ success: boolean; message: string }>;
            console.error('Tags fetch error:', {
                status: axiosError.response?.status,
                message: axiosError.response?.data?.message || axiosError.message,
                error: axiosError
            });

            const errorMessage =
                axiosError.response?.status === 400 ? 'Invalid request parameters' :
                    axiosError.response?.status === 401 ? 'Unauthorized access' :
                        axiosError.response?.status === 403 ? 'Access forbidden' :
                            axiosError.response?.data?.message || 'Failed to fetch tags';

            toast.error(errorMessage);
            throw error;
        }
    };

    const query = useQuery({
        queryKey: ['tags', params],
        queryFn: getAllTagsApiRequest,
        retry: 1,
        staleTime: 5 * 60 * 1000, // Cache for 5 minutes
    });

    return {
        tags: query.data?.data.tags || [],
        pagination: query.data?.data.pagination || {
            total: 0,
            page: params.page || 1,
            limit: params.limit || 10,
            totalPages: 0,
            hasMore: false,
        },
        isLoading: query.isLoading,
        isError: query.isError,
        error: query.error,
        isSuccess: query.isSuccess,
        refetch: query.refetch,
        isFetching: query.isFetching,
    };
};


interface CreateTagRequest {
    tagName: string;
    adminDetails: {
        adminId: string;
        adminName: string;
        adminEmail: string;
        adminRole: string;
    };
}

export const useCreateTags = () => {
    const queryClient = useQueryClient();

    const createTagApiRequest = async (tagData: CreateTagRequest): Promise<Tag> => {
        try {
            const response = await apiClient.post('/products/create-tag', tagData);

            if (!response.data.success) {
                throw new Error(response.data.message || 'Failed to create tag');
            }

            toast.success(response.data.message || 'Tag created successfully');
            return response.data.data;
        } catch (error) {
            const axiosError = error as AxiosError<{ success: boolean; message: string }>;
            console.error('Create tag error:', {
                status: axiosError.response?.status,
                message: axiosError.response?.data?.message || axiosError.message,
                error: axiosError
            });

            const errorMessage =
                axiosError.response?.status === 400 ? 'Invalid tag data' :
                    axiosError.response?.status === 401 ? 'Unauthorized access' :
                        axiosError.response?.status === 403 ? 'Access forbidden' :
                            axiosError.response?.data?.message || 'Failed to create tag';

            toast.error(errorMessage);
            throw error;
        }
    };

    const mutation = useMutation({
        mutationFn: createTagApiRequest,
        onMutate: async (newTag) => {
            // Cancel any outgoing refetches
            await queryClient.cancelQueries({ queryKey: ['tags'] });

            // Snapshot the previous value
            const previousTags = queryClient.getQueryData<GetAllTagsResponse>(['tags']);

            // Optimistically update to the new value
            if (previousTags) {
                queryClient.setQueryData<GetAllTagsResponse>(['tags'], {
                    ...previousTags,
                    data: {
                        ...previousTags.data,
                        tags: [
                            {
                                id: 'temp-id',
                                tagName: newTag.tagName,
                                createdAt: new Date().toISOString(),
                                updatedAt: new Date().toISOString(),
                                adminDetails: newTag.adminDetails,
                            },
                            ...previousTags.data.tags,
                        ],
                        pagination: {
                            ...previousTags.data.pagination,
                            total: previousTags.data.pagination.total + 1,
                        },
                    },
                });
            }

            return { previousTags };
        },
        onError: (err, _, context) => {
            // Rollback on error
            if (context?.previousTags) {
                queryClient.setQueryData(['tags'], context.previousTags);
            }
            console.error('Create tag error:', err);
        },
        onSettled: () => {
            // Always refetch after error or success
            queryClient.invalidateQueries({
                queryKey: ['tags'],
                exact: false,
            });
        },
    });

    return {
        createTag: mutation.mutate,
        createTagAsync: mutation.mutateAsync,
        isLoading: mutation.isPending,
        isError: mutation.isError,
        isSuccess: mutation.isSuccess,
        error: mutation.error,
    };
};

interface UpdateTagRequest {
    tagId: string;
    tagName: string;
    status: boolean;
    adminDetails: {
        adminId: string;
        adminName: string;
        adminEmail: string;
        adminRole: string;
    };
}

export const useUpdateTags = () => {
    const queryClient = useQueryClient();

    const updateTagApiRequest = async (tagData: UpdateTagRequest): Promise<Tag> => {
        try {
            const response = await apiClient.patch(`/products/update-tag/${tagData.tagId}`, {
                tagName: tagData.tagName,
                status: tagData.status,
                adminDetails: tagData.adminDetails
            });

            if (!response.data.success) {
                throw new Error(response.data.message || 'Failed to update tag');
            }

            toast.success(response.data.message || 'Tag updated successfully');
            return response.data.data;
        } catch (error) {
            const axiosError = error as AxiosError<{ success: boolean; message: string }>;
            console.error('Update tag error:', {
                status: axiosError.response?.status,
                message: axiosError.response?.data?.message || axiosError.message,
                error: axiosError
            });

            const errorMessage =
                axiosError.response?.status === 400 ? 'Invalid tag data' :
                    axiosError.response?.status === 401 ? 'Unauthorized access' :
                        axiosError.response?.status === 404 ? 'Tag not found' :
                            axiosError.response?.data?.message || 'Failed to update tag';

            toast.error(errorMessage);
            throw error;
        }
    };

    const mutation = useMutation({
        mutationFn: updateTagApiRequest,
        onMutate: async (updatedTag) => {
            // Cancel any outgoing refetches
            await queryClient.cancelQueries({ queryKey: ['tags'] });

            // Snapshot the previous value
            const previousTags = queryClient.getQueryData<GetAllTagsResponse>(['tags']);

            // Optimistically update to the new value
            if (previousTags) {
                queryClient.setQueryData<GetAllTagsResponse>(['tags'], {
                    ...previousTags,
                    data: {
                        ...previousTags.data,
                        tags: previousTags.data.tags.map(tag =>
                            tag.id === updatedTag.tagId
                                ? {
                                    ...tag,
                                    tagName: updatedTag.tagName,
                                    status: updatedTag.status ? 'active' : 'inactive',
                                    updatedAt: new Date().toISOString(),
                                }
                                : tag
                        ),
                    },
                });
            }

            return { previousTags };
        },
        onError: (err, _, context) => {
            // Rollback on error
            if (context?.previousTags) {
                queryClient.setQueryData(['tags'], context.previousTags);
            }
            console.error('Update tag error:', err);
        },
        onSettled: () => {
            // Invalidate related queries to ensure consistency
            queryClient.invalidateQueries({
                queryKey: ['tags'],
                exact: false,
            });
        },
    });

    return {
        updateTag: mutation.mutate,
        updateTagAsync: mutation.mutateAsync,
        isLoading: mutation.isPending,
        isError: mutation.isError,
        isSuccess: mutation.isSuccess,
        error: mutation.error,
    };
};


export const useDeleteTags = () => {
    const queryClient = useQueryClient();

    const deleteTagApiRequest = async (tagId: string): Promise<void> => {
        try {
            const response = await apiClient.delete(`/admin/tags/${tagId}`);

            if (!response.data.success) {
                throw new Error(response.data.message || 'Failed to delete tag');
            }

            toast.success(response.data.message || 'Tag deleted successfully');
        } catch (error) {
            const axiosError = error as AxiosError<{ success: boolean; message: string }>;
            console.error('Delete tag error:', {
                status: axiosError.response?.status,
                message: axiosError.response?.data?.message || axiosError.message,
                error: axiosError
            });

            const errorMessage =
                axiosError.response?.status === 400 ? 'Invalid request' :
                    axiosError.response?.status === 401 ? 'Unauthorized access' :
                        axiosError.response?.status === 404 ? 'Tag not found' :
                            axiosError.response?.data?.message || 'Failed to delete tag';

            toast.error(errorMessage);
            throw error;
        }
    };

    const mutation = useMutation({
        mutationFn: deleteTagApiRequest,
        onMutate: async (tagId) => {
            // Cancel any outgoing refetches
            await queryClient.cancelQueries({ queryKey: ['tags'] });

            // Snapshot the previous value
            const previousTags = queryClient.getQueryData<GetAllTagsResponse>(['tags']);

            // Optimistically update to the new value
            if (previousTags) {
                queryClient.setQueryData<GetAllTagsResponse>(['tags'], {
                    ...previousTags,
                    data: {
                        ...previousTags.data,
                        tags: previousTags.data.tags.filter(tag => tag.id !== tagId),
                        pagination: {
                            ...previousTags.data.pagination,
                            total: previousTags.data.pagination.total - 1,
                        },
                    },
                });
            }

            return { previousTags };
        },
        onError: (err, _, context) => {
            // Rollback on error
            if (context?.previousTags) {
                queryClient.setQueryData(['tags'], context.previousTags);
            }
            console.error('Delete tag error:', err);
        },
        onSettled: () => {
            // Invalidate related queries to ensure consistency
            queryClient.invalidateQueries({
                queryKey: ['tags'],
                exact: false,
            });
        },
    });

    return {
        deleteTag: mutation.mutate,
        deleteTagAsync: mutation.mutateAsync,
        isLoading: mutation.isPending,
        isError: mutation.isError,
        isSuccess: mutation.isSuccess,
        error: mutation.error,
    };
};

export const useDeleteCategory = () => {
    const queryClient = useQueryClient();

    const deleteCategoryApiRequest = async (categoryId: string): Promise<void> => {
        try {
            const response = await apiClient.delete(`/admin/categories/${categoryId}`);

            if (!response.data.success) {
                throw new Error(response.data.message || 'Failed to delete category');
            }

            toast.success(response.data.message || 'Category deleted successfully');
        } catch (error) {
            const axiosError = error as AxiosError<{ success: boolean; message: string }>;
            console.error('Delete category error:', {
                status: axiosError.response?.status,
                message: axiosError.response?.data?.message || axiosError.message,
                error: axiosError
            });

            const errorMessage =
                axiosError.response?.status === 400 ? 'Invalid request' :
                    axiosError.response?.status === 401 ? 'Unauthorized access' :
                        axiosError.response?.status === 404 ? 'Category not found' :
                            axiosError.response?.data?.message || 'Failed to delete category';

            toast.error(errorMessage);
            throw error;
        }
    };

    const mutation = useMutation({
        mutationFn: deleteCategoryApiRequest,
        onMutate: async (categoryId) => {
            // Cancel any outgoing refetches
            await queryClient.cancelQueries({ queryKey: ['categories'] });

            // Snapshot the previous value
            const previousCategories = queryClient.getQueryData(['categories']);

            // Optimistically update to the new value
            if (previousCategories) {
                queryClient.setQueryData(['categories'], (old: any) => ({
                    ...old,
                    data: {
                        ...old.data,
                        categories: old.data.categories.filter(
                            (category: any) => category.id !== categoryId
                        ),
                        pagination: {
                            ...old.data.pagination,
                            total: old.data.pagination.total - 1,
                        },
                    },
                }));
            }

            return { previousCategories };
        },
        onError: (err, _, context) => {
            // Rollback on error
            if (context?.previousCategories) {
                queryClient.setQueryData(['categories'], context.previousCategories);
            }
            console.error('Delete category error:', err);
        },
        onSettled: () => {
            // Invalidate related queries to ensure consistency
            queryClient.invalidateQueries({
                queryKey: ['categories'],
                exact: false,
            });
        },
    });

    return {
        deleteCategory: mutation.mutate,
        deleteCategoryAsync: mutation.mutateAsync,
        isLoading: mutation.isPending,
        isError: mutation.isError,
        isSuccess: mutation.isSuccess,
        error: mutation.error,
    };
};