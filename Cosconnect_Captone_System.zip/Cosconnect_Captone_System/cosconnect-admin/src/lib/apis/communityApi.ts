import { toast } from "sonner";
import { axiosApiClient } from "./axiosApiClient";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import axios from "axios";

// ============================================================================
// REACT QUERY HOOK — Get My Posts by user_id and user_role
// ============================================================================
export const useGetMyPosts = (user_id: string, user_role: string) => {
    const {
        data: myPosts,
        isLoading,
        isFetching,
        isError,
        error,
        refetch,
    } = useQuery<any>({
        queryKey: ["my-posts", user_id, user_role], // ✅ dynamic caching per user

        queryFn: async (): Promise<any> => {
            const response = await axiosApiClient.get<any>(
                `/community/my-posts`,
                {
                    params: { user_id, user_role }, // ✅ pass as query params
                }
            )
            return response.data
        },

        enabled: !!user_id, // ✅ only run when user_id is available
        staleTime: 1000 * 60 * 2, // cache valid for 2 minutes
        retry: 2, // retry failed requests twice
        refetchOnWindowFocus: false, // don't refetch on tab focus


    })

    return {
        myPosts,
        isLoading,
        isFetching,
        isError,
        error,
        refetch,
    }
}

interface GetAllPostsParams {
    limit?: number;
    page?: number;
    search?: string;
    onlyForSale?: boolean;
    postId?: string;
    user_id?: string;
    user_role?: string;
}

export const useGetAllPosts = (params?: GetAllPostsParams) => {

    const fetchAllPosts = async (): Promise<any> => {
        const queryParams = new URLSearchParams();

        if (params?.limit) queryParams.append("limit", params.limit.toString());
        if (params?.page) queryParams.append("page", params.page.toString());
        if (params?.search?.trim()) queryParams.append("search", params.search.trim());
        if (params?.onlyForSale) queryParams.append("onlyForSale", "true");
        if (params?.postId) queryParams.append("postId", params.postId);
        if (params?.user_id) queryParams.append("user_id", params.user_id);
        if (params?.user_role) queryParams.append("user_role", params.user_role);

        const url = `/community/get-all-posts${queryParams.toString() ? "?" + queryParams.toString() : ""
            }`;

        try {
            const response = await axiosApiClient.get<any>(url);
            return response.data;
        } catch (error: any) {
            const message = error?.response?.data?.message || "Failed to fetch posts";

            throw new Error(message);
        }
    };

    const query = useQuery<any>({
        queryKey: ["community-all-posts", params],
        queryFn: fetchAllPosts,
        staleTime: 60 * 1000, // 1 minute
        refetchOnWindowFocus: false,
        retry: 2,
    });

    return {
        isLoading: query.isLoading,
        allPosts: query.data?.data ?? [],
        pagination: query.data?.pagination,
        error: query.error,
        refetch: query.refetch,
        isFetching: query.isFetching,
        isRefetching: query.isRefetching,
    };
};

export interface ReportPostPayload {
    post_id: string;
    user_id: string;
    reason: string;
    details?: string;
}

export const useReportPost = () => {
    const reportPostApiRequest = async (payload: ReportPostPayload): Promise<any> => {
        console.log("Reporting Post Payload:", payload);
        const response = await axiosApiClient.post<any>("/community/report-post", payload);
        return response.data;
    };

    return useMutation({
        mutationFn: reportPostApiRequest,
        onError: (error: unknown) => {
            let message = "Failed to report post";
            console.error(error);
            if (axios.isAxiosError(error)) {
                message = error.response?.data?.message || message;
            }
            toast.error(message);
        },
        retry: 0,
        retryDelay: 0,
    });
};


export const useLikePost = () => {
    const likePostApiRequest = async (payload: any): Promise<any> => {
        const response = await axiosApiClient.put<any>("/community/like-post", payload)
        toast.success(response.data.message || "Post updated successfully")
        return response.data
    }

    return useMutation({
        mutationFn: likePostApiRequest,
        onError: (error: unknown) => {
            let message = "Failed to like/unlike post"
            console.log(error)
            if (axios.isAxiosError(error)) {
                message = error.response?.data?.message || message
            }
            toast.error(message)
        },
        retry: 0,
        retryDelay: 0
    })
}


export interface CommentAuthor {
    user_id: string;
    username: string;
    avatar?: string;
    role?: string;
}

export interface CommentData {
    post_id: string;
    parent_comment_id: string | null;
    content: string;
    images?: string[];
    commenter: CommentAuthor;
}

export interface CommentResponse {
    id: string;
    post_id: string;
    content: string;
    images: string[];
    commenter: CommentAuthor;
    created_at: string;
    updated_at: string;
    likes: number;
    is_liked: boolean;
    reply_count: number;
}

export const useCreatePost = () => {
    const createPostApiRequest = async (data: any): Promise<any> => {
        console.log(data)
        try {
            console.log('Creating post with data:', data);
            const response = await axiosApiClient.post<any>('/community/create-post', data);
            toast.success("Post created successfully");
            return response.data;
        } catch (error: unknown) {
            let errorMessage = "Failed to create post";

            // Log the full error for debugging
            console.error('Error creating post:', error);

            if (axios.isAxiosError(error)) {
                // Handle Axios specific errors
                if (error.response) {
                    // Server responded with a status code outside 2xx
                    errorMessage = error.response.data?.message || error.response.statusText || errorMessage;
                    console.error('Server responded with error:', {
                        status: error.response.status,
                        data: error.response.data,
                        headers: error.response.headers
                    });
                } else if (error.request) {
                    // Request was made but no response received
                    errorMessage = "No response received from server. Please check your connection.";
                    console.error('No response received:', error.request);
                } else {
                    // Something happened in setting up the request
                    errorMessage = error.message || errorMessage;
                    console.error('Request setup error:', error.message);
                }
            } else if (error instanceof Error) {
                // Handle other types of errors
                errorMessage = error.message;
            }

            toast.error(errorMessage);
            throw new Error(errorMessage, { cause: error });
        }
    };

    const mutation = useMutation<any, Error, any>({
        mutationFn: createPostApiRequest
    });

    return {
        createPost: mutation.mutateAsync,
        isLoading: mutation.isPending,
        isError: mutation.isError,
        error: mutation.error
    };
};


// ✅ Comment on Post
export const useCommentOnPost = () => {
    const commentOnPostApiRequest = async (data: any): Promise<any> => {
        try {
            const response = await axiosApiClient.post<any>('/community/comment-on-post', data);

            return response.data;
        } catch (error: any) {
            console.log("error", error)
            let message = "Failed to post comment";

            if (axios.isAxiosError(error)) {
                // Handle Axios error
                if (error.response?.data) {
                    // Try to get error message from response data
                    const errorData = error.response.data as any;
                    message = errorData.message || errorData.error?.message || message;

                    // Handle validation errors
                    if (error.response.status === 400 && errorData.errors) {
                        message = Object.values(errorData.errors as Record<string, string[]>)
                            .flat()
                            .join('\n');
                    }
                } else if (error.request) {
                    // The request was made but no response was received
                    message = "No response from server. Please check your connection.";
                } else {
                    // Something happened in setting up the request
                    message = error.message || message;
                }
            } else if (error instanceof Error) {
                // Handle standard Error
                message = error.message;
            }

            toast.error(message);
            throw new Error(message);
        }
    };

    const mutation = useMutation<any, Error, any>({
        mutationFn: commentOnPostApiRequest,
        // Optional: Add optimistic updates here if needed
        onError: (error) => {
            console.error('Comment submission error:', error);
        }
    });

    return {
        commentOnPost: mutation.mutateAsync,
        isLoading: mutation.isPending,
        isError: mutation.isError,
        error: mutation.error,
        reset: mutation.reset
    };
};


export interface Comment {
    id: string;
    post_id: string;
    parent_comment_id: string | null;
    author_id: string;
    author_name: string;
    author_role: string;
    author_avatar: string;
    content: string;
    images: string[];
    created_at: string; // ISO string
    updated_at: string; // ISO string
    reply_count: string; // backend sends as string
}

export interface GetCommentsResponse {
    success: boolean;
    data: Comment[];
    nextCursor: string | null;
    hasMore: boolean;
    message: string;
}

export const useGetCommentsOnPost = (
    params: { post_id: string; limit?: number; cursor?: string }
) => {
    const fetchComments = async (): Promise<GetCommentsResponse> => {
        try {
            const queryParams = new URLSearchParams();
            queryParams.append("post_id", params.post_id);

            if (params.limit) queryParams.append("limit", params.limit.toString());
            if (params.cursor) queryParams.append("cursor", params.cursor);

            const response = await axiosApiClient.get<GetCommentsResponse>(
                `/community/get-comments-on-post/${params.post_id}?${queryParams.toString()}`
            );

            return response.data;
        } catch (error) {
            let message = "Failed to fetch comments";

            if (axios.isAxiosError(error)) {
                if (error.response?.data?.message) {
                    message = error.response.data.message;
                }
            }
            throw error;
        }
    };

    const query = useQuery<GetCommentsResponse, Error>({
        queryKey: ["community-comments", params],
        queryFn: fetchComments,
        staleTime: 60_000,
        refetchOnWindowFocus: false,
        enabled: Boolean(params.post_id),
    });

    return {
        isLoading: query.isLoading,
        comments: query.data?.data ?? [],
        error: query.error,
        nextCursor: query.data?.nextCursor ?? null,
        hasMore: query.data?.hasMore ?? false,
        refetch: query.refetch,
        isRefetching: query.isRefetching,
    };
};




interface DeletePostResponse {
    success: boolean;
    message: string;
    data?: { id: string };
}

interface UpdatePostResponse {
    success: boolean;
    message: string;
    data?: any;
}

interface DeletePostParams {
    postId: string;
    author_id: string;
}

interface UpdatePostParams {
    postId: string;
    content?: string;
    images?: string[];
    is_for_sale?: boolean;
}

export const useDeleteCommunityPost = () => {
    const queryClient = useQueryClient();

    return useMutation<DeletePostResponse, unknown, DeletePostParams>({
        mutationFn: async ({ postId, author_id }: DeletePostParams) => {
            const response = await axiosApiClient.delete<DeletePostResponse>(
                `/community/delete-post/${postId}`,
                { data: { author_id } } // Send author_id in request body
            );
            return response.data;
        },
        onSuccess: (data) => {
            toast.success(data.message || "Post deleted successfully");
            queryClient.invalidateQueries({ queryKey: ["community-posts"] });
        },
        onError: (error: any) => {
            const message =
                error.response?.data?.message || "Failed to delete community post";
            toast.error(message);
        },
    });
};

export const useUpdateMyPost = () => {
    const queryClient = useQueryClient();

    return useMutation<UpdatePostResponse, unknown, UpdatePostParams>({
        mutationFn: async ({ postId, ...updateData }: UpdatePostParams) => {
            const response = await axiosApiClient.put<UpdatePostResponse>(
                `/community/update-my-post/${postId}`,
                updateData
            );
            return response.data;
        },
        onSuccess: (data) => {
            toast.success(data.message || "Post updated successfully");
            queryClient.invalidateQueries({ queryKey: ["community-posts"] });
        },
        onError: (error: any) => {
            const message =
                error.response?.data?.message || "Failed to update community post";
            toast.error(message);
        },
    });
};

export interface PostPayload {
    id: string;
    timestamp: string; // ISO 8601 date string
}

export const useDeleteMyComment = () => {
    const queryClient = useQueryClient();

    const deleteMyCommentApiRequest = async (
        payload: Pick<PostPayload, "id">
    ): Promise<{ success: boolean; message: string }> => {
        try {

            // ✅ axios.delete requires `data` inside config
            const response = await axiosApiClient.delete(`/community/delete-my-comment/${payload.id}`);

            return response.data;
        } catch (error: any) {
            console.error("❌ Error deleting comment:", error);
            const message =
                error.response?.data?.message || "Failed to delete comment";
            throw new Error(message);
        }
    };

    const mutation = useMutation({
        mutationFn: deleteMyCommentApiRequest,
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ["comments"] });

        },
        onError: (error: Error) => {
            console.error("Error deleting comment:", error);

        },
    });

    return {
        deleteMyComment: mutation.mutateAsync,
        isDeleting: mutation.isPending,
        error: mutation.error?.message,
    };
};



// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

interface ReportMetadata {
    currentStatus: string
    postCreatedAt: string
    reportCreatedAt: string
}

interface SendWarningPayload {
    adminAction: 'warning'
    postAuthorId: string
    postAuthorName: string
    postContent: string
    postId: string
    reason: string
    reportId: string
    reporterId: string
    reporterUsername: string
    timestamp: string
    metadata?: ReportMetadata
}

interface BlockUserPayload {
    adminAction: 'approved' | 'rejected'
    postAuthorId: string
    postAuthorName: string
    postContent: string
    postId: string
    reason: string
    reportId: string
    reporterId: string
    reporterUsername: string
    timestamp: string
    metadata?: ReportMetadata
}

interface ApiResponse {
    success: boolean
    message: string
    data?: any
    error?: string
}

// ============================================================================
// API HOOKS
// ============================================================================

/**
 * Hook for sending warning email to user
 * Endpoint: PATCH /user/warning-block
 */
export const useSendWarningBlockAccountUser = () => {
    const sendWarningBlockAccountUser = async (payload: SendWarningPayload): Promise<ApiResponse> => {
        try {
            const response = await axiosApiClient.post("/admin/user/warning-block", payload)
            return response.data
        } catch (error: any) {
            console.error('Error sending warning to user:', error)
            throw new Error(error.response?.data?.message || 'Failed to send warning to user')
        }
    }

    const mutation = useMutation({
        mutationFn: (payload: SendWarningPayload) => sendWarningBlockAccountUser(payload),
        onSuccess: (data) => {
            console.log('Warning sent successfully:', data)
        },
        onError: (error: any) => {
            console.error('Failed to send warning:', error.message)
        },
    })

    return {
        isSending: mutation.isPending,
        isSuccess: mutation.isSuccess,
        isError: mutation.isError,
        error: mutation.error,
        data: mutation.data,
        sendWarning: mutation.mutate,
        sendWarningAsync: mutation.mutateAsync,
    }
}

/**
 * Hook for blocking/suspending user account
 * Endpoint: PATCH /user/update-account-status
 */
export const useUpdateUserAccountStatus = () => {
    const updateUserAccountStatus = async (payload: BlockUserPayload): Promise<ApiResponse> => {
        try {
            const response = await axiosApiClient.patch("/user/update-account-status", payload)
            return response.data
        } catch (error: any) {
            console.error('Error updating user account status:', error)
            throw new Error(error.response?.data?.message || 'Failed to update user account status')
        }
    }

    const mutation = useMutation({
        mutationFn: (payload: BlockUserPayload) => updateUserAccountStatus(payload),
        onSuccess: (data) => {
            console.log('User account status updated successfully:', data)
        },
        onError: (error: any) => {
            console.error('Failed to update user account status:', error.message)
        },
    })

    return {
        isUpdating: mutation.isPending,
        isSuccess: mutation.isSuccess,
        isError: mutation.isError,
        error: mutation.error,
        data: mutation.data,
        blockUser: mutation.mutate,
        blockUserAsync: mutation.mutateAsync,
    }
}
export const useApprovedReportRemovePost = () => {
    return useMutation({
        mutationFn: (payload: any) => approvedReportRemovePost(payload),
        onSuccess: (data) => {
            console.log('✅ Post successfully removed:', data)
        },
        onError: (error: any) => {
            console.error('❌ Failed to remove post:', error.message)
        },
    })
}

// API call function
export const approvedReportRemovePost = async (payload: any) => {
    try {
        const response = await axiosApiClient.put('/community/approve-report-post', payload)
        return response.data
    } catch (error: any) {
        console.error('Error approving reported post:', error)
        throw new Error(error.response?.data?.message || 'Failed to approve reported post')
    }
}



interface UseGetAllPostReportsParams {
    page?: number;
    limit?: number;
    status?: string;
    sortBy?: string;
}

export const useGetAllPostReports = (params: UseGetAllPostReportsParams = {}) => {
    const { page = 1, limit = 10, status = 'all', sortBy = 'created_at' } = params;

    // --- API request function ---
    const getAllPostReportsApiRequest = async (): Promise<any> => {
        const response = await axiosApiClient.get<any>(
            `/community/get-all-report-posts`,
            {
                params: {
                    page,
                    limit,
                    status: status === 'all' ? undefined : status,
                    sortBy
                }
            }
        );
        console.log("Full response:", response.data);
        return response.data;
    };

    // --- React Query hook ---
    const query = useQuery({
        queryKey: ['post-reports', page, limit, status, sortBy],
        queryFn: getAllPostReportsApiRequest,
        staleTime: 5 * 60 * 1000, // 5 minutes
        gcTime: 10 * 60 * 1000,   // 10 minutes
        retry: (failureCount, error: any) => {
            if (error instanceof Error && error.message.includes('401')) return false;
            if (error instanceof Error && error.message.includes('403')) return false;
            return failureCount < 3;
        },
        retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
    });

    return {
        isLoading: query.isLoading,
        isError: query.isError,
        error: query.error,
        data: query.data?.data,
        fullResponse: query.data,
        refetch: query.refetch,
    };
};