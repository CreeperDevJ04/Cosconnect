import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { axiosApiClient } from "./axiosApiClient";
import { AdminGetAllRentalsResponse } from "@/types/rentals/getRentalsFinished";
import { toast } from "sonner";
import { TransactionApiResponse } from "@/types/transactions";

// 🪝 Custom hook
export const useGetTransactionsRentals = () => {
    // ✅ API Request Function
    const getTransactionRentalsApiRequest = async (): Promise<TransactionApiResponse> => {
        try {
            const { data } = await axiosApiClient.get<TransactionApiResponse>("/rental/transactions");
            return data;
        } catch (error: any) {
            const message =
                error?.response?.data?.message || "Failed to fetch transactions. Please try again.";
            toast.error(message);
            throw new Error(message);
        }
    };

    // ✅ React Query setup
    const query = useQuery({
        queryKey: ["rentalTransactions"], // unique key for caching
        queryFn: getTransactionRentalsApiRequest,
        staleTime: 1000 * 60 * 5, // cache data for 5 minutes
        refetchOnWindowFocus: false, // avoid refetching on tab focus for smoother UX
        retry: 2, // retry failed requests up to 2 times
    });

    return {
        transactions: query.data?.data.transactions || [],
        pagination: query.data?.data.pagination,
        filters: query.data?.data.filters,
        isLoading: query.isLoading,
        isError: query.isError,
        refetch: query.refetch,
    };
};

type Params = {
    page: number;
    limit: number;
};

export const useAdminGetAllRentalsIfFinished = ({ page, limit }: Params) => {
    const query = useQuery<AdminGetAllRentalsResponse>({
        queryKey: ["all-rentals-if-finished", page, limit],
        queryFn: async () => {
            const response = await axiosApiClient.get<AdminGetAllRentalsResponse>(
                "/accounting/all-rentals",
                { params: { page, limit } }
            );
            return response.data;
        },
        staleTime: 1000 * 60 * 5,
        refetchOnWindowFocus: false,
    });

    return {
        isFetching: query.isPending,
        rentalsFinished: query.data,
        isError: query.isError,
    };
};

// Shared request base
interface TransferMoneyBaseRequest {
    rentalId: string;
    amount: number;
    gcashNumber: string;
    accountName: string;
    notes?: string;
}


// Borrower refund request
interface TransferMoneyBorrowerRequest extends TransferMoneyBaseRequest {
    borrowerId: string;
    type: "refund";
}


// Lender payout request
interface TransferMoneyLenderRequest extends TransferMoneyBaseRequest {
    lenderId: string;
    type: "payout";
}


export const useTransferMoneyBorrower = () => {
    const mutation = useMutation({
        mutationFn: async (data: TransferMoneyBorrowerRequest) => {
            const payload = {
                rentalId: data.rentalId,
                amount: data.amount,
                gcashNumber: data.gcashNumber,
                accountName: data.accountName,
                notes: data.notes,
                borrowerId: data.borrowerId,
                type: data.type,
            };


            const response = await axiosApiClient.post(
                "/accounting/transfer-money-borrower",
                payload,
                { headers: { "Content-Type": "application/json" } }
            );


            return response.data;
        },
        onSuccess: () => {
            toast.success("Refund processed successfully!");
        },
        onError: () => {
            toast.error("Failed to process refund");
        },
    });


    return {
        isPending: mutation.isPending,
        isError: mutation.isError,
        mutate: mutation.mutate,
    };
};


export const useTransferMoneyLender = () => {
    const queryClient = useQueryClient();
    const mutation = useMutation({
        mutationFn: async (data: TransferMoneyLenderRequest) => {
            const payload = {
                rentalId: data.rentalId,
                lenderId: data.lenderId,
                amount: data.amount,
                gcashNumber: data.gcashNumber,
                accountName: data.accountName,
                notes: data.notes,
                type: data.type,
            };


            const response = await axiosApiClient.post(
                "/accounting/transfer-money-lender",
                payload,
                { headers: { "Content-Type": "application/json" } }
            );


            return response.data;
        },
        onSuccess: () => {
            toast.success("Payout processed successfully!");
            queryClient.invalidateQueries({ queryKey: ["analytics"] });
        },
        onError: () => {
            toast.error("Failed to process payout");
            queryClient.invalidateQueries({ queryKey: ["analytics"] });
        },
    });


    return {
        isPending: mutation.isPending,
        isError: mutation.isError,
        mutate: mutation.mutate,
    };
};
