// This hook is now integrated into useSupabaseAuth, but here's a standalone version if needed

import { DeleteUserByIdParams, DeleteUsersByBulkIdsParams, SuspendUserAccountParams, UpdateUserStatusParams } from '@/types/adminType';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import axios from 'axios';
import ky from 'ky';
import { toast } from 'sonner';
const API_BASE_URL = 'http://localhost:8000/api/v1';


export interface AdminResponse {
    message: string;
    status: 'success' | 'error';
    statusCode: number;
    data: any;
}

export const useGetAdminDataById = (id: string | null, enabled: boolean = true) => {
    console.log("idddd", id)
    return useQuery<any>({

        queryKey: ["admin", id],
        queryFn: async () => {
            if (!id) throw new Error("Admin ID is required");

            try {
                const response = await axiosApiClient.get<AdminResponse>(
                    `${API_BASE_URL}/admin/${id}`
                );

                const data = response.data;
                if (data.status === "success") {
                    return data.data;
                }

                throw new Error(data.message || "Failed to fetch admin data");
            } catch (error: any) {
                const message =
                    error?.response?.data?.message || error.message || "Error fetching admin data";
                toast.error(message);
                throw new Error(message);
            }
        },
        enabled: !!id && enabled,
        staleTime: 5 * 60 * 1000, // 5 minutes
        gcTime: 10 * 60 * 1000, // 10 minutes
        retry: (failureCount, error) => {
            if (error instanceof Error && error.message.includes("401")) return false;
            if (error instanceof Error && error.message.includes("403")) return false;
            return failureCount < 3;
        },
        retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
    });
};

// Updated types based on your JSON response
export interface UserResponse {
    message: string;
    status: 'success' | 'error';
    statusCode: number;
    data: User[] | null;
    pagination: Pagination | null;
}

export interface User {
    uid: string;
    id: string;
    username: string;
    email: string;
    phone_number: string;
    full_name: string | null;
    first_name: string | null;
    middle_name: string | null;
    last_name: string | null;
    bio: string | null;
    profile_image: string | null;
    profile_background: string | null;
    role: string[];
    current_role: string | null;
    status: 'active' | 'inactive' | 'suspended' | 'pending_verification' | 'verified' | 'rejected';
    is_online: boolean | null;
    rejected_message: string | null;
    suspended_message: string | null;
    email_verified: boolean | null;
    phone_verified: boolean | null;
    last_seen: string | null;
    last_account_status_email_sent: number | null;
    reset_token: string | null;
    reset_token_expiry: string | null;
    created_at: string;
    updated_at: string;
}

export interface Pagination {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
    hasNextPage: boolean;
    hasPrevPage: boolean;
}

interface UseGetAllUsersCreatedParams {
    page?: number;
    limit?: number;
    enabled?: boolean;
}

export const useGetAllUsersCreated = (params: UseGetAllUsersCreatedParams = {}) => {
    const {
        page = 1,
        limit = 10,
        enabled = true
    } = params

    const getAllUsersCreatedApiRequest = async (): Promise<UserResponse> => {
        try {
            const response = await ky.get(`${API_BASE_URL}/admin/all/users`, {
                searchParams: {
                    page: page.toString(),
                    limit: limit.toString(),
                },
                timeout: 10000, // 10 second timeout
            }).json<UserResponse>()

            return response
        } catch (error: any) {
            console.error("Error fetching users:", error)
            throw error
        }
    }

    const query = useQuery({
        queryKey: ['all-users-created', page, limit],
        queryFn: getAllUsersCreatedApiRequest,
        staleTime: 1000 * 60 * 5, // 5 minutes
        refetchOnWindowFocus: false,
        enabled,
        retry: 3,
        retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000), // Exponential backoff
    })

    return {
        // Raw response
        data: query.data,

        // Convenient accessors
        users: query.data?.data || [],
        pagination: query.data?.pagination,

        // Query states
        isLoading: query.isLoading,
        isError: query.isError,
        error: query.error,
        refetch: query.refetch,
        isFetching: query.isFetching,
        isRefetching: query.isRefetching,

        // Response metadata
        message: query.data?.message,
        status: query.data?.status,
        statusCode: query.data?.statusCode,
    }
}

// Optional: Hook for pagination controls with state management
import { useState } from 'react';
import { axiosApiClient } from './axiosApiClient';

export const useUsersPagination = (initialPage = 1, initialLimit = 10) => {
    const [page, setPage] = useState(initialPage)
    const [limit, setLimit] = useState(initialLimit)

    const {
        data,
        users,
        pagination,
        isLoading,
        isError,
        error,
        refetch,
        isFetching,
        isRefetching,
        message,
        status,
        statusCode
    } = useGetAllUsersCreated({ page, limit })

    const goToPage = (newPage: number) => {
        if (newPage >= 1 && newPage <= (pagination?.totalPages || 1)) {
            setPage(newPage)
        }
    }

    const goToNextPage = () => {
        if (pagination?.hasNextPage) {
            setPage(prev => prev + 1)
        }
    }

    const goToPrevPage = () => {
        if (pagination?.hasPrevPage) {
            setPage(prev => prev - 1)
        }
    }

    const changeLimit = (newLimit: number) => {
        setLimit(newLimit)
        setPage(1) // Reset to first page when changing limit
    }

    return {
        // Data
        data,
        users,
        pagination,
        message,
        status,
        statusCode,

        // Loading states
        isLoading,
        isError,
        error,
        isFetching,
        isRefetching,

        // Pagination controls
        page,
        limit,
        goToPage,
        goToNextPage,
        goToPrevPage,
        changeLimit,
        refetch,

        // Helper computed values
        hasData: users.length > 0,
        isEmpty: !isLoading && users.length === 0,
        totalUsers: pagination?.total || 0,
        currentPageUsers: users.length,
    }
}


export const useUpdateUserStatus = () => {
    const queryClient = useQueryClient();
    const updateUserStatusApiRequest = async (params: UpdateUserStatusParams & { adminId: string }) => {
        try {
            const { userId, status, adminId } = params;

            console.log("params", params)

            const response = await axios.patch(`${API_BASE_URL}/admin/user/${userId}`, {
                status,
                adminId
            });
            return { ...response.data, userId, status, adminId };
        } catch (error) {
            console.log("error", error)
            console.error('[useUpdateUserStatus] API request failed:', {
                error: error instanceof Error ? error.message : error,
                params,
                timestamp: new Date().toISOString(),
            });
            throw error;
        }
    };

    const mutation = useMutation({
        mutationFn: updateUserStatusApiRequest,
        onError: (error: Error) => {

            console.error('[useUpdateUserStatus] Mutation failed:', {
                error: error.message,
                timestamp: new Date().toISOString(),
            });
        },
        onSuccess: (data, variables) => {

            queryClient.invalidateQueries({ queryKey: ['all-users-created'] });

            console.log('[useUpdateUserStatus] Success:', {
                data,
                timestamp: new Date().toISOString(),
            });
        },
    });

    return {
        isLoading: mutation.isPending,
        mutateAsync: mutation.mutateAsync,
        isSuccess: mutation.isSuccess,
        isError: mutation.isError,
        error: mutation.error,
    };
};

export const useDeleteUserById = () => {
    const queryClient = useQueryClient();
    const deleteUserByIdApiRequest = async (params: DeleteUserByIdParams & { adminId: string }) => {
        try {
            const { userId, adminId } = params;
            const response = await axios.delete(`${API_BASE_URL}/admin/user/delete/${userId}`, {
                params: { adminId }
            });
            return response.data;
        } catch (error) {
            console.log("error", error)
            console.error('[useDeleteUserById] API request failed:', {
                error: error instanceof Error ? error.message : error,
                params,
                timestamp: new Date().toISOString(),
            });
            throw error;
        }
    };

    const mutation = useMutation({
        mutationFn: deleteUserByIdApiRequest,
        onError: (error: Error) => {
            toast.error(error.message || 'Failed to delete user');
            console.error('[useDeleteUserById] Mutation failed:', {
                error: error.message,
                timestamp: new Date().toISOString(),
            });
        },
        onSuccess: (data) => {
            queryClient.invalidateQueries({ queryKey: ['all-users-created'] });
            toast.success('User deleted successfully');
            console.log('[useDeleteUserById] Success:', {
                data,
                timestamp: new Date().toISOString(),
            });
        },
    });

    return {
        isLoading: mutation.isPending,
        mutateAsync: mutation.mutateAsync,
        isSuccess: mutation.isSuccess,
        isError: mutation.isError,
        error: mutation.error,
    };
};

export const useDeleteUsersByBulkIds = () => {
    const queryClient = useQueryClient();
    const deleteUsersByBulkIdsApiRequest = async (params: DeleteUsersByBulkIdsParams & { adminId: string }) => {
        try {
            const { userIds, adminId } = params;
            const response = await axios.delete(`${API_BASE_URL}/admin/users/bulk-delete`, {
                data: { userIds, adminId }
            });
            return response.data;
        } catch (error) {
            console.error('[useDeleteUsersByBulkIds] API request failed:', {
                error: error instanceof Error ? error.message : error,
                params,
                timestamp: new Date().toISOString(),
            });
            throw error;
        }
    };

    const mutation = useMutation({
        mutationFn: deleteUsersByBulkIdsApiRequest,
        onError: (error: Error) => {
            toast.error(error.message || 'Failed to delete users');
            console.error('[useDeleteUsersByBulkIds] Mutation failed:', {
                error: error.message,
                timestamp: new Date().toISOString(),
            });
        },
        onSuccess: (data, variables) => {
            queryClient.invalidateQueries({ queryKey: ['all-users-created'] });
            toast.success(`${variables.userIds.length} users deleted successfully`);
            console.log('[useDeleteUsersByBulkIds] Success:', {
                data,
                variables,
                timestamp: new Date().toISOString(),
            });
        },
    });

    return {
        isLoading: mutation.isPending,
        mutateAsync: mutation.mutateAsync,
        isSuccess: mutation.isSuccess,
        isError: mutation.isError,
        error: mutation.error,
    };
};

export const useSuspendUserAccount = () => {
    const suspendUserAccountApiRequest = async (params: SuspendUserAccountParams) => {
        try {
            const { userId, message } = params;
            const response = await axios.put(`${API_BASE_URL}/users/${userId}/suspend`, { message });
            return response.data;
        } catch (error) {
            console.error('[useSuspendUserAccount] API request failed:', {
                error: error instanceof Error ? error.message : error,
                params,
                timestamp: new Date().toISOString(),
            });
            throw error;
        }
    };

    const mutation = useMutation({
        mutationFn: suspendUserAccountApiRequest,
        onError: (error: Error) => {
            console.error('[useSuspendUserAccount] Mutation failed:', {
                error: error.message,
                timestamp: new Date().toISOString(),
            });
        },
        onSuccess: (data) => {
            console.log('[useSuspendUserAccount] Success:', {
                data,
                timestamp: new Date().toISOString(),
            });
        },
    });

    return {
        isLoading: mutation.isPending,
        mutateAsync: mutation.mutateAsync,
        isSuccess: mutation.isSuccess,
        isError: mutation.isError,
        error: mutation.error,
    };
};

type AdminPayload = {
    id: string;
    full_name: string;
    username: string;
    email: string;
    phone_number: string;
    profile_image: string;
    role: "admin";
    updated_at: string;
};

export const useUpdateUserDocumentStatus = () => {
    const queryClient = useQueryClient();
    const updateUserDocumentStatusApiRequest = async (params: {
        userId: string;
        documentType: string;
        adminId: string;
    }) => {
        try {
            const { userId, documentType, adminId } = params;
            const response = await axios.patch(`${API_BASE_URL}/admin/user/${userId}/document/${documentType}/verify`, {
                adminId
            });
            return { ...response.data, userId, documentType, adminId };
        } catch (error) {
            console.error('[useUpdateUserDocumentStatus] API request failed:', {
                error: error instanceof Error ? error.message : error,
                params,
                timestamp: new Date().toISOString(),
            });
            throw error;
        }
    };

    const mutation = useMutation({
        mutationFn: updateUserDocumentStatusApiRequest,
        onError: (error: Error) => {
            console.error('[useUpdateUserDocumentStatus] Mutation failed:', {
                error: error.message,
                timestamp: new Date().toISOString(),
            });
        },
        onSuccess: (data, variables) => {
            queryClient.invalidateQueries({ queryKey: ['userDataById'] });
            queryClient.invalidateQueries({ queryKey: ['all-users-created'] });
            console.log('[useUpdateUserDocumentStatus] Success:', {
                data,
                timestamp: new Date().toISOString(),
            });
        },
    });

    return {
        isLoading: mutation.isPending,
        mutateAsync: mutation.mutateAsync,
        isSuccess: mutation.isSuccess,
        isError: mutation.isError,
        error: mutation.error,
    };
};

export const useUpdateAdminInfo = () => {
    const updateAdminInfoApiRequest = async (payload: AdminPayload) => {
        const response = await axiosApiClient.put("/admin/update-info", payload);
        return response.data;
    };

    const mutation = useMutation({
        mutationFn: updateAdminInfoApiRequest,
        onSuccess: () => {
            toast.success("Admin information updated successfully!");
        },
        onError: (error: any) => {
            const message =
                error?.response?.data?.message || "Failed to update admin information.";
            toast.error(message);
        },
    });

    return {
        updateAdminInfo: mutation.mutateAsync,
        isUpdating: mutation.isPending,
        isSuccess: mutation.isSuccess,
        isError: mutation.isError,
        error: mutation.error,
        data: mutation.data,
    };
};

export const useVerifyUserDocument = () => {
    const queryClient = useQueryClient();

    const verifyUserDocumentApiRequest = async (params: {
        userId: string;
        documentType: "VALID_ID" | "SELFIE_WITH_ID";
    }) => {
        const { userId, documentType } = params;
        const response = await axios.patch(`${API_BASE_URL}/admin/user/${userId}/document/${documentType}/verify`);
        return response.data;
    };

    const mutation = useMutation({
        mutationFn: verifyUserDocumentApiRequest,
        onSuccess: (data, variables) => {
            // Invalidate user data queries to refresh the UI
            queryClient.invalidateQueries({ queryKey: ['user-data', variables.userId] });
            queryClient.invalidateQueries({ queryKey: ['all-users-created'] });

            toast.success(`${variables.documentType.replace('_', ' ')} verified successfully!`);
        },
        onError: (error: any) => {
            const message = error?.response?.data?.message || `Failed to verify document`;
            toast.error(message);
        },
    });

    return {
        verifyDocument: mutation.mutateAsync,
        isVerifying: mutation.isPending,
        isSuccess: mutation.isSuccess,
        isError: mutation.isError,
        error: mutation.error,
    };
};