import axios from 'axios';

const API_BASE_URL = "http://localhost:8000/api/v1";

export const axiosApiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// No interceptors for auth token or redirect handling

export interface ApiError {
  response?: {
    data?: {
      message?: string;
      errors?: Record<string, string[]>;
    };
    status?: number;
  };
  message?: string;
}
