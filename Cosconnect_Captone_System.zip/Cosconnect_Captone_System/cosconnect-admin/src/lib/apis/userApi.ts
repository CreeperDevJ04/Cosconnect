import { useQuery } from '@tanstack/react-query';
import { axiosApiClient } from './axiosApiClient';


export type UserResponse = {
    userInfo: {
        uid: string;
        id: string;
        username: string;
        email: string;
        phone_number: string;
        full_name: string;
        first_name: string;
        middle_name: string;
        last_name: string;
        role: string[];
        current_role: string;
        status: string;
        is_online: boolean;
        created_at: string;
        updated_at: string;
    };
    borrowerInfo: {
        addresses: {
            id: string;
            user_uid: string;
            address: string;
            street: string;
            zip_code: string;
            barangay: string;
            province: string;
            region: string;
            country: string;
            city: string;
            is_primary: boolean;
            created_at: string;
            updated_at: string;
        }[];
        documents: {
            id: string;
            user_uid: string;
            document_type: string;
            document_url: string;
            file_url: string;
            status: string;
            verified_at: string;
            created_at: string;
            updated_at: string;
        }[];
    };
    lenderInfo: {
        id: string;
        user_uid: string;
        business_name: string;
        business_description: string;
        business_type: string;
        business_email: string;
        business_phone_number: string;
        business_telephone: string;
        business_profile_image: string;
        business_background_image: string;
        upload_business_permit: string;
        business_permit_file: string;
        upload_dti_certificate: string;
        upload_storefront_photo: string;
        terms_and_conditions: string;
        is_verified: boolean;
        verified_at: string;
        verified_by: string;
        rejection_reason: string | null;
        created_at: string;
        updated_at: string;
        addresses: {
            id: string;
            business_info_id: string;
            business_address: string;
            street: string;
            zip_code: string;
            barangay: string;
            province: string;
            region: string;
            country: string;
            city: string;
            is_primary: boolean;
            created_at: string;
            updated_at: string;
        }[];
    } | null; // lenderInfo might be null for pure borrowers
};

export const useGetUserDataById = (id: string | undefined) => {
    const query = useQuery<UserResponse, Error>({
        queryKey: ['user-data', id],
        queryFn: async () => {
            if (!id) throw new Error('User ID is required');
            const res = await axiosApiClient.get<UserResponse>(`/user/data/${id}`);
            return res.data;
        },
        enabled: !!id, // only run if id is defined
        retry: 1,
    });

    return {
        isLoading: query.isPending,
        data: query.data,
        error: query.error,
        isError: query.isError
    };
};