"use client"

import { useEffect, useState } from "react"
import { useQuery } from "@tanstack/react-query"
import { axiosApiClient } from "./axiosApiClient"
import { toast } from "sonner"
import type { Transaction, TransactionApiResponse } from "@/types/transactions"

interface FilterState {
  status: string | null
  paymentType: string | null
  paymentMethod: string | null
  search: string
  dateFrom: string | null
  dateTo: string | null
}

interface UseGetTransactionsRentalsReturn {
  transactions: Transaction[]
  filteredTransactions: Transaction[]
  filters: FilterState
  setFilters: (filters: Partial<FilterState>) => void
  resetFilters: () => void
  isLoading: boolean
  isError: boolean
  refetch: () => void
  pagination: {
    page: number
    limit: number
    total: number
    totalPages: number
    hasNext: boolean
    hasPrev: boolean
  }
}

const DEFAULT_FILTERS: FilterState = {
  status: null,
  paymentType: null,
  paymentMethod: null,
  search: "",
  dateFrom: null,
  dateTo: null,
}

export const useGetTransactionsRentals = (): UseGetTransactionsRentalsReturn => {
  const [allTransactions, setAllTransactions] = useState<Transaction[]>([])
  const [filters, setFiltersState] = useState<FilterState>(DEFAULT_FILTERS)

  // ✅ API Request Function
  const getTransactionRentalsApiRequest = async (): Promise<TransactionApiResponse> => {
    try {
      const { data } = await axiosApiClient.get<TransactionApiResponse>("/rental/transactions")
      return data
    } catch (error: any) {
      const message = error?.response?.data?.message || "Failed to fetch transactions. Please try again."
      toast.error(message)
      throw new Error(message)
    }
  }

  // ✅ React Query setup - fetch once
  const query = useQuery({
    queryKey: ["rentalTransactions"],
    queryFn: getTransactionRentalsApiRequest,
    staleTime: 1000 * 60 * 5,
    refetchOnWindowFocus: false,
    retry: 2,
  })

  useEffect(() => {
    if (query.data?.data.transactions) {
      setAllTransactions(query.data.data.transactions)
    }
  }, [query.data?.data.transactions])

  const filteredTransactions = allTransactions.filter((transaction) => {
    // Status filter
    if (filters.status && transaction.status !== filters.status) {
      return false
    }

    // Payment type filter
    if (filters.paymentType && transaction.paymentType !== filters.paymentType) {
      return false
    }

    // Payment method filter
    if (filters.paymentMethod && transaction.paymentMethod !== filters.paymentMethod) {
      return false
    }

    // Search filter (searches across multiple fields)
    if (filters.search) {
      const searchLower = filters.search.toLowerCase()
      const searchableText = `
        ${transaction.referenceCode}
        ${transaction.rental?.renterName}
        ${transaction.rental?.costumeName}
        ${transaction.rental?.renterEmail}
      `.toLowerCase()

      if (!searchableText.includes(searchLower)) {
        return false
      }
    }

    // Date range filter
    if (filters.dateFrom) {
      const transactionDate = new Date(transaction.createdAt)
      const fromDate = new Date(filters.dateFrom)
      if (transactionDate < fromDate) {
        return false
      }
    }

    if (filters.dateTo) {
      const transactionDate = new Date(transaction.createdAt)
      const toDate = new Date(filters.dateTo)
      toDate.setHours(23, 59, 59, 999) // Include entire day
      if (transactionDate > toDate) {
        return false
      }
    }

    return true
  })

  const setFilters = (newFilters: Partial<FilterState>) => {
    setFiltersState((prev) => ({ ...prev, ...newFilters }))
  }

  const resetFilters = () => {
    setFiltersState(DEFAULT_FILTERS)
  }

  const totalPages = Math.ceil(filteredTransactions.length / 10)

  return {
    transactions: allTransactions,
    filteredTransactions,
    filters,
    setFilters,
    resetFilters,
    isLoading: query.isLoading,
    isError: query.isError,
    refetch: query.refetch,
    pagination: {
      page: 1,
      limit: 10,
      total: filteredTransactions.length,
      totalPages,
      hasNext: false,
      hasPrev: false,
    },
  }
}
