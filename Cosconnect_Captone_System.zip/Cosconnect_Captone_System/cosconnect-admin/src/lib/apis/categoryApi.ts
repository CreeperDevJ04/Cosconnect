import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import axios, { AxiosError } from 'axios';
import { toast } from 'sonner';
import { encrypt } from '../utils';

// Define base URL for API requests
const API_BASE_URL = 'http://localhost:8000/api/v1';

// Create axios instance with default config
const apiClient = axios.create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json',
    },
});

interface CategoryParams {
    adminId?: string;
    page?: number;
    limit?: number;
}

interface CategoryResponse {
    success: boolean;
    data: {
        categories: Array<{
            categoryId: string;
            categoryName: string;
            status: string;
            costumes?: number;
            customerCount?: number;
        }>;
        pagination: {
            total: number;
            page: number;
            limit: number;
            totalPages: number;
            hasMore: boolean;
        };
    };
}

export const useFetchAllCategories = (params?: CategoryParams) => {
    const fetchAllCategories = async (): Promise<CategoryResponse> => {
        try {
            const response = await apiClient.get(`/products/get-all-categories`, {
                params: {
                    page: params?.page || 1,
                    limit: params?.limit || 10,
                },
            });

            return response.data;
        } catch (error: any) {
            const axiosError = error as any;
            console.error('Category fetch error:', axiosError);
            toast.error(
                axiosError.response?.data?.message ||
                'Failed to fetch categories. Please try again.'
            );
            throw error;
        }
    };

    return useQuery({
        queryKey: ['categories', params],
        queryFn: fetchAllCategories,
        retry: 1,
        staleTime: 5 * 60 * 1000,
        enabled: !!params?.adminId,
    });
};

interface AdminDetails {
    adminId: string;
    adminName: string;
    adminEmail: string;
    adminRole: string;
}

interface CreateCategoryRequest {
    categoryName: string;
    adminDetails: AdminDetails;
}

interface CreateCategoryResponse {
    success: boolean;
    message: string;
    data: {
        categoryId: string;
        categoryName: string;
        createdAt: string;
    };
}

export const useCreateCategory = () => {
    const queryClient = useQueryClient();

    const createCategoryApiRequest = async (categoryData: CreateCategoryRequest): Promise<CreateCategoryResponse> => {
        try {
            const response = await apiClient.post('/products/create-category', categoryData);
            toast.success(response.data.message || 'Category created successfully');
            return response.data;
        } catch (error: any) {
            const axiosError = error as AxiosError<{ success: boolean; message: string }>;
            console.error('Create category error:', {
                status: axiosError.response?.status,
                message: axiosError.response?.data?.message || axiosError.message,
            });
            toast.error(
                axiosError.response?.data?.message ||
                'Failed to create category. Please try again.'
            );
            throw error;
        }
    };

    return useMutation({
        mutationFn: createCategoryApiRequest,
        onSuccess: async (newCategory) => {
            const previousCategories = queryClient.getQueryData<CategoryResponse>(['categories']);

            if (previousCategories) {
                queryClient.setQueryData<CategoryResponse>(['categories'], {
                    success: true,
                    data: {
                        categories: [
                            {
                                categoryId: newCategory.data.categoryId,
                                categoryName: newCategory.data.categoryName,
                                status: 'active',
                                costumes: 0,
                                customerCount: 0,
                            },
                            ...previousCategories.data.categories,
                        ],
                        pagination: {
                            ...previousCategories.data.pagination,
                            total: previousCategories.data.pagination.total + 1,
                        },
                    },
                });
            }

            await queryClient.invalidateQueries({ queryKey: ['categories'] });
        },
        onError: async (error: AxiosError) => {
            console.error('Create category error:', error);
            await queryClient.invalidateQueries({ queryKey: ['categories'] });
        },
    });
};

interface CategoryDataType {
    categoryName: string;
    status: string;
}

export const useUpdateCategory = () => {
    const queryClient = useQueryClient();

    const updateCategoryApiRequest = async (categoryId: string, categoryData: CategoryDataType): Promise<CreateCategoryResponse> => {
        try {
            const response = await apiClient.patch(`/products/update-category/${categoryId}`, categoryData);
            toast.success(response.data.message || 'Category updated successfully');
            return response.data;
        } catch (error) {
            const axiosError = error as AxiosError<{ success: boolean; message: string }>;
            console.error('Update category error:', {
                status: axiosError.response?.status,
                message: axiosError.response?.data?.message || axiosError.message,
            });

            toast.error(
                axiosError.response?.data?.message ||
                'Failed to update category. Please try again.'
            );
            throw error;
        }
    };

    const mutation = useMutation({
        mutationFn: ({ categoryId, categoryData }: { categoryId: string; categoryData: CategoryDataType }) =>
            updateCategoryApiRequest(categoryId, categoryData),
        onMutate: async ({ categoryId, categoryData }) => {
            await queryClient.cancelQueries({ queryKey: ['categories'] });

            const previousCategories = queryClient.getQueryData<CategoryResponse>(['categories']);

            if (previousCategories) {
                queryClient.setQueryData<CategoryResponse>(['categories'], {
                    success: true,
                    data: {
                        categories: previousCategories.data.categories.map(category =>
                            category.categoryId === categoryId
                                ? {
                                    ...category,
                                    categoryName: categoryData.categoryName,
                                    status: categoryData.status,
                                }
                                : category
                        ),
                        pagination: previousCategories.data.pagination,
                    },
                });
            }

            return { previousCategories };
        },
        onError: (err, _, context) => {
            if (context?.previousCategories) {
                queryClient.setQueryData<CategoryResponse>(['categories'], context.previousCategories);
            }
            console.error('Update category error:', err);
        },
        onSettled: () => {
            queryClient.invalidateQueries({
                queryKey: ['categories'],
            });
        },
    });

    return {
        updateCategory: mutation.mutate,
        updateCategoryAsync: mutation.mutateAsync,
        isLoading: mutation.isPending,
        isError: mutation.isError,
        isSuccess: mutation.isSuccess,
        error: mutation.error,
    };
};