import { format } from 'date-fns';

export const formatMessageTime = (timestamp: Date | string): string => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));

    return hours < 24 ? format(date, 'HH:mm') : format(date, 'MMM d, HH:mm');
};

export const createSlug = (name: string): string => {
    return name
        .toLowerCase()
        .replace(/[^a-z0-9\s-]/g, '')
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-')
        .trim();
};

export const createBorrowerUsername = (user: any): string => {
    return user.user_metadata?.username ||
        (user.user_metadata?.name ? createSlug(user.user_metadata.name) :
            user.user_metadata?.full_name ? createSlug(user.user_metadata.full_name) :
                user.email?.split('@')[0] || 'user');
};