export // Cosplay tags from your provided data
    const COSPLAY_TAGS = [
        // Anime & Manga
        "Anime", "Manga", "My Hero Academia", "Attack on Titan", "Naruto", "One Piece", "Demon Slayer",
        "Tokyo Revengers", "Jujutsu Kaisen", "Chainsaw Man", "Sailor Moon", "Dragon Ball", "Genshin Impact",

        // Video Games
        "Video Games", "Final Fantasy", "Overwatch", "League of Legends", "Valorant",
        "Minecraft", "Pokémon", "The Legend of Zelda", "Resident Evil", "The Witcher",

        // Movies & TV
        "Movies", "TV Shows", "Marvel", "Star Wars", "Harry Potter", "Game of Thrones",
        "Stranger Things", "Lord of the Rings", "Disney", "The Mandalorian",

        // Comic Books
        "Comic Books", "Marvel Comics", "DC Comics", "Batman", "Spider-Man", "Avengers", "X-Men",

        // VTubers
        "VTuber", "Hololive", "Nijisanji", "Virtual YouTuber",

        // K-pop/J-pop
        "K-pop", "J-pop", "BTS", "BLACKPINK", "TWICE", "EXO",

        // Styles & Types
        "Traditional", "Original", "Handmade", "Armor", "Weapon Prop", "Wig", "Full Costume",
        "Accessories", "Mask", "Bodysuit", "Magical Girl Outfit", "Mecha", "Fantasy", "Sci-Fi", "Steampunk",

        // Events
        "Convention", "Halloween", "Cosplay Competition", "Photoshoot", "Comicon", "Anime Expo",

        // Materials & Features
        "Premium", "Deluxe", "Limited Edition", "Custom Size", "Prop Included", "Wig Included",
        "Beginner Friendly", "Professional Grade", "Battle Damage", "Authentic",

        // Character Types
        "Hero", "Villain", "Princess", "Warrior", "Mage", "Ninja", "Robot",
        "Monster", "Demon", "Angel", "Ghost", "Vampire", "Werewolf", "Zombie"
    ];
