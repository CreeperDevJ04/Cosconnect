import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'
import { decrypt, encrypt } from '../utils'

export interface AdminUser {
    uid: string
    email: string
    adminName: string
    role: 'admin'
    active: boolean
    phoneNumber: string
    createdAt: string
    updatedAt: string
    lastLogin: string | null
}

interface AuthTokens {
    idToken: string
    customToken: string
}

interface AdminState {
    user: AdminUser | null
    tokens: AuthTokens | null
    isAuthenticated: boolean
}

interface AdminActions {
    setUser: (user: AdminUser | null) => void
    setTokens: (tokens: AuthTokens | null) => void
    updateUser: (userData: Partial<AdminUser>) => void
    logout: () => void
    loadEncryptedData: () => void
}

type AdminStore = AdminState & AdminActions

// Helper function to safely parse JSON
const safeJsonParse = (str: string | null): any => {
    if (!str) return null;
    try {
        return JSON.parse(str);
    } catch (e) {
        console.error('Failed to parse JSON:', e);
        return null;
    }
};

const customStorage = {
    getItem: (name: string): string | null => {
        try {
            const encryptedData = sessionStorage.getItem('admin_encrypted_data');
            if (!encryptedData) return null;
            
            const decrypted = decrypt(encryptedData);
            const parsedData = safeJsonParse(decrypted);
            if (!parsedData) return null;
            
            // Ensure we're returning the correct format
            return JSON.stringify({
                state: {
                    user: parsedData.user || null,
                    tokens: parsedData.tokens || null,
                    isAuthenticated: !!parsedData.user
                }
            });
        } catch (error) {
            console.error('Error retrieving data from storage:', error);
            return null;
        }
    },
    setItem: (name: string, value: string): void => {
        try {
            const parsedValue = JSON.parse(value);
            sessionStorage.setItem(
                'admin_encrypted_data',
                encrypt(JSON.stringify(parsedValue.state))
            );
        } catch (error) {
            console.error('Error setting data to storage:', error);
        }
    },
    removeItem: (name: string): void => {
        sessionStorage.removeItem('admin_encrypted_data');
    },
};

const useAdminStore = create<AdminStore>()(
    persist(
        (set) => ({
            user: null,
            tokens: null,
            isAuthenticated: false,

            setUser: (user: AdminUser | null) =>
                set((state) => ({
                    user,
                    isAuthenticated: !!user,
                    tokens: state.tokens
                })),

            setTokens: (tokens: AuthTokens | null) =>
                set((state) => ({
                    tokens,
                    user: state.user,
                    isAuthenticated: !!state.user
                })),

            updateUser: (userData: Partial<AdminUser>) =>
                set((state) => ({
                    user: state.user ? { ...state.user, ...userData } : null,
                    tokens: state.tokens,
                    isAuthenticated: !!state.user
                })),

            logout: () => {
                sessionStorage.removeItem('admin_encrypted_data');
                sessionStorage.removeItem('admin-auth-storage');
                set({ user: null, tokens: null, isAuthenticated: false });
            },

            loadEncryptedData: () => {
                const encryptedData = sessionStorage.getItem('admin_encrypted_data');
                if (encryptedData) {
                    try {
                        const decryptedData = decrypt(encryptedData);
                        const parsedData = safeJsonParse(decryptedData);
                        if (parsedData) {
                            set({
                                user: parsedData.user || null,
                                tokens: parsedData.tokens || null,
                                isAuthenticated: !!parsedData.user
                            });
                        }
                    } catch (error) {
                        console.error('Error loading encrypted data:', error);
                    }
                }
            }
        }),
        {
            name: 'admin-auth-storage',
            storage: createJSONStorage(() => customStorage),
            skipHydration: false // Changed to false to allow initial hydration
        }
    )
);

export default useAdminStore;