// lib/schemas/auth.ts
import { z } from 'zod';

export const signInSchema = z.object({
    email: z
        .string()
        .min(1, 'Email is required')
        .email('Please enter a valid email address')
        .max(30, 'Email must be at most 30 characters'),
    password: z
        .string()
        .min(1, 'Password is required')
        .min(6, '')
        .max(30, 'Password must be at most 30 characters'),
    rememberMe: z.boolean(),
});

export type SignInFormData = z.infer<typeof signInSchema>;

// Form field configuration for consistency
export const formFields = {
    email: {
        name: 'email' as const,
        type: 'email',
        placeholder: 'admin@company.com',
        label: 'Email Address',
        autoComplete: 'email',
    },
    password: {
        name: 'password' as const,
        type: 'password',
        placeholder: '••••••••',
        label: 'Password',
        autoComplete: 'current-password',
    },
    rememberMe: {
        name: 'rememberMe' as const,
        type: 'checkbox',
        label: 'Remember me for 30 days',
    },
} as const;