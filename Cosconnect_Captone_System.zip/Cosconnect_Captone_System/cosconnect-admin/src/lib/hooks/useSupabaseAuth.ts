"use client"

import type { Session } from "@supabase/supabase-js"
import { useEffect, useState } from "react"
import { createClient } from "../utils/supabase/client"
import { useGetAdminDataById } from "../apis/adminApi"

export interface AdminResponse {
    message: string
    status: "success" | "error"
    statusCode: number
    data: any
}

// Custom hook for Supabase authentication with admin data
export const useSupabaseAuth = () => {
    const [userId, setUserId] = useState<string | null>(null)
    const [session, setSession] = useState<Session | null>(null)
    const [sessionLoading, setSessionLoading] = useState(true)
    const supabase = createClient()

    useEffect(() => {
        let mounted = true

        const getSession = async () => {
            try {
                const {
                    data: { session },
                    error,
                } = await supabase.auth.getSession()
                if (error) throw error
                console.log("session", session)

                if (mounted) {
                    if (session?.user) {
                        setSession(session)
                        setUserId(session.user.id)
                    } else {
                        setSession(null)
                        setUserId(null)
                    }
                }
            } catch (error) {
                console.error("Error getting session:", error)
            } finally {
                if (mounted) setSessionLoading(false)
            }
        }

        getSession()

        // Listen for auth state changes
        const {
            data: { subscription },
        } = supabase.auth.onAuthStateChange(async (_event: string, session: Session | null) => {
            if (mounted) {
                setSession(session)
                if (session?.user) {
                    setUserId(session.user.id)
                } else {
                    setUserId(null)
                }
            }
        })

        return () => {
            mounted = false
            subscription?.unsubscribe()
        }
    }, [supabase.auth])
    console.log("userId", userId)
    // Fetch admin data only when we have a valid userId
    const { data: adminData, isLoading, error, refetch } = useGetAdminDataById(userId, !sessionLoading && !!userId)

    const user = session?.user || null
    const isAuthenticated = !!user

    return {
        adminData: adminData || null,
        adminUid: userId,
        user,
        session,
        isAuthenticated,
        isLoading: sessionLoading || isLoading,
        error,
        refreshAdminData: refetch,
    }
}
