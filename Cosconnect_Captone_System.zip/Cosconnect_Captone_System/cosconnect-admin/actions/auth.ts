"use server"

import { createClient } from '@/lib/utils/supabase/server';
import { revalidatePath } from 'next/cache';
import { headers } from 'next/headers';
import { redirect } from 'next/navigation';

interface SignInData {
    email: string;
    password: string;
}

interface AuthResponse {
    status: "success" | "error";
    message: string;
    user?: any;
    admin?: any;
}

export async function signIn(formData: SignInData) {
    const supabase = await createClient();

    // Sign in with email and password
    const { error, data: authData } = await supabase.auth.signInWithPassword({
        email: formData.email,
        password: formData.password
    });

    if (error) {
        return {
            status: error?.message,
            user: null,
            admin: null
        };
    }

    // Fetch admin data from the admin table
    const { data: adminData, error: adminError } = await supabase
        .from('admin')
        .select('*')
        .eq('email', formData.email)
        .single();

    if (adminError || !adminData) {
        return {
            status: 'Admin not found',
            user: null,
            admin: null
        };
    }

    return {
        status: "success",
        user: authData.user,
        admin: adminData
    };
}

export async function forgotPassword(email: string): Promise<AuthResponse> {
    try {
        const supabase = await createClient();
        const origin = (await headers()).get("origin");

        if (!origin) {
            return {
                status: "error",
                message: "Could not determine origin URL"
            };
        }

        const { error } = await supabase.auth.resetPasswordForEmail(email, {
            redirectTo: `${origin}/reset-password`
        });

        if (error) {
            return {
                status: "error",
                message: error.message
            };
        }

        return {
            status: "success",
            message: "Password reset instructions have been sent to your email"
        };
    } catch (error: any) {
        return {
            status: "error",
            message: error?.message || "An unexpected error occurred"
        };
    }
}

export async function signOut() {
    const supabase = await createClient()

    const { error } = await supabase.auth.signOut();
    console.log("eror", error)
    if (error) {
        redirect("/error")
    }

    revalidatePath("/", "layout")
    redirect("/signin")
}