```
once in the directory inside the terminal run the following in the terminal to run the project:

npm install --force
npm run dev
```

```
open http://localhost:3000 or 3001 if fronend is the first opened
```
